// رندر همه‌ی صفحه‌ها (کد واقعی Next.js با شیم) روی mock API و خروجی HTML ایستا برای پیش‌نمایش.
// نیاز: node_modules (npm i) فقط برای react / react-dom / esbuild. Next لازم نیست.
import { mkdir, writeFile, copyFile, rm, readFile } from 'node:fs/promises';
import { buildAll } from './harness/build.mjs';
import { load, renderPage, runRoute, tokens, titleOf } from './harness/render.mjs';
import { startMock } from '../mock/mock-api.mjs';

const OUT = process.argv[2] || 'preview-out';
const mock = await startMock(5291); process.env.API_URL = 'http://127.0.0.1:5291';
const { bundle, ROOT } = await buildAll(); const B = await load(bundle);
const G = (n) => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const PAGES = [
  ['عمومی', null, [['/', 'خانه'], ['/products', 'طرح‌های اقساطی'], ['/products/[slug]', 'جزئیات طرح', { slug: 'mobile-6' }], ['/calculator', 'ماشین‌حساب (با نتیجه)', {}, { amount: '10000000', months: '6' }], ['/faq', 'سوالات متداول'], ['/about', 'درباره ما'], ['/login', 'ورود'], ['/register', 'ثبت‌نام (مرحله ۱)']]],
  ['مشتری', 'customer', [['/app', 'داشبورد'], ['/app/contracts', 'فهرست قراردادها'], ['/app/contracts/[id]', 'قرارداد منتظر قبول', { id: G(1) }], ['/app/contracts/[id]', 'قرارداد قبول‌شده', { id: G(3) }], ['/app/loans', 'درخواست وام: فهرست'], ['/app/loans/new', 'درخواست وام: انتخاب طرح'], ['/app/loans/new', 'درخواست وام: محاسبه و ثبت', {}, { product: 'mobile-6', amount: '30000000', months: '12', down: '10' }], ['/app/loans/[id]', 'درخواست وام: نیازمند اطلاعات', { id: G(2002) }], ['/app/loans/[id]', 'درخواست وام: ثبت‌شده', { id: G(2001) }], ['/app/credit', 'اعتبارسنجی: فهرست و فرم'], ['/app/credit/[id]', 'اعتبارسنجی: گزارش آماده', { id: G(1901) }], ['/app/credit/[id]', 'اعتبارسنجی: منتظر رمز', { id: G(1902) }], ['/app/documents', 'مدارک و بارگذاری'], ['/app/payments', 'اعلام واریز'], ['/app/cards', 'کارت‌های مجازی'], ['/app/inbox', 'اعلان‌ها'], ['/app/tickets', 'تیکت‌ها'], ['/app/tickets/[id]', 'گفتگوی تیکت', { id: G(301) }], ['/app/security', 'امنیت و 2FA']]],
  ['مدیریت', 'super', [['/admin', 'داشبورد مدیریت'], ['/admin/contracts', 'قراردادها'], ['/admin/contracts/[id]', 'بررسی (در انتظار تأیید)', { id: G(2) }], ['/admin/contracts/[id]', 'بررسی (تأییدشده)', { id: G(4) }], ['/admin/work', 'میز کار کارشناس'], ['/admin/work', 'میز کار: فقط درخواست‌های وام', {}, { q: 'loans' }], ['/admin/statuses', 'راهنمای وضعیت‌ها'], ['/admin/loans', 'درخواست‌های وام (مدیر)'], ['/admin/loans/[id]', 'بررسی درخواست وام', { id: G(2003) }], ['/admin/credit', 'اعتبارسنجی (مدیر)'], ['/admin/credit/[id]', 'جزئیات استعلام', { id: G(1901) }], ['/admin/credit/[id]', 'استعلام ساخت‌ناموفق', { id: G(1903) }], ['/admin/credit/[id]/report', 'محتوای گزارش', { id: G(1901) }], ['/admin/credit/records', 'ریزلاگ سرویس‌دهنده'], ['/admin/documents', 'بررسی مدارک'], ['/admin/documents/[id]', 'بررسی یک مدرک', { id: G(503) }], ['/admin/payments', 'واریزها'], ['/admin/more', 'بیشتر (فهرست بخش‌ها)'], ['/admin/products', 'طرح‌های وام'], ['/admin/products/[id]/contracts', 'قراردادهای یک طرح', { id: G(1100) }], ['/admin/templates', 'قالب‌های قرارداد'], ['/admin/templates/[id]', 'ویرایش قالب (پیش‌نویس)', { id: G(1602) }], ['/admin/templates/[id]', 'قالب منتشرشده', { id: G(1601) }], ['/admin/templates/new', 'قالب جدید'], ['/admin/variables', 'متغیرهای قرارداد'], ['/admin/marketers', 'بازاریاب‌ها'], ['/admin/orders', 'سفارش‌ها'], ['/admin/inquiries', 'استعلام‌ها'], ['/admin/backups', 'پشتیبان‌گیری'], ['/admin/cards', 'کارت‌های مجازی'], ['/admin/counterparties', 'فروشندگان'], ['/admin/audit', 'حسابرسی'], ['/admin/tickets', 'تیکت‌ها'], ['/admin/tickets/[id]', 'پاسخ به تیکت (SLA گذشته)', { id: G(302) }], ['/admin/finance', 'مالی'], ['/admin/jobs', 'صف کارها'], ['/admin/roles', 'نقش‌ها و تخصیص'], ['/admin/roles/[id]', 'ویرایش نقش', { id: G(902) }]]],
];
const urlOf = (r, params = {}, search = {}) => { const p = r.replace(/\[(\w+)\]/g, (_, k) => params[k]); const q = new URLSearchParams(search).toString(); return p + (q ? '?' + q : ''); };
const fileOf = (u) => 'p' + (u.replace(/[^a-z0-9]+/gi, '-').replace(/^-|-$/g, '') || 'home') + '.html';
const map = new Map(); for (const [, , l] of PAGES) for (const [r, , p, s] of l) map.set(urlOf(r, p, s), fileOf(urlOf(r, p, s)));
const bare = new Map(); for (const [u, f] of map) if (!bare.has(u.split('?')[0])) bare.set(u.split('?')[0], f);
const HID = [['/files/me/contracts/[id]', G(1), 'customer', 'html'], ['/files/me/contracts/[id]', G(3), 'customer', 'html'], ['/files/admin/contracts/[id]', G(2), 'super', 'html'], ['/files/admin/contracts/[id]', G(4), 'super', 'html'], ['/files/admin/documents/[id]', G(503), 'super', 'png'], ['/files/admin/templates/[id]/preview', G(1602), 'super', 'html'], ['/files/admin/templates/[id]/preview', G(1601), 'super', 'html']];
for (const [r, id, , ext] of HID) map.set(r.replace('[id]', id), 'f-' + r.split('/').slice(2, 4).join('-') + '-' + id.slice(-4) + '.' + ext);
await rm(OUT, { recursive: true, force: true }); await mkdir(OUT, { recursive: true });
await copyFile(ROOT + '/src/app/globals.css', OUT + '/app.css');
const FONT = '<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;600;800&display=swap" rel="stylesheet">';
let n = 0, bad = 0;
for (const [, who, list] of PAGES) for (const [route, name, params = {}, search = {}] of list) {
  const r = await renderPage(B, route, { params, search, token: who ? tokens[who] : undefined });
  const u = urlOf(route, params, search);
  if (r.status !== 200) { console.error('FAIL', u, r.status, r.redirect || ''); bad++; continue; }
  let h = r.html.replace(/(href|src)="(\/[^"#]*)"/g, (m, a, x) => { const f = map.get(x) || bare.get(x.split('?')[0]); return f ? `${a}="${f}"` : (a === 'href' ? 'href="#"' : m); }).replace(/action="[^"]*"/g, 'action="#"');
  { const B = '<div class="flash good">پیش‌نمایش ایستا از کد واقعی Next.js (دکمه‌ها در این نسخه کار نمی‌کنند)</div>'; h = /<main[^>]*>/.test(h) ? h.replace(/<main[^>]*>/, (m) => m + B) : h; }
  const title = titleOf(B, route) || name;
  await writeFile(`${OUT}/${map.get(u)}`, `<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title} | دیجی‌بایل پی</title><link rel="stylesheet" href="app.css">${FONT}</head><body>${h}</body></html>`); n++;
}
// فایل‌های hidden (iframe قرارداد، تصویر مدرک)
const hid = async (route, params, who, file) => { const res = await runRoute(B, route, params, { token: tokens[who] }); await writeFile(`${OUT}/${file}`, Buffer.from(await res.arrayBuffer())); };
for (const [r, id, who] of HID) await hid(r, { id }, who, map.get(r.replace('[id]', id)));
const idx = `<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>پیش‌نمایش دیجی‌بایل پی</title><link rel="stylesheet" href="app.css">${FONT}</head><body><main class="wrap"><h1>پیش‌نمایش فرانت‌اند Next.js</h1><p class="lead">${n} صفحه، خروجی مستقیم کدِ App Router (با شیم next) روی API ساختگی. تم روشن/تیره از تنظیم دستگاه می‌آید.</p>${PAGES.map(([t, , l]) => `<h2>${t}</h2><div class="grid">${l.map(([r, name, p, s]) => { const u = urlOf(r, p, s); return `<a class="card" href="${map.get(u)}"><strong>${name}</strong><div class="mut ltr">${u.split('?')[0]}</div></a>`; }).join('')}</div>`).join('')}</main></body></html>`;
await writeFile(OUT + '/index.html', idx); console.log('rendered', n, 'failed', bad);
mock.close(); process.exit(bad ? 1 : 0);
