declare module 'react' { export type ReactNode = any; export const createElement: any; export function useState<T>(v: T): [T, (x: T) => void]; }
declare module 'react/jsx-runtime' { export const jsx: any; export const jsxs: any; export const Fragment: any; }
declare module 'next/headers' { export function cookies(): Promise<any>; export function headers(): Promise<any>; }
declare module 'next/navigation' { export function redirect(u: string): never; export function notFound(): never; }
declare module 'next/link' { const L: any; export default L; }
declare module 'next/server' { export const NextResponse: any; export type NextRequest = any; }
declare module 'next' { export type Metadata = any; export type Viewport = any; }
declare namespace JSX { interface IntrinsicElements { [k: string]: any } interface ElementChildrenAttribute { children: {} } }
declare const process: any; declare const Buffer: any;
declare namespace JSX { interface IntrinsicAttributes { key?: any } } declare module "*.css";
