// ساخت یک bundle از همه‌ی صفحه‌ها/لایوت‌ها/روت‌ها/اکشن‌ها با esbuild و شیم‌های next (بدون نصب Next)
import { build } from 'esbuild';
import { readdirSync, statSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
const H = join(ROOT, 'tools/harness'); export const OUT = join(ROOT, 'tools/.build');
const walk = (d) => readdirSync(d).flatMap((f) => { const p = join(d, f); return statSync(p).isDirectory() ? walk(p) : [p]; });
export async function buildAll() {
  const app = join(ROOT, 'src/app'); const files = walk(app);
  const kinds = { pages: [], layouts: [], routes: [] };
  for (const f of files) { const b = f.split('/').pop(); const rel = '/' + relative(app, dirname(f)).replace(/\\/g, '/'); const r = rel === '/.' ? '/' : rel;
    if (/^page\.tsx$/.test(b)) kinds.pages.push([r, f]); else if (/^layout\.tsx$/.test(b)) kinds.layouts.push([r, f]); else if (/^route\.ts$/.test(b)) kinds.routes.push([r, f]); }
  let src = ''; const ent = { pages: {}, layouts: {}, routes: {}, actions: {} }; let i = 0;
  for (const k of Object.keys(kinds)) for (const [r, f] of kinds[k]) { const n = `m${i++}`; src += `import * as ${n} from ${JSON.stringify(f)};\n`; ent[k][r] = n; }
  const acts = readdirSync(join(ROOT, 'src/actions')).filter((f) => f.endsWith('.ts'));
  for (const a of acts) { const n = `a${i++}`; src += `import * as ${n} from ${JSON.stringify(join(ROOT, 'src/actions', a))};\n`; ent.actions[a.replace('.ts', '')] = n; }
  src += `import * as shell from ${JSON.stringify(join(ROOT, 'src/components/Shell.tsx'))};\nimport * as session from ${JSON.stringify(join(ROOT, 'src/lib/session.ts'))};\n`;
  src += 'export const registry = {' + Object.entries(ent).map(([k, v]) => `${k}: {${Object.entries(v).map(([r, n]) => `${JSON.stringify(r)}: ${n}`).join(',')}}`).join(',') + '};\nexport { shell, session };\n';
  mkdirSync(OUT, { recursive: true }); writeFileSync(join(OUT, 'entry.mjs'), src);
  await build({
    entryPoints: [join(OUT, 'entry.mjs')], outfile: join(OUT, 'bundle.mjs'), bundle: true, platform: 'node', format: 'esm', jsx: 'automatic', logLevel: 'warning',
    external: ['react', 'react-dom', 'react/jsx-runtime', 'react-dom/static'], loader: { '.css': 'empty' },
    alias: { '@': join(ROOT, 'src'), 'next/headers': join(H, 'shim-headers.mjs'), 'next/navigation': join(H, 'shim-navigation.mjs'), 'next/link': join(H, 'shim-link.mjs'), 'next/server': join(H, 'shim-server.mjs') },
    define: { 'process.env.NODE_ENV': '"production"' },
  });
  return { ROOT, bundle: join(OUT, 'bundle.mjs'), ent };
}
