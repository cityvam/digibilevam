// شبیه‌ساز next/headers برای آزمون بیرون از Next: وضعیت درخواست در globalThis.__req
const R = () => (globalThis.__req ??= { cookies: new Map(), headers: new Map(), out: [] });
export async function cookies() {
  const r = R();
  return {
    get: (n) => (r.cookies.has(n) ? { name: n, value: r.cookies.get(n) } : undefined),
    getAll: () => [...r.cookies].map(([name, value]) => ({ name, value })),
    has: (n) => r.cookies.has(n),
    set: (n, v, o = {}) => { r.cookies.set(n, String(v)); r.out.push({ op: 'set', n, v: String(v), o }); },
    delete: (n) => { r.cookies.delete(n); r.out.push({ op: 'del', n }); },
  };
}
export async function headers() { const r = R(); return { get: (n) => r.headers.get(n.toLowerCase()) ?? null, has: (n) => r.headers.has(n.toLowerCase()) }; }
