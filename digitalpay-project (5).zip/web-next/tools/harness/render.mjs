import { createElement } from 'react';
import { prerender } from 'react-dom/static';
import { pathToFileURL } from 'node:url';

const siteKey = (r) => '/(site)' + (r === '/' ? '' : r);
const claimsTok = (o) => 'x.' + Buffer.from(JSON.stringify({ exp: Math.floor(Date.now() / 1000) + 3600, ...o })).toString('base64url') + '.y';
export const tokens = { // توکن‌های ساختگی فقط برای شیم؛ اعتبار واقعی را API می‌سنجد
  customer: claimsTok({ sub: 'u1', name: 'مریم احمدی', role: ['Customer'] }),
  admin: claimsTok({ sub: 'u2', name: 'علی رضایی', role: ['Admin'] }),
  super: claimsTok({ sub: 'u3', name: 'مدیر ارشد', role: ['SuperAdmin', 'Admin'] }),
};
export function resetReq({ path = '/', token, cookies = {}, headers = {} } = {}) {
  const c = new Map(Object.entries(cookies)); if (token) c.set('dp_t', token);
  globalThis.__req = { cookies: c, headers: new Map(Object.entries({ 'x-pathname': path, ...headers })), out: [] };
  return globalThis.__req;
}
const text = async (stream) => { const r = stream.getReader(); const d = new TextDecoder(); let s = ''; for (;;) { const { done, value } = await r.read(); if (done) break; s += d.decode(value, { stream: true }); } return s + d.decode(); };
export async function load(bundle) { return import(pathToFileURL(bundle).href + '?v=' + Date.now()); }

/** رندر صفحه با لایوت‌های مسیر (admin/app/site)؛ خروجی { status, html, redirect } */
export async function renderPage(B, route, { params = {}, search = {}, token, cookies, area } = {}) {
  const urlPath = route.replace(/\[(\w+)\]/g, (_, k) => params[k]);
  const req = resetReq({ path: urlPath, token, cookies });
  const page = B.registry.pages[route] || B.registry.pages[siteKey(route)]; if (!page) throw new Error('no page ' + route);
  const a = area || (route.startsWith('/admin') ? 'admin' : route.startsWith('/app') ? 'customer' : 'public');
  const lay = a === 'admin' ? B.registry.layouts['/admin'] : a === 'customer' ? B.registry.layouts['/app'] : B.registry.layouts['/(site)'];
  const el = createElement(lay.default, null, createElement(page.default, { params: Promise.resolve(params), searchParams: Promise.resolve(search) }));
  try {
    const { prelude } = await prerender(el, { onError: (e) => (e?.digest?.startsWith?.('NEXT_') ? e.digest : undefined) }); let html = await text(prelude);
    html = html.replace(/action="javascript:[^"]*"/g, 'action="#"');
    return { status: 200, html, req };
  } catch (e) {
    if (e?.digest === 'NEXT_REDIRECT') return { status: 303, redirect: e.to, req };
    if (e?.digest === 'NEXT_NOT_FOUND') return { status: 404, req };
    throw e;
  }
}
/** اجرای اکشن سرور و گرفتن نتیجه‌ی redirect/کوکی‌ها */
export async function runAction(B, mod, name, args = [], { token, cookies, path = '/' } = {}) {
  const req = resetReq({ token, cookies, path });
  try { await B.registry.actions[mod][name](...args); return { redirect: null, req }; }
  catch (e) { if (e?.digest === 'NEXT_REDIRECT') return { redirect: e.to, req, flash: req.out.filter((o) => o.n === 'dp_f').map((o) => JSON.parse(o.v)).at(-1) }; throw e; }
}
export async function runRoute(B, route, params, { token, cookies } = {}) {
  resetReq({ token, cookies });
  try { return await B.registry.routes[route].GET(new Request('http://x' + route), { params: Promise.resolve(params) }); }
  catch (e) { if (e?.digest === 'NEXT_REDIRECT') return new Response(null, { status: 303, headers: { Location: e.to } }); throw e; }
}

export const titleOf = (B, route) => { const p = B.registry.pages[route] || B.registry.pages[siteKey(route)]; const t = p?.metadata?.title; return typeof t === 'string' ? t : ''; };
