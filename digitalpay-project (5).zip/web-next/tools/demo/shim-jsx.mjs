// اکشن‌های فرم (تابع) را به data-act تبدیل می‌کند تا کلاینت بتواند اجرایشان کند
import * as real from 'real-jsx-runtime';
export const Fragment = real.Fragment;
const wrap = (fn) => (type, props, key) => {
  if (type === 'form' && props && typeof props.action === 'function') { const id = globalThis.__demo.regAction(props.action); const { action, ...rest } = props; props = { ...rest, 'data-act': id }; }
  return fn(type, props, key);
};
export const jsx = wrap(real.jsx); export const jsxs = wrap(real.jsxs);
