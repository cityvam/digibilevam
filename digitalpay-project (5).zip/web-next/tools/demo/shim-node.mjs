export const createServer = () => { throw new Error('no server in browser'); };
export const deflateSync = () => { throw new Error('no zlib in browser'); };
