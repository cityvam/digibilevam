export class NextRequest extends Request { get cookies() { const m = new Map((this.headers.get('cookie') || '').split(';').map((s) => s.trim().split('=')).filter((x) => x[0])); return { get: (n) => (m.has(n) ? { name: n, value: m.get(n) } : undefined) }; } get nextUrl() { return new URL(this.url); } }
export class NextResponse extends Response {
  constructor(body, init) { super(body, init); const self = this; this.cookies = { set: (n, v, o = {}) => self.headers.append('Set-Cookie', `${n}=${encodeURIComponent(v)}; Path=${o.path || '/'}${o.maxAge != null ? '; Max-Age=' + o.maxAge : ''}`), delete: (n) => self.headers.append('Set-Cookie', `${n}=; Path=/; Max-Age=0`) }; }
  static next() { return new NextResponse(null); }
}
