// ساخت دموی زنده: کد واقعی صفحه‌ها/اکشن‌ها داخل مرورگر با API ساختگی. خروجی: یک HTML مستقل.
import { build } from 'esbuild';
import { deflateSync } from 'node:zlib';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import { buildAll } from '../harness/build.mjs';
const T = dirname(fileURLToPath(import.meta.url)); const ROOT = resolve(T, '../..');
await buildAll(); // entry.mjs (registry)
// PNG نمونه‌ی مدرک را در Node می‌سازیم و به مرورگر می‌دهیم
const W = 480, H = 300, raw = Buffer.alloc((W * 3 + 1) * H);
for (let y = 0; y < H; y++) { raw[y * (W * 3 + 1)] = 0; for (let x = 0; x < W; x++) { const o = y * (W * 3 + 1) + 1 + x * 3; const edge = x < 12 || y < 12 || x > W - 13 || y > H - 13; raw[o] = edge ? 60 : 200 - (y >> 2); raw[o + 1] = edge ? 70 : 210 - (x >> 3); raw[o + 2] = edge ? 120 : 235; } }
const crcT = (() => { const t = []; for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc = (b) => { let c = 0xffffffff; for (const x of b) c = crcT[(c ^ x) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
const chunk = (t, d) => { const l = Buffer.alloc(4); l.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]); const c = Buffer.alloc(4); c.writeUInt32BE(crc(td)); return Buffer.concat([l, td, c]); };
const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(W, 0); ihdr.writeUInt32BE(H, 4); ihdr[8] = 8; ihdr[9] = 2;
const png = Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
const OUT = join(ROOT, 'tools/.build'); mkdirSync(OUT, { recursive: true });
const res = await build({
  entryPoints: [join(T, 'runtime.mjs')], bundle: true, write: false, platform: 'browser', format: 'iife', jsx: 'automatic', minify: true, logLevel: 'warning', loader: { '.css': 'empty' }, charset: 'utf8',
  alias: { '@': join(ROOT, 'src'), 'next/headers': join(T, 'shim-headers.mjs'), 'next/navigation': join(T, 'shim-navigation.mjs'), 'next/link': join(T, 'shim-link.mjs'), 'next/server': join(T, 'shim-server.mjs'),
    'node:http': join(T, 'shim-node.mjs'), 'node:zlib': join(T, 'shim-node.mjs'), 'react-dom/static': createRequire(join(ROOT, 'package.json')).resolve('react-dom/static.browser'), 'react/jsx-runtime': join(T, 'shim-jsx.mjs'), 'real-jsx-runtime': createRequire(join(ROOT, 'package.json')).resolve('react/jsx-runtime') },
  define: { 'process.env.API_URL': '"http://mock.local"', 'process.env.COOKIE_SECURE': '"false"', 'process.env.API_HOST_HEADER': 'undefined', 'process.env.NODE_ENV': '"production"', 'globalThis.__DEMO_PNG': 'window.__DEMO_PNG', 'process.argv': '[]' },
});
const js = res.outputFiles[0].text.replace(/<\/script/gi, '<\\/script');
const css = readFileSync(join(ROOT, 'src/app/globals.css'), 'utf8');
const pngJs = `window.__DEMO_PNG=Uint8Array.from(atob("${png.toString('base64')}"),c=>c.charCodeAt(0));`;
writeFileSync(join(OUT, 'demo.js'), pngJs + js);
const html = readFileSync(join(T, 'shell.html'), 'utf8').replace('/*APPCSS*/', () => css).replace('/*PNG*/', () => pngJs).replace('/*APPJS*/', () => js);
writeFileSync(join(OUT, 'demo.html'), html); console.log('demo.html', (html.length / 1024) | 0, 'KB');
