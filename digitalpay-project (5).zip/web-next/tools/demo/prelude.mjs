// Buffer کوچک (فقط from/toString برای utf8 و base64url) برای jwt.ts و mock
const enc = new TextEncoder(), dec = new TextDecoder();
const b64u = (bytes) => btoa(String.fromCharCode(...bytes)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const unb64u = (s) => Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((s.length + 3) % 4)), (c) => c.charCodeAt(0));
class B { constructor(bytes) { this.bytes = bytes; } toString(e = 'utf8') { return e === 'base64url' ? b64u(this.bytes) : dec.decode(this.bytes); } }
globalThis.Buffer = { from: (v, e) => new B(typeof v === 'string' ? (e === 'base64url' ? unb64u(v) : enc.encode(v)) : v) };
