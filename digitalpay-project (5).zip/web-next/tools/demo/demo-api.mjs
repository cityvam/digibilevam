// «سرور» ساختگی داخل مرورگر: mock هم‌شکل با C# + حالت قابل تغییر برای کارهای اصلی
import { handler, DB } from '../../mock/mock-api.mjs';
const G = (n) => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const json = (o, st = 200) => new Response(JSON.stringify(o), { status: st, headers: { 'Content-Type': 'application/json' } });
const iso = (d = 0) => new Date(Date.now() + d * 864e5).toISOString();
let seq = 2000;
const NEXT = { submit: 'ReadyForReview', return: 'Draft', approve: 'Approved', present: 'Presented', 'request-signature': 'AwaitingSignature', cancel: 'Cancelled' };

async function viaMock(method, url, headers, bodyText) {
  const u = new URL(url); let ctype = headers['content-type'] || '';
  const req = { url: u.pathname + u.search, method, headers: { authorization: headers.authorization || '', 'content-type': ctype }, on(ev, cb) { if (ev === 'data' && bodyText) cb(bodyText); if (ev === 'end') cb(); return this; }, resume() {} };
  return new Promise((ok) => { let st = 200, hd = {}; const res = { writeHead(s, h) { st = s; hd = h || {}; }, end(b) { ok(new Response(b ?? '', { status: st, headers: hd })); } }; handler(req, res).catch((e) => ok(json({ message: String(e) }, 500))); });
}
export async function demoFetch(url, init = {}) {
  const u = new URL(url); const p = u.pathname; const m = (init.method || 'GET').toUpperCase(); const h = init.headers || {};
  let body = {}; let text = ''; if (typeof init.body === 'string') { text = init.body; try { body = JSON.parse(text); } catch { /* */ } }
  const hd = Object.fromEntries(Object.entries(h).map(([k, v]) => [k.toLowerCase(), v])); if (init.body && typeof init.body !== 'string') hd['content-type'] = 'multipart/form-data';
  const id = p.split('/')[5], find = (arr, i) => arr.find((x) => x.id === i);
  let mm;
  if (m === 'POST' && (mm = /^\/api\/v1\/me\/contracts\/([^/]+)\/(sign|reject)$/.exec(p))) { const c = find(DB.contracts, mm[1]); if (c) { c.status = mm[2] === 'sign' ? 'Signed' : 'Rejected'; if (mm[2] === 'sign') c.signedAt = iso(); DB.events.push({ at: iso(), action: mm[2] === 'sign' ? 'Signed' : 'Rejected', note: body.note || null, actorId: G(100), ip: '5.202.10.8' }); DB.notes.unshift({ id: G(++seq), kind: 'Contract', title: mm[2] === 'sign' ? 'قرارداد قبول شد' : 'قرارداد رد شد', body: c.number, link: `/app/contracts/${c.id}`, isRead: false, createdOn: iso() }); } return json({}); }
  if (m === 'POST' && (mm = /^\/api\/v1\/admin\/contracts\/([^/]+)\/([a-z-]+)$/.exec(p)) && NEXT[mm[2]]) { const c = find(DB.contracts, mm[1]); if (c) { c.status = NEXT[mm[2]]; if (mm[2] === 'present') { c.presentedAt = iso(); c.userId = G(100); c.expiresAt = iso(7); } DB.events.push({ at: iso(), action: mm[2], note: null, actorId: G(8), ip: '185.10.20.31' }); } return json({}); }
  if (m === 'POST' && p === '/api/v1/me/documents') { const d = { id: G(++seq), kind: 'Other', loanId: null, fileName: 'upload.png', status: 'Pending', reviewNote: null, createdOn: iso() }; DB.docs.unshift(d); return json({ id: d.id, status: 'Pending', ocr: false }); }
  if (m === 'PUT' && (mm = /^\/api\/v1\/admin\/documents\/([^/]+)\/review$/.exec(p))) { const d = find(DB.docs, mm[1]); if (d) { d.status = body.status; d.reviewNote = body.note; } return json({}); }
  if (m === 'POST' && p === '/api/v1/me/payment-declarations') { const d = { id: G(++seq), amount: body.amount, method: body.method, reference: body.reference, paidAt: body.paidAt, status: 'Pending', reviewNote: null, createdOn: iso() }; DB.decls.unshift(d); return json({ id: d.id, status: 'Pending' }); }
  if (m === 'POST' && (mm = /^\/api\/v1\/admin\/payment-declarations\/([^/]+)\/review$/.exec(p))) { const d = find(DB.decls, mm[1]); if (d) { if (body.status === 'Rejected' && !body.note) return json({ message: 'برای رد کردن، دلیل لازم است.' }, 400); d.status = body.status; d.reviewNote = body.note; } return json({ status: body.status }); }
  if (m === 'POST' && p === '/api/v1/me/tickets') { const t = { id: G(++seq), code: 'T-' + (1050 + seq - 2000), subject: body.subject, category: body.category, priority: 'Normal', status: 'Open', userId: G(100), slaDueOn: iso(1), updatedOn: iso(), overdue: false, messages: [{ isStaff: false, isInternal: false, body: body.body, createdOn: iso() }] }; DB.tickets.unshift(t); return json({ id: t.id, code: t.code }); }
  if (m === 'POST' && (mm = /^\/api\/v1\/(me|admin)\/tickets\/([^/]+)\/reply$/.exec(p))) { const t = find(DB.tickets, mm[2]); if (t) { const staff = mm[1] === 'admin'; t.messages.push({ isStaff: staff, isInternal: !!body.internal, body: body.body, createdOn: iso() }); t.status = body.close ? 'Closed' : staff ? (body.internal ? t.status : 'Answered') : 'Open'; t.overdue = false; t.updatedOn = iso(); } return json({}); }
  return viaMock(m, url, hd, text);
}
