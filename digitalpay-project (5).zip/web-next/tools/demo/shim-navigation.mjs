export class Redirect extends Error { constructor(to) { super('NEXT_REDIRECT'); this.digest = 'NEXT_REDIRECT'; this.to = to; } }
export class NotFound extends Error { constructor() { super('NEXT_NOT_FOUND'); this.digest = 'NEXT_NOT_FOUND'; } }
export const redirect = (to) => { throw new Redirect(to); };
export const notFound = () => { throw new NotFound(); };
