import { createElement } from 'react';
export default function Link({ href, children, prefetch, ...p }) { return createElement('a', { href, ...p }, children); }
