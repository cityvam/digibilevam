// next/headers در مرورگر: کوکی‌ها در حافظه (و sessionStorage)، هدرها از وضعیت دمو
const S = () => globalThis.__demo;
export async function cookies() {
  const c = S().cookies;
  return { get: (n) => (c.has(n) ? { name: n, value: c.get(n) } : undefined), has: (n) => c.has(n), getAll: () => [...c].map(([name, value]) => ({ name, value })),
    set: (n, v) => { c.set(n, String(v)); S().persist(); }, delete: (n) => { c.delete(n); S().persist(); } };
}
export async function headers() { return { get: (n) => (n.toLowerCase() === 'x-pathname' ? S().path : null), has: () => false }; }
