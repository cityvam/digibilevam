import './prelude.mjs';
import { createElement } from 'react';
import { prerender } from 'react-dom/static';
import { registry } from '../.build/entry.mjs';
import { demoFetch } from './demo-api.mjs';
import { createRoot } from 'react-dom/client';
import HeroCalc from '@/components/home/HeroCalc';
import HeroSlides from '@/components/home/HeroSlides';
const ISL = { HeroCalc, HeroSlides };
function hydrateIslands(){ document.querySelectorAll('[data-island]').forEach(el => { const C = ISL[el.dataset.island]; if (!C) return; const h = document.createElement('div'); h.style.display = 'contents'; el.replaceWith(h); let pr = {}; try { pr = JSON.parse(el.dataset.props || '{}'); } catch {} createRoot(h).render(createElement(C, pr)); }); }

const API = 'http://mock.local';
const nativeFetch = globalThis.fetch.bind(globalThis);
globalThis.fetch = (u, i) => (String(u).startsWith(API) ? demoFetch(String(u), i) : nativeFetch(u, i));

const store = { get: (k) => { try { return sessionStorage.getItem(k); } catch { return null; } }, set: (k, v) => { try { sessionStorage.setItem(k, v); } catch { /* */ } } };
const D = (globalThis.__demo = { cookies: new Map(JSON.parse(store.get('dp') || '[]')), path: '/', acts: new Map(), n: 0,
  persist() { store.set('dp', JSON.stringify([...D.cookies])); }, regAction(f) { const id = 'a' + ++D.n; D.acts.set(id, f); return id; } });

const claimsTok = (o) => 'x.' + btoa(String.fromCharCode(...new TextEncoder().encode(JSON.stringify({ exp: Math.floor(Date.now() / 1000) + 7200, ...o })))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '') + '.y';
const TOK = { customer: claimsTok({ sub: 'u1', name: 'مریم احمدی', role: ['Customer'] }), admin: claimsTok({ sub: 'u2', name: 'علی رضایی', role: ['Admin'] }), super: claimsTok({ sub: 'u3', name: 'مدیر ارشد', role: ['SuperAdmin', 'Admin'] }) };
const siteKey = (r) => '/(site)' + (r === '/' ? '' : r);
const rx = (key) => new RegExp('^' + key.replace(/\/\(site\)/, '').replace(/\[(\w+)\]/g, '(?<$1>[^/]+)') + '/?$');
const dyn = (k) => (k.match(/\[/g) || []).length;   // مثل Next: مسیر ثابت (/new) بر پویا (/[id]) مقدم است
const pageRoutes = Object.keys(registry.pages).sort((a, b) => dyn(a) - dyn(b)).map((k) => ({ key: k, re: rx(k === '/(site)' ? '/' : k) }));
const fileRoutes = Object.keys(registry.routes).filter((k) => k.startsWith('/files/')).map((k) => ({ key: k, re: rx(k) }));
const match = (list, path) => { for (const r of list) { const m = r.re.exec(path === '' ? '/' : path); if (m) return { key: r.key, params: { ...(m.groups || {}) } }; } return null; };
const text = async (s) => { const r = s.getReader(); const d = new TextDecoder(); let o = ''; for (;;) { const { done, value } = await r.read(); if (done) break; o += d.decode(value, { stream: true }); } return o + d.decode(); };
const root = document.getElementById('app');
let cur = '';

export async function render(url) {
  const u = new URL(url, 'http://x'); let path = u.pathname.replace(/\/+$/, '') || '/'; D.acts.clear(); D.n = 0;
  if (path === '/session-expired') { const had = D.cookies.has('dp_t'); D.cookies.delete('dp_t'); if (had) D.cookies.set('dp_f', JSON.stringify({ t: 'err', m: 'نشست شما منقضی شد؛ دوباره وارد شوید.' })); D.persist(); return render('/login'); }
  if ((path.startsWith('/app') || path.startsWith('/admin')) && !D.cookies.has('dp_t')) return render('/login');
  D.path = path; const m = match(pageRoutes, path); const search = Object.fromEntries(u.searchParams);
  const area = path.startsWith('/admin') ? 'admin' : path.startsWith('/app') ? 'customer' : 'public';
  const lay = area === 'admin' ? registry.layouts['/admin'] : area === 'customer' ? registry.layouts['/app'] : registry.layouts['/(site)'];
  let el;
  if (!m) { el = createElement(registry.layouts['/(site)'].default, null, createElement('div', null, createElement('h1', null, 'صفحه پیدا نشد'), createElement('p', { className: 'lead' }, 'آدرس درست نیست یا حذف شده است.'), createElement('a', { className: 'btn', href: '/' }, 'بازگشت به خانه'))); }
  else el = createElement(lay.default, null, createElement(registry.pages[m.key].default, { params: Promise.resolve(m.params), searchParams: Promise.resolve(search) }));
  try {
    const { prelude } = await prerender(el, { onError: (e) => (e?.digest?.startsWith?.('NEXT_') ? e.digest : undefined) });
    const html = (await text(prelude)).replace(/action="javascript:[^"]*"/g, 'action="#"').replace(/ src="\/files\//g, ' data-src="/files/');
    // شبیه‌سازی middleware: پیام یک‌بارمصرف بعد از نمایش پاک می‌شود
    D.cookies.delete('dp_f'); D.cookies.delete('dp_o'); D.persist();
    return { html, path: path + u.search };
  } catch (e) {
    if (e?.digest === 'NEXT_REDIRECT') return render(e.to);
    if (e?.digest === 'NEXT_NOT_FOUND') return render('/__404');
    throw e;
  }
}
async function fillFiles() {
  for (const el of root.querySelectorAll('iframe[data-src^="/files/"], img[data-src^="/files/"]')) {
    const src = el.getAttribute('data-src'); const m = match(fileRoutes, src); if (!m) continue;
    try { const res = await registry.routes[m.key].GET(new Request('http://x' + src), { params: Promise.resolve(m.params) });
      if (el.tagName === 'IFRAME') el.srcdoc = await res.text();
      else { const b = new Uint8Array(await res.arrayBuffer()); let s = ''; b.forEach((x) => (s += String.fromCharCode(x))); el.src = `data:${res.headers.get('content-type')};base64,${btoa(s)}`; } } catch (e) { if (e?.digest === 'NEXT_REDIRECT') continue; console.error(e); }
  }
}
export async function show(url, { push = true } = {}) {
  root.setAttribute('aria-busy', 'true');
  try { const r = await render(url); root.innerHTML = r.html; cur = r.path; if (push) { history.replaceState(null, '', '#' + r.path); } else if (location.hash.slice(1) !== r.path) history.replaceState(null, '', '#' + r.path); window.scrollTo(0, 0); await fillFiles(); hydrateIslands(); document.dispatchEvent(new CustomEvent('demo:rendered')); }
  catch (e) { console.error(e); root.innerHTML = '<div class="wrap"><h1>خطای دمو</h1><pre class="ltr">' + String(e && (e.stack || e)).replace(/</g, '&lt;') + '</pre></div>'; }
  finally { root.removeAttribute('aria-busy'); }
}
// ---- رویدادها ----
document.addEventListener('click', (ev) => {
  const a = ev.target.closest?.('a[href]'); if (!a || !root.contains(a)) return; const h = a.getAttribute('href');
  if (h.startsWith('/files/')) { ev.preventDefault(); const m = match(fileRoutes, h); if (!m) return; registry.routes[m.key].GET(new Request('http://x' + h), { params: Promise.resolve(m.params) }).then(async (r) => { const b = await r.blob(); const l = document.createElement('a'); l.href = URL.createObjectURL(b); l.download = 'contract-sample.pdf'; l.click(); }); return; }
  if (h.startsWith('/') && !h.startsWith('//')) { ev.preventDefault(); show(h); } else if (h === '#') ev.preventDefault();
});
document.addEventListener('submit', async (ev) => {
  const f = ev.target; if (!root.contains(f)) return; ev.preventDefault();
  const act = f.getAttribute('data-act');
  if (!act) { if ((f.method || 'get').toLowerCase() === 'get') { const q = new URLSearchParams(new FormData(f)); [...q].forEach(([k, v]) => !v && q.delete(k)); show(D.path + (q.toString() ? '?' + q : '')); } return; }
  const fn = D.acts.get(act); if (!fn) return;
  const fd = new FormData(f); if (ev.submitter?.name) fd.set(ev.submitter.name, ev.submitter.value);
  try { await fn(fd); await show(D.path); }
  catch (e) { if (e?.digest === 'NEXT_REDIRECT') await show(e.to); else { console.error(e); alert('خطا: ' + (e && e.message)); } }
});
document.addEventListener('input', (ev) => { const i = ev.target; if (i.matches?.('input[name=amount], input[name=limit]') && i.closest('form')?.hasAttribute('data-act') !== undefined) { const FD = '۰۱۲۳۴۵۶۷۸۹'; i.value = i.value.replace(/[۰-۹]/g, (d) => FD.indexOf(d)).replace(/[^0-9]/g, '').replace(/\B(?=(\d{3})+(?!\d))/g, ','); } });
window.addEventListener('hashchange', () => { const t = location.hash.slice(1) || '/'; if (t !== cur) show(t, { push: false }); });
// ---- کنترل‌های دمو ----
window.demo = {
  login(who) { D.cookies.set('dp_t', TOK[who]); D.cookies.set('dp_f', JSON.stringify({ t: 'ok', m: 'خوش آمدید (ورود سریع دمو).' })); D.persist(); show(who === 'customer' ? '/app' : '/admin'); },
  logout() { D.cookies.clear(); D.persist(); show('/'); },
  reset() { store.set('dp', '[]'); location.reload(); },
};
show(location.hash.slice(1) || '/', { push: false });
