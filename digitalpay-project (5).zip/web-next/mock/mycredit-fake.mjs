// شبیه‌ساز «اعتبارسنجی ایران — MyCreditAPIs v3.2» دقیقاً طبق مستند ICS.IT.MyCredit MNL.V3.2 (فقط برای توسعه/تست؛ نه دقیقاً سرور واقعی).
// ورودی‌های ویژه برای تست: OTP درست «13579» ؛ کد ملی با ارقام پایانی «00» ← ShahkarFailed ؛ کد ملی «0499370899» ← اولین ساخت گزارش ناموفق (بازتولید موفق می‌شود)
import { createServer } from 'node:http';
import { randomBytes } from 'node:crypto';

const ok = (data) => ({ data, hasError: false, messages: [] });
const bad = (reason, message = reason, field = null) => ({ data: null, hasError: true, messages: [{ field, reason, message }] });
export const NC_OK = (v) => { if (!/^\d{10}$/.test(v) || /^(\d)\1{9}$/.test(v)) return false; let s = 0; for (let i = 0; i < 9; i++) s += +v[i] * (10 - i); const r = s % 11, c = +v[9]; return r < 2 ? c === r : c === 11 - r; };
const WAITS = [120, 180, 270, 270, 270];

export function createFake(opt = {}) {
  const speed = opt.speed ?? 1;                       // ضریب فشرده‌سازی زمان (مثلاً 0.01 ← ۱۰۰ برابر سریع‌تر)
  const S = { user: opt.username || 'demo', pass: opt.password || 'demo-pass', apiKey: opt.apiKey || 'KEY-' + randomBytes(6).toString('hex'), tokens: new Map(), reqs: new Map(), reports: new Map(), calls: [], callback: opt.callback || null, tokenTtlMs: opt.tokenTtlMs ?? 12 * 3600e3, genMs: opt.genMs ?? 1500, pdf: null };
  const now = () => Date.now();
  const note = (m, p, extra) => S.calls.push({ m, p, at: now(), ...extra });
  const fire = (event, r, tail = '') => { if (!S.callback) return; const msg = `${event}-${r.hash}${tail}`; fetch(`${S.callback}${S.callback.includes('?') ? '&' : '?'}message=${encodeURIComponent(msg)}`).catch(() => {}); };

  function advance(r) {                                // پیشبرد وضعیت بر اساس زمان
    if (r.status === 'InQueue' && now() >= r.readyAt) {
      if (r.failFirst && r.gens === 1) { r.status = 'ReportGenerationFailed'; fire('GenerateReportFailed', r); }
      else { r.status = 'ReportGenerated'; r.reportCode = 'RC' + randomBytes(9).toString('hex'); r.reportAt = now(); S.reports.set(r.reportCode, r); fire('ReportGenerated', r, `@${S.base}/report/${r.reportCode}&hashCode=${r.hash}&reportLink=${S.base}/report/${r.reportCode}`); }
    }
  }
  const title = { Entry: 'ثبت درخواست', OTPSent: 'ارسال توکن', OTPAccepted: 'توکن پذیرفته شد.', InQueue: 'در صف پردازش', ReportGenerated: 'ساخت گزارش', ReportGenerationFailed: 'دریافت گزارش با خطا مواجه شد', OTPLocked: 'قفل دریافت مجدد توکن', ShahkarFailed: 'عدم احراز هویت', OTPResend: 'ارسال مجدد توکن' };

  const handler = async (req, res) => {
    const url = new URL(req.url, 'http://x'); const p = url.pathname.replace(/\/+$/, ''); const m = req.method;
    const chunks = []; for await (const c of req) chunks.push(c); const raw = Buffer.concat(chunks).toString();
    const form = Object.fromEntries(new URLSearchParams(raw)); const send = (code, o, ct = 'application/json') => { res.writeHead(code, { 'content-type': ct }); res.end(typeof o === 'string' || Buffer.isBuffer(o) ? o : JSON.stringify(o)); };
    note(m, p, { ct: req.headers['content-type'] || '', hasKey: !!req.headers['x-apikey'], ver: req.headers['x-version'] || null });
    const needForm = ['POST', 'PUT'].includes(m) && raw && !(req.headers['content-type'] || '').includes('x-www-form-urlencoded');
    if (needForm) return send(415, bad('BadInput', 'Content-Type must be application/x-www-form-urlencoded'));

    // ---- ۱) و ۲) توکن ----
    if (p === '/Connect/Token' && m === 'POST') {
      if (form.username !== S.user || form.password !== S.pass) return send(400, bad('BadInput', 'نام کاربری یا رمز عبور اشتباه است', 'Password'));
      const t = { access: 'AT' + randomBytes(12).toString('hex'), refresh: 'RT' + randomBytes(12).toString('hex'), exp: now() + S.tokenTtlMs, rexp: now() + 24 * 3600e3 };
      S.tokens.set(t.access, t); return send(200, ok({ accessToken: t.access, refreshToken: t.refresh, apiKey: S.apiKey, tokenExpires: new Date(t.exp).toISOString() }));
    }
    const bearer = (req.headers.authorization || '').replace(/^Bearer /i, '');
    if (p === '/Connect/Token' && m === 'PUT') {
      const old = [...S.tokens.values()].find((t) => t.refresh === form.refreshToken && t.access === form.accessToken);
      if (!old || now() > old.rexp) return send(400, bad('BadInput', 'Invalid Request', 'AccessToken/RefreshToken'));
      const t = { access: 'AT' + randomBytes(12).toString('hex'), refresh: old.refresh, exp: now() + S.tokenTtlMs, rexp: old.rexp }; S.tokens.set(t.access, t); S.tokens.delete(old.access);
      return send(200, ok({ accessToken: t.access, refreshToken: t.refresh }));
    }
    // ---- احراز هویت سایر سرویس‌ها ----
    const tk = S.tokens.get(bearer); if (!tk || now() > tk.exp) return send(401, { message: 'Unauthorized' });
    const key = req.headers['x-apikey'] || url.searchParams.get('apikey') || url.searchParams.get('ApiKey');
    if (!key) return send(400, bad('APIKeyNotExists', 'apikey وجود ندارد.', 'apikey')); if (key !== S.apiKey) return send(400, bad('IncorrectAPIKey', 'apikey را به درستی وارد کنید.', 'apikey'));

    // ---- ۳) ارسال درخواست ----
    if (p === '/b2b/api/request' && m === 'POST') {
      const nc = form.RealPersonNationalCode, mob = form.MobileNumber, leg = form.LegalPersonNationalCode;
      if (!nc) return send(400, bad('BadInput', 'شماره ملی الزامی است.', 'RealPersonNationalCode')); if (!mob) return send(400, bad('BadInput', 'شماره موبایل الزامی است.', 'MobileNumber'));
      if (!NC_OK(nc)) return send(400, bad('BadInput', 'شماره ملی شخص نامعتبر است.', 'RealPersonNationalCode')); if (!/^09\d{9}$/.test(mob)) return send(400, bad('BadInput', 'شماره موبایل نامعتبر است.', 'MobileNumber'));
      if (leg && !/^\d{11}$/.test(leg)) return send(400, bad('BadInput', 'شناسه ملی شرکت نامعتبر است.', 'LegalPersonNationalCode'));
      const h = 'H' + randomBytes(10).toString('hex'); S.reqs.set(h, { hash: h, nc, mob, leg, status: 'OTPSent', created: now(), sends: 1, nextAt: now() + 120e3 * speed, tries: 0, gens: 0, failFirst: nc === '0499370899', otp: '13579', msgs: [] });
      return send(200, ok(h));
    }
    const mm = p.match(/^\/b2b\/api\/request\/([^/]+)\/(renewToken|validate|status|reGenerateReport)$/);
    if (mm) {
      const r = S.reqs.get(decodeURIComponent(mm[1])), op = mm[2];
      if (!r) return send(400, bad('BadInput', 'درخواستی با این مشخصات یافت نشد.', 'Code'));
      if (now() - r.created > 24 * 3600e3 * Math.max(speed, 0.0001) && speed >= 1) return send(400, bad('RequestExpired', 'تاریخ اعتبار این درخواست به اتمام رسیده است.', 'Code'));
      advance(r);
      if (op === 'status' && m === 'GET') return send(200, ok({ statusTitle: title[r.status] || r.status, status: r.status, reportLink: r.reportCode ? `${S.base}/report/${r.reportCode}` : null, otpMessageStatusTitle: 'رسیده به گوشی', otpMessageStatus: 5, reportTryCount: r.gens, reportCode: null }));
      if (op === 'renewToken' && m === 'POST') {
        if (r.status === 'OTPLocked' || r.sends >= 5) return send(400, bad('ResendLocked', 'درخواست شما تا 24 ساعت دارای اعتبار است لطفاً با پشتیبانی به شماره 41522222 تماس بگیرید.'));
        if (now() < r.nextAt) return send(400, bad('ResendWait', 'برای این درخواست امکان دریافت توکن جدید وجود ندارد. لطفاً چند لحظه دیگر تلاش کنید.'));
        r.sends++; const w = WAITS[Math.min(r.sends - 1, 4)]; r.nextAt = now() + w * 1000 * speed; r.status = 'OTPResend';
        return send(200, ok({ resendWait: w, resendLocked: r.sends >= 5 }));
      }
      if (op === 'validate' && m === 'POST') {
        if (!form.Token) return send(400, bad('BadInput', 'توکن را به درستی وارد کنید.', 'Token'));
        if (['InQueue', 'ReportGenerated'].includes(r.status)) return send(400, bad('InProccessing', 'درخواست شما در حال پردازش است.'));
        if (r.status === 'OTPLocked') return send(400, bad('OtpLocked', 'درخواست لاک شده است.', 'Token'));
        if (form.Token !== r.otp) { r.tries++; if (r.tries >= 5) { r.status = 'OTPLocked'; fire('OTPLocked', r); return send(400, bad('OtpLocked', 'درخواست لاک شده است.', 'Token')); } return send(400, bad('IncorrectToken', 'رمز وارد شده صحیح نیست.', 'Token')); }
        fire('OTPAccepted', r);
        if (r.mob.endsWith('00')) { r.status = 'ShahkarFailed'; fire('ShahkarFailed', r); return send(400, bad('ShahkarFailed', 'شماره ملی و شماره همراه با هم تطابق ندارند.')); }
        r.status = 'InQueue'; r.gens = 1; r.readyAt = now() + S.genMs * speed; return send(200, ok('Accepted'));
      }
      if (op === 'reGenerateReport' && m === 'POST') {
        if (!['ReportGenerationFailed', 'ReportGeneratedButDataLost'].includes(r.status)) return send(400, bad('InProccessingOrSucceed', 'درخواست مجدد گزارش برای این درخواست امکان‌پذیر نیست.'));
        r.status = 'InQueue'; r.gens++; r.readyAt = now() + S.genMs * speed; return send(200, ok('Accepted'));
      }
      return send(405, bad('BadInput', 'method'));
    }
    // ---- ۹) گزارش JSON ----
    const rm = p.match(/^\/Report\/([^/]+)\/(json|xml)$/i);
    if (rm && m === 'GET') {
      const r = S.reports.get(decodeURIComponent(rm[1])); if (!r) return send(400, bad('BadInput', 'کد گزارش اشتباه است.', 'Code'));
      if (rm[2].toLowerCase() !== 'json') return send(400, bad('OutputTypeNotSupported', 'نوع خروجی نامعتبر است.'));
      if (now() - r.reportAt > 48 * 3600e3) return send(400, bad('ReportExpired', 'زمان دریافت گزارش به اتمام رسیده است.'));
      return send(200, ok(report(r)));
    }
    // ---- ۱۰) PDF ----
    const pm = p.match(/^\/(?:b2b\/api\/request|report)\/([^/]+)\/pdfReport$/i);
    if (pm && m === 'GET') { const r = S.reports.get(decodeURIComponent(pm[1])); if (!r) return send(400, bad('BadInput', 'کد گزارش نامعتبر است', 'Code')); return send(200, S.pdf || PDF, 'application/pdf'); }
    // ---- ۱۱) ریزلاگ ----
    if (p === '/Record/requests' && m === 'GET') {
      const page = +(url.searchParams.get('page') || 1), size = Math.min(10000, +(url.searchParams.get('size') || 100)), sort = url.searchParams.get('sort') === '-1' ? -1 : 1;
      const all = [...S.reqs.values()].sort((a, b) => (a.created - b.created) * sort); const items = all.slice((page - 1) * size, page * size).map((r) => ({ hashCode: r.hash.slice(0, 3) + '******', status: { detail: r.status, detailFa: title[r.status] || r.status }, mobile: r.mob.slice(0, 4) + '*****' + r.mob.slice(-2), realNationalCode: r.nc.slice(0, 4) + '******', legalNationalCode: r.leg ? r.leg.slice(0, 4) + '*******' : null, requestTime: new Date(r.created).toISOString() }));
      return send(200, { data: { items }, hasError: false, messages: [], meta: { page, size, totalPages: Math.ceil(all.length / size) || 1, totalCount: all.length, hasPreviousPage: page > 1, hasNextPage: page * size < all.length, fromDate: url.searchParams.get('fromDate'), toDate: url.searchParams.get('toDate'), order: sort === 1 ? 'asc' : 'desc' } });
    }
    send(404, bad('BadInput', 'not found'));
  };
  function report(r) { return { person: { nationalCode: r.nc.slice(0, 4) + '******', name: 'نمونه‌ی آزمایشی' }, creditScore: 742, riskGrade: 'B+', summary: { activeLoans: 2, totalDebt: 184000000, overdueCount: 0, bouncedChecks: 0 }, facilities: [{ bank: 'بانک نمونه', amount: 120000000, remaining: 84000000, status: 'جاری' }, { bank: 'بانک نمونه ۲', amount: 200000000, remaining: 100000000, status: 'جاری' }], generatedAt: new Date(r.reportAt).toISOString() }; }
  const PDF = Buffer.from('%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 200 100]>>endobj\ntrailer<</Root 1 0 R>>\n%%EOF');
  return { S, handler, start: (port = 5391) => new Promise((r) => { const sv = createServer((a, b) => handler(a, b).catch((e) => { b.writeHead(500); b.end(String(e)); })); sv.listen(port, '127.0.0.1', () => { S.base = `http://127.0.0.1:${sv.address().port}`; r({ server: sv, base: S.base, S, close: () => sv.close() }); }); }) };
}
if (process.argv[1]?.endsWith('mycredit-fake.mjs')) { const f = createFake({ speed: +(process.env.SPEED || 0.02), username: process.env.U, password: process.env.P, apiKey: process.env.K, callback: process.env.CALLBACK }); f.start(+(process.env.PORT || 5391)).then((x) => console.log('fake MyCredit on', x.base, 'user=', f.S.user, 'pass=', f.S.pass)); }
