// شبیه‌ساز مسیرهای درخواست وام (هم‌شکل با LoanAppControllers.cs) برای پیش‌نمایش و تست فرانت.
const G = (n) => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const FA = { Submitted: 'ثبت‌شده', InReview: 'در حال بررسی', NeedInfo: 'نیازمند اطلاعات بیشتر', Approved: 'تأیید شد', Rejected: 'رد شد', Cancelled: 'لغو شد' };
const NEXT = { Submitted: ['InReview', 'NeedInfo', 'Approved', 'Rejected'], InReview: ['NeedInfo', 'Approved', 'Rejected'], NeedInfo: ['InReview', 'Approved', 'Rejected'] };
const LIM = { minAmount: 1000000, maxAmount: 500000000, minMonths: 3, maxMonths: 60, maxDownPercent: 70, feePerMonthPercent: 0.6, maxOpen: 3 };
const t = (ms) => new Date(Date.now() + ms).toISOString();
// همان فرمول ContractEngine.Calc (نیم‌ریال به بالا)
const R = (x) => Math.floor(x + 0.5);
export const calcLoan = (amount, downPct, feePct, months) => { const down = R(amount * downPct / 100), fin = amount - down, fee = R(fin * feePct / 100), total = fin + fee, each = Math.ceil(total / months); return { down, fin, fee, total, each, last: total - each * (months - 1) }; };
const mk = (n, user, status, o = {}) => { const amount = o.amount ?? 30000000, months = o.months ?? 12, downPercent = o.downPercent ?? 10, feePercent = Math.round(0.6 * months * 100) / 100, c = calcLoan(amount, downPercent, feePercent, months);
  return { id: G(2000 + n), userId: user, code: 'L-' + (800000 + n * 211).toString(36).toUpperCase().slice(0, 6), productKey: 'mobile-6', productName: 'وام موبایل و لپ‌تاپ', amount, downPercent, months, feePercent, down: c.down, financed: c.fin, fee: c.fee, total: c.total, each: c.each, last: c.last, status, customerNote: '', reviewNote: '', reviewedOn: null, creditRequestId: null, creditScore: null, createdOn: t(-3600e3 * 5 * n), updatedOn: t(-1800e3 * n), events: [], ...o }; };
const S = { apps: [
  mk(1, G(100), 'Submitted', { events: [['', 'Submitted', 'ثبت درخواست', false]] }),
  mk(2, G(100), 'NeedInfo', { amount: 18000000, months: 6, reviewNote: 'لطفاً تصویر فیش حقوقی سه‌ماه اخیر را در بخش مدارک بارگذاری کنید.', events: [['', 'Submitted', 'ثبت درخواست', false], ['Submitted', 'NeedInfo', 'لطفاً تصویر فیش حقوقی سه‌ماه اخیر را در بخش مدارک بارگذاری کنید.', true]] }),
  mk(3, G(101), 'InReview', { amount: 50000000, months: 24, creditRequestId: G(1901), creditScore: 742, events: [['', 'Submitted', 'ثبت درخواست', false], ['Submitted', 'InReview', '', true]] }),
  mk(4, G(102), 'Approved', { amount: 12000000, months: 6, reviewNote: 'تأیید شد؛ قرارداد به‌زودی ارائه می‌شود.', events: [['', 'Submitted', 'ثبت درخواست', false], ['Submitted', 'Approved', 'تأیید شد؛ قرارداد به‌زودی ارائه می‌شود.', true]] }),
] };
const view = (a) => ({ id: a.id, code: a.code, productKey: a.productKey, productName: a.productName, amount: a.amount, downPercent: a.downPercent, months: a.months, feePercent: a.feePercent, down: a.down, financed: a.financed, fee: a.fee, total: a.total, each: a.each, last: a.last, status: a.status, statusTitle: FA[a.status], open: !!NEXT[a.status], canCancel: !!NEXT[a.status], customerNote: a.customerNote, reviewNote: a.reviewNote, reviewedOn: a.reviewedOn, creditRequestId: a.creditRequestId, creditScore: a.creditScore, createdOn: a.createdOn, updatedOn: a.updatedOn });
const evs = (a, staffId) => a.events.map(([f, to, note, staff], i) => ({ fromStatus: f, toStatus: to, note, createdOn: t(-3600e3 * (a.events.length - i)), byStaff: staff, actorId: staff ? staffId : a.userId }));
const bad = (m) => ({ code: 400, data: { message: m } });
export function loanRoutes(p, m, u, b, { admin, userId = G(100) }) {
  const me = p.startsWith('/api/v1/me/loan-applications'), ad = p.startsWith('/api/v1/admin/loan-applications'); if (!me && !ad) return null;
  if (ad && !admin) return { code: 403, data: { message: 'دسترسی ندارید' } };
  const seg = p.replace(/^\/api\/v1\/(me|admin)\/loan-applications/, '').split('/').filter(Boolean); const id = seg[0] && /^[0-9a-f-]{36}$/.test(seg[0]) ? seg[0] : null; const act = id ? seg[1] : seg[0];
  if (me && m === 'GET' && act === 'limits') return { code: 200, data: LIM };
  if (seg[0] && !id && act !== 'limits') return { code: 404, data: { message: 'پیدا نشد' } };
  if (me && m === 'GET' && !id) return { code: 200, data: S.apps.filter((a) => a.userId === userId).sort((a, b2) => b2.createdOn.localeCompare(a.createdOn)).map(view) };
  if (ad && m === 'GET' && !id) { let xs = S.apps.slice(); const st = u.searchParams.get('status'), q = u.searchParams.get('q'); if (st) xs = xs.filter((a) => a.status === st); if (q) xs = xs.filter((a) => a.code.includes(q) || a.productName.includes(q)); return { code: 200, data: { total: xs.length, page: 1, items: xs.map((a) => ({ v: view(a), userId: a.userId })) } }; }
  if (me && m === 'POST' && !id) {
    const amount = Number(b.amount), down = Number(b.downPercent), months = Number(b.months);
    if (!b.productKey) return bad('طرح انتخاب‌شده نامعتبر است.'); if (!(amount >= LIM.minAmount && amount <= LIM.maxAmount)) return bad('مبلغ باید بین ۱٬۰۰۰٬۰۰۰ و ۵۰۰٬۰۰۰٬۰۰۰ تومان باشد.'); if (!(months >= LIM.minMonths && months <= LIM.maxMonths)) return bad('مدت باید بین ۳ و ۶۰ ماه باشد.'); if (!(down >= 0 && down <= LIM.maxDownPercent)) return bad('پیش‌پرداخت باید بین ۰ و ۷۰ درصد باشد.');
    if (S.apps.filter((a) => a.userId === userId && NEXT[a.status]).length >= LIM.maxOpen) return bad('شما همزمان حداکثر ۳ درخواست باز می‌توانید داشته باشید.');
    const a = mk(50 + S.apps.length, userId, 'Submitted', { amount, months, downPercent: down, productKey: String(b.productKey), productName: String(b.productName || 'طرح'), customerNote: String(b.note || ''), createdOn: t(0), updatedOn: t(0), events: [['', 'Submitted', 'ثبت درخواست', false]] });
    if (b.attachCredit) { a.creditRequestId = G(1901); a.creditScore = 742; } S.apps.push(a); return { code: 200, data: { application: view(a) } };
  }
  const a = S.apps.find((x) => x.id === id && (ad || x.userId === userId)); if (id && !a) return { code: 404, data: { message: 'پیدا نشد' } };
  if (m === 'GET' && !act) return me ? { code: 200, data: { application: view(a), events: evs(a, G(9)) } } : { code: 200, data: { application: view(a), userId: a.userId, events: evs(a, G(9)), credit: a.creditRequestId ? { id: a.creditRequestId, code: 'C-F089', status: 'ReportGenerated', statusTitle: 'گزارش آماده است', score: a.creditScore, reportAt: t(-3600e3) } : null, priorApplications: S.apps.filter((x) => x.userId === a.userId && x.id !== a.id).length, next: NEXT[a.status] || [] } };
  if (me && act === 'cancel') { if (!NEXT[a.status]) return bad('این درخواست دیگر قابل لغو نیست.'); a.events.push([a.status, 'Cancelled', 'لغو توسط مشتری', false]); a.status = 'Cancelled'; return { code: 200, data: { application: view(a) } }; }
  if (ad && act === 'review') { const to = String(b.status || ''), note = String(b.note || '').trim(); if (!(NEXT[a.status] || []).includes(to)) return bad('این تغییر وضعیت برای درخواست مجاز نیست.'); if ((to === 'Rejected' || to === 'NeedInfo') && note.length < 3) return bad('برای رد یا درخواست اطلاعات، توضیح برای مشتری لازم است.'); a.events.push([a.status, to, note, true]); a.status = to; a.reviewNote = note; a.reviewedOn = t(0); return { code: 200, data: { application: view(a) } }; }
  return { code: 404, data: { message: 'پیدا نشد' } };
}
