"""تست پروتکل: کلاینت پایتونی (هم‌منطق با کلاینت C#) در برابر شبیه‌ساز مستند. اجرا: python3 test/mycredit_protocol.py"""
import subprocess, sys, os, time, json, importlib.util
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location('probe', os.path.join(ROOT, '..', 'tools', 'mycredit_probe.py')); probe = importlib.util.module_from_spec(spec); spec.loader.exec_module(probe)
env = dict(os.environ, PORT='5392', SPEED='0.01', U='u1', P='p1', K='K-test')
srv = subprocess.Popen(['node', os.path.join(ROOT, 'mock', 'mycredit-fake.mjs')], env=env, stdout=subprocess.PIPE, text=True); srv.stdout.readline()
fails = []
def check(name, cond, info=''):
    print(('PASS ' if cond else 'FAIL ') + name + (' — ' + str(info) if not cond else '')); (cond or fails.append(name))
try:
    base = 'http://127.0.0.1:5392'
    bad = probe.MyCredit(base, 'u1', 'wrong'); r = bad.login(); check('wrong password → BadInput', not r['ok'] and r['reason'] == 'BadInput')
    c = probe.MyCredit(base, 'u1', 'p1'); r = c.login(); check('login ok + apiKey from response', r['ok'] and c.key == 'K-test' and c.access)
    r = c.request('0012345679', '09121234567'); check('request ok → data is hash', r['ok'] and isinstance(r['data'], str), r)
    r2 = c.request('1234567890', '09121234567'); check('bad national code → BadInput', not r2['ok'] and r2['reason'] == 'BadInput')
    r3 = c.request('0012345679', '9121234567'); check('bad mobile → BadInput', not r3['ok'] and r3['reason'] == 'BadInput')
    h = r['data']
    w = c.renew(h); check('renew too early → ResendWait', not w['ok'] and w['reason'] == 'ResendWait')
    time.sleep(1.3); w = c.renew(h); check('renew after wait ok with resendWait=180', w['ok'] and w['data']['resendWait'] == 180 and w['data']['resendLocked'] is False, w)
    v = c.validate(h, '00000'); check('wrong otp → IncorrectToken', not v['ok'] and v['reason'] == 'IncorrectToken')
    v = c.validate(h, '13579'); check('right otp accepted', v['ok'], v)
    st, code = probe.wait_report(c, h, 20, 0.2); check('report generated + code in link', st == 'ReportGenerated' and code and code.startswith('RC'), (st, code))
    rep = c.report(code); check('report json v2 has score', rep['ok'] and rep['data']['creditScore'] == 742, rep)
    pdf = c.pdf(code); check('pdf bytes %PDF', pdf['ok'] and pdf['bytes'][:4] == b'%PDF')
    v = c.validate(h, '13579'); check('double validate → InProccessing', not v['ok'] and v['reason'] == 'InProccessing')
    # شکست و بازتولید
    r = c.request('0499370899', '09121234567'); h2 = r['data']; c.validate(h2, '13579'); st, _ = probe.wait_report(c, h2, 20, 0.2); check('first generation fails for fixture', st == 'ReportGenerationFailed', st)
    g = c.regen(h2); check('regenerate accepted', g['ok'], g); st, code2 = probe.wait_report(c, h2, 20, 0.2); check('regenerated report ready', st == 'ReportGenerated' and code2, st)
    g = c.regen(h2); check('regenerate on success → InProccessingOrSucceed', not g['ok'] and g['reason'] == 'InProccessingOrSucceed')
    # شاهکار
    r = c.request('0012345679', '09120000000'); h3 = r['data']; v = c.validate(h3, '13579'); check('mismatching mobile → ShahkarFailed', not v['ok'] and v['reason'] == 'ShahkarFailed')
    # قفل شدن رمز
    r = c.request('0012345679', '09121111111'); h4 = r['data']; last = None
    for _ in range(5): last = c.validate(h4, '11111')
    check('5 wrong otps → OtpLocked', not last['ok'] and last['reason'] == 'OtpLocked', last)
    # ریزلاگ
    rec = c.records(None, None, -1, 1, 2); check('records paged with meta', rec['ok'] and len(rec['data']['items']) == 2 and rec['json']['meta']['totalCount'] >= 4, rec)
    check('records masks values', '*' in rec['data']['items'][0]['mobile'])
    # انقضای توکن ← تازه‌سازی خودکار روی ۴۰۱
    c.access = 'garbage'; c.exp = time.time() + 999; s = c.status(h); check('401 → auto re-login and retry', s['ok'], s)
    # apikey اشتباه
    k = probe.MyCredit(base, 'u1', 'p1', 'WRONG'); k.login(); k.key = 'WRONG'; s = k.status(h); check('wrong apikey → IncorrectAPIKey', not s['ok'] and s['reason'] == 'IncorrectAPIKey', s)
finally:
    srv.terminate()
print('\n%d failed' % len(fails)); sys.exit(1 if fails else 0)
