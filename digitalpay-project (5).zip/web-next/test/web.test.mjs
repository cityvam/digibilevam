import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startMock } from '../mock/mock-api.mjs';
import { buildAll } from '../tools/harness/build.mjs';
import { load, renderPage, runAction, runRoute, tokens, resetReq } from '../tools/harness/render.mjs';

const G = (n) => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
let mock, B;
before(async () => { mock = await startMock(5292); process.env.API_URL = 'http://127.0.0.1:5292'; const b = await buildAll(); B = await load(b.bundle); });
after(() => mock.close());
const fd = (o) => { const f = new FormData(); for (const [k, v] of Object.entries(o)) f.set(k, v); return f; };
const cookieOut = (r, n) => r.req.out.filter((o) => o.op === 'set' && o.n === n).at(-1);

test('صفحه‌های عمومی و مشتری و ادمین رندر می‌شوند و متن «undefined» ندارند', async () => {
  const cases = [['/', {}, null], ['/products', {}, null], ['/calculator', { amount: '10000000', months: '6' }, null], ['/app', {}, 'customer'], ['/app/contracts', {}, 'customer'], ['/admin', {}, 'super'], ['/admin/templates', {}, 'super'], ['/admin/roles', {}, 'super'], ['/admin/finance', {}, 'super']];
  for (const [route, search, who] of cases) {
    const r = await renderPage(B, route, { search, token: who ? tokens[who] : undefined });
    assert.equal(r.status, 200, route); assert.ok(r.html.length > 500, route); assert.ok(!/undefined|\[object/.test(r.html), route + ' has undefined');
  }
});
test('ماشین‌حساب: قسط‌ها با فرمول قرارداد می‌خواند', async () => {
  const r = await renderPage(B, '/calculator', { search: { amount: '10000000', down: '20', fee: '12', months: '6' } });
  assert.match(r.html, /۱,۴۹۳,۳۳۴/); assert.match(r.html, /۱,۴۹۳,۳۳۰/); // each = ceil(8,960,000/6)، آخر = باقی‌مانده
});
test('ادمین: بدون نشست → session-expired، مشتری → /app', async () => {
  assert.equal((await renderPage(B, '/admin', {})).redirect, '/session-expired');
  assert.equal((await renderPage(B, '/admin', { token: tokens.customer })).redirect, '/app');
  assert.equal((await renderPage(B, '/app', {})).redirect, '/session-expired');
});
test('ورود با ۲FA: ticket در کوکی کوتاه‌عمر؛ بعد توکن HttpOnly', async () => {
  let r = await runAction(B, 'auth', 'login', [fd({ username: '09120000000', password: 'x', captchaId: 'c1', captcha: '4827' })]);
  assert.equal(r.redirect, '/login'); assert.equal(cookieOut(r, 'dp_2fa').v, 't1'); assert.equal(cookieOut(r, 'dp_2fa').o.httpOnly, true);
  r = await runAction(B, 'auth', 'login2fa', [fd({ code: '123456' })], { cookies: { dp_2fa: 't1' } });
  assert.equal(r.redirect, '/app'); const t = cookieOut(r, 'dp_t'); assert.ok(t.v.split('.').length === 3); assert.equal(t.o.httpOnly, true); assert.equal(t.o.sameSite, 'lax');
  assert.ok(r.req.out.some((o) => o.op === 'del' && o.n === 'dp_2fa'));
});
test('ورود با کد ۲FA غلط → پیام خطا', async () => {
  const r = await runAction(B, 'auth', 'login2fa', [fd({ code: '000000' })], { cookies: { dp_2fa: 't1' } });
  assert.equal(r.redirect, '/login'); assert.equal(r.flash.t, 'err');
});
test('رمز غلط → پیام خطای API روی صفحه‌ی ورود', async () => {
  const r = await runAction(B, 'auth', 'login', [fd({ username: '09120000001', password: 'bad', captchaId: 'c1', captcha: '1' })]);
  assert.equal(r.redirect, '/login'); assert.match(r.flash.m, /نادرست/);
});
test('ثبت‌نام سه‌مرحله‌ای با حالت در کوکی', async () => {
  let r = await runAction(B, 'auth', 'regPhone', [fd({ phone: '۰۹۱۲۰۰۰۰۰۰۵', captchaId: 'c1', captcha: '4827' })]);
  assert.equal(cookieOut(r, 'dp_rp').v, '09120000005'); // ارقام فارسی نرمال شد
  r = await renderPage(B, '/register', { cookies: { dp_rp: '09120000005' } }); assert.match(r.html, /۲ از ۳/);
  r = await runAction(B, 'auth', 'regCode', [fd({ code: '123456' })], { cookies: { dp_rp: '09120000005' } });
  if (!r.flash) { assert.ok(cookieOut(r, 'dp_rt')); r = await renderPage(B, '/register', { cookies: { dp_rt: cookieOut(r, 'dp_rt').v } }); assert.match(r.html, /۳ از ۳/); }
});
test('قبول قرارداد بدون تیک موافقت رد می‌شود؛ با تیک به API می‌رود', async () => {
  let r = await runAction(B, 'customer', 'signContract', [G(1), fd({})], { token: tokens.customer });
  assert.equal(r.flash.t, 'err'); assert.equal(r.redirect, `/app/contracts/${G(1)}`);
  r = await runAction(B, 'customer', 'signContract', [G(1), fd({ agree: '1' })], { token: tokens.customer });
  assert.equal(r.flash.t, 'ok');
});
test('آپلود مدرک: نوع/حجم نامعتبر رد می‌شود', async () => {
  let r = await runAction(B, 'customer', 'uploadDocument', [fd({ kind: 'Other', file: new File(['x'], 'a.svg', { type: 'image/svg+xml' }) })], { token: tokens.customer });
  assert.match(r.flash.m, /JPG/);
  r = await runAction(B, 'customer', 'uploadDocument', [fd({ kind: 'Other', file: new File([new Uint8Array(6 * 1024 * 1024 + 1)], 'a.png', { type: 'image/png' }) })], { token: tokens.customer });
  assert.match(r.flash.m, /۶ مگابایت/);
  r = await runAction(B, 'customer', 'uploadDocument', [fd({ kind: 'Other', file: new File([new Uint8Array(10)], 'a.png', { type: 'image/png' }) })], { token: tokens.customer });
  assert.equal(r.flash.t, 'ok');
});
test('نمایش کارت: اطلاعات حساس فقط در کوکی یک‌بارمصرف، نه URL', async () => {
  const r = await runAction(B, 'customer', 'revealCard', [G(700)], { token: tokens.customer });
  assert.ok(!r.flash, 'reveal failed');
  assert.equal(r.redirect, '/app/cards/reveal'); const once = JSON.parse(cookieOut(r, 'dp_o').v); assert.ok(once.cvv); assert.ok(!r.redirect.includes(once.cvv));
  const p = await renderPage(B, '/app/cards/reveal', { token: tokens.customer, cookies: { dp_o: cookieOut(r, 'dp_o').v } }); assert.equal(p.status, 200); assert.match(p.html, /CVV/);
  assert.equal((await renderPage(B, '/app/cards/reveal', { token: tokens.customer })).redirect, '/app/cards');
});
test('هدایت باز (open redirect) ممکن نیست', async () => {
  for (const bad of ['//evil.com', 'https://evil.com', '\\\\evil']) { resetReq({}); try { await B.session.go(bad); assert.fail(); } catch (e) { assert.equal(e.to, '/'); } }
});
test('اکشن‌های ادمین برای مشتری عادی کار نمی‌کنند و عملیات ناشناخته نادیده گرفته می‌شود', async () => {
  let r = await runAction(B, 'admin', 'contractOp', [G(2), 'approve'], { token: tokens.customer }); assert.equal(r.redirect, '/app');
  r = await runAction(B, 'admin', 'contractOp', [G(2), '../../admin/backups'], { token: tokens.admin }); assert.equal(r.redirect, `/admin/contracts/${G(2)}`); assert.equal(r.flash, undefined);
  r = await runAction(B, 'admin', 'assignRole', [fd({ userId: 'not-a-guid', roleId: G(901) })], { token: tokens.admin }); assert.match(r.flash.m, /معتبر/);
});
test('پشتیبان‌گیری فقط برای مدیر ارشد', async () => {
  const a = await renderPage(B, '/admin/backups', { token: tokens.admin }); assert.match(a.html, /فقط برای مدیر ارشد/);
  const s = await renderPage(B, '/admin/backups', { token: tokens.super }); assert.match(s.html, /\.bak/);
  const r = await runAction(B, 'admin2', 'makeBackup', [], { token: tokens.admin }); assert.equal(r.redirect, '/admin');
});
test('تصویر مدرک: فقط jpeg/png/webp و بدون اجرای اسکریپت', async () => {
  const res = await runRoute(B, '/files/admin/documents/[id]', { id: G(503) }, { token: tokens.super });
  assert.equal(res.status, 200); assert.equal(res.headers.get('content-type'), 'image/png'); assert.equal(res.headers.get('content-security-policy'), "default-src 'none'");
  const noauth = await runRoute(B, '/files/admin/documents/[id]', { id: G(503) }, {}); assert.equal(noauth.status, 303);
});
test('متن قرارداد: CSP سندباکس و X-Frame-Options', async () => {
  const res = await runRoute(B, '/files/me/contracts/[id]', { id: G(1) }, { token: tokens.customer });
  assert.equal(res.status, 200); assert.match(res.headers.get('content-security-policy'), /sandbox/); assert.equal(res.headers.get('x-frame-options'), 'SAMEORIGIN');
  const p = await runRoute(B, '/files/admin/templates/[id]/preview', { id: G(1602) }, { token: tokens.super }); assert.match(p.headers.get('content-security-policy'), /sandbox/);
  const s = await runRoute(B, '/files/admin/templates/[id]/sample', { id: G(1602) }, { token: tokens.super }); assert.match(s.headers.get('content-disposition'), /attachment/);
});
test('اعلان با لینک بیرونی به صفحه‌ی امن برمی‌گردد', async () => {
  const r = await renderPage(B, '/app/inbox', { token: tokens.customer }); assert.ok(!/href="https?:\/\//.test(r.html.replace(/href="https:\/\/fonts[^"]*"/g, '')));
});

// ---- اعتبارسنجی (اعتبارسنجی ایران) ----
const VALID_NC = '0012345679'; // رقم کنترلی درست
test('اعتبارسنجی: صفحه‌های مشتری و مدیر رندر می‌شوند و رمز/کد ملی کامل نشت نمی‌کند', async () => {
  for (const [route, who, id] of [['/app/credit', 'customer'], ['/app/credit/[id]', 'customer', G(1901)], ['/app/credit/[id]', 'customer', G(1902)], ['/admin/credit', 'super'], ['/admin/credit/[id]', 'super', G(1903)], ['/admin/credit/[id]/report', 'super', G(1901)], ['/admin/credit/records', 'super']]) {
    const r = await renderPage(B, route, { params: id ? { id } : {}, token: tokens[who] }); assert.equal(r.status, 200, route); assert.ok(!/undefined|\[object/.test(r.html), route);
    assert.ok(!/13579/.test(r.html), 'otp leaked ' + route);
  }
  const r = await renderPage(B, '/app/credit/[id]', { params: { id: G(1902) }, token: tokens.customer }); assert.match(r.html, /name="token"/); assert.match(r.html, /0912\*{5}67/);
  const done = await renderPage(B, '/app/credit/[id]', { params: { id: G(1901) }, token: tokens.customer }); assert.match(done.html, /files\/me\/credit/); assert.match(done.html, /creditScore/);
});
test('اعتبارسنجی: بدون رضایت یا با کد ملی غلط، API صدا زده نمی‌شود', async () => {
  let r = await runAction(B, 'customer', 'startCredit', [fd({ nc: VALID_NC, mobile: '09121234567' })], { token: tokens.customer }); assert.equal(r.redirect, '/app/credit'); assert.match(r.flash.m, /رضایت/);
  r = await runAction(B, 'customer', 'startCredit', [fd({ nc: '1234567890', mobile: '09121234567', consent: '1' })], { token: tokens.customer }); assert.match(r.flash.m, /کد ملی/);
  r = await runAction(B, 'customer', 'startCredit', [fd({ nc: VALID_NC, mobile: '9121234567', consent: '1' })], { token: tokens.customer }); assert.match(r.flash.m, /موبایل/);
});
test('اعتبارسنجی: شروع با ارقام فارسی → صفحه‌ی رمز؛ رمز غلط خطا؛ رمز درست → در حال ساخت', async () => {
  let r = await runAction(B, 'customer', 'startCredit', [fd({ nc: '۰۰۱۲۳۴۵۶۷۹', mobile: '۰۹۱۲۱۲۳۴۵۶۷', consent: '1' })], { token: tokens.customer });
  const m = /^\/app\/credit\/([0-9a-f-]{36})$/.exec(r.redirect || ''); assert.ok(m, 'redirect ' + r.redirect); const id = m[1];
  r = await runAction(B, 'customer', 'creditOtp', [id, fd({ token: '11111' })], { token: tokens.customer }); assert.equal(r.flash.t, 'err');
  r = await runAction(B, 'customer', 'creditOtp', [id, fd({ token: '۱۳۵۷۹' })], { token: tokens.customer }); assert.equal(r.flash.t, 'ok');
  const p = await renderPage(B, '/app/credit/[id]', { params: { id }, token: tokens.customer }); assert.match(p.html, /http-equiv="refresh"|httpEquiv/i);
});
test('اعتبارسنجی: عملیات نامجاز و شناسه‌ی نامعتبر رد می‌شود', async () => {
  let r = await runAction(B, 'customer', 'creditOp', [G(1901), 'delete'], { token: tokens.customer }); assert.equal(r.redirect, '/app/credit');
  r = await runAction(B, 'customer', 'creditOp', ['../x', 'refresh'], { token: tokens.customer }); assert.equal(r.redirect, '/app/credit');
  r = await runAction(B, 'admin2', 'adminCreditOp', [G(1901), 'view-report'], { token: tokens.super }); assert.equal(r.redirect, '/admin/credit');
});
test('اعتبارسنجی: PDF فقط با نشست؛ فایل غیر PDF رد می‌شود', async () => {
  const ok = await runRoute(B, '/files/me/credit/[id]', { id: G(1901) }, { token: tokens.customer }); assert.equal(ok.status, 200); assert.equal(ok.headers.get('content-type'), 'application/pdf'); assert.match(ok.headers.get('content-disposition'), /attachment/);
  const no = await runRoute(B, '/files/me/credit/[id]', { id: G(1901) }, {}); assert.equal(no.status, 303);
  const nf = await runRoute(B, '/files/me/credit/[id]', { id: G(1902) }, { token: tokens.customer }); assert.notEqual(nf.status, 200);
});
test('اعتبارسنجی: تنظیمات ادمین اعتبارسنجی می‌شوند', async () => {
  let r = await runAction(B, 'admin2', 'creditSettings', [fd({ enabled: '1', retentionDays: '999' })], { token: tokens.super }); assert.equal(r.flash.t, 'err');
  r = await runAction(B, 'admin2', 'creditSettings', [fd({ enabled: '1', autoFetch: '1', retentionDays: '۳۰', minScore: '' })], { token: tokens.super }); assert.equal(r.flash.t, 'ok');
  r = await runAction(B, 'admin2', 'adminCreditStart', [fd({ userId: 'x', nc: VALID_NC, mobile: '09121234567', consent: '1' })], { token: tokens.super }); assert.match(r.flash.m, /مشتری/);
});

// ---- درخواست وام ----
test('درخواست وام: صفحه‌ها رندر می‌شوند و برآورد با فرمول موتور قرارداد یکی است', async () => {
  for (const [route, who, id] of [['/app/loans', 'customer'], ['/app/loans/new', 'customer'], ['/app/loans/[id]', 'customer', G(2002)], ['/admin/loans', 'super'], ['/admin/loans/[id]', 'super', G(2003)]]) {
    const r = await renderPage(B, route, { params: id ? { id } : {}, token: tokens[who] }); assert.equal(r.status, 200, route); assert.ok(!/undefined|\[object/.test(r.html), route);
  }
  const p = await renderPage(B, '/app/loans/new', { search: { product: 'mobile-6', amount: '30000000', months: '12', down: '10' }, token: tokens.customer });
  assert.match(p.html, /۲,۴۱۲,۰۰۰/); assert.match(p.html, /۲۸,۹۴۴,۰۰۰/); assert.match(p.html, /name="attachCredit"/);
  const o = await renderPage(B, '/app/loans/new', { search: { product: 'mobile-6', amount: '999999999', months: '12', down: '10' }, token: tokens.customer }); assert.match(o.html, /خارج از محدوده/); assert.ok(!/name="attachCredit"/.test(o.html));
  const nf = await renderPage(B, '/app/loans/[id]', { params: { id: G(2002) }, token: tokens.customer }); assert.match(nf.html, /فیش حقوقی/); assert.match(nf.html, /بخش مدارک/);
});
test('درخواست وام: ثبت، اعتبارسنجی ورودی، لغو', async () => {
  let r = await runAction(B, 'customer', 'createLoanApp', [fd({ product: '', amount: '30000000', months: '12', down: '10' })], { token: tokens.customer }); assert.match(r.flash.m, /طرح/);
  r = await runAction(B, 'customer', 'createLoanApp', [fd({ product: 'mobile-6', productName: 'x', amount: '500', months: '12', down: '10' })], { token: tokens.customer }); assert.equal(r.flash.t, 'err');
  r = await runAction(B, 'customer', 'createLoanApp', [fd({ product: 'mobile-6', productName: 'وام موبایل', amount: '۲۰,۰۰۰,۰۰۰', months: '۶', down: '۱۰', note: 'سلام', attachCredit: '1' })], { token: tokens.customer });
  const m = /^\/app\/loans\/([0-9a-f-]{36})$/.exec(r.redirect || ''); assert.ok(m, 'redirect ' + r.redirect); assert.equal(r.flash.t, 'ok');
  r = await runAction(B, 'customer', 'cancelLoanApp', [m[1]], { token: tokens.customer }); assert.equal(r.flash.t, 'ok');
  r = await runAction(B, 'customer', 'cancelLoanApp', [m[1]], { token: tokens.customer }); assert.equal(r.flash.t, 'err');
  r = await runAction(B, 'customer', 'cancelLoanApp', ['../x'], { token: tokens.customer }); assert.equal(r.redirect, '/app/loans');
});
test('درخواست وام: تصمیم مدیر؛ رد/اطلاعات بدون توضیح نمی‌شود؛ وضعیت نهایی تغییر نمی‌کند', async () => {
  let r = await runAction(B, 'admin2', 'reviewLoanApp', [G(2003), fd({ status: 'Rejected', note: '' })], { token: tokens.super }); assert.equal(r.flash.t, 'err');
  r = await runAction(B, 'admin2', 'reviewLoanApp', [G(2003), fd({ status: 'Approved', note: 'تأیید' })], { token: tokens.super }); assert.equal(r.flash.t, 'ok');
  r = await runAction(B, 'admin2', 'reviewLoanApp', [G(2003), fd({ status: 'Rejected', note: 'دلیل رد' })], { token: tokens.super }); assert.equal(r.flash.t, 'err');
  r = await runAction(B, 'admin2', 'reviewLoanApp', [G(2003), fd({ status: 'Hack', note: 'x' })], { token: tokens.super }); assert.equal(r.flash.t, 'err');
  const c = await runAction(B, 'admin2', 'reviewLoanApp', [G(2001), fd({ status: 'InReview' })], { token: tokens.customer }).catch((e) => e); assert.ok(c.redirect !== '/admin/loans/' + G(2001) || c.flash?.t !== 'ok');
});

test('صفحه اصلی: دکمه‌ی ماشین‌حساب برای مشتری واردشده به فرم درخواست وام می‌رود، برای مهمان به ثبت‌نام', async () => {
  const g = await renderPage(B, '/', {}); assert.match(g.html, /href="\/register"[^>]*>ثبت درخواست وام|ثبت درخواست وام/); assert.ok(!/href="\/app\/loans\/new/.test(g.html));
  const c = await renderPage(B, '/', { token: tokens.customer }); assert.match(c.html, /href="\/app\/loans\/new\?amount=30000000&(amp;)?months=12/);
});

test('داشبورد مدیریت: صف‌های نیازمند اقدام، میز کار، راهنمای وضعیت و منوی گروه‌بندی‌شده', async () => {
  const d = await renderPage(B, '/admin', { token: tokens.super }); assert.ok(!/undefined|NaN/.test(d.html)); assert.match(d.html, /نیازمند اقدام/); assert.match(d.html, /adm-nav/); assert.match(d.html, /href="\/admin\/work"/); assert.match(d.html, /class="qgrid/);
  const w = await renderPage(B, '/admin/work', { token: tokens.super }); assert.ok(!/undefined|NaN/.test(w.html)); assert.match(w.html, /میز کار کارشناس/); assert.match(w.html, /بررسی/);
  const wl = await renderPage(B, '/admin/work', { search: { q: 'loans' }, token: tokens.super }); assert.match(wl.html, /\/admin\/loans\//);
  const s = await renderPage(B, '/admin/statuses', { token: tokens.super }); assert.ok(!/undefined/.test(s.html)); assert.match(s.html, /راهنمای وضعیت/); assert.match(s.html, /قرارداد/);
});
