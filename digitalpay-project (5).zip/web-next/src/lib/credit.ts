// کمک‌های اعتبارسنجی (اعتبارسنجی ایران — MyCreditAPIs v3.2) — فقط منطق خالص؛ بدون وابستگی به Next
import { en } from '@/lib/format';
/** کد ملی ۱۰رقمی با رقم کنترلی */
export function ncOk(v: string): boolean {
  if (!/^\d{10}$/.test(v) || /^(\d)\1{9}$/.test(v)) return false;
  let s = 0; for (let i = 0; i < 9; i++) s += +v[i] * (10 - i); const r = s % 11; return r < 2 ? +v[9] === r : +v[9] === 11 - r;
}
export const mobileOk = (v: string) => /^09\d{9}$/.test(v);
export const legalOk = (v: string) => /^\d{11}$/.test(v);
export const otpOk = (v: string) => /^\d{4,8}$/.test(v);
export const clean = (v: unknown) => en(String(v ?? '')).replace(/[\s\-]/g, '');
/** وضعیت سرویس‌دهنده (بخش ۶ مستند) */
export { CREDIT_STATUS } from '@/lib/format';
/** وضعیت پیامک (جدول بخش ۶) */
export const SMS_STATUS: Record<number, string> = { 2: 'اطلاعات دقیقی یافت نشد', 3: 'رسیده به مخابرات', 4: 'نرسیده به مخابرات', 5: 'رسیده به گوشی', 6: 'نرسیده به گوشی' };
export const EV_OP: Record<string, string> = { request: 'ثبت درخواست', renew: 'ارسال مجدد رمز', validate: 'بررسی رمز', status: 'پرسش وضعیت', regenerate: 'بازتولید گزارش', report: 'دریافت گزارش', pdf: 'دریافت PDF', 'view-report': 'مشاهده‌ی گزارش', ReportGenerated: 'کال‌بک: گزارش آماده', OTPAccepted: 'کال‌بک: رمز پذیرفته شد' };
export const OPEN = (v: any) => !v.settled && !v.reportReady;
/** پرچم‌های رفتار صفحه از روی نمای API */
export const awaitingOtp = (v: any) => !v.submitted && !v.settled;
export const processing = (v: any) => v.submitted && !v.settled;
