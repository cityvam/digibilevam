import { api } from '@/lib/api';
import { fa, money, olderThan, short } from '@/lib/format';
// صف‌های کار کارشناس: هر صف از همان API های صفحه‌ی خودش خوانده می‌شود (مجوز سمت API اعمال می‌شود؛ صفی که مجوزش نیست خالی/پنهان می‌ماند).
export type QItem = { id: string; title: string; sub: string; at: unknown; href: string; hot: boolean };
export type Queue = { key: string; label: string; hint: string; actions: string; href: string; tone: 'info' | 'warn' | 'bad'; ok: boolean; count: number; items: QItem[] };
const SLA_H = 24;
const METHOD: Record<string, string> = { CardToCard: 'کارت‌به‌کارت', BankTransfer: 'حواله‌ی بانکی', Cash: 'نقدی' };
const DOCK: Record<string, string> = { NationalCard: 'کارت ملی', Salary: 'فیش حقوقی', Selfie: 'تصویر چهره', BankStatement: 'صورت‌حساب بانکی' };
const arr = (x: any) => (Array.isArray(x) ? x : null);
const oldest = (xs: QItem[]) => xs.sort((a, b) => new Date(a.at as string).getTime() - new Date(b.at as string).getTime());
export async function loadQueues(): Promise<Queue[]> {
  const [loansA, loansB, docs, decls, cons, tix, cred, inq] = await Promise.all([
    api.soft('/api/v1/admin/loan-applications', { status: 'Submitted' }), api.soft('/api/v1/admin/loan-applications', { status: 'InReview' }),
    api.soft('/api/v1/admin/documents', { status: 'Pending' }), api.soft('/api/v1/admin/payment-declarations', { status: 'Pending' }),
    api.soft('/api/v1/admin/contracts', { status: 'ReadyForReview' }), api.soft('/api/v1/admin/tickets', { status: 'Open' }),
    api.soft('/api/v1/admin/credit', { status: 'ReportGenerationFailed' }), api.soft('/api/v1/admin/inquiries')]);
  const mk = (q: Omit<Queue, 'count' | 'ok'>, xs: QItem[] | null): Queue => ({ ...q, ok: xs !== null, count: xs?.length ?? 0, items: oldest(xs ?? []) });
  const loans = loansA || loansB ? [...(loansA?.items ?? []), ...(loansB?.items ?? [])].map(({ v }: any): QItem => ({ id: v.id, title: `${v.code} — ${v.productName}`, sub: `${money(v.amount)} تومان، ${fa(v.months)} ماه${v.creditScore != null ? ` — امتیاز اعتباری ${fa(v.creditScore)}` : ''}`, at: v.createdOn, href: `/admin/loans/${v.id}`, hot: olderThan(v.createdOn, SLA_H) })) : null;
  return [
    mk({ key: 'loans', label: 'درخواست‌های وام', hint: 'ثبت‌شده و در حال بررسی', actions: 'در حال بررسی · نیاز به اطلاعات · تأیید · رد', href: '/admin/loans', tone: 'warn' }, loans),
    mk({ key: 'docs', label: 'مدارک در انتظار', hint: 'تصویر مدرک مشتری', actions: 'تأیید · رد با علت', href: '/admin/documents', tone: 'warn' }, arr(docs)?.map((d: any): QItem => ({ id: d.id, title: DOCK[d.kind] || d.kind, sub: `مشتری ${short(d.userId)}${d.fileName ? ' — ' + d.fileName : ''}`, at: d.createdOn, href: `/admin/documents/${d.id}`, hot: olderThan(d.createdOn, SLA_H) })) ?? null),
    mk({ key: 'payments', label: 'واریزهای اعلام‌شده', hint: 'نیازمند تطبیق با بانک', actions: 'تأیید (ثبت پرداخت قسط) · رد', href: '/admin/payments', tone: 'warn' }, arr(decls)?.map((d: any): QItem => ({ id: d.id, title: `${money(d.amount)} تومان — ${METHOD[d.method] || d.method}`, sub: `مشتری ${short(d.userId)} — پیگیری ${d.reference || '—'}`, at: d.createdOn, href: '/admin/payments', hot: olderThan(d.createdOn, SLA_H) })) ?? null),
    mk({ key: 'contracts', label: 'قراردادهای منتظر تأیید', hint: 'تأیید باید توسط فردی غیر از سازنده باشد', actions: 'تأیید · بازگرداندن · لغو', href: '/admin/contracts?status=ReadyForReview', tone: 'info' }, arr(cons)?.map((c: any): QItem => ({ id: c.id, title: `${fa(c.number)} — ${c.title}`, sub: `مشتری ${short(c.userId)}`, at: c.createdOn, href: `/admin/contracts/${c.id}`, hot: olderThan(c.createdOn, SLA_H) })) ?? null),
    mk({ key: 'tickets', label: 'تیکت‌های باز', hint: 'بدون پاسخ کارشناس', actions: 'پاسخ · یادداشت داخلی · بستن', href: '/admin/tickets', tone: 'info' }, arr(tix)?.map((t: any): QItem => ({ id: t.id, title: `${fa(t.code)} — ${t.subject}`, sub: `مشتری ${short(t.userId)}`, at: t.updatedOn || t.createdOn, href: `/admin/tickets/${t.id}`, hot: !!t.overdue })) ?? null),
    mk({ key: 'credit', label: 'استعلام‌های ناموفق', hint: 'ساخت گزارش اعتباری شکست خورده', actions: 'بازتولید گزارش (بدون رمز جدید)', href: '/admin/credit?status=ReportGenerationFailed', tone: 'bad' }, cred ? (cred.items ?? []).map(({ v }: any): QItem => ({ id: v.id, title: `${v.code} — ${v.statusTitle}`, sub: `کد ملی ${v.ncMask}`, at: v.updatedOn || v.createdOn, href: `/admin/credit/${v.id}`, hot: true })) : null),
    mk({ key: 'inquiries', label: 'استعلام‌های دستی در صف', hint: 'ثبت نتیجه توسط کارشناس', actions: 'ثبت نتیجه · ناموفق', href: '/admin/inquiries', tone: 'info' }, arr(inq)?.filter((x: any) => x.status === 'Queued').map((x: any): QItem => ({ id: x.id, title: x.type === 'Credit' ? 'اعتبارسنجی' : x.type === 'Identity' ? 'احراز هویت' : 'استعلام', sub: `مشتری ${short(x.userId)}${x.note ? ' — ' + x.note : ''}`, at: x.createdOn, href: '/admin/inquiries', hot: olderThan(x.createdOn, SLA_H) })) ?? null),
  ];
}
