import { cookies, headers } from 'next/headers';
import { redirect } from 'next/navigation';
import { claims } from './jwt';
import { ApiError } from './api';

export type Session = { name: string; roles: string[]; isAdmin: boolean; isSuper: boolean };
export async function getSession(): Promise<Session | null> {
  const t = (await cookies()).get('dp_t')?.value; const c = claims(t);
  if (!c || c.exp <= Date.now()) return null;
  return { name: c.name, roles: c.roles, isAdmin: c.roles.some((r) => r === 'Admin' || r === 'SuperAdmin'), isSuper: c.roles.includes('SuperAdmin') };
}
export async function requireUser(admin = false): Promise<Session> {
  const s = await getSession(); if (!s) redirect('/session-expired');
  if (admin && !s.isAdmin) redirect('/app');
  return s;
}
export const pathname = async () => (await headers()).get('x-pathname') || '/';

// ---- پیام یک‌بارمصرف (کوکی کوتاه‌عمر؛ میدل‌ور آن را پس از نمایش پاک می‌کند) ----
export type Flash = { t: 'ok' | 'err'; m: string };
export async function readFlash(): Promise<Flash | null> {
  try { const v = (await cookies()).get('dp_f')?.value; return v ? JSON.parse(v) : null; } catch { return null; }
}
export async function setFlash(f: Flash) { (await cookies()).set('dp_f', JSON.stringify(f), { path: '/', httpOnly: true, sameSite: 'lax', secure: process.env.COOKIE_SECURE === 'true', maxAge: 10 }); }
/** هدایت با پیام. فقط مسیرهای داخلی. */
export async function go(to: string, f?: Flash): Promise<never> { if (f) await setFlash(f); redirect(/^\/(?!\/)/.test(to) ? to : '/'); }
/** اجرای عملیات؛ خطای API به پیام قرمز روی همان صفحه تبدیل می‌شود (redirect های Next عبور می‌کنند). */
export async function run(back: string, ok: string, fn: () => Promise<unknown>, okTo?: string): Promise<never> {
  try { await fn(); } catch (e) { if (e instanceof ApiError) return go(back, { t: 'err', m: e.message }); throw e; }
  return go(okTo || back, ok ? { t: 'ok', m: ok } : undefined);
}
// ---- حالت چندمرحله‌ای (ثبت‌نام / ۲FA) در کوکی کوتاه‌عمر ----
export async function setState(name: string, val: string, maxAge = 600) { (await cookies()).set(name, val, { path: '/', httpOnly: true, sameSite: 'lax', secure: process.env.COOKIE_SECURE === 'true', maxAge }); }
export async function getState(name: string) { return (await cookies()).get(name)?.value; }
export async function clearState(...names: string[]) { const c = await cookies(); names.forEach((n) => c.delete(n)); }
export async function setToken(t: string) { await setState('dp_t', t, 60 * 60 * 2); }
// ---- مقدار یک‌بارمصرف حساس (کلید 2FA، اطلاعات کارت): کوکی HttpOnly ۶۰ ثانیه‌ای، هرگز در URL ----
export async function setOnce(v: unknown) { await setState('dp_o', JSON.stringify(v), 60); }
export async function readOnce<T = any>(): Promise<T | null> { try { const v = (await cookies()).get('dp_o')?.value; return v ? JSON.parse(v) : null; } catch { return null; } }
