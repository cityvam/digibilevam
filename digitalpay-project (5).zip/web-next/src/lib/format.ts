// قالب‌بندی فارسی: ارقام، پول، تاریخ شمسی، وضعیت‌ها
const FD = '۰۱۲۳۴۵۶۷۸۹';
export const fa = (v: unknown): string => String(v ?? '').replace(/[0-9]/g, (d) => FD[+d]);
export const en = (s: unknown): string => String(s ?? '').replace(/[۰-۹]/g, (d) => String(FD.indexOf(d))).replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d))).replace(/٫/g, '.').replace(/[٬،]/g, ',');
export function money(v: unknown): string {
  if (v === null || v === undefined || v === '') return '—';
  const s = typeof v === 'number' ? (Number.isInteger(v) ? String(v) : v.toFixed(8).replace(/0+$/, '')) : String(v);
  const m = /^(-?)(\d+)(?:\.(\d+))?$/.exec(s); if (!m) return fa(s);
  return fa(m[1] + m[2].replace(/\B(?=(\d{3})+(?!\d))/g, ',') + (m[3] ? '.' + m[3].slice(0, 8) : ''));
}
export function num(v: unknown): number {
  const s = en(String(v ?? '')).replace(/[,\s]/g, ''); if (s === '') return NaN; return /^-?\d+(\.\d+)?$/.test(s) ? Number(s) : NaN;
}
const DF = new Intl.DateTimeFormat('fa-IR-u-ca-persian', { year: 'numeric', month: '2-digit', day: '2-digit' });
const TF = new Intl.DateTimeFormat('fa-IR-u-ca-persian', { hour: '2-digit', minute: '2-digit', hour12: false });
export const jdate = (d: unknown): string => { if (!d) return '—'; const x = new Date(d as string); return isNaN(+x) ? '—' : DF.format(x); };
export const jdt = (d: unknown): string => { if (!d) return '—'; const x = new Date(d as string); return isNaN(+x) ? '—' : `${DF.format(x)} ${TF.format(x)}`; };
export const short = (id: unknown): string => String(id || '').slice(0, 8);

export const CREDIT_STATUS: Record<string, string> = {
  Success: 'دریافت موفق گزارش', Entry: 'ثبت درخواست', OTPSent: 'رمز یکبارمصرف ارسال شد', OTPLocked: 'دریافت مجدد رمز قفل شد', OTPAccepted: 'رمز پذیرفته شد', OTPCheckFailed: 'رمز اشتباه است', OTPResend: 'رمز مجدد ارسال شد',
  NotMatchingRealPersonNationalCodeAndMobileNumber: 'کد ملی و موبایل تطابق ندارند', NotMatchingRealPersonAndLegalPerson: 'کد ملی و شناسه‌ی ملی شرکت تطابق ندارند', IdentityCheckAccepted: 'احراز هویت انجام شد',
  ReportGenerated: 'گزارش آماده است', ReportGeneratedButDataLost: 'گزارش ساخته شد، داده از دست رفت', ReportGenerationFailed: 'ساخت گزارش ناموفق بود', IdentityCheckFailed: 'احراز هویت ناموفق', InQueue: 'در صف پردازش', Expired: 'مهلت تمام شد',
};
export const STATUS: Record<string, Record<string, string>> = {
  contract: { Draft: 'پیش‌نویس', ReadyForReview: 'در انتظار تأیید', Approved: 'تأییدشده', Presented: 'ارائه‌شده', AwaitingSignature: 'منتظر قبول مشتری', Signed: 'قبول‌شده', Rejected: 'ردشده', Expired: 'منقضی', Cancelled: 'لغوشده' },
  ticket: { Open: 'باز', Answered: 'پاسخ داده شد', Waiting: 'منتظر مشتری', Closed: 'بسته' },
  decl: { Pending: 'در انتظار بررسی', Approved: 'تأیید شد', Rejected: 'رد شد' },
  doc: { Pending: 'در انتظار بررسی', Verified: 'تأیید شد', Rejected: 'رد شد' },
  job: { Pending: 'در انتظار', Running: 'در حال اجرا', Done: 'انجام‌شده', Failed: 'ناموفق', Dead: 'مرده' },
  template: { Draft: 'پیش‌نویس', Approved: 'تأییدشده', Published: 'منتشرشده', Archived: 'بایگانی' },
  category: { Loan: 'وام', Payment: 'پرداخت و اقساط', Account: 'حساب کاربری', Contract: 'قرارداد', Other: 'سایر' },
  credit: CREDIT_STATUS,
  loanapp: { Submitted: 'ثبت‌شده', InReview: 'در حال بررسی', NeedInfo: 'نیازمند اطلاعات بیشتر', Approved: 'تأیید شد', Rejected: 'رد شد', Cancelled: 'لغو شد' },
  acct: { Asset: 'دارایی', Liability: 'بدهی', Equity: 'حقوق صاحبان سهام', Income: 'درآمد', Expense: 'هزینه' },
};
const TONES: Record<string, string> = { Signed: 'good', Approved: 'good', Verified: 'good', Done: 'good', Answered: 'good', Published: 'good', Rejected: 'bad', Dead: 'bad', Failed: 'bad', Expired: 'warn', Cancelled: 'mute', Closed: 'mute', Archived: 'mute', Pending: 'warn', ReadyForReview: 'warn', AwaitingSignature: 'warn', Presented: 'info', Open: 'info', Waiting: 'warn', Draft: 'warn', Submitted: 'info', InReview: 'info', NeedInfo: 'warn', ReportGenerated: 'good', Success: 'good', IdentityCheckAccepted: 'info', OTPAccepted: 'info', InQueue: 'info', Entry: 'mute', OTPSent: 'warn', OTPResend: 'warn', ReportGenerationFailed: 'bad', ReportGeneratedButDataLost: 'bad', IdentityCheckFailed: 'bad', OTPLocked: 'bad', OTPCheckFailed: 'bad', NotMatchingRealPersonNationalCodeAndMobileNumber: 'bad', NotMatchingRealPersonAndLegalPerson: 'bad' };
export const tone = (s: string): string => TONES[s] || 'mute';

/** «۳ ساعت پیش» */
export function ago(d: unknown): string {
  const t = new Date(d as string).getTime(); if (!d || isNaN(t)) return '—'; const s = Math.max(0, (Date.now() - t) / 1000);
  if (s < 90) return 'لحظاتی پیش'; if (s < 3600) return `${fa(Math.round(s / 60))} دقیقه پیش`; if (s < 86400) return `${fa(Math.round(s / 3600))} ساعت پیش`; return `${fa(Math.round(s / 86400))} روز پیش`;
}
export const olderThan = (d: unknown, hours: number) => { const t = new Date(d as string).getTime(); return !isNaN(t) && Date.now() - t > hours * 3600e3; };
