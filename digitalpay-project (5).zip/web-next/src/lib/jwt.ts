// فقط خواندن ادعاهای توکن برای نمایش و هدایت. اعتبار واقعی را همیشه API می‌سنجد.
export type Claims = { sub: string; name: string; roles: string[]; exp: number };
export function claims(tok: string | undefined | null): Claims | null {
  try {
    const p = JSON.parse(Buffer.from(String(tok).split('.')[1], 'base64url').toString('utf8'));
    const R = 'http://schemas.microsoft.com/ws/2008/06/identity/claims/role';
    const roles = ([] as string[]).concat(p.role ?? [], p[R] ?? []).filter(Boolean);
    const name = p.name || p['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name'] || p.unique_name || '';
    return { sub: p.sub || p['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier'] || '', name, roles, exp: p.exp ? p.exp * 1000 : 0 };
  } catch { return null; }
}
