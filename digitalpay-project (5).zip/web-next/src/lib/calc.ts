// آینه‌ی ContractEngine.Calc در بک‌اند؛ باید همیشه یکسان بماند
export function calc(amount: number, downPct: number, feePct: number, months: number) {
  const down = Math.round(amount * downPct / 100), fin = amount - down, fee = Math.round(fin * feePct / 100), total = fin + fee;
  const each = Math.ceil(total / months), last = total - each * (months - 1);
  return { down, fin, fee, total, each, last, months };
}
