import { cookies, headers } from 'next/headers';
import { redirect } from 'next/navigation';

// کلاینت API ی ASP.NET Core (فقط سمت سرور). توکن از کوکی HttpOnly می‌آید و هرگز به مرورگر نمی‌رسد.
export class ApiError extends Error { constructor(public status: number, message: string, public body?: any) { super(message); } }
export type ApiRes = { status: number; ok: boolean; data: any; buf?: ArrayBuffer; headers: Headers };

const BASE = () => (process.env.API_URL || 'http://127.0.0.1:5200').replace(/\/$/, '');

async function call(method: string, path: string, o: { json?: unknown; form?: FormData; query?: Record<string, unknown>; binary?: boolean; accept?: string } = {}): Promise<ApiRes> {
  const [c, h] = await Promise.all([cookies(), headers()]);
  const qs = o.query ? '?' + new URLSearchParams(Object.entries(o.query).filter(([, v]) => v !== undefined && v !== null && v !== '').map(([k, v]) => [k, String(v)])).toString() : '';
  const hd: Record<string, string> = { Accept: o.accept || 'application/json' };
  const ip = (h.get('x-real-ip') || h.get('x-forwarded-for') || '').split(',')[0].trim(); if (ip) hd['X-Real-IP'] = ip;
  if (process.env.API_HOST_HEADER) hd['Host'] = process.env.API_HOST_HEADER;
  const t = c.get('dp_t')?.value; if (t) hd['Authorization'] = 'Bearer ' + t;
  let body: BodyInit | undefined;
  if (o.json !== undefined) { body = JSON.stringify(o.json); hd['Content-Type'] = 'application/json'; } else if (o.form) body = o.form;
  const res = await fetch(BASE() + path + qs, { method, headers: hd, body, cache: 'no-store', signal: AbortSignal.timeout(15000) });
  if (o.binary) return { status: res.status, ok: res.ok, data: null, buf: await res.arrayBuffer(), headers: res.headers };
  const text = await res.text(); let data: any = text;
  if ((res.headers.get('content-type') || '').includes('json') && text) { try { data = JSON.parse(text); } catch { /* متن خام */ } }
  return { status: res.status, ok: res.ok, data, headers: res.headers };
}
export const msg = (r: ApiRes): string => (r.data && typeof r.data === 'object' && r.data.message) || (r.status === 429 ? 'تلاش‌های زیاد؛ کمی بعد دوباره امتحان کنید.' : r.status === 403 ? 'دسترسی این کار برای شما فعال نیست.' : r.status === 404 ? 'پیدا نشد.' : 'درخواست انجام نشد.');
async function must(p: Promise<ApiRes>): Promise<any> {
  const r = await p;
  if (r.status === 401) redirect('/session-expired');
  if (!r.ok) throw new ApiError(r.status, msg(r), r.data);
  return r.data;
}
export const api = {
  msg,
  get: (p: string, query?: Record<string, unknown>) => must(call('GET', p, { query })),
  post: (p: string, json?: unknown) => must(call('POST', p, { json: json ?? {} })),
  put: (p: string, json?: unknown) => must(call('PUT', p, { json })),
  del: (p: string) => must(call('DELETE', p)),
  upload: (p: string, form: FormData) => must(call('POST', p, { form })),
  /** وضعیت را خودت بررسی کن (بدون پرتاب خطا) */
  try: (method: string, p: string, json?: unknown) => call(method, p, { json }),
  bytes: (p: string) => call('GET', p, { binary: true }),
  html: (p: string) => call('GET', p, { binary: true, accept: 'text/html' }),
  /** GET که شکست آن مهم نیست (برای بخش‌های اختیاری صفحه) */
  soft: async (p: string, query?: Record<string, unknown>) => { const r = await call('GET', p, { query }); if (r.status === 401) redirect('/session-expired'); return r.ok ? r.data : null; },
};
