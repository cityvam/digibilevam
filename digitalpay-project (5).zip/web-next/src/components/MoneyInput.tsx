'use client';
// تنها کامپوننت کلاینتی: جداکننده‌ی هزارگان هنگام تایپ. بدون JavaScript هم فرم کار می‌کند (سرور ارقام را نرمال می‌کند).
import { useState } from 'react';
const FD = '۰۱۲۳۴۵۶۷۸۹';
const fmt = (s: string) => s.replace(/[۰-۹]/g, (d) => String(FD.indexOf(d))).replace(/[^0-9]/g, '').replace(/\B(?=(\d{3})+(?!\d))/g, ',');
export default function MoneyInput({ name, defaultValue = '', required }: { name: string; defaultValue?: string; required?: boolean }) {
  const [v, setV] = useState(fmt(String(defaultValue)));
  return <input name={name} className="ltr" inputMode="numeric" value={v} onChange={(e) => setV(fmt(e.target.value))} required={required} />;
}
