import type { ReactNode } from 'react';
import { fa } from '@/lib/format';
// نمایش عمومی گزارش اعتباری. ساختار گزارش در مستند (پیوست) نیامده؛ پس هر شیء/آرایه را بدون فرض درباره‌ی کلیدها نمایش می‌دهد.
// همه‌ی مقدارها به‌صورت متن (escape خودکار React) نمایش داده می‌شوند؛ هیچ HTML خامی تزریق نمی‌شود.
const MAX_DEPTH = 7, MAX_ITEMS = 200;
const scalar = (v: unknown): string => v === null || v === undefined ? '—' : typeof v === 'boolean' ? (v ? 'بله' : 'خیر') : typeof v === 'number' ? fa(v.toLocaleString('en-US')) : String(v).slice(0, 400);
const isObj = (v: unknown): v is Record<string, unknown> => !!v && typeof v === 'object' && !Array.isArray(v);
const flat = (v: unknown) => isObj(v) && Object.values(v).every((x) => x === null || typeof x !== 'object');
function Node({ k, v, d }: { k?: string; v: unknown; d: number }): ReactNode {
  if (d > MAX_DEPTH) return <span className="mut">…</span>;
  if (Array.isArray(v)) {
    if (!v.length) return k ? <div className="rv"><b>{k}</b><span className="mut">خالی</span></div> : null;
    if (v.every(flat)) {
      const cols = [...new Set(v.slice(0, MAX_ITEMS).flatMap((r) => Object.keys(r as object)))];
      return (<details open={d < 2}><summary>{k || 'فهرست'} <span className="mut">({fa(v.length)})</span></summary>
        <div className="tw"><table><thead><tr>{cols.map((c) => <th key={c} className="ltr">{c}</th>)}</tr></thead>
          <tbody>{v.slice(0, MAX_ITEMS).map((r, i) => <tr key={i}>{cols.map((c) => <td key={c}>{scalar((r as any)[c])}</td>)}</tr>)}</tbody></table></div></details>);
    }
    return (<details open={d < 2}><summary>{k || 'فهرست'} <span className="mut">({fa(v.length)})</span></summary>{v.slice(0, MAX_ITEMS).map((x, i) => <div className="rt-i" key={i}><Node v={x} d={d + 1} /></div>)}</details>);
  }
  if (isObj(v)) {
    const es = Object.entries(v); const sc = es.filter(([, x]) => x === null || typeof x !== 'object'), rest = es.filter(([, x]) => x !== null && typeof x === 'object');
    const body = (<>{sc.length ? <div className="rvs">{sc.map(([a, b]) => <div className="rv" key={a}><b className="ltr">{a}</b><span>{scalar(b)}</span></div>)}</div> : null}{rest.map(([a, b]) => <Node key={a} k={a} v={b} d={d + 1} />)}</>);
    return k ? <details open={d < 2}><summary className="ltr">{k}</summary><div className="rt-i">{body}</div></details> : body;
  }
  return <div className="rv"><b className="ltr">{k}</b><span>{scalar(v)}</span></div>;
}
export function ReportTree({ data }: { data: unknown }) { return <div className="rt"><Node v={data} d={0} /></div>; }
