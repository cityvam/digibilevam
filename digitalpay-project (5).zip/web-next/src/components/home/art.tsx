// تصویرسازی‌های برداری صفحه‌ی اصلی (جایگزین عکس‌ها؛ بعداً می‌شود با عکس واقعی عوض کرد)
export function Logo({ size = 40 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" aria-hidden="true">
      <rect width="48" height="48" rx="12" fill="#1e6df2" />
      <g fill="none" stroke="#fff" strokeWidth="3.6" strokeLinecap="round">
        <circle cx="15.5" cy="29" r="6.2" /><path d="M21.7 12v23" />
        <path d="M27.6 12v23" /><circle cx="33.8" cy="29" r="6.2" />
      </g>
    </svg>
  );
}

export function HeroArt() {
  return (
    <svg className="hero-art" viewBox="0 0 1000 420" preserveAspectRatio="xMinYMid slice" aria-hidden="true">
      <defs>
        <linearGradient id="hw" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#0d2a5e" /><stop offset=".55" stopColor="#1d5aa8" /><stop offset="1" stopColor="#0a1f46" /></linearGradient>
        <linearGradient id="hsky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#7fb4f2" /><stop offset="1" stopColor="#d9ecff" /></linearGradient>
        <linearGradient id="htv" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#62a8ee" /><stop offset=".6" stopColor="#cfe6ff" /><stop offset="1" stopColor="#2f8f9a" /></linearGradient>
        <linearGradient id="hmetal" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor="#c7ced8" /><stop offset=".5" stopColor="#f1f4f8" /><stop offset="1" stopColor="#b7bfcb" /></linearGradient>
        <linearGradient id="hfloor" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#b9916a" /><stop offset="1" stopColor="#7d5a3c" /></linearGradient>
      </defs>
      <rect width="1000" height="420" fill="url(#hw)" />
      {/* پنجره و آسمان‌خراش‌ها */}
      <rect x="0" y="0" width="330" height="250" fill="url(#hsky)" opacity=".9" />
      {[[10, 120, 40], [55, 70, 34], [95, 110, 46], [150, 50, 38], [195, 100, 42], [243, 80, 36], [285, 130, 45]].map(([x, y, w], i) => <rect key={i} x={x} y={y} width={w} height={250 - y} fill="#34527f" opacity={0.75 - (i % 3) * 0.12} />)}
      <g stroke="#0d2a5e" strokeWidth="5" opacity=".55"><path d="M110 0v250M220 0v250M0 125h330" /></g>
      <rect x="0" y="330" width="1000" height="90" fill="url(#hfloor)" />
      <ellipse cx="300" cy="372" rx="260" ry="26" fill="#d6c3a5" opacity=".55" />
      {/* تلویزیون */}
      <rect x="86" y="96" width="326" height="188" rx="6" fill="#0a0e18" />
      <rect x="94" y="103" width="310" height="173" fill="url(#htv)" />
      <path d="M94 230l60-48 50 34 50-60 70 70 80-50v100H94z" fill="#2c6c8a" opacity=".8" />
      <circle cx="330" cy="140" r="14" fill="#fff6c8" opacity=".9" />
      <rect x="236" y="284" width="14" height="22" fill="#222a36" /><rect x="190" y="304" width="110" height="8" rx="4" fill="#222a36" />
      {/* یخچال */}
      <rect x="440" y="78" width="104" height="250" rx="8" fill="url(#hmetal)" /><rect x="440" y="168" width="104" height="3" fill="#8e97a6" />
      <rect x="448" y="104" width="5" height="48" rx="2" fill="#7b8494" /><rect x="448" y="188" width="5" height="70" rx="2" fill="#7b8494" />
      {/* ماشین لباسشویی */}
      <rect x="566" y="170" width="116" height="158" rx="8" fill="#f4f6fa" /><rect x="566" y="170" width="116" height="30" rx="8" fill="#dfe5ee" />
      <circle cx="624" cy="262" r="44" fill="#cfd6e1" /><circle cx="624" cy="262" r="34" fill="#2a3a52" /><circle cx="624" cy="262" r="24" fill="#4b6a93" opacity=".8" />
      <circle cx="590" cy="186" r="5" fill="#8e97a6" /><rect x="640" y="182" width="28" height="8" rx="4" fill="#9aa4b4" />
      {/* لپ‌تاپ و موبایل */}
      <path d="M118 322h200l-14-8H132z" fill="#9aa4b4" /><rect x="140" y="268" width="156" height="50" rx="3" fill="#0f1726" transform="skewX(-3)" /><rect x="148" y="273" width="140" height="40" fill="#5c9ee8" transform="skewX(-3)" />
      <rect x="64" y="262" width="34" height="62" rx="6" fill="#18202e" /><rect x="68" y="268" width="26" height="50" rx="3" fill="#7bb4f3" />
      <rect x="338" y="282" width="34" height="62" rx="6" fill="#18202e" /><rect x="342" y="288" width="26" height="50" rx="3" fill="#a5d0ff" />
      {/* گلدان */}
      <rect x="14" y="290" width="34" height="40" rx="4" fill="#2a2f3a" /><g fill="#3e9b5b"><ellipse cx="22" cy="270" rx="9" ry="26" transform="rotate(-24 22 270)" /><ellipse cx="38" cy="268" rx="9" ry="28" transform="rotate(20 38 268)" /><ellipse cx="30" cy="262" rx="8" ry="28" /></g>
      <circle cx="728" cy="60" r="150" fill="#6aa6ff" opacity=".12" /><circle cx="860" cy="330" r="190" fill="#0a1f46" opacity=".35" />
    </svg>
  );
}

const T = ({ children, bg }: { children: React.ReactNode; bg: string }) => <svg viewBox="0 0 120 92" width="100%" height="100%" aria-hidden="true"><rect width="120" height="92" rx="10" fill={bg} />{children}</svg>;
export function ProductArt({ kind }: { kind: 'home' | 'phone' | 'watch' | 'car' | 'moto' }) {
  if (kind === 'home') return <T bg="#eaf1fb"><rect x="14" y="22" width="40" height="52" rx="4" fill="#cfd6e1" /><rect x="14" y="44" width="40" height="2" fill="#9aa4b4" /><rect x="60" y="40" width="34" height="34" rx="4" fill="#f6f8fb" /><circle cx="77" cy="58" r="11" fill="#33445f" /><rect x="64" y="14" width="46" height="26" rx="2" fill="#12192a" /><rect x="66" y="16" width="42" height="22" fill="#6aaef0" /></T>;
  if (kind === 'phone') return <T bg="#e6eefc"><rect x="34" y="12" width="26" height="62" rx="5" fill="#1a2438" /><rect x="37" y="16" width="20" height="54" rx="3" fill="#6f7de8" /><rect x="64" y="20" width="26" height="62" rx="5" fill="#0f172a" transform="rotate(8 77 51)" /><rect x="67" y="24" width="20" height="54" rx="3" fill="#43b7e8" transform="rotate(8 77 51)" /></T>;
  if (kind === 'watch') return <T bg="#eef2f8"><rect x="48" y="4" width="24" height="84" rx="8" fill="#2a3140" /><rect x="40" y="26" width="40" height="40" rx="11" fill="#0d1220" /><rect x="44" y="30" width="32" height="32" rx="8" fill="#f2f6ff" /><path d="M60 36v11l7 4" stroke="#1e6df2" strokeWidth="3" fill="none" strokeLinecap="round" /></T>;
  if (kind === 'car') return <T bg="#e9eff8"><path d="M14 62l8-18c2-5 6-8 12-8h38c6 0 10 3 14 8l12 10c4 2 6 5 6 10v2H14z" fill="#aab3c0" /><path d="M36 40h20v12H28zM60 40h12c4 0 7 3 10 8H60z" fill="#e9f3ff" /><circle cx="34" cy="66" r="9" fill="#1b2230" /><circle cx="34" cy="66" r="4" fill="#a8b2c2" /><circle cx="88" cy="66" r="9" fill="#1b2230" /><circle cx="88" cy="66" r="4" fill="#a8b2c2" /></T>;
  return <T bg="#ecf1f9"><circle cx="30" cy="62" r="14" fill="none" stroke="#1b2230" strokeWidth="5" /><circle cx="92" cy="62" r="14" fill="none" stroke="#1b2230" strokeWidth="5" /><path d="M30 62l16-22h22l10 22M46 40l-8-10h-10M68 40l12-10h8" stroke="#c1322e" strokeWidth="5" fill="none" strokeLinecap="round" strokeLinejoin="round" /><rect x="52" y="34" width="20" height="8" rx="3" fill="#1b2230" /></T>;
}

export function PhoneArt() {
  return (
    <svg viewBox="0 0 120 150" aria-hidden="true" className="phone-art">
      <rect x="30" y="6" width="62" height="130" rx="12" fill="#101828" /><rect x="35" y="14" width="52" height="114" rx="8" fill="#2a74f0" />
      <circle cx="61" cy="52" r="15" fill="#fff" opacity=".95" /><path d="M54 52a7 7 0 1 1 14 0 7 7 0 0 1-14 0Z" fill="#1e6df2" />
      <rect x="44" y="78" width="34" height="5" rx="2.5" fill="#fff" opacity=".9" /><rect x="48" y="90" width="26" height="4" rx="2" fill="#fff" opacity=".55" /><rect x="44" y="104" width="34" height="12" rx="6" fill="#fff" />
      <rect x="86" y="46" width="22" height="14" rx="4" fill="#fff" opacity=".9" /><path d="M92 53h10" stroke="#1e6df2" strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}

export const I = {
  support: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M4 14v-2a8 8 0 0 1 16 0v2" /><rect x="3" y="14" width="4" height="6" rx="1.5" /><rect x="17" y="14" width="4" height="6" rx="1.5" /><path d="M19 20a4 4 0 0 1-4 2h-2" /></svg>,
  grid: <svg viewBox="0 0 24 24" fill="currentColor"><rect x="3" y="3" width="8" height="8" rx="2.2" /><rect x="13" y="3" width="8" height="8" rx="2.2" /><rect x="3" y="13" width="8" height="8" rx="2.2" /><rect x="13" y="13" width="8" height="8" rx="2.2" /></svg>,
  user: <svg viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="7.5" r="4" /><path d="M4 21a8 8 0 0 1 16 0v1H4z" /></svg>,
  bolt: <svg viewBox="0 0 24 24" fill="currentColor"><path d="M13.5 2 5 13.5h6L10 22l9-12h-6z" /></svg>,
  shield: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3 4.5 6v5.5c0 4.6 3 8 7.5 9.5 4.5-1.5 7.5-4.9 7.5-9.5V6z" /><path d="m8.8 12.2 2.2 2.2 4.2-4.4" /></svg>,
  people: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><circle cx="8" cy="8" r="3" /><circle cx="17" cy="9.5" r="2.4" /><path d="M2.5 20c0-3.3 2.5-5.5 5.5-5.5s5.5 2.2 5.5 5.5M14.5 14.8c.8-.4 1.6-.6 2.5-.6 2.5 0 4.5 1.8 4.5 4.8" /></svg>,
  clock: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3.2 2" /></svg>,
  search: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="11" cy="11" r="6.5" /><path d="m16 16 4.5 4.5" /></svg>,
  arrow: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="m14.5 6-6 6 6 6" /></svg>,
  chev: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><path d="m9 5 7 7-7 7" /></svg>,
  tg: <svg viewBox="0 0 24 24" fill="currentColor"><path d="M21 4 3 11l5 2 2 6 3-4 5 4zM9 13l9-6-7 8z" /></svg>,
  ig: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><rect x="4" y="4" width="16" height="16" rx="5" /><circle cx="12" cy="12" r="3.6" /><circle cx="17" cy="7" r="1" fill="currentColor" /></svg>,
  inx: <svg viewBox="0 0 24 24" fill="currentColor"><path d="M5 9h3v10H5zM6.5 4.5a1.8 1.8 0 1 1 0 3.6 1.8 1.8 0 0 1 0-3.6ZM10 9h3v1.4c.6-1 1.8-1.7 3.3-1.7 2.8 0 3.7 1.8 3.7 4.5V19h-3v-5c0-1.4-.4-2.3-1.7-2.3-1.4 0-2.3 1-2.3 2.6V19h-3z" /></svg>,
  web: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18" /></svg>,
};
