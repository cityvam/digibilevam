'use client';
// کارت محاسبه‌ی اقساط (تنها جزیره‌ی تعاملی صفحه‌ی اصلی). فرمول = ContractEngine.Calc با پیش‌پرداخت صفر و کارمزد ۰٫۶٪ در ماه.
import Link from 'next/link';
import { useState } from 'react';
import { calc } from '@/lib/calc';
import { fa, money } from '@/lib/format';

const MIN = 5_000_000, MAX = 100_000_000, MONTHLY = 0.6;
export default function HeroCalc({ applyHref = '/register' }: { applyHref?: string }) {
  const [tab, setTab] = useState<'calc' | 'apply'>('calc');
  const [amount, setAmount] = useState(30_000_000);
  const [months, setMonths] = useState(12);
  const r = calc(amount, 0, MONTHLY * months, months);
  return (
    <div className="hc" data-island="HeroCalc" data-props={JSON.stringify({ applyHref })}>
      <div className="hc-tabs" role="tablist">
        <button type="button" role="tab" aria-selected={tab === 'apply'} className={tab === 'apply' ? 'on' : ''} onClick={() => setTab('apply')}>درخواست وام</button>
        <button type="button" role="tab" aria-selected={tab === 'calc'} className={tab === 'calc' ? 'on' : ''} onClick={() => setTab('calc')}>محاسبه اقساط</button>
      </div>
      {tab === 'calc' ? (
        <div className="hc-body">
          <label htmlFor="hc-amount" className="hc-l">مبلغ خرید</label>
          <div className="hc-amt"><span>تومان</span><output id="hc-amount">{money(amount)}</output></div>
          <input className="hc-range" type="range" min={MIN} max={MAX} step={1_000_000} value={amount} dir="rtl" aria-label="مبلغ خرید" onChange={(e) => setAmount(+e.target.value)} style={{ ['--p' as any]: `${((amount - MIN) / (MAX - MIN)) * 100}%` }} />
          <div className="hc-scale"><span>{money(MIN)}</span><span>{money(MAX)}</span></div>
          <div className="hc-two">
            <div><label htmlFor="hc-months" className="hc-l">مدت بازپرداخت</label>
              <select id="hc-months" value={months} onChange={(e) => setMonths(+e.target.value)}>{[3, 6, 9, 12, 18, 24, 36].map((m) => <option key={m} value={m}>{fa(m)} ماه</option>)}</select></div>
            <div><label htmlFor="hc-kind" className="hc-l">روش محاسبه سود</label>
              <select id="hc-kind" defaultValue="m"><option value="m">سود ماهانه</option></select></div>
          </div>
          <div className="hc-res"><div><small>مبلغ هر قسط (تقریبی)</small><b>{money(r.each)} <i>تومان</i></b></div><div><small>جمع کل پرداختی (تقریبی)</small><b>{money(r.total)} <i>تومان</i></b></div></div>
          <Link className="hc-go" href={applyHref.startsWith('/app/') ? `${applyHref}?amount=${amount}&months=${months}&down=0` : applyHref}>ثبت درخواست وام</Link>
        </div>
      ) : (
        <div className="hc-body">
          <p className="hc-p">درخواست آنلاین است و بیشتر مراحل بدون مراجعه حضوری انجام می‌شود:</p>
          <ol className="hc-ol"><li>ثبت‌نام با شماره موبایل</li><li>بارگذاری مدارک</li><li>بررسی و تأیید کارشناس</li><li>قبول الکترونیکی قرارداد</li></ol>
          <Link className="hc-go" href={applyHref}>{applyHref === '/register' ? 'شروع ثبت‌نام' : 'شروع درخواست'}</Link>
        </div>
      )}
    </div>
  );
}
