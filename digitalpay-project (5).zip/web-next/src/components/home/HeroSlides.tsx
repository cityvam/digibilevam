'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { I } from './art';

const SLIDES = [
  { k: 'با دیجی‌بایل، رویای خود را واقعیت تبدیل کنید.', h: <>خرید آسان، <em>اقساطی مطمئن</em><br />با بهترین طرح‌های خرید اقساطی</>, p: 'از موبایل و لوازم خانگی تا خودرو و تجهیزات دیجیتال، همه چیز برای یک خرید هوشمندانه در دیجی‌بایل فراهم است.' },
  { k: 'درخواست آنلاین، بدون مراجعه حضوری.', h: <>تأیید سریع، <em>قرارداد شفاف</em><br />و پیگیری اقساط از یک پنل</>, p: 'همه‌ی هزینه‌ها پیش از قبول قرارداد نمایش داده می‌شود و وضعیت درخواست را لحظه‌ای می‌بینید.' },
  { k: 'امنیت در هر مرحله.', h: <>ورود دومرحله‌ای، <em>مدارک رمزنگاری‌شده</em><br />و ثبت کامل رخدادها</>, p: 'اطلاعات و مدارک شما خصوصی نگهداری می‌شود و هیچ‌کس بدون مجوز به آن‌ها دسترسی ندارد.' },
];
export default function HeroSlides() {
  const [i, setI] = useState(0);
  useEffect(() => { const t = setInterval(() => setI((x) => (x + 1) % SLIDES.length), 7000); return () => clearInterval(t); }, []);
  const s = SLIDES[i];
  return (
    <div className="hs" data-island="HeroSlides">
      <button type="button" className="hs-nav hs-next" aria-label="اسلاید بعد" onClick={() => setI((i + 1) % SLIDES.length)}>{I.arrow}</button>
      <button type="button" className="hs-nav hs-prev" aria-label="اسلاید قبل" onClick={() => setI((i + SLIDES.length - 1) % SLIDES.length)}>{I.chev}</button>
      <div className="hs-text" aria-live="polite"><div className="hs-k">{s.k}</div><h1>{s.h}</h1><p>{s.p}</p><Link className="hs-cta" href="/products">مشاهده طرح‌ها <span aria-hidden="true">{I.arrow}</span></Link></div>
      <div className="hs-dots">{SLIDES.map((_, n) => <button type="button" key={n} aria-label={`اسلاید ${n + 1}`} aria-current={n === i} className={n === i ? 'on' : ''} onClick={() => setI(n)} />)}</div>
    </div>
  );
}
