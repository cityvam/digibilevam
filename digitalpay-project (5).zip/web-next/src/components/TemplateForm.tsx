export const TT: Record<string, string> = { Company: 'شرکت', Bank: 'بانک', Financier: 'تأمین‌کننده', Guarantee: 'ضمانت', Other: 'سایر' };
const d10 = (v: unknown) => (v ? String(v).slice(0, 10) : '');
export default function TemplateForm({ t, action, isSuper }: { t: any; action: (fd: FormData) => void | Promise<void>; isSuper: boolean }) {
  return (
    <form className="f card wide" action={action}>
      <label>عنوان<input name="title" defaultValue={t.title || ''} required maxLength={160} /></label>
      <div className="grid"><label>نوع<select name="type" defaultValue={t.type || 'Company'}>{Object.entries(TT).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></label>
        <label>طرف صادرکننده<input name="issuerParty" defaultValue={t.issuerParty || ''} maxLength={160} /></label>
        <label>اعتبار از<input type="date" name="validFrom" className="ltr" defaultValue={d10(t.validFrom)} /></label>
        <label>اعتبار تا<input type="date" name="validTo" className="ltr" defaultValue={d10(t.validTo)} /></label></div>
      <label>توضیح<textarea name="description" maxLength={600} defaultValue={t.description || ''} /></label>
      <label>شرایط استفاده<textarea name="usageConditions" maxLength={600} defaultValue={t.usageConditions || ''} /></label>
      <label>سربرگ (HTML)<textarea name="headerHtml" className="code" defaultValue={t.headerHtml || ''} /></label>
      <label>متن قرارداد (HTML)<small>{'متغیرها مثل {{full_name}}؛ فهرست در «متغیرهای قرارداد»'}</small><textarea name="bodyHtml" className="code tall" required defaultValue={t.bodyHtml || ''} /></label>
      <label>پابرگ (HTML)<textarea name="footerHtml" className="code" defaultValue={t.footerHtml || ''} /></label>
      <label>یادداشت تغییر<input name="changeNote" defaultValue={t.changeNote || ''} maxLength={300} /></label>
      {isSuper ? <label className="chk"><input type="checkbox" name="restricted" value="1" defaultChecked={!!t.restricted} /> اختصاصی (فقط مدیر ارشد ببیند)</label> : null}
      <button className="btn">ذخیره</button>
    </form>
  );
}
