import type { ReactNode } from 'react';
import { STATUS, tone } from '@/lib/format';

export const Badge = ({ group, s }: { group: string; s: string }) => <span className={`badge ${tone(s)}`}>{STATUS[group]?.[s] ?? s}</span>;
export const Empty = ({ children }: { children: ReactNode }) => <div className="empty">{children}</div>;
export const Stat = ({ label, value, sub }: { label: string; value: ReactNode; sub?: ReactNode }) => (
  <div className="stat"><div className="sl">{label}</div><div className="sv">{value}</div>{sub ? <div className="ss">{sub}</div> : null}</div>
);
export function Table({ heads, rows, empty = 'موردی نیست' }: { heads: string[]; rows: ReactNode[][]; empty?: string }) {
  if (!rows.length) return <Empty>{empty}</Empty>;
  return (
    <div className="tw"><table><thead><tr>{heads.map((h) => <th key={h}>{h}</th>)}</tr></thead>
      <tbody>{rows.map((r, i) => <tr key={i}>{r.map((c, j) => <td key={j} data-l={heads[j]}>{c}</td>)}</tr>)}</tbody></table></div>
  );
}
export const CapField = ({ c }: { c: { id: string; image: string } | null }) => c ? (
  <div className="cap"><img src={c.image} alt="تصویر امنیتی" width={140} height={48} />
    <input type="hidden" name="captchaId" value={c.id} />
    <label>کد تصویر<input name="captcha" className="ltr" inputMode="numeric" autoComplete="off" required /></label></div>
) : null;
export const fmtAmt = (m: (v: unknown) => string, v: unknown) => (v === null || v === undefined ? '—' : m(v) + ' تومان');
