import type { ReactNode } from 'react';
import Link from 'next/link';
import { fa } from '@/lib/format';
import { getSession, pathname, readFlash, type Session } from '@/lib/session';
import { logout } from '@/actions/auth';
import { I, Logo } from '@/components/home/art';

const CUST: [string, string][] = [['/app', 'داشبورد'], ['/app/documents', 'مدارک'], ['/app/payments', 'واریزها'], ['/app/cards', 'کارت‌ها'], ['/app/loans', 'درخواست وام'], ['/app/credit', 'اعتبارسنجی'], ['/app/contracts', 'قراردادها'], ['/app/inbox', 'اعلان‌ها'], ['/app/tickets', 'پشتیبانی'], ['/app/security', 'امنیت حساب']];
const ADMIN: [string, string][] = [['/admin', 'داشبورد'], ['/admin/contracts', 'قراردادها'], ['/admin/documents', 'مدارک'], ['/admin/loans', 'درخواست‌ها'], ['/admin/credit', 'اعتبارسنجی'], ['/admin/payments', 'واریزها'], ['/admin/tickets', 'تیکت‌ها'], ['/admin/finance', 'مالی'], ['/admin/more', 'بیشتر']];
const ADMIN_GROUPS: [string, [string, string][]][] = [
  ['', [['/admin', 'داشبورد'], ['/admin/work', 'میز کار کارشناس']]],
  ['کارشناسی', [['/admin/loans', 'درخواست‌های وام'], ['/admin/credit', 'اعتبارسنجی'], ['/admin/documents', 'مدارک'], ['/admin/payments', 'واریزها'], ['/admin/contracts', 'قراردادها'], ['/admin/tickets', 'تیکت‌ها'], ['/admin/inquiries', 'استعلام‌های دستی']]],
  ['مالی و عملیات', [['/admin/finance', 'مالی و تراز'], ['/admin/orders', 'سفارش‌ها'], ['/admin/cards', 'کارت‌های مجازی'], ['/admin/counterparties', 'طرف‌حساب‌ها'], ['/admin/marketers', 'بازاریاب‌ها']]],
  ['پیکربندی', [['/admin/products', 'طرح‌های وام'], ['/admin/templates', 'قالب‌های قرارداد'], ['/admin/variables', 'متغیرهای قرارداد'], ['/admin/roles', 'نقش‌ها و دسترسی']]],
  ['سیستم', [['/admin/jobs', 'صف کار'], ['/admin/audit', 'حسابرسی'], ['/admin/backups', 'پشتیبان‌گیری'], ['/admin/statuses', 'راهنمای وضعیت‌ها']]],
];
const PUB: [string, string][] = [['/', 'صفحه اصلی'], ['/products', 'طرح‌های خرید'], ['/register', 'درخواست وام'], ['/calculator', 'محاسبه‌گر'], ['/products#docs', 'مدارک مورد نیاز'], ['/faq', 'سوالات متداول'], ['/about', 'درباره ما']];

export async function Shell({ area, children }: { area: 'public' | 'customer' | 'admin'; children: ReactNode }) {
  const [u, path, flash] = await Promise.all([getSession(), pathname(), readFlash()]);
  const nav = area === 'admin' ? ADMIN : area === 'customer' ? CUST : PUB;
  const active = nav.map(([h]) => h).filter((h) => path === h || (h !== '/' && path.startsWith(h + '/'))).sort((a, b) => b.length - a.length)[0];
  if (area === 'admin') return <AdminShell u={u} path={path} flash={flash}>{children}</AdminShell>;
  if (area === 'public') return <PublicShell u={u} active={active} flash={flash}>{children}</PublicShell>;
  return (
    <div className={`area-${area}`}>
      <a className="skip" href="#main">رفتن به محتوا</a>
      <header className="top"><div className="wrap bar">
        <Link className="brand" href="/"><span className="logo" aria-hidden="true">د</span>دیجی‌بایل پی</Link>
        <nav aria-label="منوی اصلی">{nav.map(([h, t]) => <Link key={h} href={h} className={active === h ? 'on' : ''}>{t}</Link>)}</nav>
        <div className="who">
          {u ? (<>
            <span className="uname">{u.name || 'کاربر'}</span>
            {u.isAdmin && area !== 'admin' ? <Link className="btn sm" href="/admin">پنل مدیریت</Link> : null}
            {area === 'admin' ? <Link className="btn sm" href="/app">پنل مشتری</Link> : null}
            <form action={logout}><button className="btn sm ghost">خروج</button></form>
          </>) : (<><Link className="btn sm ghost" href="/login">ورود</Link><Link className="btn sm" href="/register">ثبت‌نام</Link></>)}
        </div>
      </div></header>
      <main id="main" className="wrap">
        {flash ? <div className={`flash ${flash.t === 'err' ? 'bad' : 'good'}`} role="status">{flash.m}</div> : null}
        {children}
      </main>
      <footer className="wrap foot">© دیجی‌بایل پی — پرداخت اقساطی امن — {fa(new Date().getFullYear() - 621)}</footer>
    </div>
  );
}

function AdminShell({ u, path, flash, children }: { u: Session | null; path: string; flash: { t: string; m: string } | null; children: ReactNode }) {
  const all = ADMIN_GROUPS.flatMap(([, xs]) => xs.map(([h]) => h)); const active = all.filter((h) => path === h || (h !== '/admin' && path.startsWith(h + '/'))).sort((a, b) => b.length - a.length)[0];
  return (
    <div className="area-admin">
      <a className="skip" href="#main">رفتن به محتوا</a>
      <header className="top"><div className="wrap bar">
        <Link className="brand" href="/admin"><span className="logo" aria-hidden="true">د</span>دیجی‌بایل پی <small className="mut">— مدیریت</small></Link>
        <span className="sp" />
        <div className="who">{u ? <><span className="uname">{u.name || 'کاربر'}</span><Link className="btn sm" href="/app">پنل مشتری</Link><form action={logout}><button className="btn sm ghost">خروج</button></form></> : null}</div>
      </div></header>
      <div className="wrap adm">
        <details className="adm-nav" open>
          <summary>منوی مدیریت</summary>
          <nav aria-label="منوی مدیریت">{ADMIN_GROUPS.map(([g, xs]) => (<div key={g || 'top'} className="adm-g">{g ? <h3>{g}</h3> : null}{xs.map(([h, t]) => <Link key={h} href={h} className={active === h ? 'on' : ''} aria-current={active === h ? 'page' : undefined}>{t}</Link>)}</div>))}</nav>
        </details>
        <main id="main">
          {flash ? <div className={`flash ${flash.t === 'err' ? 'bad' : 'good'}`} role="status">{flash.m}</div> : null}
          {children}
        </main>
      </div>
    </div>
  );
}

function PublicShell({ u, active, flash, children }: { u: Session | null; active?: string; flash: { t: string; m: string } | null; children: ReactNode }) {
  return (
    <div className="area-public">
      <a className="skip" href="#main">رفتن به محتوا</a>
      <header className="pub-top"><div className="pub-bar">
        <Link className="pub-brand" href="/" aria-label="دیجی‌بایل"><Logo size={42} /><span><b>دیجی‌بایل</b><small>بانک خرید اقساطی</small></span></Link>
        <nav aria-label="منوی اصلی">{PUB.map(([h, t]) => <Link key={h} href={h} className={active === h ? 'on' : ''}>{t}</Link>)}</nav>
        <div className="pub-who">
          {u ? (<><Link className="pub-login" href={u.isAdmin ? '/admin' : '/app'}>{u.name || 'پنل من'}</Link><form action={logout}><button className="pub-ic" aria-label="خروج" title="خروج">{I.arrow}</button></form></>)
            : (<><Link className="pub-ic" href="/products" aria-label="جستجوی طرح‌ها">{I.search}</Link><Link className="pub-login" href="/login">ورود / ثبت نام</Link></>)}
        </div>
      </div></header>
      <main id="main">
        {flash ? <div className="wrap"><div className={`flash ${flash.t === 'err' ? 'bad' : 'good'}`} role="status">{flash.m}</div></div> : null}
        <div className="pub-main">{children}</div>
      </main>
      <footer className="pub-foot"><div className="pub-foot-in">
        <Link className="pub-brand inv" href="/"><Logo size={38} /><span><b>دیجی‌بایل</b><small>بانک خرید اقساطی</small></span></Link>
        <nav aria-label="پیوندهای پایین صفحه"><Link href="/about">درباره ما</Link><Link href="/faq">پرسش‌های متداول</Link><Link href="/faq">حریم خصوصی</Link><Link href="/faq">قوانین و مقررات</Link></nav>
        <div className="soc" aria-label="شبکه‌های اجتماعی"><span>{I.tg}</span><span>{I.ig}</span><span>{I.inx}</span><span>{I.web}</span></div>
        <p>© {fa(new Date().getFullYear() - 621)} کلیه حقوق مادی و معنوی محفوظ و متعلق به دیجی‌بایل است.</p>
      </div></footer>
    </div>
  );
}
