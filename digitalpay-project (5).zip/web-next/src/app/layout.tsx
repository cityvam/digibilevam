import type { ReactNode } from 'react';
import type { Metadata, Viewport } from 'next';
import './globals.css';

export const metadata: Metadata = { title: { default: 'دیجی‌بایل پی', template: '%s | دیجی‌بایل پی' }, description: 'پلتفرم پرداخت اقساطی امن' };
export const viewport: Viewport = { width: 'device-width', initialScale: 1 };
export default function Root({ children }: { children: ReactNode }) {
  return <html lang="fa" dir="rtl"><body>{children}</body></html>;
}
