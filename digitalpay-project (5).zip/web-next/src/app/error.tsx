'use client';
export default function Err({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (<main className="wrap"><h1>مشکلی پیش آمد</h1><p className="lead">اگر تکرار شد این شناسه را به پشتیبانی بدهید: <span className="ltr">{error.digest || '—'}</span></p><button className="btn" onClick={() => reset()}>تلاش دوباره</button></main>);
}
