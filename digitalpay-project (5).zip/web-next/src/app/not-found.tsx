import Link from 'next/link';
import { Shell } from '@/components/Shell';
export const dynamic = 'force-dynamic';
export default function NotFound() { return <Shell area="public"><h1>صفحه پیدا نشد</h1><p className="lead">آدرس درست نیست یا حذف شده است.</p><Link className="btn" href="/">بازگشت به خانه</Link></Shell>; }
