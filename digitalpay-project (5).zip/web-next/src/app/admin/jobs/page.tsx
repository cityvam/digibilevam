import { api } from '@/lib/api';
import { fa, STATUS } from '@/lib/format';
import { Badge, Stat, Table } from '@/components/ui';
import { jobRetry } from '@/actions/admin';
export const metadata = { title: 'صف کارها' };
export default async function Jobs() {
  const [sm, j] = await Promise.all([api.get('/api/v1/admin/jobs/summary'), api.get('/api/v1/admin/jobs')]);
  return (<><h1>صف کارهای پس‌زمینه</h1>
    <div className="grid">{Object.entries(STATUS.job).map(([k, v]) => <Stat key={k} label={v} value={fa(sm.counts[k] || 0)} />)}<Stat label="قدیمی‌ترین کار معوق" value={fa(sm.oldestDueSeconds) + ' ثانیه'} /></div>
    <Table heads={['نوع', 'وضعیت', 'تلاش', 'خطا', '']} empty="کاری نیست" rows={j.map((x: any) => [<span key="t" className="ltr">{x.type}</span>, <Badge key="b" group="job" s={x.status} />, `${fa(x.attempts)}/${fa(x.maxAttempts)}`, x.lastError || '—', ['Failed', 'Dead'].includes(x.status) ? <form key="f" action={jobRetry.bind(null, x.id)}><button className="btn sm">تلاش مجدد</button></form> : null])} /></>);
}
