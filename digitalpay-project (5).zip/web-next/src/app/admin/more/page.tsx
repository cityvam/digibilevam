import Link from 'next/link';
export const metadata = { title: 'بیشتر' };
const MORE = [['/admin/loans', 'درخواست‌های وام', 'بررسی و تصمیم'], ['/admin/credit', 'اعتبارسنجی', 'استعلام، گزارش، ریزلاگ و تنظیمات'], ['/admin/templates', 'قالب‌های قرارداد', 'نسخه، تأیید و انتشار'], ['/admin/variables', 'متغیرهای قرارداد', 'کلیدهای {{...}}'], ['/admin/products', 'طرح‌های وام', 'فعال/غیرفعال و نمونه'], ['/admin/cards', 'کارت‌های مجازی', 'صدور و مسدودسازی'], ['/admin/counterparties', 'فروشندگان', 'طرف‌حساب و شبا'], ['/admin/marketers', 'بازاریاب‌ها', 'کد معرفی و پورسانت'], ['/admin/orders', 'سفارش خرید', 'پذیرنده و تحویل'], ['/admin/inquiries', 'استعلام‌ها', 'اعتبار و هویت'], ['/admin/audit', 'حسابرسی', 'گزارش رخدادها'], ['/admin/jobs', 'صف کارها', 'پیامک و پس‌زمینه'], ['/admin/roles', 'نقش‌ها و دسترسی', 'RBAC'], ['/admin/backups', 'پشتیبان‌گیری', 'فقط مدیر ارشد']];
export default function More() {
  return (<><h1>بخش‌های بیشتر</h1><div className="grid">{MORE.map(([h, t, d]) => <Link key={h} className="card" href={h}><h2>{t}</h2><p className="mut">{d}</p></Link>)}</div></>);
}
