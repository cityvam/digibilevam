import Link from 'next/link';
import { api } from '@/lib/api';
import { fa, jdate, short, STATUS } from '@/lib/format';
import { Badge, Table } from '@/components/ui';
export const metadata = { title: 'قراردادها' };
export default async function Contracts({ searchParams }: { searchParams: Promise<{ status?: string }> }) {
  const { status } = await searchParams; const cs: any[] = await api.get('/api/v1/admin/contracts', { status });
  return (<><div className="row"><h1>قراردادها</h1><span className="sp" /><form method="get" className="row"><select name="status" aria-label="فیلتر وضعیت" defaultValue={status ?? ''}><option value="">همه</option>{Object.entries(STATUS.contract).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select><button className="btn sm">اعمال</button></form></div>
    <Table heads={['شماره', 'عنوان', 'مشتری', 'وضعیت', 'ساخت', '']} empty="قراردادی نیست" rows={cs.map((c) => [fa(c.number), c.title, <span key="u" className="ltr">{short(c.userId)}</span>, <Badge key="b" group="contract" s={c.status} />, jdate(c.createdOn), <Link key="l" href={`/admin/contracts/${c.id}`}>بررسی</Link>])} /></>);
}
