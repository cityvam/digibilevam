import { notFound } from 'next/navigation';
import { api } from '@/lib/api';
import { fa, jdt } from '@/lib/format';
import { Badge, Empty } from '@/components/ui';
import { contractOp } from '@/actions/admin';
const OPS: Record<string, [string, string]> = { submit: ['Draft', 'ارسال برای تأیید'], return: ['ReadyForReview', 'بازگرداندن به پیش‌نویس'], approve: ['ReadyForReview', 'تأیید'], present: ['Approved', 'ارائه به مشتری'], 'request-signature': ['Presented', 'درخواست قبول'], cancel: ['*', 'لغو'] };
const EV: Record<string, string> = { Generated: 'ساخته شد', submit: 'ارسال برای تأیید', return: 'بازگردانده شد', approve: 'تأیید شد', present: 'به مشتری ارائه شد', 'request-signature': 'درخواست قبول', Viewed: 'مشاهده توسط کارمند', ViewedByCustomer: 'مشاهده توسط مشتری', Signed: 'قبول شد', Rejected: 'رد شد', Cancelled: 'لغو شد', AutoApproved: 'تأیید خودکار', Expired: 'منقضی شد' };
export default async function Contract({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [cs, ev] = await Promise.all([api.get('/api/v1/admin/contracts'), api.get(`/api/v1/admin/contracts/${encodeURIComponent(id)}/events`)]);
  const c = cs.find((x: any) => x.id === id); if (!c) notFound();
  const ops = Object.entries(OPS).filter(([op, [from]]) => (op === 'cancel' ? !['Signed', 'Rejected', 'Expired', 'Cancelled'].includes(c.status) : from === c.status));
  return (<>
    <div className="row"><h1>{c.title}</h1><span className="sp" /><Badge group="contract" s={c.status} /></div>
    <p className="mut">شماره {fa(c.number)} — نسخه‌ی قالب {fa(c.templateVersion)} — ساخت {jdt(c.createdOn)}</p>
    <div className="row">{ops.map(([op, [, label]]) => <form key={op} action={contractOp.bind(null, c.id, op)}><button className={`btn sm ${op === 'cancel' ? 'danger' : op === 'return' ? 'ghost' : ''}`}>{label}</button></form>)}</div>
    <p className="mut">تأییدکننده نمی‌تواند همان ایجادکننده باشد (به‌جز مدیر ارشد).</p>
    <div className="grid two"><div><iframe className="cframe" title="متن قرارداد" sandbox="" src={`/files/admin/contracts/${c.id}`} loading="lazy" /></div>
      <div className="card"><h2>تاریخچه</h2>{ev.length ? ev.map((h: any, i: number) => <div key={i} className="msg">{EV[h.action] || h.action}{h.note ? <> — {h.note}</> : null}<div className="meta">{jdt(h.at)} — <span className="ltr">{h.ip || ''}</span></div></div>) : <Empty>رویدادی نیست</Empty>}</div></div></>);
}
