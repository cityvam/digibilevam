import Link from 'next/link';
import { api } from '@/lib/api';
import { fa } from '@/lib/format';
import { Table } from '@/components/ui';
export const metadata = { title: 'ریزلاگ اعتبارسنجی' };
const D = /^\d{4}-\d{2}-\d{2}$/;
// ریزلاگ سمت سرویس‌دهنده (بخش ۱۱ مستند). تاریخ‌ها میلادی yyyy-mm-dd؛ شروع حداکثر ۳ ماه قبل، بازه حداکثر ۱ ماه.
export default async function Page({ searchParams }: { searchParams: Promise<{ from?: string; to?: string; sort?: string; page?: string }> }) {
  const sp = await searchParams; const page = Math.max(1, Number(sp.page) || 1); const from = D.test(sp.from || '') ? sp.from : undefined, to = D.test(sp.to || '') ? sp.to : undefined, sort = sp.sort === '1' ? '1' : '-1';
  const r = await api.try('GET', '/api/v1/admin/credit/records?' + new URLSearchParams({ ...(from ? { from } : {}), ...(to ? { to } : {}), sort, page: String(page), size: '50' }));
  const items: any[] = r.ok ? r.data?.data?.items || [] : []; const meta = r.ok ? r.data?.meta : null;
  return (<><div className="row"><h1>ریزلاگ سرویس‌دهنده</h1><span className="sp" /><Link className="btn sm ghost" href="/admin/credit">← استعلام‌ها</Link></div>
    <form className="row" method="get"><label>از (میلادی)<input name="from" type="date" defaultValue={from} /></label><label>تا<input name="to" type="date" defaultValue={to} /></label>
      <label>ترتیب<select name="sort" defaultValue={sort}><option value="-1">جدید به قدیم</option><option value="1">قدیم به جدید</option></select></label><button className="btn sm">نمایش</button></form>
    {!r.ok ? <div className="flash err" role="alert">{r.data?.message || 'دریافت ریزلاگ ممکن نشد.'}</div> : null}
    <Table heads={['زمان درخواست', 'وضعیت', 'کد ملی', 'موبایل', 'شناسه‌ی ملی شرکت', 'کد پیگیری']} empty="موردی نیست" rows={items.map((x) => [<span key="t" className="ltr">{String(x.requestTime || '').replace('T', ' ').slice(0, 16)}</span>, x.status?.detailFa || x.status?.detail || '—', <span key="n" className="ltr">{x.realNationalCode}</span>, <span key="m" className="ltr">{x.mobile}</span>, <span key="l" className="ltr">{x.legalNationalCode || '—'}</span>, <span key="h" className="ltr">{x.hashCode}</span>])} />
    {meta ? <p className="row">{meta.hasPreviousPage ? <Link href={`/admin/credit/records?page=${page - 1}&sort=${sort}${from ? `&from=${from}` : ''}${to ? `&to=${to}` : ''}`}>قبلی</Link> : null}<span className="mut">صفحه {fa(meta.page)} از {fa(meta.totalPages)} — {fa(meta.totalCount)} مورد</span>{meta.hasNextPage ? <Link href={`/admin/credit/records?page=${page + 1}&sort=${sort}${from ? `&from=${from}` : ''}${to ? `&to=${to}` : ''}`}>بعدی</Link> : null}</p> : null}</>);
}
