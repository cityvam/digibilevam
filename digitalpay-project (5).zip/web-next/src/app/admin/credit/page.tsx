import Link from 'next/link';
import { api } from '@/lib/api';
import { fa, jdt, short } from '@/lib/format';
import { CREDIT_STATUS } from '@/lib/credit';
import { Badge, Stat, Table } from '@/components/ui';
import { adminCreditStart, creditSettings } from '@/actions/admin2';
export const metadata = { title: 'اعتبارسنجی' };
export default async function Page({ searchParams }: { searchParams: Promise<{ status?: string; q?: string; page?: string; test?: string }> }) {
  const sp = await searchParams; const page = Math.max(1, Number(sp.page) || 1);
  const [list, h] = await Promise.all([
    api.get('/api/v1/admin/credit', { status: sp.status || undefined, q: sp.q || undefined, page }),
    api.soft('/api/v1/admin/credit/health', { test: sp.test === '1' ? 'true' : undefined })]);
  const st = h?.settings; const items: any[] = list.items || [];
  return (<><div className="row"><h1>اعتبارسنجی</h1><span className="sp" /><Link className="btn sm ghost" href="/admin/credit/records">ریزلاگ سرویس‌دهنده</Link></div>
    {h ? (<><div className="grid"><Stat label="اتصال به سرویس‌دهنده" value={h.configured ? 'تنظیم‌شده ✓' : 'تنظیم نشده ✗'} sub={h.test ? (h.test.ok ? `ورود موفق (${fa(h.test.ms)}ms)` : h.test.message) : <Link href="/admin/credit?test=1">تست ورود</Link>} />
      <Stat label="کال‌بک" value={h.callbackConfigured ? 'راز تنظیم‌شده ✓' : 'راز تنظیم نشده'} sub="آدرس /api/v1/credit/callback/‹راز›" />
      <Stat label="۳۰ روز اخیر" value={fa(h.stats?.total ?? 0)} sub={`آماده ${fa(h.stats?.ready ?? 0)} · ناموفق ${fa(h.stats?.failed ?? 0)} · باز ${fa(h.stats?.open ?? 0)}`} /></div>
      {!h.configured ? <div className="flash err">ابتدا MyCredit:BaseUrl، Username، Password و ApiKey را در پیکربندی محرمانه‌ی سرور بگذارید و IP سرور را به شرکت اعتبارسنجی ایران بدهید.</div> : null}</>) : null}
    <form className="row" method="get"><select name="status" defaultValue={sp.status || ''}><option value="">همه‌ی وضعیت‌ها</option>{Object.entries(CREDIT_STATUS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
      <input name="q" defaultValue={sp.q || ''} placeholder="کد، کد ملی یا موبایل (ابتدای شماره)" className="ltr" maxLength={20} /><button className="btn sm">جستجو</button></form>
    <Table heads={['کد', 'مشتری', 'کد ملی', 'وضعیت', 'منبع', 'ثبت', '']} empty="استعلامی نیست" rows={items.map(({ v, userId }) => [<span key="c" className="ltr">{v.code}</span>, <span key="u" className="ltr">{short(userId)}</span>, <span key="n" className="ltr">{v.ncMask}</span>, <Badge key="b" group="credit" s={v.status} />, v.source === 'Admin' ? 'مدیر' : 'مشتری', jdt(v.createdOn), <Link key="l" href={`/admin/credit/${v.id}`}>باز کردن</Link>])} />
    <p className="row">{page > 1 ? <Link href={`/admin/credit?page=${page - 1}${sp.status ? `&status=${encodeURIComponent(sp.status)}` : ''}`}>قبلی</Link> : null}<span className="mut">صفحه {fa(page)} — {fa(list.total || 0)} مورد</span>{page * 50 < (list.total || 0) ? <Link href={`/admin/credit?page=${page + 1}${sp.status ? `&status=${encodeURIComponent(sp.status)}` : ''}`}>بعدی</Link> : null}</p>
    <div className="grid two">
      <form className="f card" action={adminCreditStart}><h2>استعلام برای مشتری</h2>
        <label>شناسه‌ی مشتری (Guid)<input name="userId" className="ltr" required pattern="[0-9a-fA-F\-]{36}" /></label>
        <label>کد ملی<input name="nc" className="ltr" inputMode="numeric" required maxLength={10} /></label><label>موبایل<input name="mobile" className="ltr" inputMode="tel" required maxLength={11} /></label>
        <label>شناسه‌ی ملی شرکت (اختیاری)<input name="legal" className="ltr" inputMode="numeric" maxLength={11} /></label>
        <label className="chk"><input type="checkbox" name="consent" value="1" required /> رضایت‌نامه‌ی استعلام را مشتری تأیید کرده است.</label><button className="btn">ارسال رمز به مشتری</button></form>
      {st ? <form className="f card" action={creditSettings}><h2>تنظیمات</h2>
        <label className="chk"><input type="checkbox" name="enabled" value="1" defaultChecked={st.enabled} /> استعلام فعال باشد</label>
        <label className="chk"><input type="checkbox" name="autoFetch" value="1" defaultChecked={st.autoFetchReport} /> محتوای گزارش پس از آماده‌شدن خودکار گرفته شود (اعتبار ۴۸ ساعت)</label>
        <label>مدت نگهداری گزارش (روز)<input name="retentionDays" className="ltr" inputMode="numeric" defaultValue={st.retentionDays} required /></label>
        <label>حداقل امتیاز مجاز <span className="mut">(اختیاری)</span><input name="minScore" className="ltr" inputMode="numeric" defaultValue={st.minScore ?? ''} /></label><button className="btn">ذخیره</button></form> : null}</div></>);
}
