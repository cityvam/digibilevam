import Link from 'next/link';
import { notFound } from 'next/navigation';
import { api } from '@/lib/api';
import { fa, jdt } from '@/lib/format';
import { ReportTree } from '@/components/ReportTree';
export const metadata = { title: 'گزارش اعتباری' };
// دیدن محتوای گزارش نیازمند مجوز credit.report است و سمت API در ردپا ثبت می‌شود.
export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params; const r = await api.soft(`/api/v1/admin/credit/${encodeURIComponent(id)}/report`); if (!r) notFound();
  return (<><div className="row"><h1>گزارش اعتباری <span className="ltr">{r.request.code}</span></h1><span className="sp" /><a className="btn sm" href={`/files/admin/credit/${r.request.id}`}>PDF</a></div>
    <p className="mut">{r.request.score != null ? <>امتیاز {fa(r.request.score)} — </> : null}دریافت {jdt(r.request.reportAt)} — اعتبار تا {jdt(r.request.reportExpiresOn)}. اطلاعات حساس است؛ از آن برای تصمیم‌گیری درباره‌ی همین درخواست استفاده کنید.</p>
    <div className="card"><ReportTree data={r.report} /></div><p><Link href={`/admin/credit/${r.request.id}`}>← بازگشت</Link></p></>);
}
