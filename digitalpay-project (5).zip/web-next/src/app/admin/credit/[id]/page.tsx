import Link from 'next/link';
import { notFound } from 'next/navigation';
import { api } from '@/lib/api';
import { fa, jdt, short } from '@/lib/format';
import { awaitingOtp, EV_OP, SMS_STATUS } from '@/lib/credit';
import { Badge, Table } from '@/components/ui';
import { adminCreditOp, adminCreditOtp } from '@/actions/admin2';
export const metadata = { title: 'استعلام اعتباری' };
export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params; const d = await api.soft(`/api/v1/admin/credit/${encodeURIComponent(id)}`); if (!d) notFound(); const v = d.request, ev: any[] = d.events || [];
  return (<><div className="row"><h1>استعلام <span className="ltr">{v.code}</span></h1><span className="sp" /><Badge group="credit" s={v.status} /></div>
    <p className="mut">مشتری <span className="ltr">{short(d.userId)}</span> — کد ملی <span className="ltr">{v.ncMask}</span> — موبایل <span className="ltr">{v.mobileMask}</span>{v.legal ? ' — شخص حقوقی' : ''} — منبع {v.source === 'Admin' ? 'مدیر' : 'مشتری'}</p>
    <div className="card"><div className="rvs">
      <div className="rv"><b>ارسال رمز</b><span>{fa(v.otpSends)} از {fa(v.maxOtpSends)}{v.resendLocked ? ' (قفل)' : ''}</span></div>
      <div className="rv"><b>وضعیت پیامک رمز</b><span>{v.otpMessageStatus ? SMS_STATUS[v.otpMessageStatus] || fa(v.otpMessageStatus) : '—'}</span></div>
      <div className="rv"><b>وضعیت پیامک لینک گزارش</b><span>{v.reportMessageStatus ? SMS_STATUS[v.reportMessageStatus] || fa(v.reportMessageStatus) : '—'}</span></div>
      <div className="rv"><b>اعتبار درخواست</b><span>{jdt(v.hashExpiresOn)}</span></div><div className="rv"><b>اعتبار دریافت گزارش</b><span>{jdt(v.reportExpiresOn)}</span></div>
      <div className="rv"><b>امتیاز</b><span>{v.score != null ? fa(v.score) : '—'}</span></div><div className="rv"><b>خطای آخر</b><span>{v.lastError || '—'}</span></div></div></div>
    <div className="row">
      <form action={adminCreditOp.bind(null, v.id, 'refresh')}><button className="btn sm ghost">پرسش وضعیت</button></form>
      {awaitingOtp(v) ? <form action={adminCreditOp.bind(null, v.id, 'resend')}><button className="btn sm ghost" disabled={v.resendLocked}>ارسال مجدد رمز</button></form> : null}
      {v.canRegenerate ? <form action={adminCreditOp.bind(null, v.id, 'regenerate')}><button className="btn sm">بازتولید گزارش</button></form> : null}
      {v.reportReady ? <><Link className="btn sm" href={`/admin/credit/${v.id}/report`}>دیدن گزارش</Link><a className="btn sm ghost" href={`/files/admin/credit/${v.id}`}>PDF</a></> : null}</div>
    {awaitingOtp(v) ? <form className="f card" action={adminCreditOtp.bind(null, v.id)}><h2>ثبت رمز از طرف مشتری</h2><label>رمز<input name="token" className="ltr" inputMode="numeric" required maxLength={8} autoComplete="off" /></label><button className="btn">ثبت</button></form> : null}
    <h2>ردپای تماس‌ها</h2><Table heads={['زمان', 'نوع', 'عملیات', 'نتیجه', 'کد خطا', 'مدت', 'کاربر']} empty="رویدادی نیست" rows={ev.map((e) => [jdt(e.createdOn), e.kind, EV_OP[e.op] || e.op, <span key="o" className={`badge ${e.ok ? 'good' : 'bad'}`}>{e.ok ? 'موفق' : 'ناموفق'}</span>, <span key="r" className="ltr" title={e.message}>{e.reason || '—'}</span>, e.ms ? `${fa(e.ms)}ms` : '—', e.actorId ? <span key="a" className="ltr">{short(e.actorId)}</span> : '—'])} />
    <p><Link href="/admin/credit">← همه‌ی استعلام‌ها</Link></p></>);
}
