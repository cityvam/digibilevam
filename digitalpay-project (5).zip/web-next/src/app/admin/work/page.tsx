import Link from 'next/link';
import { ago, fa } from '@/lib/format';
import { loadQueues } from '@/lib/queues';
import { Empty } from '@/components/ui';
export const metadata = { title: 'میز کار کارشناس' };
export default async function Page({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const sp = await searchParams; const qs = (await loadQueues()).filter((q) => q.ok); const pick = qs.find((q) => q.key === sp.q); const list = pick ? [pick] : qs;
  return (<><h1>میز کار کارشناس</h1>
    <p className="mut">قدیمی‌ترین موردها بالاست. موردی که بیش از ۲۴ ساعت مانده (یا تیکتِ دیرکرد) با «فوری» علامت می‌خورد. اقدام‌ها داخل صفحه‌ی هر مورد انجام می‌شود.</p>
    <nav className="row" aria-label="صف‌ها"><Link className={`btn sm ${pick ? 'ghost' : ''}`} href="/admin/work">همه</Link>{qs.map((q) => <Link key={q.key} className={`btn sm ${pick?.key === q.key ? '' : 'ghost'}`} href={`/admin/work?q=${q.key}`}>{q.label} ({fa(q.count)})</Link>)}</nav>
    {list.length ? list.map((q) => (<section key={q.key} className="card" aria-labelledby={'q-' + q.key}>
      <div className="qh"><h2 id={'q-' + q.key}>{q.label}</h2><small>{fa(q.count)} مورد — اقدام‌ها: {q.actions}</small><span className="sp" /><Link href={q.href}>همه‌ی موردها</Link></div>
      {q.items.length ? q.items.slice(0, pick ? 100 : 6).map((i) => (<div key={i.id} className="qi"><div><b>{i.title}</b><span className="mut">{i.sub}</span></div>
        <div className="row">{i.hot ? <span className="badge bad">فوری</span> : null}<span className="mut">{ago(i.at)}</span><Link className="btn sm" href={i.href}>بررسی</Link></div></div>)) : <Empty>مورد بازی نیست ✓</Empty>}
      {!pick && q.items.length > 6 ? <p className="mut"><Link href={`/admin/work?q=${q.key}`}>{fa(q.items.length - 6)} مورد دیگر…</Link></p> : null}</section>)) : <Empty>صف کاری برای نقش شما نشان داده نمی‌شود.</Empty>}</>);
}
