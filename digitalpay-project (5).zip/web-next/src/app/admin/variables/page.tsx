import { api } from '@/lib/api';
import { Table } from '@/components/ui';
import { addVariable, deleteVariable, syncVariables } from '@/actions/admin2';
export const metadata = { title: 'متغیرهای قرارداد' };
export default async function Page() {
  const vs: any[] = await api.get('/api/v1/admin/contract-variables');
  return (<><div className="row"><h1>متغیرهای قرارداد</h1><span className="sp" /><form action={syncVariables}><button className="btn sm ghost">افزودن متغیرهای پیش‌فرض جاافتاده</button></form></div>
    <div className="stack"><Table heads={['کلید', 'عنوان', 'نوع', 'منبع', 'الزامی', 'حساس', '']} empty="متغیری نیست" rows={vs.map((v) => [<code key="k" className="ltr">{'{{' + v.key + '}}'}</code>, v.label, v.dataType, v.source + (v.path ? ' / ' + v.path : ''), v.required ? 'بله' : '—', v.sensitivity === 'Sensitive' ? <span key="s" className="badge warn">حساس</span> : '—',
      <form key="d" action={deleteVariable.bind(null, v.id)}><button className="btn sm danger">حذف</button></form>])} />
      <form className="f card" action={addVariable}><h2>متغیر جدید</h2>
        <label>کلید<small>حروف کوچک انگلیسی، عدد و _</small><input name="key" className="ltr" required pattern="[a-z][a-z0-9_]{1,59}" /></label><label>عنوان<input name="label" required maxLength={120} /></label>
        <div className="grid"><label>نوع<select name="dataType"><option>text</option><option>number</option><option>money</option><option>date</option></select></label><label>منبع<select name="source"><option>applicant</option><option>document</option><option>loan</option><option>party</option><option>system</option><option>custom</option></select></label></div>
        <label>مسیر منبع (برای منبع «custom» خالی بماند)<input name="path" className="ltr" maxLength={60} /></label><label>مقدار پیش‌فرض (برای custom)<input name="defaultValue" maxLength={200} /></label>
        <label className="chk"><input type="checkbox" name="required" value="1" /> الزامی</label><label className="chk"><input type="checkbox" name="sensitive" value="1" /> حساس (در متن پنهان/ماسک می‌شود)</label><button className="btn">افزودن</button></form></div></>);
}
