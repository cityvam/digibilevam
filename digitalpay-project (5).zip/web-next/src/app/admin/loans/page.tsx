import Link from 'next/link';
import { api } from '@/lib/api';
import { fa, jdt, money, short, STATUS } from '@/lib/format';
import { Badge, Table } from '@/components/ui';
export const metadata = { title: 'درخواست‌های وام' };
export default async function Page({ searchParams }: { searchParams: Promise<{ status?: string; q?: string; page?: string }> }) {
  const sp = await searchParams; const page = Math.max(1, Number(sp.page) || 1);
  const d = await api.get('/api/v1/admin/loan-applications', { status: sp.status || undefined, q: sp.q || undefined, page }); const items: any[] = d.items || [];
  return (<><h1>درخواست‌های وام</h1>
    <form className="row" method="get"><select name="status" defaultValue={sp.status || ''}><option value="">همه‌ی وضعیت‌ها</option>{Object.entries(STATUS.loanapp).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
      <input name="q" defaultValue={sp.q || ''} placeholder="کد یا نام طرح" maxLength={40} /><button className="btn sm">جستجو</button></form>
    <Table heads={['کد', 'مشتری', 'طرح', 'مبلغ', 'مدت', 'اعتبار', 'وضعیت', 'ثبت', '']} empty="درخواستی نیست" rows={items.map(({ v, userId }) => [<span key="c" className="ltr">{v.code}</span>, <span key="u" className="ltr">{short(userId)}</span>, v.productName, `${money(v.amount)} تومان`, `${fa(v.months)} ماه`, v.creditScore != null ? fa(v.creditScore) : '—', <Badge key="b" group="loanapp" s={v.status} />, jdt(v.createdOn), <Link key="l" href={`/admin/loans/${v.id}`}>بررسی</Link>])} />
    <p className="mut">{fa(d.total || 0)} مورد — صفحه {fa(page)}</p></>);
}
