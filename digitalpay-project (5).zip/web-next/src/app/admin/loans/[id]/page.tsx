import Link from 'next/link';
import { notFound } from 'next/navigation';
import { api } from '@/lib/api';
import { fa, jdt, money, short, STATUS } from '@/lib/format';
import { Badge } from '@/components/ui';
import { reviewLoanApp } from '@/actions/admin2';
export const metadata = { title: 'بررسی درخواست وام' };
export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params; const d = await api.soft(`/api/v1/admin/loan-applications/${encodeURIComponent(id)}`); if (!d) notFound(); const a = d.application, ev: any[] = d.events || [], next: string[] = d.next || [];
  return (<><div className="row"><h1>درخواست <span className="ltr">{a.code}</span></h1><span className="sp" /><Badge group="loanapp" s={a.status} /></div>
    <p className="mut">مشتری <span className="ltr">{short(d.userId)}</span> — {a.productName} — ثبت {jdt(a.createdOn)} — درخواست‌های قبلی این مشتری: {fa(d.priorApplications ?? 0)}</p>
    <div className="grid two"><div className="card"><h2>شرایط</h2><dl className="kv"><dt>مبلغ خرید</dt><dd>{money(a.amount)} تومان</dd><dt>پیش‌پرداخت ({fa(a.downPercent)}٪)</dt><dd>{money(a.down)} تومان</dd><dt>مبلغ تسهیلات</dt><dd>{money(a.financed)} تومان</dd><dt>کارمزد ({fa(a.feePercent)}٪)</dt><dd>{money(a.fee)} تومان</dd>
      <dt>مدت</dt><dd>{fa(a.months)} ماه</dd><dt>هر قسط / آخر</dt><dd>{money(a.each)} / {money(a.last)} تومان</dd><dt>جمع کل</dt><dd>{money(a.total)} تومان</dd></dl>{a.customerNote ? <p>توضیح مشتری: {a.customerNote}</p> : null}</div>
      <div className="card"><h2>اعتبارسنجی</h2>{d.credit ? <><p>وضعیت: <Badge group="credit" s={d.credit.status} />{d.credit.score != null ? <> — امتیاز <b>{fa(d.credit.score)}</b></> : null}</p><p><Link href={`/admin/credit/${d.credit.id}`}>جزئیات استعلام</Link> · <Link href={`/admin/credit/${d.credit.id}/report`}>دیدن گزارش</Link></p></> : <p className="mut">گزارش اعتباری پیوست نشده است. می‌توانید از <Link href="/admin/credit">بخش اعتبارسنجی</Link> استعلام بگیرید.</p>}</div></div>
    {next.length ? (<form className="f card" action={reviewLoanApp.bind(null, a.id)}><h2>تصمیم</h2>
      <label>وضعیت جدید<select name="status" required>{next.map((s) => <option key={s} value={s}>{STATUS.loanapp[s]}</option>)}</select></label>
      <label>پیام برای مشتری <span className="mut">(برای رد یا درخواست اطلاعات الزامی)</span><textarea name="note" maxLength={500} /></label><button className="btn">ثبت تصمیم</button></form>) : <p className="mut">این درخواست به وضعیت نهایی رسیده است.</p>}
    <h2>تاریخچه</h2><ol className="tl">{ev.map((e, i) => <li key={i}><b>{STATUS.loanapp[e.toStatus] || e.toStatus}</b> <span className="mut">{jdt(e.createdOn)}{e.actorId ? <> — <span className="ltr">{short(e.actorId)}</span></> : null}</span>{e.note ? <div>{e.note}</div> : null}</li>)}</ol>
    <p><Link href="/admin/loans">← همه‌ی درخواست‌ها</Link></p></>);
}
