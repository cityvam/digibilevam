import { api } from '@/lib/api';
import { money, short } from '@/lib/format';
import { Table } from '@/components/ui';
import MoneyInput from '@/components/MoneyInput';
import { addOrder, orderStatus } from '@/actions/admin2';
export const metadata = { title: 'سفارش‌ها' };
const ORD: Record<string, [string, string]> = { Pending: ['در انتظار', 'warn'], Delivered: ['تحویل شد', 'good'], Cancelled: ['لغو شد', 'mute'] };
export default async function Page() {
  const os: any[] = await api.get('/api/v1/admin/orders');
  return (<><h1>سفارش‌های خرید</h1><div className="stack">
    <Table heads={['کد', 'پذیرنده', 'مبلغ', 'مشتری', 'وضعیت', '']} empty="سفارشی نیست" rows={os.map((o) => [<span key="c" className="ltr">{o.code}</span>, o.merchantName, money(o.amount), <span key="u" className="ltr">{short(o.userId)}</span>,
      <span key="s" className={`badge ${ORD[o.status]?.[1] || 'mute'}`}>{ORD[o.status]?.[0] || o.status}</span>,
      o.status === 'Pending' ? <div key="o" className="row"><form action={orderStatus.bind(null, o.id, 'Delivered')}><button className="btn sm">تحویل شد</button></form><form action={orderStatus.bind(null, o.id, 'Cancelled')}><button className="btn sm danger">لغو</button></form></div> : null])} />
    <form className="f card" action={addOrder}><h2>سفارش جدید</h2><label>شناسه‌ی مشتری (Guid)<input name="userId" className="ltr" required pattern="[0-9a-fA-F\-]{36}" /></label>
      <label>شناسه‌ی وام (اختیاری)<input name="loanId" className="ltr" pattern="[0-9a-fA-F\-]{36}" /></label><label>پذیرنده<input name="merchant" required maxLength={120} /></label>
      <label>مبلغ (تومان)<MoneyInput name="amount" required /></label><button className="btn">ثبت</button></form></div></>);
}
