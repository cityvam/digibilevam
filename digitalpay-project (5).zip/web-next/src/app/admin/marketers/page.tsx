import { api } from '@/lib/api';
import { fa } from '@/lib/format';
import { Table } from '@/components/ui';
import { addMarketer, toggleMarketer } from '@/actions/admin2';
export const metadata = { title: 'بازاریاب‌ها' };
export default async function Page() {
  const ms: any[] = await api.get('/api/v1/admin/marketers');
  return (<><h1>بازاریاب‌ها</h1><div className="stack">
    <Table heads={['نام', 'موبایل', 'کد معرفی', 'پورسانت', 'وضعیت', '']} empty="بازاریابی ثبت نشده" rows={ms.map((m) => [m.name, <span key="p" className="ltr">{m.phone}</span>, <span key="c" className="ltr">{m.code}</span>, fa(m.commissionPercent) + '٪',
      m.isActive ? <span key="s" className="badge good">فعال</span> : <span key="s" className="badge mute">غیرفعال</span>,
      <form key="f" action={toggleMarketer.bind(null, m.id, m.name, m.phone, m.commissionPercent, !m.isActive)}><button className="btn sm ghost">{m.isActive ? 'غیرفعال کن' : 'فعال کن'}</button></form>])} />
    <form className="f card" action={addMarketer}><h2>بازاریاب جدید</h2><label>نام<input name="name" required maxLength={120} /></label><label>موبایل<input name="phone" className="ltr" inputMode="tel" required /></label>
      <label>پورسانت (درصد)<input name="commission" className="ltr" inputMode="decimal" required /></label><button className="btn">افزودن</button></form></div></>);
}
