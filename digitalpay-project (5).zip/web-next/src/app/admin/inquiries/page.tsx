import { api } from '@/lib/api';
import { jdt, short } from '@/lib/format';
import { Table } from '@/components/ui';
import { addInquiry, inquiryResult } from '@/actions/admin2';
export const metadata = { title: 'استعلام‌ها' };
const INQ: Record<string, string> = { Credit: 'اعتبارسنجی', Identity: 'احراز هویت', Other: 'سایر' };
const INQS: Record<string, [string, string]> = { Queued: ['در صف', 'warn'], Done: ['انجام شد', 'good'], Failed: ['ناموفق', 'bad'] };
export default async function Page() {
  const xs: any[] = await api.get('/api/v1/admin/inquiries');
  return (<><h1>استعلام‌ها</h1><div className="stack">
    <Table heads={['نوع', 'مشتری', 'وضعیت', 'نتیجه', 'ثبت', '']} empty="استعلامی نیست" rows={xs.map((x) => [INQ[x.type] || x.type, <span key="u" className="ltr">{short(x.userId)}</span>,
      <span key="s" className={`badge ${INQS[x.status]?.[1] || 'mute'}`}>{INQS[x.status]?.[0] || x.status}</span>, x.result || '—', jdt(x.createdOn),
      x.status === 'Queued' ? <form key="f" className="row" action={inquiryResult.bind(null, x.id)}><input name="result" placeholder="نتیجه" maxLength={300} /><button className="btn sm" name="status" value="Done">ثبت نتیجه</button><button className="btn sm danger" name="status" value="Failed">ناموفق</button></form> : null])} />
    <form className="f card" action={addInquiry}><h2>استعلام جدید</h2><label>شناسه‌ی مشتری (Guid)<input name="userId" className="ltr" required pattern="[0-9a-fA-F\-]{36}" /></label>
      <label>نوع<select name="type">{Object.entries(INQ).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></label><label>یادداشت<input name="note" maxLength={300} /></label><button className="btn">ثبت</button></form></div></>);
}
