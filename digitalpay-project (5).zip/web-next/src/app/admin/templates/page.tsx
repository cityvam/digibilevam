import Link from 'next/link';
import { api } from '@/lib/api';
import { fa, jdate } from '@/lib/format';
import { Table } from '@/components/ui';
import { TT } from '@/components/TemplateForm';
export const metadata = { title: 'قالب‌های قرارداد' };
const TS: Record<string, [string, string]> = { Draft: ['پیش‌نویس', 'warn'], Approved: ['تأییدشده', 'info'], Published: ['منتشرشده', 'good'], Archived: ['بایگانی', 'mute'] };
export default async function Page() {
  const ts: any[] = await api.get('/api/v1/admin/contract-templates');
  return (<><div className="row"><h1>قالب‌های قرارداد</h1><span className="sp" /><Link className="btn" href="/admin/templates/new">قالب جدید</Link></div>
    <Table heads={['عنوان', 'نوع', 'نسخه', 'وضعیت', 'اعتبار', '']} empty="قالبی تعریف نشده" rows={ts.map((t) => [t.title, TT[t.type] || t.type, fa(t.version), <span key="s" className={`badge ${TS[t.status]?.[1] || 'mute'}`}>{TS[t.status]?.[0] || t.status}</span>,
      `${jdate(t.validFrom)} تا ${t.validTo ? jdate(t.validTo) : 'نامحدود'}`, <Link key="l" href={`/admin/templates/${t.id}`}>باز کردن</Link>])} /></>);
}
