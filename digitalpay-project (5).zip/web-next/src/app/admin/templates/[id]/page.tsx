import { api } from '@/lib/api';
import { fa, jdate } from '@/lib/format';
import TemplateForm, { TT } from '@/components/TemplateForm';
import { readOnce, requireUser } from '@/lib/session';
import { approveTemplate, archiveTemplate, newVersion, publishTemplate, saveTemplate, uploadSample, validateTemplate } from '@/actions/admin2';
const TS: Record<string, [string, string]> = { Draft: ['پیش‌نویس', 'warn'], Approved: ['تأییدشده', 'info'], Published: ['منتشرشده', 'good'], Archived: ['بایگانی', 'mute'] };
export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params; const u = await requireUser(true);
  const [t, once] = await Promise.all([api.get(`/api/v1/admin/contract-templates/${encodeURIComponent(id)}`), readOnce<{ problems?: string[] }>()]);
  const problems = once?.problems;
  const Act = ({ op, label, cls = '', fn }: { op: string; label: string; cls?: string; fn: (id: string) => Promise<void> }) => <form key={op} action={fn.bind(null, t.id)}><button className={`btn sm ${cls}`}>{label}</button></form>;
  return (<>
    <div className="row"><h1>{t.title}</h1><span className="sp" /><span className={`badge ${TS[t.status]?.[1] || 'mute'}`}>{TS[t.status]?.[0] || t.status}</span><span className="badge mute">نسخه {fa(t.version)}</span></div>
    {problems?.length ? <div className="flash bad"><strong>مشکل‌های قالب:</strong><ul>{problems.map((p, i) => <li key={i}>{p}</li>)}</ul></div> : problems ? <div className="flash good">مشکلی در قالب پیدا نشد.</div> : null}
    <div className="row">
      {t.status === 'Draft' ? <><Act op="validate" label="اعتبارسنجی" cls="ghost" fn={validateTemplate as any} /><Act op="approve" label="تأیید" fn={approveTemplate as any} /></> : null}
      {t.status === 'Approved' ? <Act op="publish" label="انتشار" fn={publishTemplate as any} /> : null}
      {t.status === 'Published' ? <Act op="nv" label="نسخه‌ی جدید" fn={newVersion as any} /> : null}
      {t.status !== 'Archived' ? <Act op="archive" label="بایگانی" cls="danger" fn={archiveTemplate as any} /> : null}</div>
    <p className="mut">تأییدکننده نمی‌تواند همان سازنده باشد (به‌جز مدیر ارشد). فقط پیش‌نویس ویرایش می‌شود؛ برای تغییر نسخه‌ی منتشرشده، نسخه‌ی جدید بسازید.</p>
    <div className="grid two"><div>{t.status === 'Draft' ? <TemplateForm t={t} action={saveTemplate.bind(null, t.id)} isSuper={u.isSuper} /> :
      <div className="card"><dl className="kv"><dt>نوع</dt><dd>{TT[t.type] || t.type}</dd><dt>صادرکننده</dt><dd>{t.issuerParty || '—'}</dd><dt>اعتبار</dt><dd>{jdate(t.validFrom)} تا {t.validTo ? jdate(t.validTo) : 'نامحدود'}</dd><dt>یادداشت</dt><dd>{t.changeNote || '—'}</dd></dl><p className="mut">برای ویرایش، نسخه‌ی جدید بسازید.</p></div>}</div>
      <div className="card"><h2>فایل نمونه (PDF یا Word)</h2>
        {t.sampleFileName ? <p>فایل فعلی: <span className="ltr">{t.sampleFileName}</span> — <a href={`/files/admin/templates/${t.id}/sample`}>دانلود</a></p> : <p className="mut">فایلی بارگذاری نشده.</p>}
        <form className="f" action={uploadSample.bind(null, t.id)}><label>فایل (تا ۵ مگابایت)<input type="file" name="file" accept=".pdf,.doc,.docx" required /></label><button className="btn sm">بارگذاری</button></form></div>
      <div className="card"><h2>پیش‌نمایش با داده‌ی نمونه</h2><iframe className="cframe" title="پیش‌نمایش قالب" sandbox="" src={`/files/admin/templates/${t.id}/preview`} loading="lazy" /></div></div></>);
}
