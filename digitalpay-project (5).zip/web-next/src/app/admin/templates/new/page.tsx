import TemplateForm from '@/components/TemplateForm';
import { requireUser } from '@/lib/session';
import { createTemplate } from '@/actions/admin2';
export const metadata = { title: 'قالب جدید' };
export default async function Page() {
  const u = await requireUser(true);
  return (<><h1>قالب جدید</h1><TemplateForm t={{ type: 'Company' }} action={createTemplate} isSuper={u.isSuper} /><p className="mut">متن قرارداد بعد از ساخت قابل ویرایش است تا زمانی که پیش‌نویس باشد.</p></>);
}
