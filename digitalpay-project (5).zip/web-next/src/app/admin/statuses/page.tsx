import Link from 'next/link';
import { CREDIT_STATUS } from '@/lib/credit';
import { STATUS } from '@/lib/format';
export const metadata = { title: 'راهنمای وضعیت‌ها' };
type Row = [string, string, string, string?];   // [وضعیت، معنی، چه کسی/چه می‌شود کرد، پیوند]
const BLOCKS: { title: string; where: string; href: string; rows: Row[] }[] = [
  { title: 'درخواست وام مشتری', where: 'مجوز loans.view / loans.review', href: '/admin/loans', rows: [
    ['Submitted', 'مشتری ثبت کرده و کسی ندیده است', 'کارشناس: در حال بررسی · نیاز به اطلاعات · تأیید · رد'], ['InReview', 'کارشناس در حال بررسی است', 'کارشناس: نیاز به اطلاعات · تأیید · رد'],
    ['NeedInfo', 'منتظر مدرک/توضیح مشتری', 'مشتری مدرک می‌دهد؛ کارشناس دوباره «در حال بررسی»، تأیید یا رد می‌کند'], ['Approved', 'نهایی؛ مشتری اعلان می‌گیرد', 'قرارداد از بخش قراردادها ساخته و ارائه می‌شود'], ['Rejected', 'نهایی؛ علت برای مشتری فرستاده می‌شود', 'تغییرناپذیر'], ['Cancelled', 'مشتری لغو کرده', 'تغییرناپذیر']] },
  { title: 'قرارداد', where: 'تأیید باید توسط فردی غیر از سازنده باشد (مگر ارشد)', href: '/admin/contracts', rows: [
    ['Draft', 'پیش‌نویس ساخته‌شده', 'ارسال برای تأیید · لغو'], ['ReadyForReview', 'منتظر تأیید کارشناس دوم', 'تأیید · بازگرداندن به پیش‌نویس · لغو'], ['Approved', 'تأییدشده', 'ارائه به مشتری · لغو'],
    ['Presented', 'به مشتری ارائه شد (۷ روز اعتبار)', 'درخواست امضا · لغو'], ['AwaitingSignature', 'منتظر قبول/رد مشتری', 'مشتری قبول یا رد می‌کند؛ کارشناس می‌تواند لغو کند'], ['Signed', 'قبول‌شده؛ نهایی', 'تغییرناپذیر (متن و هش ثابت)'], ['Rejected', 'مشتری رد کرده', 'تغییرناپذیر'], ['Expired', 'مهلت تمام شد', 'تغییرناپذیر'], ['Cancelled', 'لغو شد', 'تغییرناپذیر']] },
  { title: 'مدرک مشتری', where: 'بررسی تصویر و فیلدهای OCR', href: '/admin/documents', rows: [['Pending', 'منتظر بررسی', 'تأیید · رد با علت (علت به مشتری نشان داده می‌شود)'], ['Verified', 'تأیید شد', '—'], ['Rejected', 'رد شد', 'مشتری مدرک جدید بارگذاری می‌کند']] },
  { title: 'اعلام واریز', where: 'تطبیق با صورت‌حساب بانک', href: '/admin/payments', rows: [['Pending', 'مشتری واریز را اعلام کرده', 'تأیید (قسط پرداخت‌شده ثبت می‌شود) · رد'], ['Approved', 'تأیید شد', '—'], ['Rejected', 'رد شد', 'مشتری دوباره اعلام می‌کند']] },
  { title: 'تیکت پشتیبانی', where: 'مهلت پاسخ (SLA) روی هر تیکت نمایش داده می‌شود', href: '/admin/tickets', rows: [['Open', 'مشتری نوشته؛ پاسخ داده نشده', 'پاسخ · یادداشت داخلی · بستن'], ['Answered', 'کارشناس پاسخ داده', 'مشتری ادامه می‌دهد یا تیکت بسته می‌شود'], ['Waiting', 'منتظر مشتری', 'پیگیری یا بستن'], ['Closed', 'بسته شد', '—']] },
  { title: 'اعتبارسنجی', where: 'مجوز credit.view / credit.manage / credit.report', href: '/admin/credit', rows: Object.entries(CREDIT_STATUS).map(([k, v]): Row => [k, v, ({ OTPSent: 'مشتری رمز را وارد می‌کند؛ مدیر می‌تواند رمز مجدد بفرستد (حداکثر ۵ بار)', OTPResend: 'منتظر رمز مشتری', InQueue: 'خودکار؛ وضعیت از سرویس‌دهنده/کال‌بک می‌آید (پرسش وضعیت دستی ممکن است)', ReportGenerated: 'دیدن گزارش (مجوز credit.report) · PDF', ReportGenerationFailed: 'بازتولید گزارش — بدون رمز جدید، تا ۲۴ ساعت', ReportGeneratedButDataLost: 'بازتولید گزارش', OTPLocked: 'نهایی؛ استعلام جدید لازم است', Expired: 'نهایی؛ استعلام جدید لازم است', IdentityCheckFailed: 'نهایی؛ مشتری باید اطلاعات درست را دوباره وارد کند' } as Record<string, string>)[k] || (k.startsWith('NotMatching') ? 'نهایی؛ کد ملی/موبایل/شناسه را بررسی کنید و استعلام جدید ثبت شود' : '—')]) },
  { title: 'سفارش خرید', where: 'ثبت توسط کارشناس', href: '/admin/orders', rows: [['Pending', 'در انتظار تحویل', 'تحویل‌شده · لغو'], ['Delivered', 'تحویل شد', '—'], ['Cancelled', 'لغو شد', '—']] },
  { title: 'کار پس‌زمینه (صف کار)', where: 'پیامک، پرسش وضعیت اعتبارسنجی و …', href: '/admin/jobs', rows: [['Pending', 'در صف اجرا', 'خودکار'], ['Running', 'در حال اجرا', 'خودکار'], ['Done', 'انجام شد', '—'], ['Failed', 'ناموفق؛ خودکار دوباره تلاش می‌شود', 'اگر تکرار شد: بررسی خطا'], ['Dead', 'از تلاش مجدد گذشته', 'تلاش دوباره‌ی دستی از صفحه‌ی صف کار']] },
];
const label = (k: string) => STATUS.loanapp[k] ?? STATUS.contract[k] ?? STATUS.doc[k] ?? STATUS.ticket[k] ?? STATUS.job[k] ?? STATUS.credit[k] ?? STATUS.decl[k] ?? k;
export default function Page() {
  return (<><h1>راهنمای وضعیت‌ها و اقدام‌ها</h1>
    <p className="mut">برای هر بخش: هر وضعیت چه معنی دارد و کارشناس در آن وضعیت چه کاری می‌تواند بکند. دسترسی هر اقدام را نقش‌ها تعیین می‌کنند (<Link href="/admin/roles">نقش‌ها و دسترسی</Link>).</p>
    {BLOCKS.map((b) => (<section key={b.title} className="card"><div className="qh"><h2>{b.title}</h2><small>{b.where}</small><span className="sp" /><Link href={b.href}>باز کردن</Link></div>
      <div className="tw"><table><thead><tr><th>وضعیت</th><th>معنی</th><th>اقدام‌های ممکن</th></tr></thead><tbody>{b.rows.map(([k, m, a]) => <tr key={k}><td data-l="وضعیت"><b>{b.title === 'سفارش خرید' ? ({ Pending: 'در انتظار', Delivered: 'تحویل شد', Cancelled: 'لغو شد' } as Record<string, string>)[k] : label(k)}</b> <span className="ltr mut">{k}</span></td><td data-l="معنی">{m}</td><td data-l="اقدام‌ها">{a}</td></tr>)}</tbody></table></div></section>))}</>);
}
