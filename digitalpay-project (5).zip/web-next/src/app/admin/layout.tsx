import type { ReactNode } from 'react';
import { Shell } from '@/components/Shell';
import { requireUser } from '@/lib/session';
export const dynamic = 'force-dynamic';
export default async function L({ children }: { children: ReactNode }) { await requireUser(true); return <Shell area="admin">{children}</Shell>; }
