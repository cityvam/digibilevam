import { api } from '@/lib/api';
import { Table } from '@/components/ui';
import { addCounterparty, toggleCounterparty } from '@/actions/admin2';
export const metadata = { title: 'طرف‌حساب‌ها' };
export default async function Page() {
  const cs: any[] = await api.get('/api/v1/admin/counterparties');
  return (<><h1>طرف‌حساب‌ها (فروشندگان)</h1><div className="stack"><div>
    <Table heads={['نام', 'شبا', 'وضعیت', '']} empty="طرف‌حسابی نیست" rows={cs.map((c) => [c.name, <span key="i" className="ltr">{c.iban}</span>, c.isActive ? <span key="s" className="badge good">فعال</span> : <span key="s" className="badge mute">غیرفعال</span>,
      <form key="f" action={toggleCounterparty.bind(null, c.id, c.name, c.iban, !c.isActive)}><button className="btn sm ghost">{c.isActive ? 'غیرفعال کن' : 'فعال کن'}</button></form>])} /></div>
    <form className="f card" action={addCounterparty}><h2>طرف‌حساب جدید</h2><label>نام<input name="name" required maxLength={120} /></label>
      <label>شماره شبا<small>مثال: IR + ۲۴ رقم</small><input name="iban" className="ltr" required pattern="[Ii][Rr][0-9 ]{24,30}" /></label><button className="btn">افزودن</button></form></div></>);
}
