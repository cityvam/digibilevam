import { api } from '@/lib/api';
import { fa, jdt } from '@/lib/format';
import { Badge } from '@/components/ui';
import { ticketReply } from '@/actions/admin';
export default async function Ticket({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params; const { t, messages } = await api.get(`/api/v1/admin/tickets/${encodeURIComponent(id)}`);
  return (<><div className="row"><h1>{t.subject}</h1><span className="sp" /><Badge group="ticket" s={t.status} /></div><p className="mut">کد {fa(t.code)} — مهلت پاسخ {jdt(t.slaDueOn)}</p>
    <div className="tick">{messages.map((m: any, i: number) => <div key={i} className={`msg ${m.isStaff ? 'staff' : ''}`}><div className="meta">{m.isInternal ? 'یادداشت داخلی' : m.isStaff ? 'پشتیبان' : 'مشتری'} — {jdt(m.createdOn)}</div>{m.body}</div>)}</div>
    <form className="f card" action={ticketReply.bind(null, t.id)}><label>پاسخ<textarea name="body" required /></label>
      <label className="chk"><input type="checkbox" name="internal" value="1" /> یادداشت داخلی (مشتری نمی‌بیند)</label><label className="chk"><input type="checkbox" name="close" value="1" /> بعد از ارسال، تیکت بسته شود</label><button className="btn">ثبت</button></form></>);
}
