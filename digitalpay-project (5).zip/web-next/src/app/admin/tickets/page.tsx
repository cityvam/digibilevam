import Link from 'next/link';
import { api } from '@/lib/api';
import { fa, jdt } from '@/lib/format';
import { Badge, Table } from '@/components/ui';
export const metadata = { title: 'تیکت‌ها' };
export default async function Tickets({ searchParams }: { searchParams: Promise<{ status?: string; overdue?: string }> }) {
  const q = await searchParams; const ts: any[] = await api.get('/api/v1/admin/tickets', { status: q.status, overdue: q.overdue ? 'true' : undefined });
  return (<><div className="row"><h1>تیکت‌های پشتیبانی</h1><span className="sp" /><Link className="btn sm ghost" href="/admin/tickets?overdue=1">فقط گذشته از مهلت</Link></div>
    <Table heads={['کد', 'موضوع', 'اولویت', 'وضعیت', 'مهلت پاسخ', '']} empty="تیکتی نیست" rows={ts.map((t) => [fa(t.code), t.subject, t.priority === 'High' ? <span key="p" className="badge bad">بالا</span> : 'عادی', <Badge key="b" group="ticket" s={t.status} />, t.overdue ? <span key="o" className="badge bad">گذشته</span> : jdt(t.slaDueOn), <Link key="l" href={`/admin/tickets/${t.id}`}>پاسخ</Link>])} /></>);
}
