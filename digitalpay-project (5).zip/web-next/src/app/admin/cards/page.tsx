import { api } from '@/lib/api';
import { money } from '@/lib/format';
import { Table } from '@/components/ui';
import MoneyInput from '@/components/MoneyInput';
import { adminCardOp, issueCard } from '@/actions/admin';
export const metadata = { title: 'کارت‌های مجازی' };
const CARD: Record<string, [string, string]> = { Active: ['فعال', 'good'], Frozen: ['مسدود', 'warn'], Closed: ['بسته', 'mute'] };
export default async function Cards({ searchParams }: { searchParams: Promise<{ status?: string }> }) {
  const q = await searchParams; const cs: any[] = await api.get('/api/v1/admin/virtual-cards', { status: q.status });
  return (<><h1>کارت‌های مجازی</h1><div className="stack"><div>
    <Table heads={['کارت', 'دارنده', 'سقف', 'مصرف', 'وضعیت', '']} empty="کارتی نیست" rows={cs.map((c) => [<span key="n" className="ltr">{c.number}</span>, c.holderName, money(c.limit), money(c.spent),
      <span key="s" className={`badge ${CARD[c.status]?.[1] || 'mute'}`}>{CARD[c.status]?.[0] || c.status}</span>,
      c.status === 'Closed' ? null : <div key="o" className="row"><form action={adminCardOp.bind(null, c.id, c.status === 'Frozen' ? 'unfreeze' : 'freeze')}><button className="btn sm ghost">{c.status === 'Frozen' ? 'رفع مسدودی' : 'مسدود'}</button></form><form action={adminCardOp.bind(null, c.id, 'close')}><button className="btn sm danger">بستن</button></form></div>])} /></div>
    <form className="f card" action={issueCard}><h2>صدور کارت</h2>
      <label>شناسه‌ی وام (Guid)<input name="loanId" className="ltr" required pattern="[0-9a-fA-F\-]{36}" /></label><label>شناسه‌ی مشتری (Guid)<input name="userId" className="ltr" required pattern="[0-9a-fA-F\-]{36}" /></label>
      <label>نام دارنده<input name="holderName" required maxLength={80} /></label><label>سقف (تومان)<MoneyInput name="limit" required /></label><button className="btn">صدور</button></form></div></>);
}
