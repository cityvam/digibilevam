import { api } from '@/lib/api';
import { fa, jdate, money, STATUS } from '@/lib/format';
import { Stat, Table } from '@/components/ui';
export const metadata = { title: 'مالی' };
export default async function Finance() {
  const [tb, es, au] = await Promise.all([api.get('/api/v1/admin/ledger/trial-balance'), api.get('/api/v1/admin/ledger/entries'), api.try('GET', '/api/v1/admin/audit/verify')]);
  return (<><h1>مالی و دفتر کل</h1>
    <div className="grid"><Stat label="جمع بدهکار" value={money(tb.totalDebit)} /><Stat label="جمع بستانکار" value={money(tb.totalCredit)} /><Stat label="تراز" value={tb.balanced ? 'متوازن ✓' : 'نامتوازن ✗'} />
      {au.ok ? <Stat label="زنجیره‌ی حسابرسی" value={au.data?.ok === false ? 'مشکوک ✗' : 'سالم ✓'} /> : null}</div>
    <h2>تراز آزمایشی</h2><Table heads={['کد', 'حساب', 'نوع', 'بدهکار', 'بستانکار']} empty="حسابی نیست" rows={tb.rows.map((r: any) => [fa(r.code), r.name, STATUS.acct[r.type] || r.type, money(r.debit), money(r.credit)])} />
    <h2>آخرین سندها</h2><Table heads={['شماره', 'شرح', 'مرجع', 'مبلغ', 'تاریخ']} empty="سندی نیست" rows={es.map((e: any) => [fa(e.number), e.memo + (e.reversalOf ? ' (معکوس)' : ''), fa(e.reference || '—'), money(e.debit), jdate(e.createdOn)])} /></>);
}
