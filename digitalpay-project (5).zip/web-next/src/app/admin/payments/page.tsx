import { api } from '@/lib/api';
import { fa, jdate, money, STATUS } from '@/lib/format';
import { Badge, Empty } from '@/components/ui';
import { reviewPayment } from '@/actions/admin';
export const metadata = { title: 'واریزها' };
const METHODS: Record<string, string> = { CardToCard: 'کارت به کارت', BankTransfer: 'حواله‌ی بانکی' };
export default async function Payments({ searchParams }: { searchParams: Promise<{ status?: string }> }) {
  const q = await searchParams; const st = q.status ?? 'Pending'; const ds: any[] = await api.get('/api/v1/admin/payment-declarations', { status: st });
  return (<><div className="row"><h1>اعلام واریزها</h1><span className="sp" /><form method="get" className="row"><select name="status" aria-label="وضعیت" defaultValue={st}><option value="">همه</option>{Object.entries(STATUS.decl).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select><button className="btn sm">اعمال</button></form></div>
    <p className="mut">تأیید واریز خودِ شما ممکن نیست و رد کردن به دلیل نیاز دارد.</p>
    {ds.length ? <div className="tick">{ds.map((d) => (<div key={d.id} className="card"><div className="row"><strong>{money(d.amount)} تومان</strong><span className="mut">{METHODS[d.method] || d.method} — پیگیری {fa(d.reference)} — {jdate(d.paidAt)}</span><span className="sp" /><Badge group="decl" s={d.status} /></div>
      {d.note ? <p className="mut">{d.note}</p> : null}
      {d.status === 'Pending' ? <form className="row" action={reviewPayment.bind(null, d.id)}><input name="note" placeholder="دلیل (برای رد الزامی)" maxLength={300} /><button className="btn sm" name="status" value="Approved">تأیید</button><button className="btn sm danger" name="status" value="Rejected">رد</button></form> : d.reviewNote ? <p className="mut">توضیح: {d.reviewNote}</p> : null}</div>))}</div> : <Empty>واریزی نیست</Empty>}</>);
}
