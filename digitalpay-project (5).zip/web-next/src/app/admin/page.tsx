import Link from 'next/link';
import { api } from '@/lib/api';
import { fa } from '@/lib/format';
import { loadQueues } from '@/lib/queues';
import { Empty } from '@/components/ui';
export const metadata = { title: 'داشبورد مدیریت' };
export default async function Dash() {
  const [qs, d] = await Promise.all([loadQueues(), api.soft('/api/v1/admin/dashboard') as Promise<Record<string, any[]> | null>]); const groups = Object.entries(d ?? {});
  const shown = qs.filter((q) => q.ok); const total = shown.reduce((a, q) => a + q.count, 0), hot = shown.reduce((a, q) => a + q.items.filter((i) => i.hot).length, 0);
  return (<><div className="row"><h1>داشبورد مدیریت</h1><span className="sp" /><Link className="btn" href="/admin/work">میز کار کارشناس</Link></div>
    <section aria-labelledby="todo"><div className="qh"><h2 id="todo">نیازمند اقدام</h2><small>{total ? <>{fa(total)} مورد{hot ? <> — <b>{fa(hot)} مورد دیرکرد یا فوری</b></> : null}</> : 'همه‌چیز رسیدگی شده است'}</small></div>
      {shown.length ? <div className="qgrid">{shown.map((q) => (<Link key={q.key} href={q.href} className={`qc ${q.count === 0 ? 'zero' : q.tone === 'bad' ? 'bad' : q.items.some((i) => i.hot) ? 'hot' : ''}`}>
        <div className="n">{fa(q.count)}</div><div className="l">{q.label}</div><small>{q.hint}</small><small>اقدام: {q.actions}</small></Link>))}</div> : <Empty>صف کاری برای نقش شما نشان داده نمی‌شود.</Empty>}</section>
    {groups.length ? groups.map(([g, ks]) => (<div key={g}><h2>{g}</h2><div className="grid">{ks.map((k, i) => (
      <div key={i} className={`stat ${k.warn && k.value > 0 ? 'alert' : ''}`}><div className="sl">{k.label}</div><div className="sv">{fa(k.value)}{k.unit ? <> <small className="mut">{k.unit}</small></> : null}</div>{k.warn && k.value > 0 ? <span className="badge bad">نیازمند توجه</span> : null}</div>))}</div></div>))
      : null}
    <p className="mut">راهنمای معنی هر وضعیت و اقدام‌های ممکن: <Link href="/admin/statuses">راهنمای وضعیت‌ها</Link></p></>);
}
