import { api } from '@/lib/api';
import { saveProductContracts } from '@/actions/admin2';
export const metadata = { title: 'قراردادهای طرح' };
const STG: Record<string, string> = { Application: 'ثبت درخواست', Approval: 'تأیید', Disbursement: 'پرداخت' };
export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [links, ts]: any[] = await Promise.all([api.get(`/api/v1/admin/loan-products/${encodeURIComponent(id)}/contracts`), api.get('/api/v1/admin/contract-templates')]);
  const groups = [...new Map(ts.filter((t: any) => t.status !== 'Archived').map((t: any) => [t.groupKey, t])).values()] as any[];
  return (<><h1>قراردادهای لازم این طرح</h1>
    <form className="f card wide" action={saveProductContracts.bind(null, id)}><input type="hidden" name="count" value={links.length} />
      {links.map((l: any, i: number) => (<div key={i} className="card sub"><div className="row"><strong>{l.title || l.groupKey}</strong><span className="sp" /><label className="chk"><input type="checkbox" name={`del_${i}`} value="1" /> حذف</label></div>
        <input type="hidden" name={`gk_${i}`} value={l.groupKey} />
        <div className="grid"><label>مرحله<select name={`stage_${i}`} defaultValue={l.stage}>{Object.entries(STG).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></label><label>شرط (اختیاری)<input name={`cond_${i}`} defaultValue={l.condition || ''} className="ltr" maxLength={300} /></label></div>
        <label className="chk"><input type="checkbox" name={`req_${i}`} value="1" defaultChecked={!!l.required} /> الزامی</label><label className="chk"><input type="checkbox" name={`rev_${i}`} value="1" defaultChecked={!!l.requiresReview} /> نیازمند بازبینی کارشناس</label></div>))}
      <div className="card sub"><h2>افزودن قرارداد</h2><label>قالب<select name="gk_new" defaultValue=""><option value="">— انتخاب کنید —</option>{groups.map((t) => <option key={t.groupKey} value={t.groupKey}>{t.title}</option>)}</select></label>
        <label>مرحله<select name="stage_new">{Object.entries(STG).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></label></div>
      <button className="btn">ذخیره‌ی فهرست</button></form><p className="mut">هر قالب فقط یک بار در یک طرح می‌آید.</p></>);
}
