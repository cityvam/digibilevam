import Link from 'next/link';
import { api } from '@/lib/api';
import { fa, money } from '@/lib/format';
import { Table } from '@/components/ui';
import { seedProducts, toggleProduct } from '@/actions/admin';
export const metadata = { title: 'طرح‌های وام' };
export default async function Products() {
  const ps: any[] = await api.get('/api/v1/admin/loan-products');
  return (<><div className="row"><h1>طرح‌های وام</h1><span className="sp" />{ps.length ? null : <form action={seedProducts}><button className="btn sm">ساخت طرح‌های نمونه</button></form>}</div>
    <Table heads={['طرح', 'بازه‌ی مبلغ', 'کارمزد/سود', 'نمایش', 'وضعیت', '']} empty="طرحی تعریف نشده" rows={ps.map((p) => [
      <span key="n"><strong>{p.shape.name}</strong><div className="mut ltr">{p.shape.id}</div></span>, `${money(p.shape.minAmount)} تا ${money(p.shape.maxAmount)}`, p.shape.interestPercent ? fa(p.shape.interestPercent) + '٪' : '—', p.showInList ? 'در فهرست' : 'پنهان',
      p.isActive ? <span key="a" className="badge good">فعال</span> : <span key="a" className="badge mute">غیرفعال</span>,
      <div key="o" className="row"><Link className="btn sm ghost" href={`/admin/products/${p.id}/contracts`}>قراردادها</Link><form action={toggleProduct.bind(null, p.id)}><button className="btn sm ghost">{p.isActive ? 'غیرفعال کن' : 'فعال کن'}</button></form></div>])} />
    <p className="mut">ویرایش کامل پله‌های کارمزد و شرایط فعلاً از API یا فرانت قدیمی انجام می‌شود.</p></>);
}
