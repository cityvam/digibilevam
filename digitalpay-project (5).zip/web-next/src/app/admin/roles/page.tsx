import Link from 'next/link';
import { api } from '@/lib/api';
import { fa, jdate, short } from '@/lib/format';
import { Table } from '@/components/ui';
import { assignRole, createRole, seedRoles, unassignRole } from '@/actions/admin';
import PermBoxes from './PermBoxes';
export const metadata = { title: 'نقش‌ها' };
export default async function Roles() {
  const [r, cat, asg]: any[] = await Promise.all([api.get('/api/v1/admin/iam/roles'), api.get('/api/v1/admin/iam/permissions'), api.get('/api/v1/admin/iam/assignments')]);
  const name = (id: string) => r.find((x: any) => x.id === id)?.name || '—';
  return (<>
    <div className="row"><h1>نقش‌ها و دسترسی‌ها</h1><span className="sp" /><form action={seedRoles}><button className="btn sm ghost">افزودن نقش‌های پیش‌فرض</button></form></div>
    <div className="grid two">{r.map((x: any) => (<div key={x.id} className="card"><div className="row"><h2>{x.name}</h2><span className="sp" />{x.isSystem ? <span className="badge mute">سیستمی</span> : null}<span className="badge mute">{fa(x.users)} کاربر</span></div>
      <p className="mut">{x.description}</p><div className="row">{x.permissions.map((p: string) => <span key={p} className="badge info ltr">{p}</span>)}</div><div className="row"><Link className="btn sm ghost" href={`/admin/roles/${x.id}`}>ویرایش</Link></div></div>))}</div>
    <h2>نقش جدید</h2>
    <form className="f card" action={createRole}><label>نام<input name="name" required minLength={2} maxLength={80} /></label><label>توضیح<input name="description" maxLength={300} /></label><PermBoxes cat={cat} /><button className="btn">ایجاد</button></form>
    <h2>تخصیص نقش به کاربر</h2>
    <div className="grid two"><form className="f card" action={assignRole}><label>شناسه‌ی کاربر (Guid)<input name="userId" className="ltr" required pattern="[0-9a-fA-F\-]{36}" /></label>
      <label>نقش<select name="roleId">{r.map((x: any) => <option key={x.id} value={x.id}>{x.name}</option>)}</select></label><button className="btn">تخصیص</button></form>
      <div><Table heads={['کاربر', 'نقش', 'تاریخ', '']} empty="تخصیصی نیست" rows={asg.map((a: any) => [<span key="u" className="ltr">{short(a.userId)}</span>, name(a.roleId), jdate(a.assignedOn), <form key="f" action={unassignRole.bind(null, a.id)}><button className="btn sm danger">برداشتن</button></form>])} /></div></div></>);
}
