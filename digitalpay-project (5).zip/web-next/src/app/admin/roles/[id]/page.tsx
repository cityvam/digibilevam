import { notFound } from 'next/navigation';
import { api } from '@/lib/api';
import { deleteRole, saveRole } from '@/actions/admin';
import PermBoxes from '../PermBoxes';
export default async function Role({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [r, cat]: any[] = await Promise.all([api.get('/api/v1/admin/iam/roles'), api.get('/api/v1/admin/iam/permissions')]);
  const x = r.find((q: any) => q.id === id); if (!x) notFound();
  return (<><h1>ویرایش نقش «{x.name}»</h1>
    <form className="f card" action={saveRole.bind(null, x.id)}><label>نام<input name="name" defaultValue={x.name} required minLength={2} maxLength={80} /></label><label>توضیح<input name="description" defaultValue={x.description || ''} maxLength={300} /></label><PermBoxes cat={cat} have={x.permissions} /><button className="btn">ذخیره</button></form>
    {x.isSystem ? null : <form action={deleteRole.bind(null, x.id)}><button className="btn danger">حذف نقش</button></form>}
    <p className="mut">دادن مجوز «مدیریت دسترسی» فقط از مدیر ارشد برمی‌آید.</p></>);
}
