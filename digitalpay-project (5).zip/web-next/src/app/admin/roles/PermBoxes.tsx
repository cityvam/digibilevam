export default function PermBoxes({ cat, have = [] }: { cat: { key: string; label: string }[]; have?: string[] }) {
  return (<fieldset className="perms"><legend>مجوزها</legend>{cat.map((x) => (
    <label key={x.key} className="chk"><input type="checkbox" name="perm" value={x.key} defaultChecked={have.includes(x.key)} /> <span>{x.label} <small className="ltr mut">{x.key}</small></span></label>))}</fieldset>);
}
