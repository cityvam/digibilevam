import { api } from '@/lib/api';
import { fa, jdt } from '@/lib/format';
import { Table } from '@/components/ui';
export const metadata = { title: 'حسابرسی' };
export default async function Audit() {
  const [rows, v] = await Promise.all([api.get('/api/v1/admin/audit', { take: 200 }), api.try('GET', '/api/v1/admin/audit/verify')]);
  return (<><h1>گزارش حسابرسی</h1>
    {v.ok ? <div className={`flash ${v.data.ok ? 'good' : 'bad'}`}>{v.data.ok ? <>زنجیره‌ی هش سالم است ({fa(v.data.checkedCount)} رکورد بررسی شد).</> : <>زنجیره در رکورد {fa(v.data.brokenAt)} شکسته است؛ موضوع را فوراً بررسی کنید.</>}</div> : <p className="mut">راستی‌آزمایی زنجیره فقط برای مدیر ارشد است.</p>}
    <Table heads={['#', 'کاربر', 'متد', 'مسیر', 'کد', 'IP', 'زمان']} empty="رکوردی نیست" rows={rows.map((a: any) => [fa(a.seq), a.userName || '—', <span key="m" className="ltr">{a.method}</span>, <span key="p" className="ltr">{a.path}</span>, fa(a.statusCode), <span key="i" className="ltr">{a.ip}</span>, jdt(a.at)])} /></>);
}
