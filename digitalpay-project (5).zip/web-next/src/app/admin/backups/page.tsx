import { api } from '@/lib/api';
import { fa, jdt } from '@/lib/format';
import { Empty, Table } from '@/components/ui';
import { requireUser } from '@/lib/session';
import { makeBackup } from '@/actions/admin2';
export const metadata = { title: 'پشتیبان‌گیری' };
export default async function Page() {
  const u = await requireUser(true);
  if (!u.isSuper) return <Empty>این بخش فقط برای مدیر ارشد است.</Empty>;
  const bs: any[] = await api.get('/api/v1/admin/backups');
  return (<><div className="row"><h1>پشتیبان پایگاه داده</h1><span className="sp" /><form action={makeBackup}><button className="btn">تهیه‌ی پشتیبان همین حالا</button></form></div>
    <Table heads={['فایل', 'حجم', 'زمان']} empty="پشتیبانی نیست" rows={bs.map((b) => [<span key="n" className="ltr">{b.name}</span>, fa(Math.round(b.size / 1048576)) + ' مگابایت', jdt(b.createdOn)])} />
    <p className="mut">بازگردانی عمداً از طریق وب انجام نمی‌شود؛ باید دستی و با توقف سرویس باشد. فایل‌ها را روی سرور بیرونی هم کپی کنید (offsite-backup.sh).</p></>);
}
