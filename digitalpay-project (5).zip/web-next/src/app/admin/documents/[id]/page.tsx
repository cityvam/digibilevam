import { notFound } from 'next/navigation';
import { api } from '@/lib/api';
import { fa, jdt, short } from '@/lib/format';
import { Badge } from '@/components/ui';
import { reviewDocument } from '@/actions/admin';
const KIND: Record<string, string> = { NationalCard: 'کارت ملی (رو)', NationalCardBack: 'کارت ملی (پشت)', Birth: 'شناسنامه', Selfie: 'سلفی با مدرک', Salary: 'فیش حقوقی', Other: 'سایر' };
export default async function Doc({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params; const d = (await api.get('/api/v1/admin/documents')).find((x: any) => x.id === id); if (!d) notFound();
  return (<><div className="row"><h1>{KIND[d.kind] || d.kind}</h1><span className="sp" /><Badge group="doc" s={d.status} /></div>
    <p className="mut">مشتری <span className="ltr">{short(d.userId)}</span> — {jdt(d.createdOn)} — {fa(Math.round(d.sizeBytes / 1024))} کیلوبایت</p>
    <div className="grid two"><div className="card"><img className="docimg" src={`/files/admin/documents/${d.id}`} alt="تصویر مدرک" /></div>
      <div>{d.ocrText ? <div className="card"><h2>متن خوانده‌شده (OCR)</h2><div className="contract">{d.ocrText}</div></div> : null}
        <form className="f card" action={reviewDocument.bind(null, d.id)}><h2>نتیجه‌ی بررسی</h2>
          <label>وضعیت<select name="status"><option value="Verified">تأیید</option><option value="Rejected">رد</option><option value="Pending">بازگرداندن به انتظار</option></select></label>
          <label>توضیح برای مشتری<textarea name="note" maxLength={300} defaultValue={d.reviewNote || ''} /></label><button className="btn">ثبت</button></form></div></div></>);
}
