import Link from 'next/link';
import { api } from '@/lib/api';
import { jdt, short, STATUS } from '@/lib/format';
import { Badge, Table } from '@/components/ui';
export const metadata = { title: 'مدارک' };
const KIND: Record<string, string> = { NationalCard: 'کارت ملی (رو)', NationalCardBack: 'کارت ملی (پشت)', Birth: 'شناسنامه', Selfie: 'سلفی با مدرک', Salary: 'فیش حقوقی', Other: 'سایر' };
export default async function Documents({ searchParams }: { searchParams: Promise<{ status?: string }> }) {
  const q = await searchParams; const st = q.status ?? 'Pending'; const ds: any[] = await api.get('/api/v1/admin/documents', { status: st });
  return (<><div className="row"><h1>بررسی مدارک</h1><span className="sp" /><form method="get" className="row"><select name="status" aria-label="وضعیت" defaultValue={st}><option value="">همه</option>{Object.entries(STATUS.doc).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select><button className="btn sm">اعمال</button></form></div>
    <Table heads={['نوع', 'مشتری', 'فایل', 'وضعیت', 'ثبت', '']} empty="مدرکی نیست" rows={ds.map((d) => [KIND[d.kind] || d.kind, <span key="u" className="ltr">{short(d.userId)}</span>, <span key="f" className="ltr">{d.fileName}</span>, <Badge key="b" group="doc" s={d.status} />, jdt(d.createdOn), <Link key="l" href={`/admin/documents/${d.id}`}>بررسی</Link>])} /></>);
}
