import { api } from '@/lib/api';
import { requireUser } from '@/lib/session';
export const dynamic = 'force-dynamic';
// متن قرارداد (HTML از API) فقط داخل iframe سندباکس‌شده؛ CSP سخت‌گیرانه چون محتوا قالب‌ساز است.
const FRAME_CSP = "default-src 'none'; style-src 'unsafe-inline'; img-src data:; sandbox; frame-ancestors 'self'";
export async function GET(_: Request, { params }: { params: Promise<{ id: string }> }) {
  await requireUser(); const { id } = await params;
  const r = await api.html(`/api/v1/me/contracts/${encodeURIComponent(id)}/html`);
  if (!r.ok) return new Response('متن قرارداد در دسترس نیست', { status: r.status === 404 ? 404 : 502, headers: { 'Content-Type': 'text/plain; charset=utf-8' } });
  return new Response(r.buf, { headers: { 'Content-Type': 'text/html; charset=utf-8', 'Content-Security-Policy': FRAME_CSP, 'X-Frame-Options': 'SAMEORIGIN', 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'no-store' } });
}
