import { api } from '@/lib/api';
import { requireUser } from '@/lib/session';
export const dynamic = 'force-dynamic';
const esc = (v: string) => v.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!));
// پیش‌نمایش قالب با داده‌ی نمونه، داخل iframe سندباکس‌شده
export async function GET(_: Request, { params }: { params: Promise<{ id: string }> }) {
  await requireUser(true); const { id } = await params;
  const r = await api.try('POST', `/api/v1/admin/contract-templates/${encodeURIComponent(id)}/preview`, {});
  let body: string = r.ok ? String(r.data.html || '') : '<p>پیش‌نمایش در دسترس نیست.</p>';
  const errs = r.ok && r.data.errors?.length ? `<p style="color:#b42318">خطا: ${esc(JSON.stringify(r.data.errors))}</p>` : '';
  body = /<body[^>]*>/i.test(body) ? body.replace(/<body[^>]*>/i, (m) => m + errs) : errs + body;
  return new Response(body, { headers: { 'Content-Type': 'text/html; charset=utf-8', 'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'; img-src data:; sandbox; frame-ancestors 'self'", 'X-Frame-Options': 'SAMEORIGIN', 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'no-store' } });
}
