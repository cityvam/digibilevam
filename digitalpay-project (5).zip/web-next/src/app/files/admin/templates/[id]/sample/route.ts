import { api } from '@/lib/api';
import { requireUser } from '@/lib/session';
export const dynamic = 'force-dynamic';
export async function GET(_: Request, { params }: { params: Promise<{ id: string }> }) {
  await requireUser(true); const { id } = await params;
  const r = await api.bytes(`/api/v1/admin/contract-templates/${encodeURIComponent(id)}/sample`);
  if (!r.ok) return new Response('not found', { status: 404, headers: { 'Content-Type': 'text/plain' } });
  const ct = r.headers.get('content-type') || '';
  return new Response(r.buf, { headers: { 'Content-Type': ct.startsWith('application/pdf') ? 'application/pdf' : 'application/octet-stream', 'Content-Disposition': 'attachment; filename="contract-sample"', 'Content-Security-Policy': "default-src 'none'; sandbox", 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'private, no-store' } });
}
