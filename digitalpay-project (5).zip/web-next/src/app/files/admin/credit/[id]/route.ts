import { api } from '@/lib/api';
import { requireUser } from '@/lib/session';
export const dynamic = 'force-dynamic';
// فایل PDF گزارش اعتباری (مدیر؛ نیازمند مجوز credit.report) (ByteArray از API). فقط PDF واقعی عبور می‌کند.
export async function GET(_: Request, { params }: { params: Promise<{ id: string }> }) {
  await requireUser(true); const { id } = await params;
  const r = await api.bytes(`/api/v1/admin/credit/${encodeURIComponent(id)}/pdf`);
  const ct = (r.headers.get('content-type') || '').split(';')[0].trim();
  if (!r.ok || ct !== 'application/pdf' || new TextDecoder('latin1').decode(r.buf.slice(0, 5)) !== '%PDF-') return new Response('گزارش در دسترس نیست', { status: r.status === 404 ? 404 : 502, headers: { 'Content-Type': 'text/plain; charset=utf-8' } });
  return new Response(r.buf, { headers: { 'Content-Type': 'application/pdf', 'Content-Disposition': 'attachment; filename="credit-report.pdf"', 'Content-Security-Policy': "default-src 'none'", 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'private, no-store' } });
}
