import { api } from '@/lib/api';
import { requireUser } from '@/lib/session';
export const dynamic = 'force-dynamic';
// فقط تصویر امن؛ هر نوع دیگر (مثلاً SVG/HTML) رد می‌شود
export async function GET(_: Request, { params }: { params: Promise<{ id: string }> }) {
  await requireUser(true); const { id } = await params;
  const r = await api.bytes(`/api/v1/admin/documents/${encodeURIComponent(id)}/file`);
  const ct = (r.headers.get('content-type') || '').split(';')[0].trim();
  if (!r.ok || !/^image\/(jpeg|png|webp)$/.test(ct)) return new Response('not found', { status: 404, headers: { 'Content-Type': 'text/plain' } });
  return new Response(r.buf, { headers: { 'Content-Type': ct, 'Content-Security-Policy': "default-src 'none'", 'Content-Disposition': 'inline', 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'private, no-store' } });
}
