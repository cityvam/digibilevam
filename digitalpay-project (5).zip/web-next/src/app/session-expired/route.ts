import { NextResponse, type NextRequest } from 'next/server';
// کوکی را در یک Route Handler می‌شود پاک کرد (در Server Component نمی‌شود). Location نسبی تا پشت پراکسی درست بماند.
export function GET(req: NextRequest) {
  const res = new NextResponse(null, { status: 303, headers: { Location: '/login', 'Cache-Control': 'no-store' } });
  const had = !!req.cookies.get('dp_t');
  res.cookies.delete('dp_t');
  if (had) res.cookies.set('dp_f', JSON.stringify({ t: 'err', m: 'نشست شما منقضی شد؛ دوباره وارد شوید.' }), { path: '/', httpOnly: true, sameSite: 'lax', maxAge: 10 });
  return res;
}
