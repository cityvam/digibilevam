import Link from 'next/link';
import { api } from '@/lib/api';
import { money } from '@/lib/format';
import { fmtAmt } from '@/components/ui';
export const metadata = { title: 'طرح‌های اقساطی' };
export default async function Products() {
  const list: any[] = (await api.soft('/api/v1/loan-products')) || [];
  return (<><h1>طرح‌های اقساطی</h1><p className="lead">طرحی را انتخاب کنید و با ماشین‌حساب برآورد بگیرید.</p>
    {list.length ? <div className="grid">{list.map((p) => (
      <Link key={p.id} className="card" href={`/products/${p.id}`}><div className="row"><h2>{p.title || p.name}</h2>{p.badge ? <span className="badge info">{p.badge}</span> : null}</div>
        <p className="mut">{p.description}</p><div className="mut">از {fmtAmt(money, p.minAmount)} تا {fmtAmt(money, p.maxAmount)}</div></Link>))}</div>
      : <div className="empty">فعلاً طرحی فعال نیست.</div>}
    <section id="docs" className="card"><h2>مدارک مورد نیاز</h2><ul><li>تصویر کارت ملی (روی و پشت کارت)</li><li>تصویر شناسنامه</li><li>عکس سلفی همراه مدرک</li><li>فیش حقوقی یا مدرک درآمد (بسته به طرح)</li></ul><p className="mut">فهرست دقیق هر طرح در صفحه‌ی جزئیات همان طرح آمده است.</p></section></>);
}
