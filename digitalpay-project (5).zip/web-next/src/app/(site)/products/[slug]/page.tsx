import Link from 'next/link';
import { notFound } from 'next/navigation';
import { api } from '@/lib/api';
import { fa, money } from '@/lib/format';
import { fmtAmt } from '@/components/ui';
import { getSession } from '@/lib/session';
export default async function Product({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const p = await api.soft('/api/v1/loan-products/' + encodeURIComponent(slug)); if (!p) notFound();
  const docs: any[] = Array.isArray(p.documents) ? p.documents : []; const u = await getSession();
  return (<>
    <div className="row"><h1>{p.title || p.name}</h1><span className="sp" />{p.badge ? <span className="badge info">{p.badge}</span> : null}</div><p className="lead">{p.description}</p>
    <div className="grid two"><div className="card"><dl className="kv"><dt>حداقل مبلغ</dt><dd>{fmtAmt(money, p.minAmount)}</dd><dt>حداکثر مبلغ</dt><dd>{fmtAmt(money, p.maxAmount)}</dd><dt>فاصله‌ی اقساط</dt><dd>{fa(p.intervalDays)} روز</dd></dl></div>
      <div className="card"><h2>مدارک لازم</h2>{docs.length ? <ul>{docs.map((d, i) => <li key={i}>{d.label || d.name}{d.required ? <> <span className="badge warn">الزامی</span></> : null}</li>)}</ul> : <p className="mut">مدرک خاصی لازم نیست.</p>}</div></div>
    <div className="row"><Link className="btn" href="/calculator">ماشین‌حساب اقساط</Link>{u ? <Link className="btn" href={`/app/loans/new?product=${encodeURIComponent(slug)}`}>درخواست این طرح</Link> : null}{u ? <Link className="btn ghost" href="/app/documents">بارگذاری مدارک</Link> : <Link className="btn ghost" href="/register">ثبت‌نام</Link>}</div>
  </>);
}
