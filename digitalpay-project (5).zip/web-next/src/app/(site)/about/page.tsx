export const metadata = { title: 'درباره ما' };
export default function About() { return (<><h1>درباره‌ی دیجی‌بایل پی</h1><p className="lead">پلتفرم پرداخت اقساطی (BNPL) با تمرکز بر امنیت، شفافیت و پشتیبانی سریع.</p></>); }
