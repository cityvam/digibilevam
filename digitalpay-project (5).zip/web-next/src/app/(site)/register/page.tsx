import { api } from '@/lib/api';
import { fa } from '@/lib/format';
import { CapField } from '@/components/ui';
import { getState } from '@/lib/session';
import { regCode, regFinish, regPhone, restartRegister } from '@/actions/auth';
export const metadata = { title: 'ثبت‌نام' };
export default async function Register() {
  const [phone, ticket] = await Promise.all([getState('dp_rp'), getState('dp_rt')]);
  if (ticket) {
    const c = await api.soft('/api/v1/security/captcha');
    return (<><h1>ثبت‌نام (۳ از ۳)</h1><form className="f card" action={regFinish}>
      <label>نام و نام خانوادگی<input name="fullName" required /></label>
      <label>کد ملی<input name="nationalCode" className="ltr" inputMode="numeric" maxLength={10} required /></label>
      <label>ایمیل (اختیاری)<input name="email" type="email" className="ltr" /></label>
      <label>رمز عبور<small>حداقل ۸ نویسه</small><input name="password" type="password" className="ltr" minLength={8} autoComplete="new-password" required /></label>
      <CapField c={c} /><button className="btn">ایجاد حساب</button></form></>);
  }
  if (phone) return (<><h1>ثبت‌نام (۲ از ۳)</h1><form className="f card" action={regCode}>
    <p className="mut">کد پیامکی به {fa(phone)} ارسال شد.</p>
    <label>کد پیامکی<input name="code" className="ltr" inputMode="numeric" autoComplete="one-time-code" required /></label><button className="btn">تأیید</button></form>
    <form action={restartRegister}><button className="btn ghost sm">تغییر شماره</button></form></>);
  const c = await api.soft('/api/v1/security/captcha');
  return (<><h1>ثبت‌نام (۱ از ۳)</h1><form className="f card" action={regPhone}>
    <label>شماره موبایل<input name="phone" className="ltr" inputMode="tel" autoComplete="tel" required /></label><CapField c={c} /><button className="btn">ارسال کد پیامکی</button></form></>);
}
