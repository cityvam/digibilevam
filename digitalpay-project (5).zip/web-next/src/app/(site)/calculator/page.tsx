import { calc } from '@/lib/calc';
import { fa, money, num } from '@/lib/format';
import MoneyInput from '@/components/MoneyInput';
export const metadata = { title: 'ماشین‌حساب اقساط' };
type SP = Promise<Record<string, string | string[] | undefined>>;
const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v);
export default async function Calculator({ searchParams }: { searchParams: SP }) {
  const q = await searchParams;
  const a = num(one(q.amount)), d = num(one(q.down) ?? 20), f = num(one(q.fee) ?? 12), m = num(one(q.months) ?? 6);
  const ok = a > 0 && d >= 0 && d < 100 && f >= 0 && f <= 100 && m >= 1 && m <= 36 && Number.isInteger(m);
  const r = ok ? calc(a, d, f, m) : null;
  return (<>
    <h1>ماشین‌حساب اقساط</h1><p className="lead">برآورد بر پایه‌ی همان فرمول قرارداد؛ مبلغ نهایی در قرارداد می‌آید.</p>
    <div className="grid two">
      <form className="f card" method="get">
        <label>مبلغ کالا (تومان)<MoneyInput name="amount" defaultValue={one(q.amount) ?? ''} required /></label>
        <label>پیش‌پرداخت (درصد)<input name="down" className="ltr" inputMode="numeric" defaultValue={one(q.down) ?? 20} /></label>
        <label>کارمزد (درصد)<input name="fee" className="ltr" inputMode="numeric" defaultValue={one(q.fee) ?? 12} /></label>
        <label>تعداد اقساط<select name="months" defaultValue={String(m)}>{[3, 4, 6, 9, 12, 18, 24, 36].map((x) => <option key={x} value={x}>{fa(x)} ماهه</option>)}</select></label>
        <button className="btn">محاسبه</button>
      </form>
      <div className="card">{r ? (<><h2>نتیجه</h2><dl className="kv">
        <dt>پیش‌پرداخت</dt><dd>{money(r.down)} تومان</dd><dt>مبلغ تسهیلات</dt><dd>{money(r.fin)} تومان</dd><dt>کارمزد</dt><dd>{money(r.fee)} تومان</dd>
        <dt>مجموع بازپرداخت</dt><dd>{money(r.total)} تومان</dd><dt>هر قسط</dt><dd>{money(r.each)} تومان</dd><dt>قسط آخر</dt><dd>{money(r.last)} تومان</dd></dl></>)
        : <div className="empty">مقدارها را وارد کنید تا نتیجه این‌جا نمایش داده شود.</div>}</div>
    </div></>);
}
