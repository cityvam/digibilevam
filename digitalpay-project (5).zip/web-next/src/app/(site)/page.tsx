import Link from 'next/link';
import { HeroArt, I, PhoneArt, ProductArt } from '@/components/home/art';
import HeroCalc from '@/components/home/HeroCalc';
import HeroSlides from '@/components/home/HeroSlides';
import { fa, money } from '@/lib/format';
import { getSession } from '@/lib/session';

export const metadata = { title: 'خرید اقساطی امن' };
const FEATURES = [
  { t: 'پرداخت آسان', d: 'اقساط متناسب با توان شما', i: I.shield, c: 'f-blue' },
  { t: 'سریع و مطمئن', d: 'بررسی و پاسخ در کوتاه‌ترین زمان', i: I.bolt, c: 'f-sky' },
  { t: 'بدون ضامن', d: '(در طرح‌های منتخب) با شرایط ویژه', i: I.user, c: 'f-ind' },
  { t: 'پوشش گسترده', d: 'انواع کالاها و خدمات', i: I.grid, c: 'f-green' },
  { t: 'پشتیبانی حرفه‌ای', d: 'در تمام مراحل', i: I.support, c: 'f-blue' },
];
const PLANS: { kind: 'home' | 'phone' | 'watch' | 'car' | 'moto'; tag: string; t: string; d: string; max: number; mo: [number, number] }[] = [
  { kind: 'home', tag: 'کالاهای خانگی', t: 'طرح لوازم خانگی', d: 'اقساط متنوع و مناسب', max: 20_000_000, mo: [6, 24] },
  { kind: 'phone', tag: 'موبایل', t: 'طرح موبایل و تبلت', d: 'بهترین اقساط منعطف', max: 15_000_000, mo: [6, 24] },
  { kind: 'watch', tag: 'ساعت هوشمند', t: 'طرح ساعت هوشمند', d: 'با سود کمتر و بازپرداخت آسان', max: 10_000_000, mo: [6, 18] },
  { kind: 'car', tag: 'خودرو', t: 'طرح خودرو', d: 'اقساط متنوع و پوشش کامل', max: 500_000_000, mo: [6, 60] },
  { kind: 'moto', tag: 'موتورسیکلت', t: 'طرح موتورسیکلت', d: 'با شرایط ویژه و اقساط بلندمدت', max: 50_000_000, mo: [6, 36] },
];
const WHY = [
  { t: 'امنیت اطلاعات', d: 'با بالاترین استانداردها', i: I.shield },
  { t: 'رضایت مشتری بالا', d: 'اعتماد شما سرمایه ماست', i: I.people },
  { t: 'پشتیبانی ۲۴ ساعته', d: 'همیشه همراه شما', i: I.clock },
];
const STEPS = [
  ['ثبت درخواست', 'اطلاعات خود را وارد کنید'], ['بررسی و تأیید', 'مدارک و اعتبار شما بررسی می‌شود'], ['امضای قرارداد', 'قبول الکترونیکی با کد پیامکی'],
  ['پرداخت پیش‌پرداخت', 'در صورت نیاز طرح'], ['ثبت سفارش', 'خرید از پذیرنده‌ی طرف قرارداد'], ['دریافت وام', 'مبلغ وام به حساب شما واریز می‌شود'],
];
export default async function Home() {
  const u = await getSession(); const applyHref = u && !u.isAdmin ? '/app/loans/new' : '/register';
  return (<div className="home">
    <section className="hero" aria-label="معرفی">
      <HeroArt />
      <div className="hero-in">
        <HeroCalc applyHref={applyHref} />
        <HeroSlides />
      </div>
    </section>

    <section className="feats" aria-label="مزایا">{FEATURES.map((f) => (
      <div key={f.t} className="feat"><span className={`ficon ${f.c}`}>{f.i}</span><div><b>{f.t}</b><small>{f.d}</small></div></div>))}</section>

    <section className="plans" aria-labelledby="plans-h">
      <div className="sec-h"><div><h2 id="plans-h">طرح‌های وام و خرید اقساطی</h2><p>با توجه به نیاز خود، بهترین طرح را انتخاب کنید.</p></div><Link className="all" href="/products">مشاهده همه طرح‌ها <span aria-hidden="true">{I.arrow}</span></Link></div>
      <div className="plan-grid">{PLANS.map((p) => (
        <Link key={p.t} href="/products" className="plan"><div className="plan-top"><div className="plan-img"><ProductArt kind={p.kind} /></div><div className="plan-tx"><span className="tag">{p.tag}</span><h3>{p.t}</h3><p>{p.d}</p></div></div>
          <div className="plan-meta"><span>تا {money(p.max)} تومان</span><span>{fa(p.mo[0])} تا {fa(p.mo[1])} ماه</span></div><div className="plan-more">مشاهده جزئیات <span aria-hidden="true">{I.arrow}</span></div></Link>))}</div>
    </section>

    <section className="why" aria-labelledby="why-h">
      <div className="why-in">
        <div className="why-app"><div><b>اپلیکیشن دیجی‌بایل</b><p>دسترسی سریع‌تر، تجربه بهتر</p><span className="why-dl" aria-disabled="true">دانلود اپلیکیشن</span></div><PhoneArt /></div>
        <div className="why-list">{WHY.map((w) => <div key={w.t} className="why-i"><span className="why-ic">{w.i}</span><b>{w.t}</b><small>{w.d}</small></div>)}</div>
        <div className="why-t"><h2 id="why-h">چرا دیجی‌بایل؟</h2><p>با ما، خرید اقساطی آسان‌تر، سریع‌تر و مطمئن‌تر است.</p></div>
      </div>
    </section>

    <section className="steps" aria-labelledby="steps-h">
      <div className="steps-h"><h2 id="steps-h">مراحل دریافت وام</h2><p>در چند مرحله ساده، وام خود را دریافت کنید.</p></div>
      <ol className="steps-l">{STEPS.map(([t, d], i) => <li key={t}><span className="sn">{fa(i + 1)}</span><div><b>{t}</b><small>{d}</small></div></li>)}</ol>
    </section>
  </div>);
}
