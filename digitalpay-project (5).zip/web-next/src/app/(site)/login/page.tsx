import Link from 'next/link';
import { redirect } from 'next/navigation';
import { api } from '@/lib/api';
import { CapField } from '@/components/ui';
import { getSession, getState } from '@/lib/session';
import { login, login2fa, restartLogin } from '@/actions/auth';
export const metadata = { title: 'ورود' };
export default async function Login() {
  if (await getSession()) redirect('/app');
  if (await getState('dp_2fa')) return (<><h1>تأیید دومرحله‌ای</h1>
    <form className="f card" action={login2fa}><label>کد ۶ رقمی برنامه‌ی احراز هویت<small>یا یکی از کدهای بازیابی</small><input name="code" className="ltr" inputMode="numeric" autoComplete="one-time-code" required /></label><button className="btn">تأیید</button></form>
    <form action={restartLogin}><button className="btn ghost sm">انصراف و ورود دوباره</button></form></>);
  const c = await api.soft('/api/v1/security/captcha');
  return (<><h1>ورود</h1>
    <form className="f card" action={login}>
      <label>موبایل یا نام کاربری<input name="username" className="ltr" autoComplete="username" required /></label>
      <label>رمز عبور<input name="password" type="password" className="ltr" autoComplete="current-password" required /></label>
      <CapField c={c} /><button className="btn">ورود</button><Link href="/register">حساب ندارید؟ ثبت‌نام</Link></form></>);
}
