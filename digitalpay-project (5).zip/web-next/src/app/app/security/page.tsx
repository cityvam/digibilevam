import { api } from '@/lib/api';
import { readOnce } from '@/lib/session';
import { disable2fa, enable2fa, setup2fa } from '@/actions/customer';
export const metadata = { title: 'امنیت حساب' };
export default async function Security() {
  const [s, once] = await Promise.all([api.get('/api/v1/me/2fa'), readOnce<{ secret?: string; rc?: string[] }>()]);
  return (<><h1>امنیت حساب</h1>
    <div className="card"><div className="row"><h2>ورود دومرحله‌ای</h2><span className="sp" />{s.enabled ? <span className="badge good">فعال</span> : <span className="badge warn">غیرفعال</span>}</div>
      {s.enabled ? <form className="f" action={disable2fa}><label>کد فعلی برنامه<input name="code" className="ltr" inputMode="numeric" required /></label><button className="btn danger">غیرفعال‌سازی</button></form>
        : once?.secret ? (<><p className="mut">این کلید را در برنامه‌ی احراز هویت (TOTP) وارد کنید؛ فقط همین یک بار نمایش داده می‌شود:</p><p className="ltr"><code>{once.secret}</code></p>
          <form className="f" action={enable2fa}><label>کد ۶ رقمی<input name="code" className="ltr" inputMode="numeric" required /></label><button className="btn">تأیید و فعال‌سازی</button></form></>)
        : (<><p className="mut">با یک برنامه‌ی احراز هویت حساب خود را امن‌تر کنید.</p><form action={setup2fa}><button className="btn">شروع فعال‌سازی</button></form></>)}</div>
    {once?.rc ? <><h2>کدهای بازیابی</h2><p className="mut">فقط همین یک‌بار نمایش داده می‌شود؛ جای امن نگه دارید.</p><div className="card ltr"><code>{once.rc.join('   ')}</code></div></> : null}</>);
}
