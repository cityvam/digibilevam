import Link from 'next/link';
import { api } from '@/lib/api';
import { fa, jdt, money } from '@/lib/format';
import { Badge, Table } from '@/components/ui';
export const metadata = { title: 'درخواست وام' };
export default async function Page() {
  const xs: any[] = await api.get('/api/v1/me/loan-applications');
  return (<><div className="row"><h1>درخواست وام</h1><span className="sp" /><Link className="btn" href="/app/loans/new">درخواست جدید</Link></div>
    <Table heads={['کد', 'طرح', 'مبلغ', 'مدت', 'وضعیت', 'ثبت', '']} empty="هنوز درخواستی ثبت نکرده‌اید" rows={xs.map((a) => [<span key="c" className="ltr">{a.code}</span>, a.productName, `${money(a.amount)} تومان`, `${fa(a.months)} ماه`, <Badge key="b" group="loanapp" s={a.status} />, jdt(a.createdOn), <Link key="l" href={`/app/loans/${a.id}`}>جزئیات</Link>])} /></>);
}
