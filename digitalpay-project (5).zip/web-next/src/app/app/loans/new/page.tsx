import { api } from '@/lib/api';
import { calc } from '@/lib/calc';
import { en, fa, money, num } from '@/lib/format';
import { createLoanApp } from '@/actions/customer';
import MoneyInput from '@/components/MoneyInput';
export const metadata = { title: 'درخواست وام جدید' };
type SP = Promise<Record<string, string | string[] | undefined>>;
const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v);
export default async function Page({ searchParams }: { searchParams: SP }) {
  const q = await searchParams;
  const [products, lim, mine] = await Promise.all([api.soft('/api/v1/loan-products') as Promise<any[] | null>, api.get('/api/v1/me/loan-applications/limits'), api.soft('/api/v1/me/credit') as Promise<any[] | null>]);
  const list = (products || []).filter((p) => p.isActive !== false); const sel = list.find((p) => p.id === one(q.product)) || null;
  const amount = num(en(one(q.amount) ?? '')) || 0, months = Math.trunc(num(en(one(q.months) ?? ''))) || 12, down = num(en(one(q.down) ?? '')) || 10;
  const lo = Math.max(lim.minAmount, sel?.minAmount ?? 0), hi = Math.min(lim.maxAmount, sel?.maxAmount ?? lim.maxAmount);
  const ok = amount >= lo && amount <= hi && months >= lim.minMonths && months <= lim.maxMonths && down >= 0 && down <= lim.maxDownPercent;
  const feePct = Math.round(lim.feePerMonthPercent * months * 100) / 100; const r = ok ? calc(amount, down, feePct, months) : null;
  const hasCredit = (mine || []).some((c) => c.reportReady);
  return (<><h1>درخواست وام جدید</h1>
    <form className="f card" method="get"><h2>۱) طرح و مبلغ</h2>
      <label>طرح<select name="product" defaultValue={sel?.id ?? ''} required><option value="" disabled>انتخاب کنید…</option>{list.map((p) => <option key={p.id} value={p.id}>{p.title || p.name}</option>)}</select></label>
      <label>مبلغ خرید (تومان){sel ? <span className="mut"> — از {money(lo)} تا {money(hi)}</span> : null}<MoneyInput name="amount" defaultValue={amount ? String(amount) : ""} required /></label>
      <label>مدت (ماه، {fa(lim.minMonths)} تا {fa(lim.maxMonths)})<input name="months" className="ltr" inputMode="numeric" defaultValue={months} /></label>
      <label>پیش‌پرداخت (درصد، تا {fa(lim.maxDownPercent)})<input name="down" className="ltr" inputMode="numeric" defaultValue={down} /></label>
      <button className="btn ghost">محاسبه‌ی اقساط</button></form>
    {amount && !ok ? <div className="flash err" role="alert">مبلغ، مدت یا پیش‌پرداخت خارج از محدوده‌ی مجاز است.</div> : null}
    {r && sel ? (<form className="f card" action={createLoanApp}><h2>۲) بررسی و ثبت</h2>
      <dl className="kv"><dt>طرح</dt><dd>{sel.title || sel.name}</dd><dt>پیش‌پرداخت</dt><dd>{money(r.down)} تومان</dd><dt>مبلغ تسهیلات</dt><dd>{money(r.fin)} تومان</dd><dt>کارمزد ({fa(feePct)}٪)</dt><dd>{money(r.fee)} تومان</dd>
        <dt>هر قسط</dt><dd><b>{money(r.each)} تومان</b></dd><dt>جمع کل پرداخت</dt><dd>{money(r.total)} تومان</dd></dl>
      <p className="mut">مبلغ نهایی را سرور هنگام ثبت دوباره محاسبه می‌کند؛ این برآورد تقریبی است.</p>
      <input type="hidden" name="product" value={sel.id} /><input type="hidden" name="productName" value={sel.title || sel.name} /><input type="hidden" name="amount" value={amount} /><input type="hidden" name="months" value={months} /><input type="hidden" name="down" value={down} />
      <label>توضیح برای کارشناس <span className="mut">(اختیاری)</span><textarea name="note" maxLength={500} /></label>
      {hasCredit ? <label className="chk"><input type="checkbox" name="attachCredit" value="1" defaultChecked /> گزارش اعتباری آماده‌ی من به درخواست پیوست شود</label> : <p className="mut">برای سرعت بیشتر در بررسی، می‌توانید قبل از ثبت یک <a href="/app/credit">استعلام اعتباری</a> انجام دهید.</p>}
      <button className="btn">ثبت درخواست</button></form>) : null}</>);
}
