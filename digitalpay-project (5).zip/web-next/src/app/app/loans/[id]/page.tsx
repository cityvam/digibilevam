import Link from 'next/link';
import { notFound } from 'next/navigation';
import { api } from '@/lib/api';
import { fa, jdt, money } from '@/lib/format';
import { Badge } from '@/components/ui';
import { cancelLoanApp } from '@/actions/customer';
export const metadata = { title: 'درخواست وام' };
const T: Record<string, string> = { Submitted: 'ثبت‌شده', InReview: 'در حال بررسی', NeedInfo: 'نیازمند اطلاعات بیشتر', Approved: 'تأیید شد', Rejected: 'رد شد', Cancelled: 'لغو شد' };
export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params; const d = await api.soft(`/api/v1/me/loan-applications/${encodeURIComponent(id)}`); if (!d) notFound(); const a = d.application, ev: any[] = d.events || [];
  return (<><div className="row"><h1>درخواست <span className="ltr">{a.code}</span></h1><span className="sp" /><Badge group="loanapp" s={a.status} /></div>
    <p className="mut">{a.productName} — ثبت {jdt(a.createdOn)}</p>
    {a.reviewNote ? <div className={`flash ${a.status === 'Rejected' ? 'err' : 'ok'}`} role="status"><b>پیام کارشناس:</b> {a.reviewNote}</div> : null}
    {a.status === 'NeedInfo' ? <p>مدارک خواسته‌شده را در <Link href="/app/documents">بخش مدارک</Link> بارگذاری کنید؛ سپس کارشناس بررسی را ادامه می‌دهد.</p> : null}
    {a.status === 'Approved' ? <p>درخواست شما تأیید شد؛ قرارداد پس از آماده‌شدن در <Link href="/app/contracts">بخش قراردادها</Link> برای قبول قرار می‌گیرد.</p> : null}
    <div className="grid two"><div className="card"><h2>شرایط درخواست</h2><dl className="kv"><dt>مبلغ خرید</dt><dd>{money(a.amount)} تومان</dd><dt>پیش‌پرداخت ({fa(a.downPercent)}٪)</dt><dd>{money(a.down)} تومان</dd><dt>مبلغ تسهیلات</dt><dd>{money(a.financed)} تومان</dd>
      <dt>کارمزد ({fa(a.feePercent)}٪)</dt><dd>{money(a.fee)} تومان</dd><dt>مدت</dt><dd>{fa(a.months)} ماه</dd><dt>هر قسط</dt><dd><b>{money(a.each)} تومان</b></dd><dt>قسط آخر</dt><dd>{money(a.last)} تومان</dd><dt>جمع کل پرداخت</dt><dd>{money(a.total)} تومان</dd></dl>
      {a.customerNote ? <p className="mut">توضیح شما: {a.customerNote}</p> : null}{a.creditRequestId ? <p className="mut">گزارش اعتباری شما پیوست شده است.</p> : null}</div>
      <div className="card"><h2>روند بررسی</h2><ol className="tl">{ev.map((e, i) => <li key={i}><b>{T[e.toStatus] || e.toStatus}</b> <span className="mut">{jdt(e.createdOn)}{e.byStaff ? ' — کارشناس' : ''}</span>{e.note && e.note !== 'ثبت درخواست' ? <div>{e.note}</div> : null}</li>)}</ol>
        {a.canCancel ? <form action={cancelLoanApp.bind(null, a.id)}><button className="btn sm danger">لغو درخواست</button></form> : null}</div></div>
    <p><Link href="/app/loans">← همه‌ی درخواست‌ها</Link></p></>);
}
