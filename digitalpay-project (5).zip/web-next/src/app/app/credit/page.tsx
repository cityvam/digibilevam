import Link from 'next/link';
import { api } from '@/lib/api';
import { fa, jdt } from '@/lib/format';
import { Badge, Table } from '@/components/ui';
import { startCredit } from '@/actions/customer';
export const metadata = { title: 'اعتبارسنجی' };
export default async function Page() {
  const xs: any[] = await api.get('/api/v1/me/credit');
  return (<><h1>اعتبارسنجی</h1>
    <p className="mut">گزارش اعتباری شما از «شرکت اعتبارسنجی ایران» دریافت می‌شود. برای تأیید هویت، یک رمز یکبارمصرف به موبایل شما پیامک می‌شود؛ شماره باید به نام همان کد ملی ثبت شده باشد.</p>
    <div className="grid two">
      <div><h2>استعلام‌های من</h2><Table heads={['کد', 'وضعیت', 'ثبت', '']} empty="هنوز استعلامی نداشته‌اید" rows={xs.map((r) => [<span key="c" className="ltr">{r.code}</span>, <Badge key="b" group="credit" s={r.status} />, jdt(r.createdOn), <Link key="l" href={`/app/credit/${r.id}`}>{r.reportReady ? 'دیدن گزارش' : 'پیگیری'}</Link>])} /></div>
      <form className="f card" action={startCredit}><h2>استعلام جدید</h2>
        <label>کد ملی<input name="nc" className="ltr" inputMode="numeric" autoComplete="off" required maxLength={10} pattern="[0-9۰-۹]{10}" /></label>
        <label>شماره‌ی موبایل (به نام همین کد ملی)<input name="mobile" className="ltr" inputMode="tel" autoComplete="tel" required maxLength={11} pattern="[0-9۰-۹]{11}" placeholder="09121234567" /></label>
        <label>شناسه‌ی ملی شرکت <span className="mut">(فقط شخص حقوقی؛ آنگاه کد ملی و موبایل مدیرعامل را وارد کنید)</span><input name="legal" className="ltr" inputMode="numeric" maxLength={11} pattern="([0-9۰-۹]{11})?" /></label>
        <label className="chk"><input type="checkbox" name="consent" value="1" required /> با دریافت گزارش اعتباری خودم از شرکت اعتبارسنجی ایران و ارائه‌ی آن به {`دیجی‌بایل پی`} برای بررسی درخواست خرید اقساطی موافقم.</label>
        <button className="btn">ارسال رمز یکبارمصرف</button>
        <p className="mut">هر درخواست {fa(24)} ساعت معتبر است و رمز حداکثر {fa(5)} بار قابل ارسال مجدد است.</p></form></div></>);
}
