import Link from 'next/link';
import { notFound } from 'next/navigation';
import { api } from '@/lib/api';
import { fa, jdt } from '@/lib/format';
import { awaitingOtp, processing, SMS_STATUS } from '@/lib/credit';
import { Badge } from '@/components/ui';
import { ReportTree } from '@/components/ReportTree';
import { creditOp, creditOtp } from '@/actions/customer';
export const metadata = { title: 'استعلام اعتباری' };
export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params; const v = await api.soft(`/api/v1/me/credit/${encodeURIComponent(id)}`); if (!v) notFound();
  const rep = v.reportReady ? await api.soft(`/api/v1/me/credit/${encodeURIComponent(id)}/report`) : null;
  const wait = Number(v.resendIn) || 0;
  return (<>
    {processing(v) ? <meta httpEquiv="refresh" content="8" /> : null}
    <div className="row"><h1>استعلام اعتباری</h1><span className="sp" /><Badge group="credit" s={v.status} /></div>
    <p className="mut"><span className="ltr">{v.code}</span> — کد ملی <span className="ltr">{v.ncMask}</span> — موبایل <span className="ltr">{v.mobileMask}</span> — ثبت {jdt(v.createdOn)}</p>
    {v.lastError ? <div className="flash err" role="alert">{v.lastError}</div> : null}
    {awaitingOtp(v) ? (<div className="grid two">
      <form className="f card" action={creditOtp.bind(null, v.id)}><h2>رمز یکبارمصرف</h2>
        <p className="mut">رمز به شماره‌ی {v.mobileMask} پیامک شد. {v.otpMessageStatus ? <>وضعیت پیامک: {SMS_STATUS[v.otpMessageStatus] || '—'}.</> : null}</p>
        <label>رمز<input name="token" className="ltr" inputMode="numeric" autoComplete="one-time-code" required minLength={4} maxLength={8} autoFocus /></label><button className="btn">تأیید و ساخت گزارش</button></form>
      <div className="card"><h2>رمز نرسید؟</h2>
        <p>ارسال {fa(v.otpSends)} از {fa(v.maxOtpSends)}. {v.resendLocked ? 'سقف ارسال مجدد پر شده است؛ تا ۲۴ ساعت با پشتیبانی تماس بگیرید.' : wait > 0 ? <>برای ارسال مجدد حدود {fa(wait)} ثانیه صبر کنید و صفحه را تازه کنید.</> : 'می‌توانید رمز جدید بگیرید.'}</p>
        <form action={creditOp.bind(null, v.id, 'resend')}><button className="btn ghost" disabled={v.resendLocked || wait > 0}>ارسال مجدد رمز</button></form>
        <p className="mut">مهلت این درخواست تا {jdt(v.hashExpiresOn)}</p></div></div>) : null}
    {processing(v) ? (<div className="card"><h2>در حال ساخت گزارش…</h2><p>معمولاً چند ثانیه تا چند دقیقه طول می‌کشد؛ این صفحه خودکار تازه می‌شود.</p>
      <form action={creditOp.bind(null, v.id, 'refresh')}><button className="btn ghost">به‌روزرسانی وضعیت</button></form></div>) : null}
    {v.canRegenerate ? (<div className="card"><h2>ساخت گزارش ناموفق بود</h2><p>نیازی به رمز جدید نیست؛ همان درخواست دوباره اجرا می‌شود (تا {jdt(v.hashExpiresOn)}).</p>
      <form action={creditOp.bind(null, v.id, 'regenerate')}><button className="btn">تلاش دوباره</button></form></div>) : null}
    {v.settled && !v.reportReady && !v.canRegenerate ? <div className="card"><p>این استعلام به پایان رسیده است. در صورت نیاز یک استعلام جدید ثبت کنید. <Link href="/app/credit">بازگشت</Link></p></div> : null}
    {rep ? (<div className="stack"><div className="row"><h2>گزارش اعتباری</h2><span className="sp" />
        <a className="btn sm" href={`/files/me/credit/${v.id}`}>دریافت PDF</a></div>
      <p className="mut">{v.score != null ? <>امتیاز: <b>{fa(v.score)}</b> — </> : null}دریافت {jdt(v.reportAt)} — اعتبار دریافت تا {jdt(v.reportExpiresOn)}</p>
      <div className="card"><ReportTree data={rep.report} /></div></div>) : null}
    <p><Link href="/app/credit">← همه‌ی استعلام‌ها</Link></p></>);
}
