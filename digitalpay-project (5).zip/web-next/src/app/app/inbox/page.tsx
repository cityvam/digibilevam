import Link from 'next/link';
import { api } from '@/lib/api';
import { jdt } from '@/lib/format';
import { Empty } from '@/components/ui';
import { readAll } from '@/actions/customer';
export const metadata = { title: 'اعلان‌ها' };
const safe = (l: unknown) => (/^\/(?!\/)[\w\-./?=&%]*$/.test(String(l)) ? String(l) : '/app/inbox');
export default async function Inbox() {
  const n: any[] = await api.get('/api/v1/me/notifications');
  return (<><div className="row"><h1>اعلان‌ها</h1><span className="sp" /><form action={readAll}><button className="btn sm ghost">همه خوانده شد</button></form></div>
    {n.length ? <div className="tick">{n.map((x, i) => <div key={i} className="msg">{x.isRead ? null : <><span className="badge info">جدید</span> </>}<strong>{x.title}</strong><div className="mut">{x.body}</div>
      <div className="meta">{jdt(x.createdOn)}{x.link ? <> — <Link href={safe(x.link)}>باز کردن</Link></> : null}</div></div>)}</div> : <Empty>اعلانی ندارید</Empty>}</>);
}
