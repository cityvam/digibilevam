import Link from 'next/link';
import { api } from '@/lib/api';
import { fa, STATUS } from '@/lib/format';
import { Badge, Table } from '@/components/ui';
import { createTicket } from '@/actions/customer';
export const metadata = { title: 'پشتیبانی' };
export default async function Tickets() {
  const ts: any[] = await api.get('/api/v1/me/tickets');
  return (<><h1>پشتیبانی</h1><div className="grid two">
    <div><Table heads={['کد', 'موضوع', 'وضعیت', '']} empty="تیکتی ندارید" rows={ts.map((t) => [fa(t.code), t.subject, <Badge key="b" group="ticket" s={t.status} />, <Link key="l" href={`/app/tickets/${t.id}`}>باز کردن</Link>])} /></div>
    <form className="f card" action={createTicket}><h2>تیکت جدید</h2>
      <label>موضوع<input name="subject" required maxLength={120} /></label>
      <label>دسته<select name="category">{Object.entries(STATUS.category).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></label>
      <label>پیام<textarea name="body" required /></label><button className="btn">ارسال</button></form></div></>);
}
