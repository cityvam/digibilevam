import { api } from '@/lib/api';
import { fa, jdt } from '@/lib/format';
import { Badge } from '@/components/ui';
import { replyTicket } from '@/actions/customer';
export default async function Ticket({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params; const t = await api.get(`/api/v1/me/tickets/${encodeURIComponent(id)}`);
  return (<><div className="row"><h1>{t.subject}</h1><span className="sp" /><Badge group="ticket" s={t.status} /></div><p className="mut">کد {fa(t.code)}</p>
    <div className="tick">{t.messages.map((m: any, i: number) => <div key={i} className={`msg ${m.isStaff ? 'staff' : ''}`}><div className="meta">{m.isStaff ? 'پشتیبان' : 'شما'} — {jdt(m.createdOn)}</div>{m.body}</div>)}</div>
    <form className="f card" action={replyTicket.bind(null, t.id)}><label>پاسخ شما<textarea name="body" required /></label><button className="btn">ارسال پاسخ</button></form></>);
}
