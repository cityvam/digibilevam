import { api } from '@/lib/api';
import { fa, jdate, money } from '@/lib/format';
import { Badge, Table } from '@/components/ui';
import MoneyInput from '@/components/MoneyInput';
import { declarePayment } from '@/actions/customer';
export const metadata = { title: 'اعلام واریز' };
const METHODS: Record<string, string> = { CardToCard: 'کارت به کارت', BankTransfer: 'حواله‌ی بانکی' };
export default async function Payments() {
  const ds: any[] = await api.get('/api/v1/me/payment-declarations');
  return (<><h1>اعلام واریز</h1><div className="grid two">
    <div><Table heads={['مبلغ', 'روش', 'پیگیری', 'تاریخ', 'وضعیت']} empty="واریزی ثبت نشده" rows={ds.map((d) => [money(d.amount), METHODS[d.method] || d.method, fa(d.reference), jdate(d.paidAt), <Badge key="b" group="decl" s={d.status} />])} /></div>
    <form className="f card" action={declarePayment}><h2>ثبت واریز جدید</h2>
      <label>مبلغ (تومان)<MoneyInput name="amount" required /></label>
      <label>روش<select name="method">{Object.entries(METHODS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></label>
      <label>شماره پیگیری<input name="reference" className="ltr" inputMode="numeric" required /></label>
      <label>تاریخ پرداخت (میلادی)<small>مثال: 2026-10-27</small><input name="paidAt" type="date" className="ltr" required /></label>
      <label>توضیح<textarea name="note" maxLength={300} /></label><button className="btn">ثبت</button></form></div></>);
}
