import { api } from '@/lib/api';
import { Badge, Table } from '@/components/ui';
import { uploadDocument } from '@/actions/customer';
export const metadata = { title: 'مدارک' };
const DOC_KINDS: Record<string, string> = { NationalCard: 'کارت ملی (روی کارت)', NationalCardBack: 'کارت ملی (پشت کارت)', Birth: 'شناسنامه', Selfie: 'عکس سلفی با مدرک', Salary: 'فیش حقوقی', Other: 'سایر' };
export default async function Documents() {
  const ds: any[] = await api.get('/api/v1/me/documents');
  return (<><h1>مدارک من</h1><div className="grid two">
    <div><Table heads={['نوع', 'فایل', 'وضعیت', 'توضیح']} empty="هنوز مدرکی بارگذاری نکرده‌اید" rows={ds.map((d) => [DOC_KINDS[d.kind] || d.kind, <span key="f" className="ltr">{d.fileName}</span>, <Badge key="b" group="doc" s={d.status} />, d.reviewNote || '—'])} /></div>
    <form className="f card" action={uploadDocument}><h2>بارگذاری مدرک</h2>
      <label>نوع مدرک<select name="kind">{Object.entries(DOC_KINDS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></label>
      <label>عکس مدرک<small>JPG، PNG یا WEBP تا ۶ مگابایت</small><input type="file" name="file" accept="image/jpeg,image/png,image/webp" required /></label><button className="btn">بارگذاری</button></form></div></>);
}
