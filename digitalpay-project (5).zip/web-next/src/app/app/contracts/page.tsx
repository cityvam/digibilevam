import Link from 'next/link';
import { api } from '@/lib/api';
import { fa, jdate } from '@/lib/format';
import { Badge, Table } from '@/components/ui';
export const metadata = { title: 'قراردادها' };
export default async function Contracts() {
  const cs: any[] = await api.get('/api/v1/me/contracts');
  return (<><h1>قراردادهای من</h1><Table heads={['شماره', 'عنوان', 'وضعیت', 'ارائه', '']} empty="هنوز قراردادی برای شما ارائه نشده است"
    rows={cs.map((c) => [fa(c.number), c.title, <Badge key="b" group="contract" s={c.status} />, jdate(c.presentedAt), <Link key="l" href={`/app/contracts/${c.id}`}>مشاهده</Link>])} /></>);
}
