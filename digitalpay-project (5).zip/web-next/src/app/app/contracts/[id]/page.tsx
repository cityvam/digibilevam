import { notFound } from 'next/navigation';
import { api } from '@/lib/api';
import { fa, jdate, jdt } from '@/lib/format';
import { Badge } from '@/components/ui';
import { rejectContract, signContract } from '@/actions/customer';
export default async function Contract({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const c = (await api.get('/api/v1/me/contracts')).find((x: any) => x.id === id); if (!c) notFound();
  const open = c.status === 'Presented' || c.status === 'AwaitingSignature';
  return (<>
    <div className="row"><h1>{c.title}</h1><span className="sp" /><Badge group="contract" s={c.status} /></div>
    <p className="mut">شماره {fa(c.number)} — مهلت قبول: {jdate(c.expiresAt)}{c.signedAt ? <> — قبول‌شده در {jdt(c.signedAt)}</> : null}</p>
    <iframe className="cframe" title="متن قرارداد" sandbox="" src={`/files/me/contracts/${c.id}`} loading="lazy" />
    {open ? (<div className="grid two">
      <form className="f card" action={signContract.bind(null, c.id)}><label className="chk"><input type="checkbox" name="agree" value="1" required /> متن قرارداد را کامل خوانده‌ام و می‌پذیرم.</label><button className="btn">قبول قرارداد</button>
        <p className="mut">این یک قبول ساده‌ی الکترونیکی است؛ زمان، کاربر، IP و مرورگر ثبت می‌شود و امضای دیجیتال قانونی نیست.</p></form>
      <form className="f card" action={rejectContract.bind(null, c.id)}><label>دلیل رد<textarea name="note" maxLength={300} required /></label><button className="btn danger">رد قرارداد</button></form></div>) : null}
  </>);
}
