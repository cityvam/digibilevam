import { api } from '@/lib/api';
import { money } from '@/lib/format';
import { Empty } from '@/components/ui';
import { cardOp, revealCard } from '@/actions/customer';
export const metadata = { title: 'کارت‌های مجازی' };
const CARD: Record<string, [string, string]> = { Active: ['فعال', 'good'], Frozen: ['مسدود موقت', 'warn'], Closed: ['بسته', 'mute'] };
export default async function Cards() {
  const cs: any[] = await api.get('/api/v1/me/cards');
  return (<><h1>کارت‌های مجازی</h1>
    {cs.length ? <div className="grid">{cs.map((c) => (
      <div key={c.id} className="card"><div className="row"><strong className="ltr">{c.number}</strong><span className="sp" /><span className={`badge ${CARD[c.status]?.[1] || 'mute'}`}>{CARD[c.status]?.[0] || c.status}</span></div>
        <dl className="kv"><dt>دارنده</dt><dd>{c.holderName}</dd><dt>انقضا</dt><dd className="ltr">{c.expiry}</dd><dt>سقف</dt><dd>{money(c.limit)}</dd><dt>مصرف‌شده</dt><dd>{money(c.spent)}</dd><dt>باقی‌مانده</dt><dd>{money(c.remaining)}</dd></dl>
        <div className="row">{c.status !== 'Closed' ? (<><form action={revealCard.bind(null, c.id)}><button className="btn sm">نمایش شماره و CVV</button></form>
          <form action={cardOp.bind(null, c.id, c.status === 'Frozen' ? 'unfreeze' : 'freeze')}><button className="btn sm ghost">{c.status === 'Frozen' ? 'رفع مسدودی' : 'مسدود موقت'}</button></form></>) : null}</div></div>))}</div>
      : <Empty>هنوز کارت مجازی برای شما صادر نشده است</Empty>}</>);
}
