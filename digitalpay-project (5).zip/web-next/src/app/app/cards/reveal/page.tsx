import Link from 'next/link';
import { redirect } from 'next/navigation';
import { readOnce } from '@/lib/session';
export const metadata = { title: 'اطلاعات کارت' };
export default async function Reveal() {
  const r = await readOnce<{ number: string; cvv: string; expiry: string }>(); if (!r?.number) redirect('/app/cards');
  return (<><h1>اطلاعات کامل کارت</h1><div className="card"><dl className="kv"><dt>شماره</dt><dd className="ltr">{r.number}</dd><dt>CVV</dt><dd className="ltr">{r.cvv}</dd><dt>انقضا</dt><dd className="ltr">{r.expiry}</dd></dl>
    <p className="mut">این نمایش در گردش کارت ثبت شد. اطلاعات را با کسی به اشتراک نگذارید. با رفرش صفحه این اطلاعات دیگر نمایش داده نمی‌شود.</p><Link className="btn" href="/app/cards">بازگشت</Link></div></>);
}
