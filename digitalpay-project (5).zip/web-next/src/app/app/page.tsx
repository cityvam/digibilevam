import Link from 'next/link';
import { api } from '@/lib/api';
import { fa, jdate, jdt } from '@/lib/format';
import { Empty, Stat, Table } from '@/components/ui';
import { requireUser } from '@/lib/session';
export const metadata = { title: 'داشبورد' };
export default async function Dash() {
  const u = await requireUser();
  const [cnt, notes, cs, ts] = await Promise.all([api.get('/api/v1/me/notifications/count'), api.get('/api/v1/me/notifications'), api.get('/api/v1/me/contracts'), api.get('/api/v1/me/tickets')]);
  const todo = cs.filter((c: any) => c.status === 'Presented' || c.status === 'AwaitingSignature');
  return (<><h1>سلام {u.name}</h1><p className="lead">خلاصه‌ی وضعیت حساب شما</p>
    <div className="grid"><Stat label="اعلان خوانده‌نشده" value={fa(cnt.unread)} /><Stat label="قراردادهای قبول‌شده" value={fa(cs.filter((c: any) => c.status === 'Signed').length)} />
      <Stat label="نیازمند اقدام شما" value={fa(todo.length)} sub="قرارداد منتظر قبول" /><Stat label="تیکت باز" value={fa(ts.filter((t: any) => t.status !== 'Closed').length)} /></div>
    {todo.length ? (<><h2>قراردادهای منتظر شما</h2><Table heads={['شماره', 'عنوان', 'مهلت', '']} rows={todo.map((c: any) => [fa(c.number), c.title, jdate(c.expiresAt), <Link key="l" className="btn sm" href={`/app/contracts/${c.id}`}>بررسی و قبول</Link>])} /></>) : null}
    <h2>آخرین اعلان‌ها</h2>
    {notes.length ? <div className="tick">{notes.slice(0, 3).map((x: any, i: number) => <div key={i} className="msg"><strong>{x.title}</strong><div className="mut">{x.body}</div><div className="meta">{jdt(x.createdOn)}</div></div>)}</div> : <Empty>اعلانی ندارید</Empty>}</>);
}
