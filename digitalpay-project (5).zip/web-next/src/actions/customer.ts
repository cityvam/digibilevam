'use server';
import { api } from '@/lib/api';
import { en, num } from '@/lib/format';
import { go, requireUser, run, setOnce } from '@/lib/session';
import { clean, legalOk, mobileOk, ncOk, otpOk } from '@/lib/credit';

const s = (fd: FormData, k: string) => String(fd.get(k) ?? '');
const DOC_OK = new Set(['image/jpeg', 'image/png', 'image/webp']);

export async function signContract(id: string, fd: FormData) {
  await requireUser(); const back = `/app/contracts/${id}`;
  if (s(fd, 'agree') !== '1') return go(back, { t: 'err', m: 'برای قبول، تیک موافقت را بزنید.' });
  return run(back, 'قرارداد قبول شد.', () => api.post(`/api/v1/me/contracts/${id}/sign`, {}));
}
export async function rejectContract(id: string, fd: FormData) {
  await requireUser(); return run(`/app/contracts/${id}`, 'قرارداد رد شد.', () => api.post(`/api/v1/me/contracts/${id}/reject`, { note: s(fd, 'note') }));
}
export async function uploadDocument(fd: FormData) {
  await requireUser(); const f = fd.get('file');
  if (!(f instanceof File) || !f.size) return go('/app/documents', { t: 'err', m: 'فایلی انتخاب نشده است.' });
  if (f.size > 6 * 1024 * 1024) return go('/app/documents', { t: 'err', m: 'حجم فایل بیش از ۶ مگابایت است.' });
  if (!DOC_OK.has(f.type)) return go('/app/documents', { t: 'err', m: 'فقط JPG، PNG یا WEBP مجاز است.' });
  const out = new FormData(); out.set('kind', s(fd, 'kind')); out.set('file', f, f.name);
  return run('/app/documents', 'مدرک بارگذاری شد و در انتظار بررسی است.', () => api.upload('/api/v1/me/documents', out));
}
export async function declarePayment(fd: FormData) {
  await requireUser(); const a = num(s(fd, 'amount'));
  if (!(a > 0)) return go('/app/payments', { t: 'err', m: 'مبلغ نامعتبر است.' });
  const d = new Date(s(fd, 'paidAt') + 'T12:00:00Z'); if (isNaN(+d)) return go('/app/payments', { t: 'err', m: 'تاریخ نامعتبر است.' });
  return run('/app/payments', 'واریز ثبت شد و پس از بررسی اعمال می‌شود.', () => api.post('/api/v1/me/payment-declarations', { amount: a, method: s(fd, 'method'), reference: en(s(fd, 'reference')), paidAt: d.toISOString(), note: s(fd, 'note') || null }));
}
export async function revealCard(id: string) {
  await requireUser(); const r = await api.try('POST', `/api/v1/me/cards/${id}/reveal`, {});
  if (!r.ok) return go('/app/cards', { t: 'err', m: api.msg(r) });
  await setOnce({ number: r.data.number, cvv: r.data.cvv, expiry: r.data.expiry }); return go('/app/cards/reveal');
}
export async function cardOp(id: string, op: string) {
  await requireUser(); if (op !== 'freeze' && op !== 'unfreeze') return go('/app/cards');
  return run('/app/cards', 'انجام شد.', () => api.post(`/api/v1/me/cards/${id}/${op}`, {}));
}
export async function readAll() { await requireUser(); return run('/app/inbox', 'انجام شد.', () => api.post('/api/v1/me/notifications/read-all', {})); }
export async function createTicket(fd: FormData) {
  await requireUser(); const r = await api.try('POST', '/api/v1/me/tickets', { subject: s(fd, 'subject'), category: s(fd, 'category'), body: s(fd, 'body') });
  if (!r.ok) return go('/app/tickets', { t: 'err', m: api.msg(r) });
  return go(`/app/tickets/${r.data.id}`, { t: 'ok', m: 'تیکت ثبت شد.' });
}
export async function replyTicket(id: string, fd: FormData) { await requireUser(); return run(`/app/tickets/${id}`, 'ارسال شد.', () => api.post(`/api/v1/me/tickets/${id}/reply`, { body: s(fd, 'body') })); }
export async function setup2fa() { await requireUser(); const r = await api.post('/api/v1/me/2fa/setup'); await setOnce({ secret: r.secret }); return go('/app/security'); }
export async function enable2fa(fd: FormData) {
  await requireUser(); const r = await api.try('POST', '/api/v1/me/2fa/enable', { code: en(s(fd, 'code')) });
  if (!r.ok) return go('/app/security', { t: 'err', m: api.msg(r) });
  await setOnce({ rc: r.data.recoveryCodes || [] }); return go('/app/security', { t: 'ok', m: 'فعال شد.' });
}
export async function disable2fa(fd: FormData) { await requireUser(); return run('/app/security', 'غیرفعال شد.', () => api.post('/api/v1/me/2fa/disable', { code: en(s(fd, 'code')) })); }

// ---- اعتبارسنجی (اعتبارسنجی ایران) ----
const CID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export async function startCredit(fd: FormData) {
  await requireUser(); const back = '/app/credit';
  const nc = clean(fd.get('nc')), mobile = clean(fd.get('mobile')), legal = clean(fd.get('legal'));
  if (s(fd, 'consent') !== '1') return go(back, { t: 'err', m: 'برای استعلام باید رضایت‌نامه را تأیید کنید.' });
  if (!ncOk(nc)) return go(back, { t: 'err', m: 'کد ملی نامعتبر است.' });
  if (!mobileOk(mobile)) return go(back, { t: 'err', m: 'شماره‌ی موبایل نامعتبر است (مثل ۰۹۱۲۱۲۳۴۵۶۷).' });
  if (legal && !legalOk(legal)) return go(back, { t: 'err', m: 'شناسه‌ی ملی شرکت باید ۱۱ رقم باشد.' });
  const r = await api.try('POST', '/api/v1/me/credit', { nationalCode: nc, mobileNumber: mobile, legalNationalCode: legal || null, consent: true });
  if (!r.ok) return go(back, { t: 'err', m: api.msg(r) });
  return go(`/app/credit/${r.data.request.id}`, { t: 'ok', m: 'رمز یکبارمصرف برای موبایل شما پیامک شد.' });
}
const CREDIT_OPS = new Set(['resend', 'refresh', 'regenerate']);
export async function creditOp(id: string, op: string) {
  await requireUser(); const back = `/app/credit/${id}`; if (!CID.test(id) || !CREDIT_OPS.has(op)) return go('/app/credit');
  return run(back, { resend: 'رمز جدید ارسال شد.', refresh: 'وضعیت به‌روز شد.', regenerate: 'درخواست ساخت دوباره‌ی گزارش ثبت شد.' }[op]!, () => api.post(`/api/v1/me/credit/${id}/${op}`, {}));
}
export async function creditOtp(id: string, fd: FormData) {
  await requireUser(); const back = `/app/credit/${id}`; if (!CID.test(id)) return go('/app/credit');
  const t = clean(fd.get('token')); if (!otpOk(t)) return go(back, { t: 'err', m: 'رمز یکبارمصرف را درست وارد کنید.' });
  return run(back, 'رمز پذیرفته شد؛ گزارش در حال ساخت است.', () => api.post(`/api/v1/me/credit/${id}/otp`, { token: t }));
}

// ---- درخواست وام ----
export async function createLoanApp(fd: FormData) {
  await requireUser(); const back = '/app/loans/new';
  const amount = num(en(s(fd, 'amount'))), months = Math.trunc(num(en(s(fd, 'months')))), down = num(en(s(fd, 'down'))), key = s(fd, 'product').trim();
  if (!key) return go(back, { t: 'err', m: 'طرح را انتخاب کنید.' });
  if (!(amount > 0) || !(months > 0) || !(down >= 0)) return go(`${back}?product=${encodeURIComponent(key)}`, { t: 'err', m: 'مبلغ، مدت و پیش‌پرداخت را درست وارد کنید.' });
  const r = await api.try('POST', '/api/v1/me/loan-applications', { productKey: key, productName: s(fd, 'productName'), amount, downPercent: down, months, note: s(fd, 'note').slice(0, 500), attachCredit: s(fd, 'attachCredit') === '1' });
  if (!r.ok) return go(`${back}?product=${encodeURIComponent(key)}&amount=${amount}&months=${months}&down=${down}`, { t: 'err', m: api.msg(r) });
  return go(`/app/loans/${r.data.application.id}`, { t: 'ok', m: 'درخواست ثبت شد؛ نتیجه از طریق اعلان‌ها اطلاع داده می‌شود.' });
}
export async function cancelLoanApp(id: string) {
  await requireUser(); if (!CID.test(id)) return go('/app/loans');
  return run(`/app/loans/${id}`, 'درخواست لغو شد.', () => api.post(`/api/v1/me/loan-applications/${id}/cancel`, {}));
}
