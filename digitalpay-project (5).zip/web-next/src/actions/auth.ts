'use server';
import { api } from '@/lib/api';
import { en } from '@/lib/format';
import { clearState, getState, go, setState, setToken } from '@/lib/session';

const s = (fd: FormData, k: string) => String(fd.get(k) ?? '');

async function finish(d: any) {
  const t = d?.accessToken || d?.token;
  if (!t) return go('/login', { t: 'err', m: 'ورود انجام نشد.' });
  await setToken(t); await clearState('dp_2fa', 'dp_rp', 'dp_rt');
  return go('/app', { t: 'ok', m: 'خوش آمدید.' });
}
export async function login(fd: FormData) {
  const r = await api.try('POST', '/api/v1/security/login', { username: en(s(fd, 'username')), password: s(fd, 'password'), captchaId: s(fd, 'captchaId'), captchaAnswer: en(s(fd, 'captcha')) });
  if (r.status === 202 && r.data?.needs2fa) { await setState('dp_2fa', r.data.ticket, 300); return go('/login'); }
  if (!r.ok) return go('/login', { t: 'err', m: api.msg(r) });
  return finish(r.data);
}
export async function login2fa(fd: FormData) {
  const ticket = await getState('dp_2fa'); if (!ticket) return go('/login', { t: 'err', m: 'زمان تأیید تمام شد؛ دوباره وارد شوید.' });
  const r = await api.try('POST', '/api/v1/security/2fa/complete', { ticket, code: en(s(fd, 'code')) });
  if (!r.ok) return go('/login', { t: 'err', m: api.msg(r) });
  return finish(r.data);
}
export async function restartLogin() { await clearState('dp_2fa'); return go('/login'); }

export async function regPhone(fd: FormData) {
  const phone = en(s(fd, 'phone'));
  const r = await api.try('POST', '/api/v1/security/otp/request', { phone, captchaId: s(fd, 'captchaId'), captchaAnswer: en(s(fd, 'captcha')), purpose: 'register' });
  if (!r.ok) return go('/register', { t: 'err', m: api.msg(r) });
  await setState('dp_rp', phone, 600); return go('/register');
}
export async function regCode(fd: FormData) {
  const phone = await getState('dp_rp'); if (!phone) return go('/register', { t: 'err', m: 'زمان تأیید تمام شد؛ از اول شروع کنید.' });
  const r = await api.try('POST', '/api/v1/security/otp/verify', { phone, code: en(s(fd, 'code')), purpose: 'register' });
  if (!r.ok) return go('/register', { t: 'err', m: api.msg(r) });
  await setState('dp_rt', r.data.ticket, 600); await clearState('dp_rp'); return go('/register');
}
export async function regFinish(fd: FormData) {
  const ticket = await getState('dp_rt'); if (!ticket) return go('/register', { t: 'err', m: 'زمان ثبت‌نام تمام شد؛ از اول شروع کنید.' });
  const r = await api.try('POST', '/api/v1/security/register', { ticket, fullName: s(fd, 'fullName'), nationalCode: en(s(fd, 'nationalCode')), password: s(fd, 'password'), email: s(fd, 'email') || null, captchaId: s(fd, 'captchaId'), captchaAnswer: en(s(fd, 'captcha')) });
  if (!r.ok) return go('/register', { t: 'err', m: api.msg(r) });
  return finish(r.data);
}
export async function restartRegister() { await clearState('dp_rp', 'dp_rt'); return go('/register'); }
export async function logout() { await clearState('dp_t', 'dp_2fa', 'dp_rp', 'dp_rt'); return go('/', { t: 'ok', m: 'خارج شدید.' }); }
