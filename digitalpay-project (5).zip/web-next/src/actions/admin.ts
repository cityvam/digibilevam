'use server';
import { api } from '@/lib/api';
import { en, num } from '@/lib/format';
import { go, requireUser, run } from '@/lib/session';

const s = (fd: FormData, k: string) => String(fd.get(k) ?? '');
const GUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const A = () => requireUser(true);
// فهرست مجاز عملیات: هرگز مسیر API را از ورودی کاربر نساز
const CONTRACT_OPS = new Set(['submit', 'return', 'approve', 'present', 'request-signature', 'cancel']);
const CARD_OPS = new Set(['freeze', 'unfreeze', 'close']);

export async function contractOp(id: string, op: string) { await A(); const b = `/admin/contracts/${id}`; if (!CONTRACT_OPS.has(op)) return go(b); return run(b, 'انجام شد.', () => api.post(`/api/v1/admin/contracts/${id}/${op}`, {})); }
export async function ticketReply(id: string, fd: FormData) { await A(); return run(`/admin/tickets/${id}`, 'ثبت شد.', () => api.post(`/api/v1/admin/tickets/${id}/reply`, { body: s(fd, 'body'), internal: s(fd, 'internal') === '1', close: s(fd, 'close') === '1' })); }
export async function jobRetry(id: string) { await A(); return run('/admin/jobs', 'دوباره در صف قرار گرفت.', () => api.post(`/api/v1/admin/jobs/${id}/retry`, {})); }

const roleBody = (fd: FormData) => ({ name: s(fd, 'name'), description: s(fd, 'description') || null, permissions: fd.getAll('perm').map(String) });
export async function createRole(fd: FormData) { await A(); return run('/admin/roles', 'نقش ساخته شد.', () => api.post('/api/v1/admin/iam/roles', roleBody(fd))); }
export async function seedRoles() { await A(); return run('/admin/roles', 'نقش‌های پیش‌فرض اضافه شد.', () => api.post('/api/v1/admin/iam/seed-defaults', {})); }
export async function assignRole(fd: FormData) {
  await A(); if (!GUID.test(s(fd, 'userId'))) return go('/admin/roles', { t: 'err', m: 'شناسه‌ی کاربر معتبر نیست.' });
  return run('/admin/roles', 'نقش تخصیص داده شد.', () => api.post('/api/v1/admin/iam/assign', { userId: s(fd, 'userId'), roleId: s(fd, 'roleId') }));
}
export async function unassignRole(id: string) { await A(); return run('/admin/roles', 'نقش برداشته شد.', () => api.del(`/api/v1/admin/iam/assignments/${id}`)); }
export async function deleteRole(id: string) { await A(); return run('/admin/roles', 'حذف شد.', () => api.del(`/api/v1/admin/iam/roles/${id}`)); }
export async function saveRole(id: string, fd: FormData) { await A(); return run('/admin/roles', 'ذخیره شد.', () => api.put(`/api/v1/admin/iam/roles/${id}`, roleBody(fd))); }

export async function reviewDocument(id: string, fd: FormData) { await A(); return run('/admin/documents', 'ثبت شد.', () => api.put(`/api/v1/admin/documents/${id}/review`, { status: s(fd, 'status'), note: s(fd, 'note') || null })); }
export async function reviewPayment(id: string, fd: FormData) { await A(); return run('/admin/payments', 'ثبت شد.', () => api.post(`/api/v1/admin/payment-declarations/${id}/review`, { status: s(fd, 'status'), note: s(fd, 'note') || null })); }
export async function seedProducts() { await A(); return run('/admin/products', 'طرح‌های نمونه ساخته شد.', () => api.post('/api/v1/admin/loan-products/seed', {})); }
export async function toggleProduct(id: string) { await A(); return run('/admin/products', 'وضعیت طرح عوض شد.', () => api.post(`/api/v1/admin/loan-products/${id}/toggle`, {})); }
export async function issueCard(fd: FormData) {
  await A(); const lim = num(s(fd, 'limit'));
  if (!GUID.test(s(fd, 'loanId')) || !GUID.test(s(fd, 'userId')) || !(lim > 0)) return go('/admin/cards', { t: 'err', m: 'شناسه‌ها یا سقف نامعتبر است.' });
  return run('/admin/cards', 'کارت صادر شد.', () => api.post('/api/v1/admin/virtual-cards/issue', { loanId: s(fd, 'loanId'), userId: s(fd, 'userId'), holderName: s(fd, 'holderName'), limit: lim }));
}
export async function adminCardOp(id: string, op: string) { await A(); if (!CARD_OPS.has(op)) return go('/admin/cards'); return run('/admin/cards', 'انجام شد.', () => api.post(`/api/v1/admin/virtual-cards/${id}/${op}`, {})); }
