'use server';
import { api } from '@/lib/api';
import { en, fa, num } from '@/lib/format';
import { go, requireUser, run, setOnce } from '@/lib/session';
import { clean, legalOk, mobileOk, ncOk, otpOk } from '@/lib/credit';

const s = (fd: FormData, k: string) => String(fd.get(k) ?? '');
const GUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const A = () => requireUser(true);

export async function addCounterparty(fd: FormData) { await A(); return run('/admin/counterparties', 'افزوده شد.', () => api.post('/api/v1/admin/counterparties', { name: s(fd, 'name'), iban: en(s(fd, 'iban')), isActive: true })); }
export async function toggleCounterparty(id: string, name: string, iban: string, active: boolean) { await A(); return run('/admin/counterparties', 'ذخیره شد.', () => api.put(`/api/v1/admin/counterparties/${id}`, { name, iban, isActive: active })); }
export async function addMarketer(fd: FormData) { await A(); return run('/admin/marketers', 'افزوده شد.', () => api.post('/api/v1/admin/marketers', { name: s(fd, 'name'), phone: en(s(fd, 'phone')), commissionPercent: num(s(fd, 'commission')) || 0, isActive: true })); }
export async function toggleMarketer(id: string, name: string, phone: string, commission: number, active: boolean) { await A(); return run('/admin/marketers', 'ذخیره شد.', () => api.put(`/api/v1/admin/marketers/${id}`, { name, phone, commissionPercent: commission, isActive: active })); }
export async function addOrder(fd: FormData) {
  await A(); const a = num(s(fd, 'amount')), loan = s(fd, 'loanId');
  if (!GUID.test(s(fd, 'userId')) || (loan && !GUID.test(loan)) || !(a > 0)) return go('/admin/orders', { t: 'err', m: 'شناسه یا مبلغ نامعتبر است.' });
  return run('/admin/orders', 'سفارش ثبت شد.', () => api.post('/api/v1/admin/orders', { userId: s(fd, 'userId'), loanId: loan || null, merchantName: s(fd, 'merchant'), amount: a }));
}
export async function orderStatus(id: string, status: string) { await A(); if (status !== 'Delivered' && status !== 'Cancelled') return go('/admin/orders'); return run('/admin/orders', 'وضعیت ثبت شد.', () => api.post(`/api/v1/admin/orders/${id}/status`, { status })); }
export async function addInquiry(fd: FormData) {
  await A(); if (!GUID.test(s(fd, 'userId'))) return go('/admin/inquiries', { t: 'err', m: 'شناسه‌ی مشتری نامعتبر است.' });
  return run('/admin/inquiries', 'ثبت شد.', () => api.post('/api/v1/admin/inquiries', { userId: s(fd, 'userId'), type: s(fd, 'type'), note: s(fd, 'note') || null }));
}
export async function inquiryResult(id: string, fd: FormData) { await A(); return run('/admin/inquiries', 'نتیجه ثبت شد.', () => api.post(`/api/v1/admin/inquiries/${id}/result`, { status: s(fd, 'status'), result: s(fd, 'result') || null })); }
export async function makeBackup() { const u = await A(); if (!u.isSuper) return go('/admin', { t: 'err', m: 'فقط مدیر ارشد.' }); return run('/admin/backups', 'پشتیبان تهیه شد.', () => api.post('/api/v1/admin/backups', {})); }

// ---- قالب‌ها ----
const dIn = (v: string) => (/^\d{4}-\d{2}-\d{2}$/.test(v) ? `${v}T00:00:00Z` : null);
const tplBody = (fd: FormData) => ({ title: s(fd, 'title'), type: s(fd, 'type'), issuerParty: s(fd, 'issuerParty') || null, parties: [], description: s(fd, 'description') || null, usageConditions: s(fd, 'usageConditions') || null, counterPartyId: null, restricted: s(fd, 'restricted') === '1', headerHtml: s(fd, 'headerHtml') || null, bodyHtml: s(fd, 'bodyHtml') || null, footerHtml: s(fd, 'footerHtml') || null, validFrom: dIn(s(fd, 'validFrom')), validTo: dIn(s(fd, 'validTo')), changeNote: s(fd, 'changeNote') || null });
export async function createTemplate(fd: FormData) {
  await A(); const r = await api.try('POST', '/api/v1/admin/contract-templates', tplBody(fd));
  if (!r.ok) return go('/admin/templates/new', { t: 'err', m: api.msg(r) });
  return go(`/admin/templates/${r.data.id}`, { t: 'ok', m: 'قالب ساخته شد.' });
}
export async function saveTemplate(id: string, fd: FormData) {
  await A(); const r = await api.try('PUT', `/api/v1/admin/contract-templates/${id}`, tplBody(fd)); const b = `/admin/templates/${id}`;
  if (!r.ok) return go(b, { t: 'err', m: api.msg(r) });
  await setOnce({ problems: r.data?.problems || [] }); return go(b, { t: 'ok', m: 'ذخیره شد.' });
}
export async function validateTemplate(id: string) {
  await A(); const r = await api.try('POST', `/api/v1/admin/contract-templates/${id}/validate`, {}); const b = `/admin/templates/${id}`;
  if (!r.ok) return go(b, { t: 'err', m: api.msg(r) }); await setOnce({ problems: r.data.problems || [] }); return go(b);
}
export async function approveTemplate(id: string) {
  await A(); const r = await api.try('POST', `/api/v1/admin/contract-templates/${id}/approve`, {}); const b = `/admin/templates/${id}`;
  if (r.status === 422) { await setOnce({ problems: r.data.problems || [] }); return go(b); }
  return go(b, r.ok ? { t: 'ok', m: 'قالب تأیید شد.' } : { t: 'err', m: api.msg(r) });
}
export async function publishTemplate(id: string) { await A(); return run(`/admin/templates/${id}`, 'قالب منتشر شد.', () => api.post(`/api/v1/admin/contract-templates/${id}/publish`, {})); }
export async function archiveTemplate(id: string) { await A(); return run('/admin/templates', 'بایگانی شد.', () => api.post(`/api/v1/admin/contract-templates/${id}/archive`, {})); }
export async function newVersion(id: string) {
  await A(); const r = await api.try('POST', `/api/v1/admin/contract-templates/${id}/new-version`, {});
  if (!r.ok) return go(`/admin/templates/${id}`, { t: 'err', m: api.msg(r) });
  return go(`/admin/templates/${r.data.id}`, { t: 'ok', m: `نسخه‌ی ${fa(r.data.version)} ساخته شد.` });
}
export async function uploadSample(id: string, fd: FormData) {
  await A(); const f = fd.get('file'); const b = `/admin/templates/${id}`;
  if (!(f instanceof File) || !f.size) return go(b, { t: 'err', m: 'فایلی انتخاب نشده است.' });
  if (f.size > 5 * 1024 * 1024) return go(b, { t: 'err', m: 'حجم فایل بیش از ۵ مگابایت است.' });
  const out = new FormData(); out.set('file', f, f.name);
  return run(b, 'فایل نمونه بارگذاری شد.', () => api.upload(`/api/v1/admin/contract-templates/${id}/sample`, out));
}
// ---- متغیرها ----
export async function addVariable(fd: FormData) {
  await A(); return run('/admin/variables', 'متغیر افزوده شد.', () => api.post('/api/v1/admin/contract-variables', { key: s(fd, 'key'), label: s(fd, 'label'), dataType: s(fd, 'dataType'), source: s(fd, 'source'), path: s(fd, 'path') || null, required: s(fd, 'required') === '1', format: null, sensitivity: s(fd, 'sensitive') === '1' ? 'Sensitive' : 'Normal', defaultValue: s(fd, 'defaultValue') || null, validation: null }));
}
export async function syncVariables() { await A(); return run('/admin/variables', 'انجام شد.', () => api.post('/api/v1/admin/contract-variables/sync-defaults', {})); }
export async function deleteVariable(id: string) { await A(); return run('/admin/variables', 'حذف شد.', () => api.del(`/api/v1/admin/contract-variables/${id}`)); }
// ---- قراردادهای طرح ----
export async function saveProductContracts(id: string, fd: FormData) {
  await A(); const n = Math.min(+s(fd, 'count') || 0, 20), items: any[] = [];
  for (let i = 0; i < n; i++) if (s(fd, 'del_' + i) !== '1' && GUID.test(s(fd, 'gk_' + i))) items.push({ groupKey: s(fd, 'gk_' + i), stage: s(fd, 'stage_' + i), required: s(fd, 'req_' + i) === '1', condition: s(fd, 'cond_' + i) || null, requiresReview: s(fd, 'rev_' + i) === '1', sortOrder: items.length });
  if (GUID.test(s(fd, 'gk_new'))) items.push({ groupKey: s(fd, 'gk_new'), stage: s(fd, 'stage_new'), required: true, condition: null, requiresReview: true, sortOrder: items.length });
  return run(`/admin/products/${id}/contracts`, 'ذخیره شد.', () => api.put(`/api/v1/admin/loan-products/${id}/contracts`, items));
}

// ---- اعتبارسنجی (مدیریت) ----
const CRID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const CR_OPS = new Set(['resend', 'refresh', 'regenerate']);
export async function adminCreditStart(fd: FormData) {
  await requireUser(true); const back = '/admin/credit'; const uid = String(fd.get('userId') ?? '').trim();
  const nc = clean(fd.get('nc')), mobile = clean(fd.get('mobile')), legal = clean(fd.get('legal'));
  if (!CRID.test(uid)) return go(back, { t: 'err', m: 'شناسه‌ی مشتری نامعتبر است.' });
  if (String(fd.get('consent') ?? '') !== '1') return go(back, { t: 'err', m: 'تأیید رضایت مشتری الزامی است.' });
  if (!ncOk(nc)) return go(back, { t: 'err', m: 'کد ملی نامعتبر است.' }); if (!mobileOk(mobile)) return go(back, { t: 'err', m: 'موبایل نامعتبر است.' });
  if (legal && !legalOk(legal)) return go(back, { t: 'err', m: 'شناسه‌ی ملی شرکت باید ۱۱ رقم باشد.' });
  const r = await api.try('POST', '/api/v1/admin/credit', { userId: uid, nationalCode: nc, mobileNumber: mobile, legalNationalCode: legal || null, consent: true });
  if (!r.ok) return go(back, { t: 'err', m: api.msg(r) });
  return go(`/admin/credit/${r.data.request.id}`, { t: 'ok', m: 'استعلام ثبت شد و رمز برای مشتری پیامک شد.' });
}
export async function adminCreditOp(id: string, op: string) {
  await requireUser(true); const back = `/admin/credit/${id}`; if (!CRID.test(id) || !CR_OPS.has(op)) return go('/admin/credit');
  return run(back, 'انجام شد.', () => api.post(`/api/v1/admin/credit/${id}/${op}`, {}));
}
export async function adminCreditOtp(id: string, fd: FormData) {
  await requireUser(true); const back = `/admin/credit/${id}`; if (!CRID.test(id)) return go('/admin/credit');
  const t = clean(fd.get('token')); if (!otpOk(t)) return go(back, { t: 'err', m: 'رمز را درست وارد کنید.' });
  return run(back, 'رمز ثبت شد.', () => api.post(`/api/v1/admin/credit/${id}/otp`, { token: t }));
}
export async function creditSettings(fd: FormData) {
  await requireUser(true); const days = num(en(String(fd.get('retentionDays') ?? ''))); const ms = String(fd.get('minScore') ?? '').trim();
  if (!(days >= 1 && days <= 365)) return go('/admin/credit', { t: 'err', m: 'مدت نگهداری گزارش باید بین ۱ تا ۳۶۵ روز باشد.' });
  return run('/admin/credit', 'تنظیمات ذخیره شد.', () => api.put('/api/v1/admin/credit/settings', { enabled: String(fd.get('enabled')) === '1', autoFetchReport: String(fd.get('autoFetch')) === '1', retentionDays: days, minScore: ms ? num(en(ms)) : null }));
}

// ---- درخواست وام (مدیر) ----
const LA_TO = new Set(['InReview', 'NeedInfo', 'Approved', 'Rejected']);
export async function reviewLoanApp(id: string, fd: FormData) {
  await requireUser(true); const back = `/admin/loans/${id}`; if (!CRID.test(id)) return go('/admin/loans');
  const to = String(fd.get('status') ?? ''); if (!LA_TO.has(to)) return go(back, { t: 'err', m: 'وضعیت نامعتبر است.' });
  return run(back, 'ثبت شد.', () => api.post(`/api/v1/admin/loan-applications/${id}/review`, { status: to, note: String(fd.get('note') ?? '').slice(0, 500) }));
}
