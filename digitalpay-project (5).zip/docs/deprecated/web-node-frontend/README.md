# digitalpay-web (Node.js)
فرانت‌اند رندر سمت سرور، بدون وابستگی npm، روی API ی ASP.NET Core. توکن در کوکی HttpOnly، CSRF دوبل، CSP سخت‌گیر (بدون اسکریپت/استایل درون‌خطی).
- اجرا (توسعه): `npm run mock` در یک ترمینال، `npm run dev` در دیگری، سپس http://127.0.0.1:3000 (مشتری: هر نام کاربری با رمز دلخواه؛ مدیر: نام کاربری که به 0000 ختم شود، کد دومرحله‌ای 123456).
- تست: `npm test`   پیش‌نمایش ایستا: `npm run preview`   دود مرورگر: `python3 tools/e2e_smoke.py URL`
- نصب سرور: `sudo bash install-web.sh`
- نقشه‌ی صفحه‌ها: src/pages/{public,customer,admin}.js ؛ قرارداد API: mock/mock-api.js
