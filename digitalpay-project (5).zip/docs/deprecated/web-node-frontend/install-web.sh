#!/usr/bin/env bash
# نصب فرانت Node.js روی Ubuntu. با sudo اجرا شود. چیزی را از سرویس ASP.NET تغییر نمی‌دهد.
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "با sudo اجرا کنید"; exit 1; }
command -v node >/dev/null || { echo "Node.js ≥ 20 لازم است: apt install nodejs  (یا NodeSource)"; exit 1; }
node -e 'process.exit(+process.versions.node.split(".")[0]>=20?0:1)' || { echo "Node قدیمی است"; exit 1; }
SRC="$(cd "$(dirname "$0")" && pwd)"; DEST=/opt/digitalpay-web
id dpweb >/dev/null 2>&1 || useradd --system --no-create-home --shell /usr/sbin/nologin dpweb
mkdir -p "$DEST" /etc/digitalpay && rsync -a --delete --exclude mock --exclude test --exclude tools --exclude .env "$SRC/" "$DEST/" 2>/dev/null || cp -r "$SRC/src" "$SRC/public" "$SRC/package.json" "$DEST/"
if [ ! -f /etc/digitalpay/web.env ]; then cp "$SRC/.env.sample" /etc/digitalpay/web.env; sed -i "s/^WEB_SECRET=.*/WEB_SECRET=$(openssl rand -hex 32)/" /etc/digitalpay/web.env; chmod 600 /etc/digitalpay/web.env; chown root:dpweb /etc/digitalpay/web.env; chmod 640 /etc/digitalpay/web.env; echo "ساخته شد: /etc/digitalpay/web.env (API_HOST_HEADER را بررسی کنید)"; fi
cp "$SRC/digitalpay-web.service" /etc/systemd/system/ && systemctl daemon-reload && systemctl enable --now digitalpay-web
sleep 1; curl -fsS http://127.0.0.1:3000/healthz && echo " ← سرویس بالا است"
echo "بعد: nginx را طبق nginx.snippet تنظیم کنید و nginx -t && systemctl reload nginx"
