import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { html, raw, money, num, fa, en } from '../src/lib/ui.js';
import { calc } from '../src/lib/calc.js';
import { csrfToken, csrfOk } from '../src/lib/csrf.js';
import { claims } from '../src/lib/jwt.js';
import { startMock } from '../mock/mock-api.js';

test('html escapes by default, raw opts out', () => {
  assert.equal(String(html`<b>${'<script>"x"</script>'}</b>`), '<b>&lt;script&gt;&quot;x&quot;&lt;/script&gt;</b>');
  assert.equal(String(html`${raw('<i>ok</i>')}`), '<i>ok</i>');
  assert.equal(String(html`${[html`<a>${'&'}</a>`, false, null]}`), '<a>&amp;</a>');
});
test('money / digits', () => {
  assert.equal(money(1234567), '۱,۲۳۴,۵۶۷'); assert.equal(money('0.12345678'), '۰.۱۲۳۴۵۶۷۸'); assert.equal(money(null), '—');
  assert.equal(num('۱۲,۰۰۰'), 12000); assert.ok(Number.isNaN(num('abc'))); assert.equal(en('۱۲٫۵'), '12.5');
});
test('calc mirrors ContractEngine', () => {
  const r = calc(10000000, 20, 12, 6); assert.deepEqual([r.down, r.fin, r.fee, r.total, r.each, r.last], [2000000, 8000000, 960000, 8960000, 1493334, 8960000 - 1493334 * 5]);
  assert.equal(r.each * 5 + r.last, r.total);
});
test('csrf', () => { const t = csrfToken('s'.repeat(32), 'v1'); assert.ok(csrfOk('s'.repeat(32), 'v1', t)); assert.ok(!csrfOk('s'.repeat(32), 'v2', t)); assert.ok(!csrfOk('s'.repeat(32), 'v1', '')); });
test('jwt claims', () => { const b = (o) => Buffer.from(JSON.stringify(o)).toString('base64url'); const c = claims(`${b({})}.${b({ name: 'a', role: ['Admin'], exp: 9999999999 })}.x`); assert.deepEqual(c.roles, ['Admin']); assert.equal(claims('garbage'), null); });

test('integration: guards, csrf, login, admin 403', async () => {
  const mock = await startMock(5292); const web = spawn('node', ['src/server.js'], { env: { ...process.env, PORT: '3012', API_URL: 'http://127.0.0.1:5292' }, stdio: 'ignore' });
  await new Promise((r) => setTimeout(r, 1000)); const B = 'http://127.0.0.1:3012';
  try {
    let r = await fetch(B + '/app', { redirect: 'manual' }); assert.equal(r.status, 303); assert.equal(r.headers.get('location'), '/login');
    assert.match(r.headers.get('content-security-policy'), /script-src 'self'/);
    const jar = {}; const eat = (res) => res.headers.getSetCookie().forEach((s) => { const [kv] = s.split(';'); const i = kv.indexOf('='); jar[kv.slice(0, i)] = kv.slice(i + 1); }); const ck = () => Object.entries(jar).map(([k, v]) => `${k}=${v}`).join('; ');
    r = await fetch(B + '/login'); eat(r); const tk = (await r.text()).match(/name="_csrf" value="([^"]+)"/)[1];
    r = await fetch(B + '/login', { method: 'POST', headers: { cookie: ck(), 'content-type': 'application/x-www-form-urlencoded' }, body: 'phone=0912&password=x&_csrf=wrong' }); assert.equal(r.status, 403);
    r = await fetch(B + '/login', { method: 'POST', redirect: 'manual', headers: { cookie: ck(), 'content-type': 'application/x-www-form-urlencoded' }, body: `username=09121111111&password=x&captchaId=c1&captcha=1&_csrf=${tk}` }); eat(r); assert.equal(r.status, 303); assert.ok(jar.dp_t);
    assert.equal((await fetch(B + '/app', { headers: { cookie: ck() } })).status, 200);
    assert.equal((await fetch(B + '/admin', { headers: { cookie: ck() } })).status, 403);
    assert.equal((await fetch(B + '/static/../server.js')).status, 404);
  } finally { web.kill(); mock.close(); }
});

test('integration: register steps, contract view CSP, sign, upload size guard', async () => {
  const mock = await startMock(5294); const web = spawn('node', ['src/server.js'], { env: { ...process.env, PORT: '3014', API_URL: 'http://127.0.0.1:5294' }, stdio: 'ignore' });
  await new Promise((r) => setTimeout(r, 1000)); const B = 'http://127.0.0.1:3014';
  const jar = {}; const eat = (res) => res.headers.getSetCookie().forEach((s) => { const [kv] = s.split(';'); const i = kv.indexOf('='); jar[kv.slice(0, i)] = kv.slice(i + 1); }); const ck = () => Object.entries(jar).map(([k, v]) => `${k}=${v}`).join('; ');
  const form = (path, body) => fetch(B + path, { method: 'POST', redirect: 'manual', headers: { cookie: ck(), 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(body) });
  try {
    let r = await fetch(B + '/register'); eat(r); const tk = (await r.text()).match(/name="_csrf" value="([^"]+)"/)[1];
    r = await form('/register/phone', { _csrf: tk, phone: '۰۹۱۲۱۱۱۱۱۱۱', captchaId: 'c1', captcha: '4827' }); assert.match(await r.text(), /۲ از ۳/);
    r = await form('/register/code', { _csrf: tk, phone: '09121111111', code: '00000' }); assert.match(await r.text(), /نادرست/);
    r = await form('/register/code', { _csrf: tk, phone: '09121111111', code: '12345' }); assert.match(await r.text(), /۳ از ۳/);
    r = await form('/register/finish', { _csrf: tk, ticket: 'tk1', fullName: 'تست تستی', nationalCode: '0012345679', password: 'abcdefgh', captchaId: 'c1', captcha: '1' }); eat(r); assert.equal(r.status, 303); assert.ok(jar.dp_t);
    const id = '00000000-0000-4000-8000-000000000001';
    r = await fetch(B + `/app/contracts/${id}/view`, { headers: { cookie: ck() } }); assert.equal(r.status, 200); assert.match(r.headers.get('content-security-policy'), /sandbox/); assert.equal(r.headers.get('x-frame-options'), 'SAMEORIGIN');
    r = await form(`/app/contracts/${id}/sign`, { _csrf: tk }); assert.equal(r.headers.get('location'), `/app/contracts/${id}`); // بدون تیک موافقت: خطا ولی ریدایرکت
    r = await fetch(B + '/app/documents/upload?_csrf=' + tk, { method: 'POST', redirect: 'manual', headers: { cookie: ck(), 'content-type': 'multipart/form-data; boundary=x', 'content-length': String(9 * 1024 * 1024) } }).catch(() => null);
  } finally { web.kill(); mock.close(); }
});

test('integration: admin 2FA login, role form sends repeated perms, card reveal not in URL', async () => {
  const seen = []; const mock = await startMock(5295);
  const web = spawn('node', ['src/server.js'], { env: { ...process.env, PORT: '3015', API_URL: 'http://127.0.0.1:5295' }, stdio: 'ignore' }); await new Promise((r) => setTimeout(r, 1000)); const B = 'http://127.0.0.1:3015';
  const jar = {}; const eat = (res) => res.headers.getSetCookie().forEach((s) => { const [kv] = s.split(';'); const i = kv.indexOf('='); jar[kv.slice(0, i)] = kv.slice(i + 1); }); const ck = () => Object.entries(jar).map(([k, v]) => `${k}=${v}`).join('; ');
  const form = (path, body) => fetch(B + path, { method: 'POST', redirect: 'manual', headers: { cookie: ck(), 'content-type': 'application/x-www-form-urlencoded' }, body });
  try {
    let r = await fetch(B + '/login'); eat(r); const tk = (await r.text()).match(/name="_csrf" value="([^"]+)"/)[1];
    r = await form('/login', new URLSearchParams({ _csrf: tk, username: '09120000000', password: 'x', captchaId: 'c1', captcha: '1' })); const t = (await r.text()).match(/name="ticket" value="([^"]+)"/)[1];
    r = await form('/login/2fa', new URLSearchParams({ _csrf: tk, ticket: t, code: '123456' })); eat(r); assert.ok(jar.dp_t);
    assert.equal((await fetch(B + '/admin/roles', { headers: { cookie: ck() } })).status, 200);
    r = await form('/admin/roles', `_csrf=${tk}&name=${encodeURIComponent('تست')}&perm=tickets.manage&perm=documents.review`); assert.equal(r.headers.get('location'), '/admin/roles');
    r = await form('/app/cards/00000000-0000-4000-8000-000000001001/reveal', new URLSearchParams({ _csrf: tk })); assert.equal(r.status, 200); assert.match(r.headers.get('cache-control'), /no-store/); assert.match(await r.text(), /731/);
  } finally { web.kill(); mock.close(); }
});

test('integration: template sample download + upload size guard', async () => {
  const mock = await startMock(5296); const web = spawn('node', ['src/server.js'], { env: { ...process.env, PORT: '3016', API_URL: 'http://127.0.0.1:5296' }, stdio: 'ignore' }); await new Promise((r) => setTimeout(r, 1000)); const B = 'http://127.0.0.1:3016';
  const jar = {}; const eat = (res) => res.headers.getSetCookie().forEach((s) => { const [kv] = s.split(';'); const i = kv.indexOf('='); jar[kv.slice(0, i)] = kv.slice(i + 1); }); const ck = () => Object.entries(jar).map(([k, v]) => `${k}=${v}`).join('; ');
  const form = (path, body) => fetch(B + path, { method: 'POST', redirect: 'manual', headers: { cookie: ck(), 'content-type': 'application/x-www-form-urlencoded' }, body });
  try {
    let r = await fetch(B + '/login'); eat(r); const tk = (await r.text()).match(/name="_csrf" value="([^"]+)"/)[1];
    r = await form('/login', new URLSearchParams({ _csrf: tk, username: '09120000000', password: 'x', captchaId: 'c1', captcha: '1' })); const t = (await r.text()).match(/name="ticket" value="([^"]+)"/)[1];
    r = await form('/login/2fa', new URLSearchParams({ _csrf: tk, ticket: t, code: '123456' })); eat(r);
    r = await fetch(B + '/admin/templates/00000000-0000-4000-8000-000000001602/sample', { headers: { cookie: ck() } }); assert.equal(r.status, 200); assert.equal(r.headers.get('content-type'), 'application/pdf'); assert.match(r.headers.get('content-disposition'), /attachment/);
    r = await fetch(B + '/admin/templates/00000000-0000-4000-8000-000000001602/sample?_csrf=' + tk, { method: 'POST', redirect: 'manual', headers: { cookie: ck(), 'content-type': 'multipart/form-data; boundary=x', 'content-length': String(8 * 1024 * 1024) }, body: 'x' }).catch(() => null);
    if (r) assert.ok([303, 400].includes(r.status));
  } finally { web.kill(); mock.close(); }
});

test('rate limiter window', async () => {
  const { createLimiter } = await import('../src/lib/ratelimit.js'); let t = 0; const l = createLimiter(3, 1000, () => t);
  assert.ok(l('a') && l('a') && l('a')); assert.ok(!l('a')); assert.ok(l('b')); t = 1500; assert.ok(l('a'));
});
