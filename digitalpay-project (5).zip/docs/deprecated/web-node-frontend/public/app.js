// بهبود تدریجی: جداکننده‌ی هزارگان هنگام تایپ مبلغ + ارقام فارسی. بدون این فایل هم همه‌چیز کار می‌کند.
(function(){
  var FD='۰۱۲۳۴۵۶۷۸۹';
  function norm(s){return s.replace(/[۰-۹]/g,function(d){return FD.indexOf(d)}).replace(/[^0-9]/g,'')}
  document.querySelectorAll('input[data-money]').forEach(function(i){
    i.addEventListener('input',function(){var v=norm(i.value);i.value=v.replace(/\B(?=(\d{3})+(?!\d))/g,',')});
  });
  var t=document.querySelector('[data-theme-toggle]');
  if(t)t.addEventListener('click',function(){var r=document.documentElement;r.dataset.theme=r.dataset.theme==='dark'?'light':'dark'});
})();
