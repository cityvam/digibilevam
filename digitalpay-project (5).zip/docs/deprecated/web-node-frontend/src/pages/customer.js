import { page, csrf, table, stat, empty } from '../lib/layout.js';
import { html, raw, money, num, fa, en, jdate, jdt, badge, STATUS } from '../lib/ui.js';
import { ApiError } from '../lib/api.js';

const DOC_KINDS = { NationalCard: 'کارت ملی (روی کارت)', NationalCardBack: 'کارت ملی (پشت کارت)', Birth: 'شناسنامه', Selfie: 'عکس سلفی با مدرک', Salary: 'فیش حقوقی', Other: 'سایر' };
const DECL = { Pending: 'در انتظار بررسی', Approved: 'تأیید شد', Rejected: 'رد شد' };
const METHODS = { CardToCard: 'کارت به کارت', BankTransfer: 'حواله‌ی بانکی' };
const CSP_FRAME = "default-src 'none'; style-src 'unsafe-inline'; img-src data:; sandbox; frame-ancestors 'self'";

export const contractFrame = (id, base) => html`<iframe class="cframe" title="متن قرارداد" sandbox="" src="${base}/${id}/view" loading="lazy"></iframe>`;
export async function serveContractHtml(ctx, apiPath) {
  const r = await ctx.api.raw('GET', apiPath, { headers: { Accept: 'text/html' } });
  if (!r.ok) return ctx.send(r.status === 404 ? 404 : 502, 'متن قرارداد در دسترس نیست', 'text/plain; charset=utf-8');
  ctx.send(200, r.text, 'text/html; charset=utf-8', { 'Content-Security-Policy': CSP_FRAME, 'X-Frame-Options': 'SAMEORIGIN' });
}

export function registerCustomer(app) {
  const guard = (ctx) => { if (!ctx.user) ctx.redirect('/login', { t: 'err', m: 'ابتدا وارد شوید.' }); };
  const wrap = (fn) => async (ctx) => { try { await fn(ctx); } catch (e) { if (e instanceof ApiError && e.status === 401) { ctx.clearCookie('dp_t'); return ctx.redirect('/login', { t: 'err', m: 'نشست شما تمام شد؛ دوباره وارد شوید.' }); } if (e instanceof ApiError) return ctx.html(page(ctx, { area: 'customer', title: 'خطا', body: html`<div class="empty">${e.message}</div>` }), e.status === 403 ? 403 : 400); throw e; } };
  const G = (p, fn) => app.get(p, guard, wrap(fn)); const Po = (p, fn) => app.post(p, guard, wrap(fn));
  const pg = (ctx, title, body, active) => ctx.html(page(ctx, { area: 'customer', title, body, active }));
  const back = (ctx, to, r, ok) => ctx.redirect(to, r.ok ? { t: 'ok', m: ok } : { t: 'err', m: ctx.api.msg(r) });

  G('/app', async (ctx) => {
    const [cnt, notes, cs, ts] = await Promise.all([ctx.api.get('/api/v1/me/notifications/count'), ctx.api.get('/api/v1/me/notifications'), ctx.api.get('/api/v1/me/contracts'), ctx.api.get('/api/v1/me/tickets')]);
    const todo = cs.filter((c) => c.status === 'Presented' || c.status === 'AwaitingSignature');
    pg(ctx, 'داشبورد', html`<h1>سلام ${ctx.user.name}</h1><p class="lead">خلاصه‌ی وضعیت حساب شما</p>
<div class="grid">${stat('اعلان خوانده‌نشده', fa(cnt.unread))}${stat('قراردادهای قبول‌شده', fa(cs.filter((c) => c.status === 'Signed').length))}${stat('نیازمند اقدام شما', fa(todo.length), 'قرارداد منتظر قبول')}${stat('تیکت باز', fa(ts.filter((t) => t.status !== 'Closed').length))}</div>
${todo.length ? html`<h2>قراردادهای منتظر شما</h2>${table(['شماره', 'عنوان', 'مهلت', ''], todo.map((c) => [fa(c.number), c.title, jdate(c.expiresAt), html`<a class="btn sm" href="/app/contracts/${c.id}">بررسی و قبول</a>`]))}` : ''}
<h2>آخرین اعلان‌ها</h2>${notes.length ? html`<div class="tick">${notes.slice(0, 3).map((x) => html`<div class="msg"><strong>${x.title}</strong><div class="mut">${x.body}</div><div class="meta">${jdt(x.createdOn)}</div></div>`)}</div>` : empty('اعلانی ندارید')}`, '/app');
  });

  G('/app/contracts', async (ctx) => {
    const cs = await ctx.api.get('/api/v1/me/contracts');
    pg(ctx, 'قراردادها', html`<h1>قراردادهای من</h1>${table(['شماره', 'عنوان', 'وضعیت', 'ارائه', ''], cs.map((c) => [fa(c.number), c.title, badge('contract', c.status), jdate(c.presentedAt), html`<a href="/app/contracts/${c.id}">مشاهده</a>`]), 'هنوز قراردادی برای شما ارائه نشده است')}`, '/app/contracts');
  });
  G('/app/contracts/:id/view', (ctx) => serveContractHtml(ctx, `/api/v1/me/contracts/${ctx.params.id}/html`));
  G('/app/contracts/:id', async (ctx) => {
    const c = (await ctx.api.get('/api/v1/me/contracts')).find((x) => x.id === ctx.params.id); if (!c) return ctx.html(await app.notFound(ctx), 404);
    const open = c.status === 'Presented' || c.status === 'AwaitingSignature';
    pg(ctx, c.title, html`<div class="row"><h1>${c.title}</h1><span class="sp"></span>${badge('contract', c.status)}</div><p class="mut">شماره ${fa(c.number)} — مهلت قبول: ${jdate(c.expiresAt)}${c.signedAt ? html` — قبول‌شده در ${jdt(c.signedAt)}` : ''}</p>
${contractFrame(c.id, '/app/contracts')}
${open ? html`<div class="grid two"><form class="f card" method="post" action="/app/contracts/${c.id}/sign">${csrf(ctx)}<label class="chk"><input type="checkbox" name="agree" value="1" required> متن قرارداد را کامل خوانده‌ام و می‌پذیرم.</label><button class="btn">قبول قرارداد</button><p class="mut">این یک قبول ساده‌ی الکترونیکی است؛ زمان، کاربر، IP و مرورگر ثبت می‌شود و امضای دیجیتال قانونی نیست.</p></form>
<form class="f card" method="post" action="/app/contracts/${c.id}/reject">${csrf(ctx)}<label>دلیل رد<textarea name="note" maxlength="300" required></textarea></label><button class="btn danger">رد قرارداد</button></form></div>` : ''}`, '/app/contracts');
  });
  Po('/app/contracts/:id/sign', async (ctx) => { if (ctx.body.agree !== '1') return ctx.redirect(`/app/contracts/${ctx.params.id}`, { t: 'err', m: 'برای قبول، تیک موافقت را بزنید.' }); back(ctx, `/app/contracts/${ctx.params.id}`, await ctx.api.try('POST', `/api/v1/me/contracts/${ctx.params.id}/sign`, {}), 'قرارداد قبول شد.'); });
  Po('/app/contracts/:id/reject', async (ctx) => back(ctx, `/app/contracts/${ctx.params.id}`, await ctx.api.try('POST', `/api/v1/me/contracts/${ctx.params.id}/reject`, { note: ctx.body.note }), 'قرارداد رد شد.'));

  G('/app/documents', async (ctx) => {
    const ds = await ctx.api.get('/api/v1/me/documents');
    pg(ctx, 'مدارک', html`<h1>مدارک من</h1><div class="grid two"><div>${table(['نوع', 'فایل', 'وضعیت', 'توضیح'], ds.map((d) => [DOC_KINDS[d.kind] || d.kind, html`<span class="ltr">${d.fileName}</span>`, badge('doc', d.status), d.reviewNote || '—']), 'هنوز مدرکی بارگذاری نکرده‌اید')}</div>
<form class="f card" method="post" enctype="multipart/form-data" action="/app/documents/upload?_csrf=${ctx.csrf}"><h2>بارگذاری مدرک</h2><label>نوع مدرک<select name="kind">${Object.entries(DOC_KINDS).map(([k, v]) => html`<option value="${k}">${v}</option>`)}</select></label><label>عکس مدرک<small>JPG، PNG یا WEBP تا ۶ مگابایت</small><input type="file" name="file" accept="image/jpeg,image/png,image/webp" required></label><button class="btn">بارگذاری</button></form></div>`, '/app/documents');
  });
  app.post('/app/documents/upload', guard, wrap(async (ctx) => {
    const len = +(ctx.req.headers['content-length'] || 0); if (!len || len > 7 * 1024 * 1024) return ctx.redirect('/app/documents', { t: 'err', m: 'حجم فایل بیش از حد مجاز است.' });
    const r = await ctx.api.pipe('POST', '/api/v1/me/documents', ctx.req, { 'Content-Type': ctx.req.headers['content-type'], 'Content-Length': String(len) });
    back(ctx, '/app/documents', r, 'مدرک بارگذاری شد و در انتظار بررسی است.');
  }));

  G('/app/payments', async (ctx) => {
    const ds = await ctx.api.get('/api/v1/me/payment-declarations');
    pg(ctx, 'اعلام واریز', html`<h1>اعلام واریز</h1><div class="grid two"><div>${table(['مبلغ', 'روش', 'پیگیری', 'تاریخ', 'وضعیت'], ds.map((d) => [money(d.amount), METHODS[d.method] || d.method, fa(d.reference), jdate(d.paidAt), badge('decl', d.status)]), 'واریزی ثبت نشده')}</div>
<form class="f card" method="post" action="/app/payments"><h2>ثبت واریز جدید</h2>${csrf(ctx)}<label>مبلغ (تومان)<input name="amount" data-money class="ltr" inputmode="numeric" required></label><label>روش<select name="method">${Object.entries(METHODS).map(([k, v]) => html`<option value="${k}">${v}</option>`)}</select></label><label>شماره پیگیری<input name="reference" class="ltr" inputmode="numeric" required></label><label>تاریخ پرداخت (میلادی)<small>مثال: 2026-10-27</small><input name="paidAt" type="date" class="ltr" required></label><label>توضیح<textarea name="note" maxlength="300"></textarea></label><button class="btn">ثبت</button></form></div>`, '/app/payments');
  });
  Po('/app/payments', async (ctx) => { const a = num(ctx.body.amount); if (!(a > 0)) return ctx.redirect('/app/payments', { t: 'err', m: 'مبلغ نامعتبر است.' }); back(ctx, '/app/payments', await ctx.api.try('POST', '/api/v1/me/payment-declarations', { amount: a, method: ctx.body.method, reference: en(ctx.body.reference || ''), paidAt: new Date(ctx.body.paidAt + 'T12:00:00Z').toISOString(), note: ctx.body.note || null }), 'واریز ثبت شد و پس از بررسی اعمال می‌شود.'); });

  const CARD = { Active: ['فعال', 'good'], Frozen: ['مسدود موقت', 'warn'], Closed: ['بسته', 'mute'] };
  G('/app/cards', async (ctx) => {
    const cs = await ctx.api.get('/api/v1/me/cards');
    pg(ctx, 'کارت‌های مجازی', html`<h1>کارت‌های مجازی</h1>${cs.length ? html`<div class="grid">${cs.map((c) => html`<div class="card"><div class="row"><strong class="ltr">${c.number}</strong><span class="sp"></span><span class="badge ${CARD[c.status]?.[1] || 'mute'}">${CARD[c.status]?.[0] || c.status}</span></div>
<dl class="kv"><dt>دارنده</dt><dd>${c.holderName}</dd><dt>انقضا</dt><dd class="ltr">${c.expiry}</dd><dt>سقف</dt><dd>${money(c.limit)}</dd><dt>مصرف‌شده</dt><dd>${money(c.spent)}</dd><dt>باقی‌مانده</dt><dd>${money(c.remaining)}</dd></dl>
<div class="row">${c.status !== 'Closed' ? html`<form method="post" action="/app/cards/${c.id}/reveal">${csrf(ctx)}<button class="btn sm">نمایش شماره و CVV</button></form><form method="post" action="/app/cards/${c.id}/${c.status === 'Frozen' ? 'unfreeze' : 'freeze'}">${csrf(ctx)}<button class="btn sm ghost">${c.status === 'Frozen' ? 'رفع مسدودی' : 'مسدود موقت'}</button></form>` : ''}</div></div>`)}</div>` : empty('هنوز کارت مجازی برای شما صادر نشده است')}`, '/app/cards');
  });
  Po('/app/cards/:id/reveal', async (ctx) => {
    const r = await ctx.api.try('POST', `/api/v1/me/cards/${ctx.params.id}/reveal`, {}); if (!r.ok) return back(ctx, '/app/cards', r, '');
    ctx.headers['Cache-Control'] = 'no-store, private';
    pg(ctx, 'اطلاعات کارت', html`<h1>اطلاعات کامل کارت</h1><div class="card"><dl class="kv"><dt>شماره</dt><dd class="ltr">${r.data.number}</dd><dt>CVV</dt><dd class="ltr">${r.data.cvv}</dd><dt>انقضا</dt><dd class="ltr">${r.data.expiry}</dd></dl><p class="mut">این نمایش در گردش کارت ثبت شد. اطلاعات را با کسی به اشتراک نگذارید.</p><a class="btn" href="/app/cards">بازگشت</a></div>`, '/app/cards');
  });
  for (const op of ['freeze', 'unfreeze']) Po(`/app/cards/:id/${op}`, async (ctx) => back(ctx, '/app/cards', await ctx.api.try('POST', `/api/v1/me/cards/${ctx.params.id}/${op}`, {}), 'انجام شد.'));

  G('/app/inbox', async (ctx) => {
    const n = await ctx.api.get('/api/v1/me/notifications');
    pg(ctx, 'اعلان‌ها', html`<div class="row"><h1>اعلان‌ها</h1><span class="sp"></span><form method="post" action="/app/inbox/read-all">${csrf(ctx)}<button class="btn sm ghost">همه خوانده شد</button></form></div>${n.length ? html`<div class="tick">${n.map((x) => html`<div class="msg">${x.isRead ? '' : html`<span class="badge info">جدید</span> `}<strong>${x.title}</strong><div class="mut">${x.body}</div><div class="meta">${jdt(x.createdOn)}${x.link ? html` — <a href="${safeLink(x.link)}">باز کردن</a>` : ''}</div></div>`)}</div>` : empty('اعلانی ندارید')}`, '/app/inbox');
  });
  const safeLink = (l) => (/^\/(?!\/)[\w\-./?=&%]*$/.test(String(l)) ? l : '/app/inbox');
  Po('/app/inbox/read-all', async (ctx) => back(ctx, '/app/inbox', await ctx.api.try('POST', '/api/v1/me/notifications/read-all', {}), 'انجام شد.'));

  G('/app/tickets', async (ctx) => {
    const ts = await ctx.api.get('/api/v1/me/tickets');
    pg(ctx, 'پشتیبانی', html`<h1>پشتیبانی</h1><div class="grid two"><div>${table(['کد', 'موضوع', 'وضعیت', ''], ts.map((t) => [fa(t.code), t.subject, badge('ticket', t.status), html`<a href="/app/tickets/${t.id}">باز کردن</a>`]), 'تیکتی ندارید')}</div>
<form class="f card" method="post" action="/app/tickets">${csrf(ctx)}<h2>تیکت جدید</h2><label>موضوع<input name="subject" required maxlength="120"></label><label>دسته<select name="category">${Object.entries(STATUS.category).map(([k, v]) => html`<option value="${k}">${v}</option>`)}</select></label><label>پیام<textarea name="body" required></textarea></label><button class="btn">ارسال</button></form></div>`, '/app/tickets');
  });
  Po('/app/tickets', async (ctx) => { const r = await ctx.api.try('POST', '/api/v1/me/tickets', { subject: ctx.body.subject, category: ctx.body.category, body: ctx.body.body }); if (!r.ok) return ctx.redirect('/app/tickets', { t: 'err', m: ctx.api.msg(r) }); ctx.redirect(`/app/tickets/${r.data.id}`, { t: 'ok', m: 'تیکت ثبت شد.' }); });
  G('/app/tickets/:id', async (ctx) => {
    const t = await ctx.api.get(`/api/v1/me/tickets/${ctx.params.id}`);
    pg(ctx, t.subject, html`<div class="row"><h1>${t.subject}</h1><span class="sp"></span>${badge('ticket', t.status)}</div><p class="mut">کد ${fa(t.code)}</p><div class="tick">${t.messages.map((m) => html`<div class="msg ${m.isStaff ? 'staff' : ''}"><div class="meta">${m.isStaff ? 'پشتیبان' : 'شما'} — ${jdt(m.createdOn)}</div>${m.body}</div>`)}</div>
<form class="f card" method="post" action="/app/tickets/${t.id}/reply">${csrf(ctx)}<label>پاسخ شما<textarea name="body" required></textarea></label><button class="btn">ارسال پاسخ</button></form>`, '/app/tickets');
  });
  Po('/app/tickets/:id/reply', async (ctx) => back(ctx, `/app/tickets/${ctx.params.id}`, await ctx.api.try('POST', `/api/v1/me/tickets/${ctx.params.id}/reply`, { body: ctx.body.body }), 'ارسال شد.'));

  const secPage = async (ctx, extra = {}) => {
    const s = await ctx.api.get('/api/v1/me/2fa');
    pg(ctx, 'امنیت حساب', html`<h1>امنیت حساب</h1><div class="card"><div class="row"><h2>ورود دومرحله‌ای</h2><span class="sp"></span>${s.enabled ? html`<span class="badge good">فعال</span>` : html`<span class="badge warn">غیرفعال</span>`}</div>
${s.enabled ? html`<form class="f" method="post" action="/app/security/disable">${csrf(ctx)}<label>کد فعلی برنامه<input name="code" class="ltr" inputmode="numeric" required></label><button class="btn danger">غیرفعال‌سازی</button></form>` : extra.secret ? html`<p class="mut">این کلید را در برنامه‌ی احراز هویت (TOTP) وارد کنید؛ فقط همین یک بار نمایش داده می‌شود:</p><p class="ltr"><code>${extra.secret}</code></p><form class="f" method="post" action="/app/security/enable">${csrf(ctx)}<label>کد ۶ رقمی<input name="code" class="ltr" inputmode="numeric" required></label><button class="btn">تأیید و فعال‌سازی</button></form>` : html`<p class="mut">با یک برنامه‌ی احراز هویت حساب خود را امن‌تر کنید.</p><form method="post" action="/app/security/setup">${csrf(ctx)}<button class="btn">شروع فعال‌سازی</button></form>`}</div>
${extra.rc ? html`<h2>کدهای بازیابی</h2><p class="mut">فقط همین یک‌بار نمایش داده می‌شود؛ جای امن نگه دارید.</p><div class="card ltr"><code>${extra.rc.join('   ')}</code></div>` : ''}`, '/app/security');
  };
  G('/app/security', (ctx) => secPage(ctx));
  Po('/app/security/setup', async (ctx) => { const r = await ctx.api.post('/api/v1/me/2fa/setup'); ctx.headers['Cache-Control'] = 'no-store'; await secPage(ctx, { secret: r.secret }); });
  Po('/app/security/enable', async (ctx) => { const r = await ctx.api.try('POST', '/api/v1/me/2fa/enable', { code: en(ctx.body.code || '') }); if (!r.ok) return ctx.redirect('/app/security', { t: 'err', m: ctx.api.msg(r) }); ctx.flash = { t: 'ok', m: 'فعال شد.' }; await secPage(ctx, { rc: r.data.recoveryCodes || [] }); });
  Po('/app/security/disable', async (ctx) => back(ctx, '/app/security', await ctx.api.try('POST', '/api/v1/me/2fa/disable', { code: en(ctx.body.code || '') }), 'غیرفعال شد.'));
}
