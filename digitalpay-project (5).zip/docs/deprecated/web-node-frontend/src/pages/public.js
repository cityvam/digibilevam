import { page, csrf } from '../lib/layout.js';
import { html, raw, money, num, fa, en } from '../lib/ui.js';
import { calc } from '../lib/calc.js';

const FAQ = [['اقساط چطور محاسبه می‌شود؟', 'مبلغ پیش‌پرداخت کسر می‌شود، کارمزد روی مبلغ باقی‌مانده اعمال می‌شود و مجموع بین اقساط تقسیم می‌شود. قسط آخر مابه‌التفاوت را جذب می‌کند.'], ['قرارداد چگونه قبول می‌شود؟', 'پس از تأیید کارشناس، قرارداد برای شما ارائه می‌شود و با تأیید ساده‌ی الکترونیکی (کد پیامکی) قبول می‌شود.'], ['اطلاعات من امن است؟', 'شماره‌ها و مدارک رمزنگاری و فایل‌ها خصوصی نگهداری می‌شوند و ورود دومرحله‌ای قابل فعال‌سازی است.'], ['چطور پشتیبانی بگیرم؟', 'از بخش پشتیبانی در پنل خود تیکت بسازید؛ زمان پاسخ‌گویی (SLA) روی هر تیکت نمایش داده می‌شود.']];

async function captcha(ctx) { try { return await ctx.api.get('/api/v1/security/captcha'); } catch { return null; } }
const fmtAmt = (v) => v === null || v === undefined ? '—' : money(v) + ' تومان';
const capField = (c) => c ? html`<div class="cap"><img src="${c.image}" alt="تصویر امنیتی" width="140" height="48"><input type="hidden" name="captchaId" value="${c.id}"><label>کد تصویر<input name="captcha" class="ltr" inputmode="numeric" autocomplete="off" required></label></div>` : '';

export function registerPublic(app) {
  app.get('/', (ctx) => ctx.html(page(ctx, { title: 'خرید اقساطی امن', active: '/', body: html`
<section class="hero"><h1>هر چه می‌خواهید بخرید،<br>اقساطی و بدون دردسر پرداخت کنید</h1><p class="lead">درخواست آنلاین، تأیید سریع، قرارداد شفاف و پیگیری اقساط از یک پنل.</p>
<div class="cta"><a class="btn" href="/register">شروع کنید</a><a class="btn ghost" href="/calculator">ماشین‌حساب اقساط</a></div></section>
<div class="grid"><div class="card"><h2>شفاف</h2><p class="mut">همه‌ی هزینه‌ها پیش از قبول قرارداد نمایش داده می‌شود.</p></div><div class="card"><h2>امن</h2><p class="mut">ورود دومرحله‌ای، ثبت رخداد و فایل‌های رمزنگاری‌شده.</p></div><div class="card"><h2>سریع</h2><p class="mut">اعلان لحظه‌ای وضعیت درخواست و قرارداد.</p></div></div>` })));

  app.get('/calculator', (ctx) => {
    const q = ctx.query; const a = num(q.amount), d = num(q.down ?? 20), f = num(q.fee ?? 12), m = num(q.months ?? 6);
    const ok = a > 0 && d >= 0 && d < 100 && f >= 0 && f <= 100 && m >= 1 && m <= 36 && Number.isInteger(m); const r = ok ? calc(a, d, f, m) : null;
    ctx.html(page(ctx, { title: 'ماشین‌حساب اقساط', active: '/calculator', body: html`<h1>ماشین‌حساب اقساط</h1><p class="lead">برآورد بر پایه‌ی همان فرمول قرارداد؛ مبلغ نهایی در قرارداد می‌آید.</p>
<div class="grid two"><form class="f card" method="get"><label>مبلغ کالا (تومان)<input name="amount" data-money class="ltr" inputmode="numeric" value="${q.amount ?? ''}" required></label>
<label>پیش‌پرداخت (درصد)<input name="down" class="ltr" inputmode="numeric" value="${q.down ?? 20}"></label><label>کارمزد (درصد)<input name="fee" class="ltr" inputmode="numeric" value="${q.fee ?? 12}"></label>
<label>تعداد اقساط<select name="months">${[3, 4, 6, 9, 12, 18, 24, 36].map((x) => html`<option value="${x}" ${x === m ? raw('selected') : ''}>${fa(x)} ماهه</option>`)}</select></label><button class="btn">محاسبه</button></form>
<div class="card">${r ? html`<h2>نتیجه</h2><dl class="kv"><dt>پیش‌پرداخت</dt><dd>${money(r.down)} تومان</dd><dt>مبلغ تسهیلات</dt><dd>${money(r.fin)} تومان</dd><dt>کارمزد</dt><dd>${money(r.fee)} تومان</dd><dt>مجموع بازپرداخت</dt><dd>${money(r.total)} تومان</dd><dt>هر قسط</dt><dd>${money(r.each)} تومان</dd><dt>قسط آخر</dt><dd>${money(r.last)} تومان</dd></dl>` : html`<div class="empty">مقدارها را وارد کنید تا نتیجه این‌جا نمایش داده شود.</div>`}</div></div>` }));
  });
  app.get('/faq', (ctx) => ctx.html(page(ctx, { title: 'سوالات متداول', active: '/faq', body: html`<h1>سوالات متداول</h1>${FAQ.map(([q, a]) => html`<details class="card"><summary><strong>${q}</strong></summary><p class="mut">${a}</p></details><br>`)}` })));
  app.get('/about', (ctx) => ctx.html(page(ctx, { title: 'درباره ما', active: '/about', body: html`<h1>درباره‌ی دیجی‌بایل پی</h1><p class="lead">پلتفرم پرداخت اقساطی (BNPL) با تمرکز بر امنیت، شفافیت و پشتیبانی سریع.</p>` })));

  app.get('/products', async (ctx) => {
    let list = []; try { list = await ctx.api.get('/api/v1/loan-products'); } catch { /* خالی */ }
    ctx.html(page(ctx, { title: 'طرح‌های اقساطی', active: '/products', body: html`<h1>طرح‌های اقساطی</h1><p class="lead">طرحی را انتخاب کنید و با ماشین‌حساب برآورد بگیرید.</p>${list.length ? html`<div class="grid">${list.map((p) => html`<a class="card" href="/products/${p.id}"><div class="row"><h2>${p.title || p.name}</h2>${p.badge ? html`<span class="badge info">${p.badge}</span>` : ''}</div><p class="mut">${p.description}</p><div class="mut">از ${fmtAmt(p.minAmount)} تا ${fmtAmt(p.maxAmount)}</div></a>`)}</div>` : html`<div class="empty">فعلاً طرحی فعال نیست.</div>`}` }));
  });
  app.get('/products/:slug', async (ctx) => {
    let p; try { p = await ctx.api.get('/api/v1/loan-products/' + encodeURIComponent(ctx.params.slug)); } catch { return ctx.html(await app.notFound(ctx), 404); }
    const docs = Array.isArray(p.documents) ? p.documents : [];
    ctx.html(page(ctx, { title: p.title || p.name, active: '/products', body: html`<div class="row"><h1>${p.title || p.name}</h1><span class="sp"></span>${p.badge ? html`<span class="badge info">${p.badge}</span>` : ''}</div><p class="lead">${p.description}</p>
<div class="grid two"><div class="card"><dl class="kv"><dt>حداقل مبلغ</dt><dd>${fmtAmt(p.minAmount)}</dd><dt>حداکثر مبلغ</dt><dd>${fmtAmt(p.maxAmount)}</dd><dt>فاصله‌ی اقساط</dt><dd>${fa(p.intervalDays)} روز</dd></dl></div>
<div class="card"><h2>مدارک لازم</h2>${docs.length ? html`<ul>${docs.map((d) => html`<li>${d.label || d.name}${d.required ? html` <span class="badge warn">الزامی</span>` : ''}</li>`)}</ul>` : html`<p class="mut">مدرک خاصی لازم نیست.</p>`}</div></div>
<div class="row"><a class="btn" href="/calculator">ماشین‌حساب اقساط</a>${ctx.user ? html`<a class="btn ghost" href="/app/documents">بارگذاری مدارک</a>` : html`<a class="btn ghost" href="/register">ثبت‌نام</a>`}</div>` }));
  });

  // ---------- ورود ----------
  app.get('/login', async (ctx) => { if (ctx.user) return ctx.redirect('/app'); const c = await captcha(ctx);
    ctx.html(page(ctx, { title: 'ورود', body: html`<h1>ورود</h1><form class="f card" method="post" action="/login">${csrf(ctx)}<label>موبایل یا نام کاربری<input name="username" class="ltr" autocomplete="username" required></label><label>رمز عبور<input name="password" type="password" class="ltr" autocomplete="current-password" required></label>${capField(c)}<button class="btn">ورود</button><a href="/register">حساب ندارید؟ ثبت‌نام</a></form>` })); });
  app.post('/login', async (ctx) => {
    const b = ctx.body; const r = await ctx.api.try('POST', '/api/v1/security/login', { username: en(b.username || ''), password: b.password, captchaId: b.captchaId, captchaAnswer: en(b.captcha || '') });
    if (r.status === 202 && r.data?.needs2fa) return ctx.html(page(ctx, { title: 'تأیید دومرحله‌ای', body: html`<h1>تأیید دومرحله‌ای</h1><form class="f card" method="post" action="/login/2fa">${csrf(ctx)}<input type="hidden" name="ticket" value="${r.data.ticket}"><label>کد ۶ رقمی برنامه‌ی احراز هویت<small>یا یکی از کدهای بازیابی</small><input name="code" class="ltr" inputmode="numeric" autocomplete="one-time-code" required></label><button class="btn">تأیید</button></form>` }));
    if (!r.ok) return ctx.redirect('/login', { t: 'err', m: ctx.api.msg(r) });
    return finish(ctx, r.data);
  });
  app.post('/login/2fa', async (ctx) => {
    const r = await ctx.api.try('POST', '/api/v1/security/2fa/complete', { ticket: ctx.body.ticket, code: en(ctx.body.code || '') });
    if (!r.ok) return ctx.redirect('/login', { t: 'err', m: ctx.api.msg(r) }); finish(ctx, r.data);
  });
  function finish(ctx, d) { const t = d.accessToken || d.token; if (!t) return ctx.redirect('/login', { t: 'err', m: 'ورود انجام نشد.' }); ctx.cookie('dp_t', t, { maxAge: 60 * 60 * 2 }); ctx.redirect('/app', { t: 'ok', m: 'خوش آمدید.' }); }

  // ---------- ثبت‌نام سه‌مرحله‌ای: موبایل+کپچا ← کد پیامکی ← مشخصات ----------
  app.get('/register', async (ctx) => { const c = await captcha(ctx);
    ctx.html(page(ctx, { title: 'ثبت‌نام', body: html`<h1>ثبت‌نام (۱ از ۳)</h1><form class="f card" method="post" action="/register/phone">${csrf(ctx)}<label>شماره موبایل<input name="phone" class="ltr" inputmode="tel" autocomplete="tel" required></label>${capField(c)}<button class="btn">ارسال کد پیامکی</button></form>` })); });
  const codeStep = (ctx, phone, note) => ctx.html(page(ctx, { title: 'ثبت‌نام', body: html`<h1>ثبت‌نام (۲ از ۳)</h1><form class="f card" method="post" action="/register/code">${csrf(ctx)}<input type="hidden" name="phone" value="${phone}"><p class="mut">${note || 'کد پیامکی به ' + fa(phone) + ' ارسال شد.'}</p><label>کد پیامکی<input name="code" class="ltr" inputmode="numeric" autocomplete="one-time-code" required></label><button class="btn">تأیید</button></form>` }));
  app.post('/register/phone', async (ctx) => {
    const phone = en(ctx.body.phone || ''); const r = await ctx.api.try('POST', '/api/v1/security/otp/request', { phone, captchaId: ctx.body.captchaId, captchaAnswer: en(ctx.body.captcha || ''), purpose: 'register' });
    if (!r.ok) return ctx.redirect('/register', { t: 'err', m: ctx.api.msg(r) }); codeStep(ctx, phone);
  });
  app.post('/register/code', async (ctx) => {
    const phone = en(ctx.body.phone || ''); const r = await ctx.api.try('POST', '/api/v1/security/otp/verify', { phone, code: en(ctx.body.code || ''), purpose: 'register' });
    if (!r.ok) { ctx.flash = { t: 'err', m: ctx.api.msg(r) }; return codeStep(ctx, phone, 'دوباره کد را وارد کنید.'); }
    const c = await captcha(ctx);
    ctx.html(page(ctx, { title: 'ثبت‌نام', body: html`<h1>ثبت‌نام (۳ از ۳)</h1><form class="f card" method="post" action="/register/finish">${csrf(ctx)}<input type="hidden" name="ticket" value="${r.data.ticket}"><label>نام و نام خانوادگی<input name="fullName" required></label><label>کد ملی<input name="nationalCode" class="ltr" inputmode="numeric" maxlength="10" required></label><label>ایمیل (اختیاری)<input name="email" type="email" class="ltr"></label><label>رمز عبور<small>حداقل ۸ نویسه</small><input name="password" type="password" class="ltr" minlength="8" autocomplete="new-password" required></label>${capField(c)}<button class="btn">ایجاد حساب</button></form>` }));
  });
  app.post('/register/finish', async (ctx) => {
    const b = ctx.body; const r = await ctx.api.try('POST', '/api/v1/security/register', { ticket: b.ticket, fullName: b.fullName, nationalCode: en(b.nationalCode || ''), password: b.password, email: b.email || null, captchaId: b.captchaId, captchaAnswer: en(b.captcha || '') });
    if (!r.ok) return ctx.redirect('/register', { t: 'err', m: ctx.api.msg(r) }); finish(ctx, r.data);
  });
  app.post('/logout', (ctx) => { ctx.clearCookie('dp_t'); ctx.redirect('/', { t: 'ok', m: 'خارج شدید.' }); });
}
