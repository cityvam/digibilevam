import { page, csrf, table, stat, empty } from '../lib/layout.js';
import { html, raw, esc, money, num, en, fa, jdate, jdt, badge, STATUS } from '../lib/ui.js';
import { ApiError } from '../lib/api.js';
import { contractFrame, serveContractHtml } from './customer.js';

const OPS = { submit: ['Draft', 'ارسال برای تأیید'], return: ['ReadyForReview', 'بازگرداندن به پیش‌نویس'], approve: ['ReadyForReview', 'تأیید'], present: ['Approved', 'ارائه به مشتری'], 'request-signature': ['Presented', 'درخواست قبول'], cancel: ['*', 'لغو'] };
const EV = { Generated: 'ساخته شد', submit: 'ارسال برای تأیید', return: 'بازگردانده شد', approve: 'تأیید شد', present: 'به مشتری ارائه شد', 'request-signature': 'درخواست قبول', Viewed: 'مشاهده توسط کارمند', ViewedByCustomer: 'مشاهده توسط مشتری', Signed: 'قبول شد', Rejected: 'رد شد', Cancelled: 'لغو شد', AutoApproved: 'تأیید خودکار', Expired: 'منقضی شد' };
const MORE = [['/admin/templates', 'قالب‌های قرارداد', 'نسخه، تأیید و انتشار'], ['/admin/variables', 'متغیرهای قرارداد', 'کلیدهای {{...}}'], ['/admin/products', 'طرح‌های وام', 'فعال/غیرفعال و نمونه'], ['/admin/cards', 'کارت‌های مجازی', 'صدور و مسدودسازی'], ['/admin/counterparties', 'فروشندگان', 'طرف‌حساب و شبا'], ['/admin/marketers', 'بازاریاب‌ها', 'کد معرفی و پورسانت'], ['/admin/orders', 'سفارش خرید', 'پذیرنده و تحویل'], ['/admin/inquiries', 'استعلام‌ها', 'اعتبار و هویت'], ['/admin/audit', 'حسابرسی', 'گزارش رخدادها'], ['/admin/jobs', 'صف کارها', 'پیامک و پس‌زمینه'], ['/admin/roles', 'نقش‌ها و دسترسی', 'RBAC'], ['/admin/backups', 'پشتیبان‌گیری', 'فقط مدیر ارشد']];
const short = (id) => String(id || '').slice(0, 8);

export function registerAdmin(app) {
  const guard = (ctx) => { if (!ctx.user) return ctx.redirect('/login', { t: 'err', m: 'ابتدا وارد شوید.' }); if (!ctx.user.isAdmin) return ctx.html(page(ctx, { title: 'دسترسی ممنوع', body: empty('این بخش مخصوص مدیران است.') }), 403); };
  const wrap = (fn) => async (ctx) => { try { await fn(ctx); } catch (e) { if (e instanceof ApiError) { if (e.status === 401) { ctx.clearCookie('dp_t'); return ctx.redirect('/login', { t: 'err', m: 'نشست تمام شد.' }); } return ctx.html(page(ctx, { area: 'admin', title: 'خطا', body: empty(e.status === 403 ? 'مجوز این بخش برای شما فعال نیست.' : e.message) }), e.status === 403 ? 403 : 400); } throw e; } };
  const G = (p, fn) => app.get(p, guard, wrap(fn)); const Po = (p, fn) => app.post(p, guard, wrap(fn));
  const pg = (ctx, title, body, active) => ctx.html(page(ctx, { area: 'admin', title, body, active }));
  const back = (ctx, to, r, ok) => ctx.redirect(to, r.ok ? { t: 'ok', m: ok } : { t: 'err', m: ctx.api.msg(r) });

  G('/admin', async (ctx) => {
    const d = await ctx.api.get('/api/v1/admin/dashboard'); const groups = Object.entries(d);
    pg(ctx, 'داشبورد مدیریت', html`<h1>داشبورد مدیریت</h1>${groups.length ? groups.map(([g, ks]) => html`<h2>${g}</h2><div class="grid">${ks.map((k) => html`<div class="stat ${k.warn && k.value > 0 ? 'alert' : ''}"><div class="sl">${k.label}</div><div class="sv">${fa(k.value)}${k.unit ? html` <small class="mut">${k.unit}</small>` : ''}</div>${k.warn && k.value > 0 ? html`<span class="badge bad">نیازمند توجه</span>` : ''}</div>`)}</div>`) : empty('برای نمایش شاخص‌ها، مجوزی به نقش شما داده نشده است.')}`, '/admin');
  });

  G('/admin/contracts', async (ctx) => {
    const cs = await ctx.api.get('/api/v1/admin/contracts', { status: ctx.query.status });
    pg(ctx, 'قراردادها', html`<div class="row"><h1>قراردادها</h1><span class="sp"></span><form method="get" class="row"><select name="status" aria-label="فیلتر وضعیت"><option value="">همه</option>${Object.entries(STATUS.contract).map(([k, v]) => html`<option value="${k}" ${ctx.query.status === k ? raw('selected') : ''}>${v}</option>`)}</select><button class="btn sm">اعمال</button></form></div>
${table(['شماره', 'عنوان', 'مشتری', 'وضعیت', 'ساخت', ''], cs.map((c) => [fa(c.number), c.title, html`<span class="ltr">${short(c.userId)}</span>`, badge('contract', c.status), jdate(c.createdOn), html`<a href="/admin/contracts/${c.id}">بررسی</a>`]), 'قراردادی نیست')}`, '/admin/contracts');
  });
  G('/admin/contracts/:id/view', (ctx) => serveContractHtml(ctx, `/api/v1/admin/contracts/${ctx.params.id}/html`));
  G('/admin/contracts/:id', async (ctx) => {
    const [cs, ev] = await Promise.all([ctx.api.get('/api/v1/admin/contracts'), ctx.api.get(`/api/v1/admin/contracts/${ctx.params.id}/events`)]);
    const c = cs.find((x) => x.id === ctx.params.id); if (!c) return ctx.html(await app.notFound(ctx), 404);
    const ops = Object.entries(OPS).filter(([op, [from]]) => (op === 'cancel' ? !['Signed', 'Rejected', 'Expired', 'Cancelled'].includes(c.status) : from === c.status));
    pg(ctx, 'بررسی قرارداد', html`<div class="row"><h1>${c.title}</h1><span class="sp"></span>${badge('contract', c.status)}</div><p class="mut">شماره ${fa(c.number)} — نسخه‌ی قالب ${fa(c.templateVersion)} — ساخت ${jdt(c.createdOn)}</p>
<div class="row">${ops.map(([op, [, label]]) => html`<form method="post" action="/admin/contracts/${c.id}/${op}">${csrf(ctx)}<button class="btn sm ${op === 'cancel' ? 'danger' : op === 'return' ? 'ghost' : ''}">${label}</button></form>`)}</div>
<p class="mut">تأییدکننده نمی‌تواند همان ایجادکننده باشد (به‌جز مدیر ارشد).</p>
<div class="grid two"><div>${contractFrame(c.id, '/admin/contracts')}</div><div class="card"><h2>تاریخچه</h2>${ev.length ? ev.map((h) => html`<div class="msg">${EV[h.action] || h.action}${h.note ? html` — ${h.note}` : ''}<div class="meta">${jdt(h.at)} — <span class="ltr">${h.ip || ''}</span></div></div>`) : empty('رویدادی نیست')}</div></div>`, '/admin/contracts');
  });
  for (const op of Object.keys(OPS)) Po(`/admin/contracts/:id/${op}`, async (ctx) => back(ctx, `/admin/contracts/${ctx.params.id}`, await ctx.api.try('POST', `/api/v1/admin/contracts/${ctx.params.id}/${op}`, {}), 'انجام شد.'));

  G('/admin/tickets', async (ctx) => {
    const ts = await ctx.api.get('/api/v1/admin/tickets', { status: ctx.query.status, overdue: ctx.query.overdue ? 'true' : undefined });
    pg(ctx, 'تیکت‌ها', html`<div class="row"><h1>تیکت‌های پشتیبانی</h1><span class="sp"></span><a class="btn sm ghost" href="/admin/tickets?overdue=1">فقط گذشته از مهلت</a></div>${table(['کد', 'موضوع', 'اولویت', 'وضعیت', 'مهلت پاسخ', ''], ts.map((t) => [fa(t.code), t.subject, t.priority === 'High' ? html`<span class="badge bad">بالا</span>` : 'عادی', badge('ticket', t.status), t.overdue ? html`<span class="badge bad">گذشته</span>` : jdt(t.slaDueOn), html`<a href="/admin/tickets/${t.id}">پاسخ</a>`]), 'تیکتی نیست')}`, '/admin/tickets');
  });
  G('/admin/tickets/:id', async (ctx) => {
    const { t, messages } = await ctx.api.get(`/api/v1/admin/tickets/${ctx.params.id}`);
    pg(ctx, t.subject, html`<div class="row"><h1>${t.subject}</h1><span class="sp"></span>${badge('ticket', t.status)}</div><p class="mut">کد ${fa(t.code)} — مهلت پاسخ ${jdt(t.slaDueOn)}</p><div class="tick">${messages.map((m) => html`<div class="msg ${m.isStaff ? 'staff' : ''}"><div class="meta">${m.isInternal ? 'یادداشت داخلی' : m.isStaff ? 'پشتیبان' : 'مشتری'} — ${jdt(m.createdOn)}</div>${m.body}</div>`)}</div>
<form class="f card" method="post" action="/admin/tickets/${t.id}/reply">${csrf(ctx)}<label>پاسخ<textarea name="body" required></textarea></label><label class="chk"><input type="checkbox" name="internal" value="1"> یادداشت داخلی (مشتری نمی‌بیند)</label><label class="chk"><input type="checkbox" name="close" value="1"> بعد از ارسال، تیکت بسته شود</label><button class="btn">ثبت</button></form>`, '/admin/tickets');
  });
  Po('/admin/tickets/:id/reply', async (ctx) => back(ctx, `/admin/tickets/${ctx.params.id}`, await ctx.api.try('POST', `/api/v1/admin/tickets/${ctx.params.id}/reply`, { body: ctx.body.body, internal: ctx.body.internal === '1', close: ctx.body.close === '1' }), 'ثبت شد.'));

  G('/admin/finance', async (ctx) => {
    const [tb, es, au] = await Promise.all([ctx.api.get('/api/v1/admin/ledger/trial-balance'), ctx.api.get('/api/v1/admin/ledger/entries'), ctx.api.try('GET', '/api/v1/admin/audit/verify')]);
    pg(ctx, 'مالی', html`<h1>مالی و دفتر کل</h1><div class="grid">${stat('جمع بدهکار', money(tb.totalDebit))}${stat('جمع بستانکار', money(tb.totalCredit))}${stat('تراز', tb.balanced ? 'متوازن ✓' : 'نامتوازن ✗')}${au.ok ? stat('زنجیره‌ی حسابرسی', au.data?.ok === false ? 'مشکوک ✗' : 'سالم ✓') : ''}</div>
<h2>تراز آزمایشی</h2>${table(['کد', 'حساب', 'نوع', 'بدهکار', 'بستانکار'], tb.rows.map((r) => [fa(r.code), r.name, STATUS.acct[r.type] || r.type, money(r.debit), money(r.credit)]), 'حسابی نیست')}
<h2>آخرین سندها</h2>${table(['شماره', 'شرح', 'مرجع', 'مبلغ', 'تاریخ'], es.map((e) => [fa(e.number), e.memo + (e.reversalOf ? ' (معکوس)' : ''), fa(e.reference || '—'), money(e.debit), jdate(e.createdOn)]), 'سندی نیست')}`, '/admin/finance');
  });

  G('/admin/jobs', async (ctx) => {
    const [sm, j] = await Promise.all([ctx.api.get('/api/v1/admin/jobs/summary'), ctx.api.get('/api/v1/admin/jobs')]);
    pg(ctx, 'صف کارها', html`<h1>صف کارهای پس‌زمینه</h1><div class="grid">${Object.entries(STATUS.job).map(([k, v]) => stat(v, fa(sm.counts[k] || 0)))}${stat('قدیمی‌ترین کار معوق', fa(sm.oldestDueSeconds) + ' ثانیه')}</div>
${table(['نوع', 'وضعیت', 'تلاش', 'خطا', ''], j.map((x) => [html`<span class="ltr">${x.type}</span>`, badge('job', x.status), `${fa(x.attempts)}/${fa(x.maxAttempts)}`, x.lastError || '—', ['Failed', 'Dead'].includes(x.status) ? html`<form method="post" action="/admin/jobs/${x.id}/retry">${csrf(ctx)}<button class="btn sm">تلاش مجدد</button></form>` : '']), 'کاری نیست')}`, '/admin/jobs');
  });
  Po('/admin/jobs/:id/retry', async (ctx) => back(ctx, '/admin/jobs', await ctx.api.try('POST', `/api/v1/admin/jobs/${ctx.params.id}/retry`, {}), 'دوباره در صف قرار گرفت.'));

  const GUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  const permBoxes = (cat, have = []) => html`<fieldset class="perms"><legend>مجوزها</legend>${cat.map((x) => html`<label class="chk"><input type="checkbox" name="perm" value="${x.key}" ${have.includes(x.key) ? raw('checked') : ''}> <span>${x.label} <small class="ltr mut">${x.key}</small></span></label>`)}</fieldset>`;
  const permsFrom = (ctx) => [].concat(ctx.multi?.perm ?? []);
  G('/admin/roles', async (ctx) => {
    const [r, cat, asg] = await Promise.all([ctx.api.get('/api/v1/admin/iam/roles'), ctx.api.get('/api/v1/admin/iam/permissions'), ctx.api.get('/api/v1/admin/iam/assignments')]);
    const name = (id) => r.find((x) => x.id === id)?.name || '—';
    pg(ctx, 'نقش‌ها', html`<div class="row"><h1>نقش‌ها و دسترسی‌ها</h1><span class="sp"></span><form method="post" action="/admin/roles/seed">${csrf(ctx)}<button class="btn sm ghost">افزودن نقش‌های پیش‌فرض</button></form></div>
<div class="grid two">${r.map((x) => html`<div class="card"><div class="row"><h2>${x.name}</h2><span class="sp"></span>${x.isSystem ? html`<span class="badge mute">سیستمی</span>` : ''}<span class="badge mute">${fa(x.users)} کاربر</span></div><p class="mut">${x.description}</p><div class="row">${x.permissions.map((p) => html`<span class="badge info ltr">${p}</span>`)}</div><div class="row"><a class="btn sm ghost" href="/admin/roles/${x.id}">ویرایش</a></div></div>`)}</div>
<h2>نقش جدید</h2><form class="f card" method="post" action="/admin/roles">${csrf(ctx)}<label>نام<input name="name" required minlength="2" maxlength="80"></label><label>توضیح<input name="description" maxlength="300"></label>${permBoxes(cat)}<button class="btn">ایجاد</button></form>
<h2>تخصیص نقش به کاربر</h2><div class="grid two"><form class="f card" method="post" action="/admin/roles/assign">${csrf(ctx)}<label>شناسه‌ی کاربر (Guid)<input name="userId" class="ltr" required pattern="[0-9a-fA-F-]{36}"></label><label>نقش<select name="roleId">${r.map((x) => html`<option value="${x.id}">${x.name}</option>`)}</select></label><button class="btn">تخصیص</button></form>
<div>${table(['کاربر', 'نقش', 'تاریخ', ''], asg.map((a) => [html`<span class="ltr">${short(a.userId)}</span>`, name(a.roleId), jdate(a.assignedOn), html`<form method="post" action="/admin/roles/unassign/${a.id}">${csrf(ctx)}<button class="btn sm danger">برداشتن</button></form>`]), 'تخصیصی نیست')}</div></div>`, '/admin/roles');
  });
  G('/admin/roles/:id', async (ctx) => {
    const [r, cat] = await Promise.all([ctx.api.get('/api/v1/admin/iam/roles'), ctx.api.get('/api/v1/admin/iam/permissions')]); const x = r.find((q) => q.id === ctx.params.id); if (!x) return ctx.html(await app.notFound(ctx), 404);
    pg(ctx, x.name, html`<h1>ویرایش نقش «${x.name}»</h1><form class="f card" method="post" action="/admin/roles/${x.id}">${csrf(ctx)}<label>نام<input name="name" value="${x.name}" required minlength="2" maxlength="80"></label><label>توضیح<input name="description" value="${x.description || ''}" maxlength="300"></label>${permBoxes(cat, x.permissions)}<button class="btn">ذخیره</button></form>
${x.isSystem ? '' : html`<form method="post" action="/admin/roles/${x.id}/delete">${csrf(ctx)}<button class="btn danger">حذف نقش</button></form>`}<p class="mut">دادن مجوز «مدیریت دسترسی» فقط از مدیر ارشد برمی‌آید.</p>`, '/admin/roles');
  });
  const roleBody = (ctx) => ({ name: ctx.body.name, description: ctx.body.description || null, permissions: permsFrom(ctx) });
  Po('/admin/roles', async (ctx) => back(ctx, '/admin/roles', await ctx.api.try('POST', '/api/v1/admin/iam/roles', roleBody(ctx)), 'نقش ساخته شد.'));
  Po('/admin/roles/seed', async (ctx) => back(ctx, '/admin/roles', await ctx.api.try('POST', '/api/v1/admin/iam/seed-defaults', {}), 'نقش‌های پیش‌فرض اضافه شد.'));
  Po('/admin/roles/assign', async (ctx) => { if (!GUID.test(ctx.body.userId || '')) return ctx.redirect('/admin/roles', { t: 'err', m: 'شناسه‌ی کاربر معتبر نیست.' }); back(ctx, '/admin/roles', await ctx.api.try('POST', '/api/v1/admin/iam/assign', { userId: ctx.body.userId, roleId: ctx.body.roleId }), 'نقش تخصیص داده شد.'); });
  Po('/admin/roles/unassign/:id', async (ctx) => back(ctx, '/admin/roles', await ctx.api.try('DELETE', `/api/v1/admin/iam/assignments/${ctx.params.id}`), 'نقش برداشته شد.'));
  Po('/admin/roles/:id/delete', async (ctx) => back(ctx, '/admin/roles', await ctx.api.try('DELETE', `/api/v1/admin/iam/roles/${ctx.params.id}`), 'حذف شد.'));
  Po('/admin/roles/:id', async (ctx) => back(ctx, '/admin/roles', await ctx.api.try('PUT', `/api/v1/admin/iam/roles/${ctx.params.id}`, roleBody(ctx)), 'ذخیره شد.'));

  // ---------- مدارک ----------
  const KIND = { NationalCard: 'کارت ملی (رو)', NationalCardBack: 'کارت ملی (پشت)', Birth: 'شناسنامه', Selfie: 'سلفی با مدرک', Salary: 'فیش حقوقی', Other: 'سایر' };
  G('/admin/documents', async (ctx) => {
    const st = ctx.query.status ?? 'Pending'; const ds = await ctx.api.get('/api/v1/admin/documents', { status: st });
    pg(ctx, 'مدارک', html`<div class="row"><h1>بررسی مدارک</h1><span class="sp"></span><form method="get" class="row"><select name="status" aria-label="وضعیت"><option value="">همه</option>${Object.entries(STATUS.doc).map(([k, v]) => html`<option value="${k}" ${st === k ? raw('selected') : ''}>${v}</option>`)}</select><button class="btn sm">اعمال</button></form></div>
${table(['نوع', 'مشتری', 'فایل', 'وضعیت', 'ثبت', ''], ds.map((d) => [KIND[d.kind] || d.kind, html`<span class="ltr">${short(d.userId)}</span>`, html`<span class="ltr">${d.fileName}</span>`, badge('doc', d.status), jdt(d.createdOn), html`<a href="/admin/documents/${d.id}">بررسی</a>`]), 'مدرکی نیست')}`, '/admin/documents');
  });
  G('/admin/documents/:id/file', async (ctx) => {
    const r = await ctx.api.raw('GET', `/api/v1/admin/documents/${ctx.params.id}/file`, { headers: { Accept: 'image/*' } });
    const ct = String(r.headers['content-type'] || ''); if (!r.ok || !/^image\/(jpeg|png|webp)$/.test(ct)) return ctx.send(404, 'not found', 'text/plain');
    ctx.send(200, r.buf, ct, { 'Content-Security-Policy': "default-src 'none'", 'Content-Disposition': 'inline', 'Cache-Control': 'private, no-store' });
  });
  G('/admin/documents/:id', async (ctx) => {
    const d = (await ctx.api.get('/api/v1/admin/documents')).find((x) => x.id === ctx.params.id); if (!d) return ctx.html(await app.notFound(ctx), 404);
    pg(ctx, 'بررسی مدرک', html`<div class="row"><h1>${KIND[d.kind] || d.kind}</h1><span class="sp"></span>${badge('doc', d.status)}</div><p class="mut">مشتری <span class="ltr">${short(d.userId)}</span> — ${jdt(d.createdOn)} — ${fa(Math.round(d.sizeBytes / 1024))} کیلوبایت</p>
<div class="grid two"><div class="card"><img class="docimg" src="/admin/documents/${d.id}/file" alt="تصویر مدرک"></div><div>${d.ocrText ? html`<div class="card"><h2>متن خوانده‌شده (OCR)</h2><div class="contract">${d.ocrText}</div></div>` : ''}
<form class="f card" method="post" action="/admin/documents/${d.id}/review">${csrf(ctx)}<h2>نتیجه‌ی بررسی</h2><label>وضعیت<select name="status"><option value="Verified">تأیید</option><option value="Rejected">رد</option><option value="Pending">بازگرداندن به انتظار</option></select></label><label>توضیح برای مشتری<textarea name="note" maxlength="300">${d.reviewNote || ''}</textarea></label><button class="btn">ثبت</button></form></div></div>`, '/admin/documents');
  });
  Po('/admin/documents/:id/review', async (ctx) => back(ctx, '/admin/documents', await ctx.api.try('PUT', `/api/v1/admin/documents/${ctx.params.id}/review`, { status: ctx.body.status, note: ctx.body.note || null }), 'ثبت شد.'));

  // ---------- واریزها ----------
  const METHODS = { CardToCard: 'کارت به کارت', BankTransfer: 'حواله‌ی بانکی' };
  G('/admin/payments', async (ctx) => {
    const st = ctx.query.status ?? 'Pending'; const ds = await ctx.api.get('/api/v1/admin/payment-declarations', { status: st });
    pg(ctx, 'واریزها', html`<div class="row"><h1>اعلام واریزها</h1><span class="sp"></span><form method="get" class="row"><select name="status" aria-label="وضعیت"><option value="">همه</option>${Object.entries(STATUS.decl).map(([k, v]) => html`<option value="${k}" ${st === k ? raw('selected') : ''}>${v}</option>`)}</select><button class="btn sm">اعمال</button></form></div>
<p class="mut">تأیید واریز خودِ شما ممکن نیست و رد کردن به دلیل نیاز دارد.</p>
${ds.length ? html`<div class="tick">${ds.map((d) => html`<div class="card"><div class="row"><strong>${money(d.amount)} تومان</strong><span class="mut">${METHODS[d.method] || d.method} — پیگیری ${fa(d.reference)} — ${jdate(d.paidAt)}</span><span class="sp"></span>${badge('decl', d.status)}</div>${d.note ? html`<p class="mut">${d.note}</p>` : ''}
${d.status === 'Pending' ? html`<form class="row" method="post" action="/admin/payments/${d.id}/review">${csrf(ctx)}<input name="note" placeholder="دلیل (برای رد الزامی)" maxlength="300"><button class="btn sm" name="status" value="Approved">تأیید</button><button class="btn sm danger" name="status" value="Rejected">رد</button></form>` : d.reviewNote ? html`<p class="mut">توضیح: ${d.reviewNote}</p>` : ''}</div>`)}</div>` : empty('واریزی نیست')}`, '/admin/payments');
  });
  Po('/admin/payments/:id/review', async (ctx) => back(ctx, '/admin/payments', await ctx.api.try('POST', `/api/v1/admin/payment-declarations/${ctx.params.id}/review`, { status: ctx.body.status, note: ctx.body.note || null }), 'ثبت شد.'));

  // ---------- حسابرسی ----------
  G('/admin/audit', async (ctx) => {
    const [rows, v] = await Promise.all([ctx.api.get('/api/v1/admin/audit', { take: 200 }), ctx.api.try('GET', '/api/v1/admin/audit/verify')]);
    pg(ctx, 'حسابرسی', html`<h1>گزارش حسابرسی</h1>${v.ok ? html`<div class="flash ${v.data.ok ? 'good' : 'bad'}">${v.data.ok ? html`زنجیره‌ی هش سالم است (${fa(v.data.checkedCount)} رکورد بررسی شد).` : html`زنجیره در رکورد ${fa(v.data.brokenAt)} شکسته است؛ موضوع را فوراً بررسی کنید.`}</div>` : html`<p class="mut">راستی‌آزمایی زنجیره فقط برای مدیر ارشد است.</p>`}
${table(['#', 'کاربر', 'متد', 'مسیر', 'کد', 'IP', 'زمان'], rows.map((a) => [fa(a.seq), a.userName || '—', html`<span class="ltr">${a.method}</span>`, html`<span class="ltr">${a.path}</span>`, fa(a.statusCode), html`<span class="ltr">${a.ip}</span>`, jdt(a.at)]), 'رکوردی نیست')}`, '/admin/audit');
  });

  // ---------- طرح‌های وام ----------
  G('/admin/products', async (ctx) => {
    const ps = await ctx.api.get('/api/v1/admin/loan-products');
    pg(ctx, 'طرح‌های وام', html`<div class="row"><h1>طرح‌های وام</h1><span class="sp"></span>${ps.length ? '' : html`<form method="post" action="/admin/products/seed">${csrf(ctx)}<button class="btn sm">ساخت طرح‌های نمونه</button></form>`}</div>
${table(['طرح', 'بازه‌ی مبلغ', 'کارمزد/سود', 'نمایش', 'وضعیت', ''], ps.map((p) => [html`<strong>${p.shape.name}</strong><div class="mut ltr">${p.shape.id}</div>`, `${money(p.shape.minAmount)} تا ${money(p.shape.maxAmount)}`, p.shape.interestPercent ? fa(p.shape.interestPercent) + '٪' : '—', p.showInList ? 'در فهرست' : 'پنهان', p.isActive ? html`<span class="badge good">فعال</span>` : html`<span class="badge mute">غیرفعال</span>`, html`<div class="row"><a class="btn sm ghost" href="/admin/products/${p.id}/contracts">قراردادها</a><form method="post" action="/admin/products/${p.id}/toggle">${csrf(ctx)}<button class="btn sm ghost">${p.isActive ? 'غیرفعال کن' : 'فعال کن'}</button></form></div>`]), 'طرحی تعریف نشده')}<p class="mut">ویرایش کامل پله‌های کارمزد و شرایط فعلاً از API یا فرانت قدیمی انجام می‌شود.</p>`, '/admin/products');
  });
  Po('/admin/products/seed', async (ctx) => back(ctx, '/admin/products', await ctx.api.try('POST', '/api/v1/admin/loan-products/seed', {}), 'طرح‌های نمونه ساخته شد.'));
  Po('/admin/products/:id/toggle', async (ctx) => back(ctx, '/admin/products', await ctx.api.try('POST', `/api/v1/admin/loan-products/${ctx.params.id}/toggle`, {}), 'وضعیت طرح عوض شد.'));

  // ---------- کارت‌های مجازی ----------
  const CARD = { Active: ['فعال', 'good'], Frozen: ['مسدود', 'warn'], Closed: ['بسته', 'mute'] };
  G('/admin/cards', async (ctx) => {
    const cs = await ctx.api.get('/api/v1/admin/virtual-cards', { status: ctx.query.status });
    pg(ctx, 'کارت‌های مجازی', html`<h1>کارت‌های مجازی</h1><div class="stack"><div>${table(['کارت', 'دارنده', 'سقف', 'مصرف', 'وضعیت', ''], cs.map((c) => [html`<span class="ltr">${c.number}</span>`, c.holderName, money(c.limit), money(c.spent), html`<span class="badge ${CARD[c.status]?.[1] || 'mute'}">${CARD[c.status]?.[0] || c.status}</span>`, c.status === 'Closed' ? '' : html`<div class="row"><form method="post" action="/admin/cards/${c.id}/${c.status === 'Frozen' ? 'unfreeze' : 'freeze'}">${csrf(ctx)}<button class="btn sm ghost">${c.status === 'Frozen' ? 'رفع مسدودی' : 'مسدود'}</button></form><form method="post" action="/admin/cards/${c.id}/close">${csrf(ctx)}<button class="btn sm danger">بستن</button></form></div>`]), 'کارتی نیست')}</div>
<form class="f card" method="post" action="/admin/cards/issue">${csrf(ctx)}<h2>صدور کارت</h2><label>شناسه‌ی وام (Guid)<input name="loanId" class="ltr" required pattern="[0-9a-fA-F-]{36}"></label><label>شناسه‌ی مشتری (Guid)<input name="userId" class="ltr" required pattern="[0-9a-fA-F-]{36}"></label><label>نام دارنده<input name="holderName" required maxlength="80"></label><label>سقف (تومان)<input name="limit" data-money class="ltr" inputmode="numeric" required></label><button class="btn">صدور</button></form></div>`, '/admin/cards');
  });
  Po('/admin/cards/issue', async (ctx) => { const b = ctx.body; const lim = num(b.limit); if (!GUID.test(b.loanId || '') || !GUID.test(b.userId || '') || !(lim > 0)) return ctx.redirect('/admin/cards', { t: 'err', m: 'شناسه‌ها یا سقف نامعتبر است.' }); back(ctx, '/admin/cards', await ctx.api.try('POST', '/api/v1/admin/virtual-cards/issue', { loanId: b.loanId, userId: b.userId, holderName: b.holderName, limit: lim }), 'کارت صادر شد.'); });
  for (const op of ['freeze', 'unfreeze', 'close']) Po(`/admin/cards/:id/${op}`, async (ctx) => back(ctx, '/admin/cards', await ctx.api.try('POST', `/api/v1/admin/virtual-cards/${ctx.params.id}/${op}`, {}), 'انجام شد.'));

  // ---------- طرف‌حساب‌ها ----------
  G('/admin/counterparties', async (ctx) => {
    const cs = await ctx.api.get('/api/v1/admin/counterparties');
    pg(ctx, 'طرف‌حساب‌ها', html`<h1>طرف‌حساب‌ها (فروشندگان)</h1><div class="stack"><div>${table(['نام', 'شبا', 'وضعیت', ''], cs.map((c) => [c.name, html`<span class="ltr">${c.iban}</span>`, c.isActive ? html`<span class="badge good">فعال</span>` : html`<span class="badge mute">غیرفعال</span>`, html`<form method="post" action="/admin/counterparties/${c.id}">${csrf(ctx)}<input type="hidden" name="name" value="${c.name}"><input type="hidden" name="iban" value="${c.iban}"><input type="hidden" name="active" value="${c.isActive ? '0' : '1'}"><button class="btn sm ghost">${c.isActive ? 'غیرفعال کن' : 'فعال کن'}</button></form>`]), 'طرف‌حسابی نیست')}</div>
<form class="f card" method="post" action="/admin/counterparties">${csrf(ctx)}<h2>طرف‌حساب جدید</h2><label>نام<input name="name" required maxlength="120"></label><label>شماره شبا<small>مثال: IR + ۲۴ رقم</small><input name="iban" class="ltr" required pattern="[Ii][Rr][0-9 ]{24,30}"></label><button class="btn">افزودن</button></form></div>`, '/admin/counterparties');
  });
  Po('/admin/counterparties', async (ctx) => back(ctx, '/admin/counterparties', await ctx.api.try('POST', '/api/v1/admin/counterparties', { name: ctx.body.name, iban: en(ctx.body.iban || ''), isActive: true }), 'افزوده شد.'));
  Po('/admin/counterparties/:id', async (ctx) => back(ctx, '/admin/counterparties', await ctx.api.try('PUT', `/api/v1/admin/counterparties/${ctx.params.id}`, { name: ctx.body.name, iban: ctx.body.iban, isActive: ctx.body.active === '1' }), 'ذخیره شد.'));

  G('/admin/more', (ctx) => pg(ctx, 'بیشتر', html`<h1>سایر بخش‌ها</h1><div class="grid">${MORE.map(([h, t, d]) => html`<a class="card" href="${h}"><strong>${t}</strong><div class="mut">${d}</div></a>`)}</div>`, '/admin/more'));

  // ---------- بازاریاب‌ها ----------
  G('/admin/marketers', async (ctx) => {
    const ms = await ctx.api.get('/api/v1/admin/marketers');
    pg(ctx, 'بازاریاب‌ها', html`<h1>بازاریاب‌ها</h1><div class="stack">${table(['نام', 'موبایل', 'کد معرفی', 'پورسانت', 'وضعیت', ''], ms.map((m) => [m.name, html`<span class="ltr">${m.phone}</span>`, html`<span class="ltr">${m.code}</span>`, fa(m.commissionPercent) + '٪', m.isActive ? html`<span class="badge good">فعال</span>` : html`<span class="badge mute">غیرفعال</span>`, html`<form method="post" action="/admin/marketers/${m.id}">${csrf(ctx)}<input type="hidden" name="name" value="${m.name}"><input type="hidden" name="phone" value="${m.phone}"><input type="hidden" name="commission" value="${m.commissionPercent}"><input type="hidden" name="active" value="${m.isActive ? '0' : '1'}"><button class="btn sm ghost">${m.isActive ? 'غیرفعال کن' : 'فعال کن'}</button></form>`]), 'بازاریابی ثبت نشده')}
<form class="f card" method="post" action="/admin/marketers">${csrf(ctx)}<h2>بازاریاب جدید</h2><label>نام<input name="name" required maxlength="120"></label><label>موبایل<input name="phone" class="ltr" inputmode="tel" required></label><label>پورسانت (درصد)<input name="commission" class="ltr" inputmode="decimal" required></label><button class="btn">افزودن</button></form></div>`, '/admin/more');
  });
  Po('/admin/marketers', async (ctx) => back(ctx, '/admin/marketers', await ctx.api.try('POST', '/api/v1/admin/marketers', { name: ctx.body.name, phone: en(ctx.body.phone || ''), commissionPercent: num(ctx.body.commission) || 0, isActive: true }), 'افزوده شد.'));
  Po('/admin/marketers/:id', async (ctx) => back(ctx, '/admin/marketers', await ctx.api.try('PUT', `/api/v1/admin/marketers/${ctx.params.id}`, { name: ctx.body.name, phone: ctx.body.phone, commissionPercent: num(ctx.body.commission) || 0, isActive: ctx.body.active === '1' }), 'ذخیره شد.'));

  // ---------- سفارش‌ها ----------
  const ORD = { Pending: ['در انتظار', 'warn'], Delivered: ['تحویل شد', 'good'], Cancelled: ['لغو شد', 'mute'] };
  G('/admin/orders', async (ctx) => {
    const os = await ctx.api.get('/api/v1/admin/orders');
    pg(ctx, 'سفارش‌ها', html`<h1>سفارش‌های خرید</h1><div class="stack">${table(['کد', 'پذیرنده', 'مبلغ', 'مشتری', 'وضعیت', ''], os.map((o) => [html`<span class="ltr">${o.code}</span>`, o.merchantName, money(o.amount), html`<span class="ltr">${short(o.userId)}</span>`, html`<span class="badge ${ORD[o.status]?.[1] || 'mute'}">${ORD[o.status]?.[0] || o.status}</span>`, o.status === 'Pending' ? html`<div class="row"><form method="post" action="/admin/orders/${o.id}/status">${csrf(ctx)}<input type="hidden" name="status" value="Delivered"><button class="btn sm">تحویل شد</button></form><form method="post" action="/admin/orders/${o.id}/status">${csrf(ctx)}<input type="hidden" name="status" value="Cancelled"><button class="btn sm danger">لغو</button></form></div>` : '']), 'سفارشی نیست')}
<form class="f card" method="post" action="/admin/orders">${csrf(ctx)}<h2>سفارش جدید</h2><label>شناسه‌ی مشتری (Guid)<input name="userId" class="ltr" required pattern="[0-9a-fA-F-]{36}"></label><label>شناسه‌ی وام (اختیاری)<input name="loanId" class="ltr" pattern="[0-9a-fA-F-]{36}"></label><label>پذیرنده<input name="merchant" required maxlength="120"></label><label>مبلغ (تومان)<input name="amount" data-money class="ltr" inputmode="numeric" required></label><button class="btn">ثبت</button></form></div>`, '/admin/more');
  });
  Po('/admin/orders', async (ctx) => { const b = ctx.body, a = num(b.amount); if (!GUID.test(b.userId || '') || (b.loanId && !GUID.test(b.loanId)) || !(a > 0)) return ctx.redirect('/admin/orders', { t: 'err', m: 'شناسه یا مبلغ نامعتبر است.' }); back(ctx, '/admin/orders', await ctx.api.try('POST', '/api/v1/admin/orders', { userId: b.userId, loanId: b.loanId || null, merchantName: b.merchant, amount: a }), 'سفارش ثبت شد.'); });
  Po('/admin/orders/:id/status', async (ctx) => back(ctx, '/admin/orders', await ctx.api.try('POST', `/api/v1/admin/orders/${ctx.params.id}/status`, { status: ctx.body.status }), 'وضعیت ثبت شد.'));

  // ---------- استعلام‌ها ----------
  const INQ = { Credit: 'اعتبارسنجی', Identity: 'احراز هویت', Other: 'سایر' }; const INQS = { Queued: ['در صف', 'warn'], Done: ['انجام شد', 'good'], Failed: ['ناموفق', 'bad'] };
  G('/admin/inquiries', async (ctx) => {
    const xs = await ctx.api.get('/api/v1/admin/inquiries');
    pg(ctx, 'استعلام‌ها', html`<h1>استعلام‌ها</h1><div class="stack">${table(['نوع', 'مشتری', 'وضعیت', 'نتیجه', 'ثبت', ''], xs.map((x) => [INQ[x.type] || x.type, html`<span class="ltr">${short(x.userId)}</span>`, html`<span class="badge ${INQS[x.status]?.[1] || 'mute'}">${INQS[x.status]?.[0] || x.status}</span>`, x.result || '—', jdt(x.createdOn), x.status === 'Queued' ? html`<form class="row" method="post" action="/admin/inquiries/${x.id}/result">${csrf(ctx)}<input name="result" placeholder="نتیجه" maxlength="300"><button class="btn sm" name="status" value="Done">ثبت نتیجه</button><button class="btn sm danger" name="status" value="Failed">ناموفق</button></form>` : '']), 'استعلامی نیست')}
<form class="f card" method="post" action="/admin/inquiries">${csrf(ctx)}<h2>استعلام جدید</h2><label>شناسه‌ی مشتری (Guid)<input name="userId" class="ltr" required pattern="[0-9a-fA-F-]{36}"></label><label>نوع<select name="type">${Object.entries(INQ).map(([k, v]) => html`<option value="${k}">${v}</option>`)}</select></label><label>یادداشت<input name="note" maxlength="300"></label><button class="btn">ثبت</button></form></div>`, '/admin/more');
  });
  Po('/admin/inquiries', async (ctx) => { if (!GUID.test(ctx.body.userId || '')) return ctx.redirect('/admin/inquiries', { t: 'err', m: 'شناسه‌ی مشتری نامعتبر است.' }); back(ctx, '/admin/inquiries', await ctx.api.try('POST', '/api/v1/admin/inquiries', { userId: ctx.body.userId, type: ctx.body.type, note: ctx.body.note || null }), 'ثبت شد.'); });
  Po('/admin/inquiries/:id/result', async (ctx) => back(ctx, '/admin/inquiries', await ctx.api.try('POST', `/api/v1/admin/inquiries/${ctx.params.id}/result`, { status: ctx.body.status, result: ctx.body.result || null }), 'نتیجه ثبت شد.'));

  // ---------- پشتیبان‌گیری (فقط مدیر ارشد) ----------
  G('/admin/backups', async (ctx) => {
    if (!ctx.user.isSuper) return ctx.html(page(ctx, { area: 'admin', title: 'پشتیبان‌گیری', body: empty('این بخش فقط برای مدیر ارشد است.') }), 403);
    const bs = await ctx.api.get('/api/v1/admin/backups');
    pg(ctx, 'پشتیبان‌گیری', html`<div class="row"><h1>پشتیبان پایگاه داده</h1><span class="sp"></span><form method="post" action="/admin/backups">${csrf(ctx)}<button class="btn">تهیه‌ی پشتیبان همین حالا</button></form></div>
${table(['فایل', 'حجم', 'زمان'], bs.map((b) => [html`<span class="ltr">${b.name}</span>`, fa(Math.round(b.size / 1048576)) + ' مگابایت', jdt(b.createdOn)]), 'پشتیبانی نیست')}<p class="mut">بازگردانی عمداً از طریق وب انجام نمی‌شود؛ باید دستی و با توقف سرویس باشد. فایل‌ها را روی سرور بیرونی هم کپی کنید (offsite-backup.sh).</p>`, '/admin/more');
  });
  Po('/admin/backups', async (ctx) => { if (!ctx.user.isSuper) return ctx.redirect('/admin', { t: 'err', m: 'فقط مدیر ارشد.' }); back(ctx, '/admin/backups', await ctx.api.try('POST', '/api/v1/admin/backups', {}), 'پشتیبان تهیه شد.'); });

  // ---------- قالب‌های قرارداد ----------
  const TT = { Company: 'شرکت', Bank: 'بانک', Financier: 'تأمین‌کننده', Guarantee: 'ضمانت', Other: 'سایر' };
  const TS = { Draft: ['پیش‌نویس', 'warn'], Approved: ['تأییدشده', 'info'], Published: ['منتشرشده', 'good'], Archived: ['بایگانی', 'mute'] };
  const tsb = (st) => html`<span class="badge ${TS[st]?.[1] || 'mute'}">${TS[st]?.[0] || st}</span>`;
  const dOnly = (v) => (v ? String(v).slice(0, 10) : '');
  const dIn = (v) => (/^\d{4}-\d{2}-\d{2}$/.test(v || '') ? `${v}T00:00:00Z` : null);
  G('/admin/templates', async (ctx) => {
    const ts = await ctx.api.get('/api/v1/admin/contract-templates');
    pg(ctx, 'قالب‌های قرارداد', html`<div class="row"><h1>قالب‌های قرارداد</h1><span class="sp"></span><a class="btn" href="/admin/templates/new">قالب جدید</a></div>${table(['عنوان', 'نوع', 'نسخه', 'وضعیت', 'اعتبار', ''], ts.map((t) => [t.title, TT[t.type] || t.type, fa(t.version), tsb(t.status), `${jdate(t.validFrom)} تا ${t.validTo ? jdate(t.validTo) : 'نامحدود'}`, html`<a href="/admin/templates/${t.id}">باز کردن</a>`]), 'قالبی تعریف نشده')}`, '/admin/more');
  });
  const tplForm = (ctx, t, action) => html`<form class="f card wide" method="post" action="${action}">${csrf(ctx)}
<label>عنوان<input name="title" value="${t.title || ''}" required maxlength="160"></label>
<div class="grid"><label>نوع<select name="type">${Object.entries(TT).map(([k, v]) => html`<option value="${k}" ${t.type === k ? raw('selected') : ''}>${v}</option>`)}</select></label><label>طرف صادرکننده<input name="issuerParty" value="${t.issuerParty || ''}" maxlength="160"></label>
<label>اعتبار از<input type="date" name="validFrom" class="ltr" value="${dOnly(t.validFrom)}"></label><label>اعتبار تا<input type="date" name="validTo" class="ltr" value="${dOnly(t.validTo)}"></label></div>
<label>توضیح<textarea name="description" maxlength="600">${t.description || ''}</textarea></label><label>شرایط استفاده<textarea name="usageConditions" maxlength="600">${t.usageConditions || ''}</textarea></label>
<label>سربرگ (HTML)<textarea name="headerHtml" class="code">${t.headerHtml || ''}</textarea></label><label>متن قرارداد (HTML)<small>متغیرها مثل {{full_name}}؛ فهرست در «متغیرهای قرارداد»</small><textarea name="bodyHtml" class="code tall" required>${t.bodyHtml || ''}</textarea></label><label>پابرگ (HTML)<textarea name="footerHtml" class="code">${t.footerHtml || ''}</textarea></label>
<label>یادداشت تغییر<input name="changeNote" value="${t.changeNote || ''}" maxlength="300"></label>${ctx.user.isSuper ? html`<label class="chk"><input type="checkbox" name="restricted" value="1" ${t.restricted ? raw('checked') : ''}> اختصاصی (فقط مدیر ارشد ببیند)</label>` : ''}<button class="btn">ذخیره</button></form>`;
  const tplBody = (ctx, b) => ({ title: b.title, type: b.type, issuerParty: b.issuerParty || null, parties: [], description: b.description || null, usageConditions: b.usageConditions || null, counterPartyId: null, restricted: b.restricted === '1', headerHtml: b.headerHtml || null, bodyHtml: b.bodyHtml || null, footerHtml: b.footerHtml || null, validFrom: dIn(b.validFrom), validTo: dIn(b.validTo), changeNote: b.changeNote || null });
  G('/admin/templates/new', (ctx) => pg(ctx, 'قالب جدید', html`<h1>قالب جدید</h1>${tplForm(ctx, { type: 'Company' }, '/admin/templates')}<p class="mut">متن قرارداد بعد از ساخت قابل ویرایش است تا زمانی که پیش‌نویس باشد.</p>`, '/admin/more'));
  Po('/admin/templates', async (ctx) => { const r = await ctx.api.try('POST', '/api/v1/admin/contract-templates', tplBody(ctx, ctx.body)); if (!r.ok) return ctx.redirect('/admin/templates/new', { t: 'err', m: ctx.api.msg(r) }); ctx.redirect(`/admin/templates/${r.data.id}`, { t: 'ok', m: 'قالب ساخته شد.' }); });
  const tplPage = async (ctx, problems) => {
    const t = await ctx.api.get(`/api/v1/admin/contract-templates/${ctx.params.id}`);
    const act = (op, label, cls = '') => html`<form method="post" action="/admin/templates/${t.id}/${op}">${csrf(ctx)}<button class="btn sm ${cls}">${label}</button></form>`;
    pg(ctx, t.title, html`<div class="row"><h1>${t.title}</h1><span class="sp"></span>${tsb(t.status)}<span class="badge mute">نسخه ${fa(t.version)}</span></div>
${problems?.length ? html`<div class="flash bad"><strong>مشکل‌های قالب:</strong><ul>${problems.map((p) => html`<li>${p}</li>`)}</ul></div>` : problems ? html`<div class="flash good">مشکلی در قالب پیدا نشد.</div>` : ''}
<div class="row">${t.status === 'Draft' ? html`${act('validate', 'اعتبارسنجی', 'ghost')}${act('approve', 'تأیید')}` : ''}${t.status === 'Approved' ? act('publish', 'انتشار') : ''}${t.status === 'Published' ? act('new-version', 'نسخه‌ی جدید') : ''}${t.status !== 'Archived' ? act('archive', 'بایگانی', 'danger') : ''}</div>
<p class="mut">تأییدکننده نمی‌تواند همان سازنده باشد (به‌جز مدیر ارشد). فقط پیش‌نویس ویرایش می‌شود؛ برای تغییر نسخه‌ی منتشرشده، نسخه‌ی جدید بسازید.</p>
<div class="grid two"><div>${t.status === 'Draft' ? tplForm(ctx, t, `/admin/templates/${t.id}`) : html`<div class="card"><dl class="kv"><dt>نوع</dt><dd>${TT[t.type] || t.type}</dd><dt>صادرکننده</dt><dd>${t.issuerParty || '—'}</dd><dt>اعتبار</dt><dd>${jdate(t.validFrom)} تا ${t.validTo ? jdate(t.validTo) : 'نامحدود'}</dd><dt>یادداشت</dt><dd>${t.changeNote || '—'}</dd></dl><p class="mut">برای ویرایش، نسخه‌ی جدید بسازید.</p></div>`}</div>
<div class="card"><h2>فایل نمونه (PDF یا Word)</h2>${t.sampleFileName ? html`<p>فایل فعلی: <span class="ltr">${t.sampleFileName}</span> — <a href="/admin/templates/${t.id}/sample">دانلود</a></p>` : html`<p class="mut">فایلی بارگذاری نشده.</p>`}<form class="f" method="post" enctype="multipart/form-data" action="/admin/templates/${t.id}/sample?_csrf=${ctx.csrf}"><label>فایل (تا ۵ مگابایت)<input type="file" name="file" accept=".pdf,.doc,.docx" required></label><button class="btn sm">بارگذاری</button></form></div>
<div class="card"><h2>پیش‌نمایش با داده‌ی نمونه</h2><form method="post" action="/admin/templates/${t.id}/preview" target="pvframe">${csrf(ctx)}<button class="btn sm">نمایش پیش‌نمایش</button></form><iframe class="cframe" name="pvframe" title="پیش‌نمایش قالب" sandbox=""></iframe></div></div>`, '/admin/more');
  };
  G('/admin/templates/:id/sample', async (ctx) => {
    const r = await ctx.api.raw('GET', `/api/v1/admin/contract-templates/${ctx.params.id}/sample`, { headers: { Accept: '*/*' } });
    const ct = String(r.headers['content-type'] || ''); if (!r.ok) return ctx.send(404, 'not found', 'text/plain');
    ctx.send(200, r.buf, ct.startsWith('application/pdf') ? 'application/pdf' : 'application/octet-stream', { 'Content-Disposition': 'attachment; filename="contract-sample"', 'Content-Security-Policy': "default-src 'none'; sandbox", 'Cache-Control': 'private, no-store' });
  });
  app.post('/admin/templates/:id/sample', guard, wrap(async (ctx) => {
    const len = +(ctx.req.headers['content-length'] || 0); if (!len || len > 5.5 * 1024 * 1024) return ctx.redirect(`/admin/templates/${ctx.params.id}`, { t: 'err', m: 'حجم فایل بیش از ۵ مگابایت است.' });
    back(ctx, `/admin/templates/${ctx.params.id}`, await ctx.api.pipe('POST', `/api/v1/admin/contract-templates/${ctx.params.id}/sample`, ctx.req, { 'Content-Type': ctx.req.headers['content-type'], 'Content-Length': String(len) }), 'فایل نمونه بارگذاری شد.');
  }));
  G('/admin/templates/:id', (ctx) => tplPage(ctx));
  Po('/admin/templates/:id', async (ctx) => { const r = await ctx.api.try('PUT', `/api/v1/admin/contract-templates/${ctx.params.id}`, tplBody(ctx, ctx.body)); if (!r.ok) return back(ctx, `/admin/templates/${ctx.params.id}`, r, ''); ctx.flash = { t: 'ok', m: 'ذخیره شد.' }; await tplPage(ctx, r.data?.problems || []); });
  Po('/admin/templates/:id/validate', async (ctx) => { const r = await ctx.api.try('POST', `/api/v1/admin/contract-templates/${ctx.params.id}/validate`, {}); if (!r.ok) return back(ctx, `/admin/templates/${ctx.params.id}`, r, ''); await tplPage(ctx, r.data.problems || []); });
  Po('/admin/templates/:id/approve', async (ctx) => { const r = await ctx.api.try('POST', `/api/v1/admin/contract-templates/${ctx.params.id}/approve`, {}); if (r.status === 422) { await tplPage(ctx, r.data.problems || []); return; } back(ctx, `/admin/templates/${ctx.params.id}`, r, 'قالب تأیید شد.'); });
  Po('/admin/templates/:id/publish', async (ctx) => back(ctx, `/admin/templates/${ctx.params.id}`, await ctx.api.try('POST', `/api/v1/admin/contract-templates/${ctx.params.id}/publish`, {}), 'قالب منتشر شد.'));
  Po('/admin/templates/:id/archive', async (ctx) => back(ctx, '/admin/templates', await ctx.api.try('POST', `/api/v1/admin/contract-templates/${ctx.params.id}/archive`, {}), 'بایگانی شد.'));
  Po('/admin/templates/:id/new-version', async (ctx) => { const r = await ctx.api.try('POST', `/api/v1/admin/contract-templates/${ctx.params.id}/new-version`, {}); if (!r.ok) return back(ctx, `/admin/templates/${ctx.params.id}`, r, ''); ctx.redirect(`/admin/templates/${r.data.id}`, { t: 'ok', m: `نسخه‌ی ${fa(r.data.version)} ساخته شد.` }); });
  Po('/admin/templates/:id/preview', async (ctx) => {
    const r = await ctx.api.try('POST', `/api/v1/admin/contract-templates/${ctx.params.id}/preview`, {});
    const body = r.ok ? r.data.html : '<p>پیش‌نمایش در دسترس نیست.</p>'; const errs = r.ok && r.data.errors?.length ? `<p style="color:#b42318">خطا: ${esc(JSON.stringify(r.data.errors))}</p>` : '';
    ctx.send(200, body.replace(/<body[^>]*>/i, (m) => m + errs), 'text/html; charset=utf-8', { 'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'; img-src data:; sandbox; frame-ancestors 'self'", 'X-Frame-Options': 'SAMEORIGIN' });
  });

  // ---------- متغیرهای قرارداد ----------
  G('/admin/variables', async (ctx) => {
    const vs = await ctx.api.get('/api/v1/admin/contract-variables');
    pg(ctx, 'متغیرهای قرارداد', html`<div class="row"><h1>متغیرهای قرارداد</h1><span class="sp"></span><form method="post" action="/admin/variables/sync">${csrf(ctx)}<button class="btn sm ghost">افزودن متغیرهای پیش‌فرض جاافتاده</button></form></div>
<div class="stack">${table(['کلید', 'عنوان', 'نوع', 'منبع', 'الزامی', 'حساس', ''], vs.map((v) => [html`<code class="ltr">{{${v.key}}}</code>`, v.label, v.dataType, v.source + (v.path ? ' / ' + v.path : ''), v.required ? 'بله' : '—', v.sensitivity === 'Sensitive' ? html`<span class="badge warn">حساس</span>` : '—', html`<form method="post" action="/admin/variables/${v.id}/delete">${csrf(ctx)}<button class="btn sm danger">حذف</button></form>`]), 'متغیری نیست')}
<form class="f card" method="post" action="/admin/variables">${csrf(ctx)}<h2>متغیر جدید</h2><label>کلید<small>حروف کوچک انگلیسی، عدد و _</small><input name="key" class="ltr" required pattern="[a-z][a-z0-9_]{1,59}"></label><label>عنوان<input name="label" required maxlength="120"></label>
<div class="grid"><label>نوع<select name="dataType"><option>text</option><option>number</option><option>money</option><option>date</option></select></label><label>منبع<select name="source"><option>applicant</option><option>document</option><option>loan</option><option>party</option><option>system</option><option>custom</option></select></label></div>
<label>مسیر منبع (برای منبع «custom» خالی بماند)<input name="path" class="ltr" maxlength="60"></label><label>مقدار پیش‌فرض (برای custom)<input name="defaultValue" maxlength="200"></label><label class="chk"><input type="checkbox" name="required" value="1"> الزامی</label><label class="chk"><input type="checkbox" name="sensitive" value="1"> حساس (در متن پنهان/ماسک می‌شود)</label><button class="btn">افزودن</button></form></div>`, '/admin/more');
  });
  Po('/admin/variables', async (ctx) => { const b = ctx.body; back(ctx, '/admin/variables', await ctx.api.try('POST', '/api/v1/admin/contract-variables', { key: b.key, label: b.label, dataType: b.dataType, source: b.source, path: b.path || null, required: b.required === '1', format: null, sensitivity: b.sensitive === '1' ? 'Sensitive' : 'Normal', defaultValue: b.defaultValue || null, validation: null }), 'متغیر افزوده شد.'); });
  Po('/admin/variables/sync', async (ctx) => back(ctx, '/admin/variables', await ctx.api.try('POST', '/api/v1/admin/contract-variables/sync-defaults', {}), 'انجام شد.'));
  Po('/admin/variables/:id/delete', async (ctx) => back(ctx, '/admin/variables', await ctx.api.try('DELETE', `/api/v1/admin/contract-variables/${ctx.params.id}`), 'حذف شد.'));

  // ---------- قراردادهای لازم هر طرح ----------
  const STG = { Application: 'ثبت درخواست', Approval: 'تأیید', Disbursement: 'پرداخت' };
  G('/admin/products/:id/contracts', async (ctx) => {
    const [links, ts] = await Promise.all([ctx.api.get(`/api/v1/admin/loan-products/${ctx.params.id}/contracts`), ctx.api.get('/api/v1/admin/contract-templates')]);
    const groups = [...new Map(ts.filter((t) => t.status !== 'Archived').map((t) => [t.groupKey, t])).values()];
    pg(ctx, 'قراردادهای طرح', html`<h1>قراردادهای لازم این طرح</h1><form class="f card wide" method="post" action="/admin/products/${ctx.params.id}/contracts">${csrf(ctx)}<input type="hidden" name="count" value="${links.length}">
${links.map((l, i) => html`<div class="card sub"><div class="row"><strong>${l.title || l.groupKey}</strong><span class="sp"></span><label class="chk"><input type="checkbox" name="del_${i}" value="1"> حذف</label></div><input type="hidden" name="gk_${i}" value="${l.groupKey}"><div class="grid"><label>مرحله<select name="stage_${i}">${Object.entries(STG).map(([k, v]) => html`<option value="${k}" ${l.stage === k ? raw('selected') : ''}>${v}</option>`)}</select></label><label>شرط (اختیاری)<input name="cond_${i}" value="${l.condition || ''}" class="ltr" maxlength="300"></label></div><label class="chk"><input type="checkbox" name="req_${i}" value="1" ${l.required ? raw('checked') : ''}> الزامی</label><label class="chk"><input type="checkbox" name="rev_${i}" value="1" ${l.requiresReview ? raw('checked') : ''}> نیازمند بازبینی کارشناس</label></div>`)}
<div class="card sub"><h2>افزودن قرارداد</h2><label>قالب<select name="gk_new"><option value="">— انتخاب کنید —</option>${groups.map((t) => html`<option value="${t.groupKey}">${t.title}</option>`)}</select></label><label>مرحله<select name="stage_new">${Object.entries(STG).map(([k, v]) => html`<option value="${k}">${v}</option>`)}</select></label></div><button class="btn">ذخیره‌ی فهرست</button></form><p class="mut">هر قالب فقط یک بار در یک طرح می‌آید.</p>`, '/admin/more');
  });
  Po('/admin/products/:id/contracts', async (ctx) => {
    const b = ctx.body, n = Math.min(+b.count || 0, 20), items = [];
    for (let i = 0; i < n; i++) if (b['del_' + i] !== '1' && GUID.test(b['gk_' + i] || '')) items.push({ groupKey: b['gk_' + i], stage: b['stage_' + i], required: b['req_' + i] === '1', condition: b['cond_' + i] || null, requiresReview: b['rev_' + i] === '1', sortOrder: items.length });
    if (GUID.test(b.gk_new || '')) items.push({ groupKey: b.gk_new, stage: b.stage_new, required: true, condition: null, requiresReview: true, sortOrder: items.length });
    back(ctx, `/admin/products/${ctx.params.id}/contracts`, await ctx.api.try('PUT', `/api/v1/admin/loan-products/${ctx.params.id}/contracts`, items), 'ذخیره شد.');
  });
}
