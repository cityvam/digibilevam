import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { createApp } from './lib/http.js';
import { apiFor } from './lib/api.js';
import { page } from './lib/layout.js';
import { html } from './lib/ui.js';
import { registerPublic } from './pages/public.js';
import { registerCustomer } from './pages/customer.js';
import { registerAdmin } from './pages/admin.js';

const here = dirname(fileURLToPath(import.meta.url));
const cfg = {
  port: +(process.env.PORT || 3000), host: process.env.HOST || '127.0.0.1',
  api: process.env.API_URL || 'http://127.0.0.1:5200', apiHost: process.env.API_HOST_HEADER || '',
  secret: process.env.WEB_SECRET || '', secure: process.env.COOKIE_SECURE === 'true',
};
if (cfg.secret.length < 32) { if (process.env.NODE_ENV === 'production') { console.error('WEB_SECRET باید ≥ ۳۲ نویسه باشد'); process.exit(1); } cfg.secret = 'dev-only-secret-dev-only-secret-0000'; }

const app = createApp({ secret: cfg.secret, secure: cfg.secure, publicDir: join(here, '..', 'public'), apiHost: cfg.apiHost });
app.use((ctx) => { ctx.api = apiFor(ctx, cfg.api); });
app.notFound = async (ctx) => page(ctx, { title: 'پیدا نشد', body: html`<div class="empty"><h1>۴۰۴</h1><p>این صفحه وجود ندارد.</p><a class="btn" href="/">بازگشت</a></div>` });
app.errorPage = async (ctx, m, st) => page(ctx, { title: 'خطا', body: html`<div class="empty"><h1>${st === 403 ? 'دسترسی ممنوع' : 'خطا'}</h1><p>${m}</p><a class="btn" href="/">صفحه‌ی اصلی</a></div>` });
app.get('/healthz', (ctx) => ctx.send(200, 'ok', 'text/plain'));
registerPublic(app, cfg); registerCustomer(app, cfg); registerAdmin(app, cfg);
app.listen(cfg.port, cfg.host).then(() => console.log(`digitalpay-web on http://${cfg.host}:${cfg.port} → ${cfg.api}`));
