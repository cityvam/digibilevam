#!/usr/bin/env python3
"""دود (smoke) با Playwright روی یک نمونه‌ی در حال اجرا. نمونه: python3 tools/e2e_smoke.py http://127.0.0.1:3000"""
import sys
from playwright.sync_api import sync_playwright
base = (sys.argv[1] if len(sys.argv) > 1 else 'http://127.0.0.1:3000').rstrip('/')
bad = []
with sync_playwright() as p:
    b = p.chromium.launch()
    for w in (1280, 390):
        pg = b.new_page(viewport={'width': w, 'height': 900})
        pg.on('console', lambda m: bad.append(m.text) if m.type == 'error' else None)
        for path in ('/', '/calculator', '/faq', '/login', '/register'):
            r = pg.goto(base + path)
            assert r.status == 200, (path, r.status)
            assert pg.evaluate('document.documentElement.scrollWidth') <= w, f'افقی‌اسکرول {path}@{w}'
    b.close()
print('CSP/console errors:', bad or 'none'); sys.exit(1 if bad else 0)
