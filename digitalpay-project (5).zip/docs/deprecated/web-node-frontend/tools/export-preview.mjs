// اجرای برنامه‌ی واقعی روی mock API و خروجی گرفتن همه‌ی صفحه‌ها به‌صورت HTML ایستا برای پیش‌نمایش.
import { spawn } from 'node:child_process';
import { mkdir, writeFile, copyFile, rm } from 'node:fs/promises';
import { startMock } from '../mock/mock-api.js';
const OUT = process.argv[2] || 'preview-out'; const PORT = 3011;
const mock = await startMock(5291);
const web = spawn('node', ['src/server.js'], { env: { ...process.env, PORT, API_URL: 'http://127.0.0.1:5291' }, stdio: 'inherit' });
await new Promise((r) => setTimeout(r, 1200));
const base = `http://127.0.0.1:${PORT}`;
class Jar { c = {}; eat(res) { for (const s of res.headers.getSetCookie()) { const [kv] = s.split(';'); const i = kv.indexOf('='); const k = kv.slice(0, i), v = kv.slice(i + 1); if (/Max-Age=0/.test(s)) delete this.c[k]; else this.c[k] = v; } } h() { return Object.entries(this.c).map(([k, v]) => `${k}=${v}`).join('; '); } }
async function get(jar, p) { const r = await fetch(base + p, { headers: { cookie: jar.h() }, redirect: 'manual' }); jar.eat(r); return r; }
async function post(jar, p, form) { const lp = await get(jar, '/login'); const t = (await lp.text()).match(/name="_csrf" value="([^"]+)"/)[1]; const r = await fetch(base + p, { method: 'POST', headers: { cookie: jar.h(), 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ _csrf: t, ...form }), redirect: 'manual' }); jar.eat(r); return r; }
const anon = new Jar(), cust = new Jar(), adm = new Jar();
await post(cust, '/login', { username: '09120000001', password: 'x', captchaId: 'c1', captcha: '4827' });
const ar = await post(adm, '/login', { username: '09120000000', password: 'x', captchaId: 'c1', captcha: '4827' });
const t2 = (await ar.text()).match(/name="ticket" value="([^"]+)"/)[1]; // 2FA page
const lp = await get(adm, '/login'); const tk = (await lp.text()).match(/name="_csrf" value="([^"]+)"/)[1];
const r2 = await fetch(base + '/login/2fa', { method: 'POST', headers: { cookie: adm.h(), 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ _csrf: tk, ticket: t2, code: '123456' }), redirect: 'manual' }); adm.eat(r2);
const G = (n) => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const PAGES = [
  ['عمومی', anon, [['/', 'خانه'], ['/products', 'طرح‌های اقساطی'], ['/products/mobile-6', 'جزئیات طرح'], ['/calculator?amount=10000000&months=6', 'ماشین‌حساب (با نتیجه)'], ['/faq', 'سوالات متداول'], ['/about', 'درباره ما'], ['/login', 'ورود'], ['/register', 'ثبت‌نام (مرحله ۱)']]],
  ['مشتری', cust, [['/app', 'داشبورد'], ['/app/contracts', 'فهرست قراردادها'], [`/app/contracts/${G(1)}`, 'قرارداد منتظر قبول'], [`/app/contracts/${G(3)}`, 'قرارداد قبول‌شده'], ['/app/documents', 'مدارک و بارگذاری'], ['/app/payments', 'اعلام واریز'], ['/app/cards', 'کارت‌های مجازی'], ['/app/inbox', 'اعلان‌ها'], ['/app/tickets', 'تیکت‌ها'], [`/app/tickets/${G(301)}`, 'گفتگوی تیکت'], ['/app/security', 'امنیت و 2FA']]],
  ['مدیریت', adm, [['/admin', 'داشبورد مدیریت'], ['/admin/contracts', 'قراردادها'], [`/admin/contracts/${G(2)}`, 'بررسی (در انتظار تأیید)'], [`/admin/contracts/${G(4)}`, 'بررسی (تأییدشده)'], ['/admin/documents', 'بررسی مدارک'], [`/admin/documents/${G(503)}`, 'بررسی یک مدرک'], ['/admin/payments', 'واریزها'], ['/admin/more', 'بیشتر (فهرست بخش‌ها)'], ['/admin/products', 'طرح‌های وام'], [`/admin/products/${G(1100)}/contracts`, 'قراردادهای یک طرح'], ['/admin/templates', 'قالب‌های قرارداد'], [`/admin/templates/${G(1602)}`, 'ویرایش قالب (پیش‌نویس)'], [`/admin/templates/${G(1601)}`, 'قالب منتشرشده'], ['/admin/templates/new', 'قالب جدید'], ['/admin/variables', 'متغیرهای قرارداد'], ['/admin/marketers', 'بازاریاب‌ها'], ['/admin/orders', 'سفارش‌ها'], ['/admin/inquiries', 'استعلام‌ها'], ['/admin/backups', 'پشتیبان‌گیری'], ['/admin/cards', 'کارت‌های مجازی'], ['/admin/counterparties', 'فروشندگان'], ['/admin/audit', 'حسابرسی'], ['/admin/tickets', 'تیکت‌ها'], [`/admin/tickets/${G(302)}`, 'پاسخ به تیکت (SLA گذشته)'], ['/admin/finance', 'مالی'], ['/admin/jobs', 'صف کارها'], ['/admin/roles', 'نقش‌ها و تخصیص'], [`/admin/roles/${G(902)}`, 'ویرایش نقش']]],
];
const HIDDEN = [[adm, `/admin/documents/${G(503)}/file`], [cust, `/app/contracts/${G(1)}/view`], [cust, `/app/contracts/${G(3)}/view`], [adm, `/admin/contracts/${G(2)}/view`], [adm, `/admin/contracts/${G(4)}/view`]];
const file = (p) => p.endsWith('/file') ? 'img-' + p.split('/').at(-2).slice(-4) + '.png' : 'p' + (p.replace(/[^a-z0-9]+/gi, '-').replace(/^-|-$/g, '') || 'home') + '.html';
const map = new Map(); for (const [, , l] of PAGES) for (const [p] of l) map.set(p.split('?')[0] + (p.includes('?') ? '?' + p.split('?')[1] : ''), file(p));
await rm(OUT, { recursive: true, force: true }); await mkdir(OUT, { recursive: true });
await copyFile('public/app.css', OUT + '/app.css'); await copyFile('public/app.js', OUT + '/app.js');
for (const [, p] of HIDDEN) map.set(p, file(p));
const bare = new Map(); for (const [p, f] of map) if (!bare.has(p.split('?')[0])) bare.set(p.split('?')[0], f);
let n = 0;
for (const [, jar, list] of [...PAGES, ['', null, []]].concat([])) for (const [p] of list) {
  const r = await get(jar, p); let h = await r.text(); if (r.status !== 200) { console.error('FAIL', p, r.status); process.exitCode = 1; }
  h = h.replace(/(href|src)="(\/[^"#]*)"/g, (m, a, u) => { if (u.startsWith('/static/')) return `${a}="${u.slice(8)}"`; const f = map.get(u) || bare.get(u.split('?')[0]); return f ? `${a}="${f}"` : (a === 'href' ? 'href="#"' : m); });
  h = h.replace(/<div class="flash (?:good|bad)" role="status">.*?<\/div>/s, '').replace(/action="[^"]*"/g, 'action="#"').replace('</head>', '<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;600;800&display=swap" rel="stylesheet"></head>').replace(/<main/, '<div class="wrap"><div class="flash good">پیش‌نمایش ایستا از برنامه‌ی واقعی (دکمه‌ها در این نسخه کار نمی‌کنند)</div></div><main');
  await writeFile(`${OUT}/${map.get(p)}`, h); n++;
}
for (const [jar, p] of HIDDEN) { const r = await get(jar, p); await writeFile(`${OUT}/${map.get(p)}`, Buffer.from(await r.arrayBuffer())); }
const idx = `<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>پیش‌نمایش دیجی‌بایل پی</title><link rel="stylesheet" href="app.css"><link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;600;800&display=swap" rel="stylesheet"></head><body><main class="wrap"><h1>پیش‌نمایش فرانت‌اند Node.js</h1><p class="lead">${n} صفحه، خروجی مستقیم برنامه‌ی واقعی روی API ساختگی. تم روشن/تیره از تنظیم دستگاه می‌آید.</p>${PAGES.map(([t, , l]) => `<h2>${t}</h2><div class="grid">${l.map(([p, name]) => `<a class="card" href="${map.get(p)}"><strong>${name}</strong><div class="mut ltr">${p.split('?')[0]}</div></a>`).join('')}</div>`).join('')}</main></body></html>`;
await writeFile(OUT + '/index.html', idx); console.log('exported', n);
web.kill(); mock.close();
