using System.Security.Claims;
using System.Text;
using Ghestine.Domain.Entities;
using Ghestine.API.Iam;
using Ghestine.API.Tenancy;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using __DBNS__;
namespace Ghestine.API.NoJs;

// پایش صف کار بدون JS (/nojs/admin/jobs). مجوز: settings.manage
[Route("nojs/admin/jobs")]
public class NoJsJobsController : Controller
{
    private readonly AppDbContext _db; private readonly IAntiforgery _af; private readonly PermissionService _ps;
    public NoJsJobsController(AppDbContext db, IAntiforgery af, PermissionService ps) { _db = db; _af = af; _ps = ps; }
    async Task<bool> Allowed(CancellationToken ct)
    {
        var t = Request.Cookies["dp_t"]; if (string.IsNullOrEmpty(t)) return false;
        Request.Headers.Authorization = "Bearer " + t; var r = await HttpContext.AuthenticateAsync("Bearer");
        if (!r.Succeeded || r.Principal == null) return false; HttpContext.User = r.Principal;
        return await _ps.HasAsync(r.Principal, this.Tid(), "settings.manage", ct);
    }
    async Task<bool> Csrf() { try { await _af.ValidateRequestAsync(HttpContext); return true; } catch (AntiforgeryValidationException) { return false; } }
    static readonly Dictionary<string, string> St = new() { ["Pending"] = "در انتظار", ["Running"] = "در حال اجرا", ["Done"] = "انجام‌شده", ["Failed"] = "ناموفق", ["Dead"] = "مرده (پس از چند تلاش)" };

    [HttpGet("")]
    public async Task<IActionResult> Index(string? status, string? msg, CancellationToken ct)
    {
        if (!await Allowed(ct)) return Redirect("/nojs/admin/login");
        var tid = this.Tid(); var q = _db.Set<BackgroundJob>().Where(j => j.TenantId == tid);
        var counts = await q.GroupBy(j => j.Status).Select(g => new { g.Key, n = g.Count() }).ToListAsync(ct);
        var filter = status is "Pending" or "Running" or "Done" or "Failed" or "Dead" ? status : null;
        var rows = await (filter == null ? q.Where(j => j.Status != "Done") : q.Where(j => j.Status == filter)).OrderByDescending(j => j.CreatedOn).Take(100).ToListAsync(ct);
        var af = _af.GetAndStoreTokens(HttpContext); var tok = $"<input type=\"hidden\" name=\"{af.FormFieldName}\" value=\"{H.E(af.RequestToken)}\">";
        var sb = new StringBuilder("<h1>صف کارها</h1>");
        if (!string.IsNullOrEmpty(msg)) sb.Append($"<p class=\"ok\">{H.E(msg)}</p>");
        sb.Append("<div class=\"g\">");
        foreach (var k in St.Keys) sb.Append($"<a class=\"card\" style=\"text-decoration:none;color:inherit\" href=\"/nojs/admin/jobs?status={k}\"><b style=\"font-size:1.6em\">{H.Fa(counts.FirstOrDefault(c => c.Key == k)?.n ?? 0)}</b><br>{St[k]}</a>");
        sb.Append("</div><div class=\"card\" style=\"overflow:auto\"><table><tr><th>نوع</th><th>وضعیت</th><th>تلاش</th><th>آخرین خطا</th><th></th></tr>");
        foreach (var j in rows)
            sb.Append($"<tr><td dir=\"ltr\">{H.E(j.Type)}</td><td>{St.GetValueOrDefault(j.Status, j.Status)}</td><td>{H.Fa(j.Attempts)}/{H.Fa(j.MaxAttempts)}</td><td dir=\"ltr\"><small>{H.E(j.LastError)}</small></td><td>{(j.Status is "Dead" or "Failed" ? $"<form method=\"post\" action=\"/nojs/admin/jobs/{j.Id}/retry\" style=\"margin:0\">{tok}<button class=\"btn2\">اجرای دوباره</button></form>" : "")}</td></tr>");
        sb.Append("</table></div>"); if (rows.Count == 0) sb.Append("<p>کاری در این وضعیت نیست.</p>");
        Response.Headers["Cache-Control"] = "no-store"; Response.Headers["Content-Security-Policy"] = "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'";
        return Content(H.Page("صف کارها", sb.ToString(), true).Replace("__AF__", tok), "text/html; charset=utf-8");
    }
    [HttpPost("{id:guid}/retry")]
    public async Task<IActionResult> Retry(Guid id, CancellationToken ct)
    {
        if (!await Allowed(ct)) return Redirect("/nojs/admin/login"); if (!await Csrf()) return BadRequest();
        var j = await _db.Set<BackgroundJob>().FirstOrDefaultAsync(x => x.Id == id && x.TenantId == this.Tid(), ct); if (j == null) return NotFound();
        if (j.Status is "Dead" or "Failed") { j.Status = "Pending"; j.Attempts = 0; j.RunAt = DateTime.UtcNow; j.LastError = ""; await _db.SaveChangesAsync(ct); }
        return Redirect("/nojs/admin/jobs?msg=" + Uri.EscapeDataString("کار دوباره در صف قرار گرفت"));
    }
}
