using System.Security.Claims;
using System.Text;
using Ghestine.Domain.Entities;
using Ghestine.API.Iam;
using Ghestine.API.Support;
using Ghestine.API.Tenancy;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using __DBNS__;
namespace Ghestine.API.NoJs;

// پشتیبانی بدون JS: مشتری (/nojs/me/tickets) و کارشناس (/nojs/admin/tickets، مجوز tickets.manage)
[Route("nojs")]
public class NoJsSupportController : Controller
{
    private readonly AppDbContext _db; private readonly IAntiforgery _af; private readonly SupportService _s; private readonly PermissionService _ps;
    public NoJsSupportController(AppDbContext db, IAntiforgery af, SupportService s, PermissionService ps) { _db = db; _af = af; _s = s; _ps = ps; }
    async Task<Guid?> Me()
    {
        var t = Request.Cookies["dp_t"]; if (string.IsNullOrEmpty(t)) return null; Request.Headers.Authorization = "Bearer " + t;
        var r = await HttpContext.AuthenticateAsync("Bearer"); if (!r.Succeeded || r.Principal == null) return null; HttpContext.User = r.Principal;
        return Guid.TryParse(r.Principal.FindFirstValue(ClaimTypes.NameIdentifier) ?? r.Principal.FindFirstValue("sub"), out var g) ? g : null;
    }
    async Task<bool> Staff(CancellationToken ct) => await Me() != null && await _ps.HasAsync(User, this.Tid(), "tickets.manage", ct);
    async Task<bool> Csrf() { try { await _af.ValidateRequestAsync(HttpContext); return true; } catch (AntiforgeryValidationException) { return false; } }
    ContentResult Page(string title, string body, bool admin, int code = 200)
    {
        var t = _af.GetAndStoreTokens(HttpContext); var tok = $"<input type=\"hidden\" name=\"{t.FormFieldName}\" value=\"{H.E(t.RequestToken)}\">";
        Response.StatusCode = code; Response.Headers["Cache-Control"] = "no-store"; Response.Headers["Content-Security-Policy"] = "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'";
        var nav = admin ? "" : "<a href=\"/nojs/me\">قراردادهای من</a><a href=\"/nojs/me/inbox\">اعلان‌ها</a><a href=\"/nojs/me/tickets\">پشتیبانی</a><a href=\"/nojs/me/notifications\">اعلان‌ها</a><a href=\"/nojs/me/security\">امنیت حساب</a><form method=\"post\" action=\"/nojs/logout\" style=\"margin:0\">__AF__<button class=\"btn2\">خروج</button></form>";
        var html = H.Page(title, body, admin);
        if (!admin) html = html.Replace("<a href=\"/nojs/login\">ورود</a><a href=\"/nojs/register\">ثبت‌نام</a><a href=\"/nojs/admin\">ورود مدیر</a>", nav);
        return Content(html.Replace("__AF__", tok), "text/html; charset=utf-8");
    }
    static string Dt(DateTime d) => H.Fa(d.ToString("yyyy-MM-dd HH:mm")) + " UTC";
    static string Msgs(IEnumerable<TicketMessage> ms, bool showInternal) => string.Concat(ms.Select(m => $"<div class=\"card\" style=\"{(m.IsInternal ? "border-style:dashed;" : "")}{(m.IsStaff ? "background:#241838" : "")}\"><small>{(m.IsInternal ? "یادداشت داخلی · " : "")}{(m.IsStaff ? "پشتیبان" : "مشتری")} · {Dt(m.CreatedOn)}</small><p style=\"white-space:pre-wrap;margin:6px 0 0\">{H.E(m.Body)}</p></div>"));

    // ---------- مشتری ----------
    [HttpGet("me/tickets")]
    public async Task<IActionResult> MyList(string? msg, CancellationToken ct)
    {
        var u = await Me(); if (u == null) return Redirect("/nojs/login");
        var l = await _db.Set<SupportTicket>().Where(t => t.TenantId == this.Tid() && t.UserId == u).OrderByDescending(t => t.UpdatedOn).Take(100).ToListAsync(ct);
        var sb = new StringBuilder("<h1>پشتیبانی</h1>");
        if (!string.IsNullOrEmpty(msg)) sb.Append($"<p class=\"ok\">{H.E(msg)}</p>");
        sb.Append("<form method=\"post\" action=\"/nojs/me/tickets/new\" class=\"card\">__AF__<h3>تیکت جدید</h3><label for=\"s\">موضوع</label><input id=\"s\" name=\"subject\" minlength=\"4\" maxlength=\"160\" required><label for=\"c\">دسته</label><select id=\"c\" name=\"category\">");
        foreach (var k in Sla.Categories) sb.Append($"<option value=\"{k}\">{Sla.CatFa[k]}</option>");
        sb.Append("</select><label for=\"b\">شرح مشکل</label><textarea id=\"b\" name=\"body\" rows=\"5\" minlength=\"10\" maxlength=\"4000\" required></textarea><p><small>رمز، کد CVV و کد پیامکی را هرگز برای پشتیبانی ننویسید.</small></p><p><button>ارسال</button></p></form>");
        sb.Append("<div class=\"card\" style=\"overflow:auto\"><table><tr><th>کد</th><th>موضوع</th><th>وضعیت</th><th>آخرین فعالیت</th><th></th></tr>");
        foreach (var t in l) sb.Append($"<tr><td dir=\"ltr\">{H.E(t.Code)}</td><td>{H.E(t.Subject)}</td><td>{Sla.StFa[t.Status]}</td><td>{Dt(t.UpdatedOn)}</td><td><a href=\"/nojs/me/tickets/{t.Id}\">مشاهده</a></td></tr>");
        sb.Append("</table></div>"); if (l.Count == 0) sb.Append("<p>هنوز تیکتی ندارید.</p>");
        return Page("پشتیبانی", sb.ToString(), false);
    }
    [HttpPost("me/tickets/new")]
    public async Task<IActionResult> MyNew([FromForm] string subject, [FromForm] string? category, [FromForm] string body, CancellationToken ct)
    {
        var u = await Me(); if (u == null) return Redirect("/nojs/login"); if (!await Csrf()) return BadRequest();
        var (t, e) = await _s.Create(this.Tid(), u.Value, subject ?? "", category ?? "Other", "Normal", body ?? "", ct);
        return t == null ? Redirect("/nojs/me/tickets?msg=" + Uri.EscapeDataString(e ?? "ثبت نشد")) : Redirect($"/nojs/me/tickets/{t.Id}?msg=" + Uri.EscapeDataString("تیکت ثبت شد. کد پیگیری: " + t.Code));
    }
    [HttpGet("me/tickets/{id:guid}")]
    public async Task<IActionResult> MyOne(Guid id, string? msg, CancellationToken ct)
    {
        var u = await Me(); if (u == null) return Redirect("/nojs/login");
        var t = await _db.Set<SupportTicket>().FirstOrDefaultAsync(x => x.Id == id && x.TenantId == this.Tid() && x.UserId == u, ct); if (t == null) return Page("پیدا نشد", "<p class=\"err\">این تیکت وجود ندارد.</p>", false, 404);
        var ms = await _db.Set<TicketMessage>().Where(x => x.TicketId == id && !x.IsInternal).OrderBy(x => x.CreatedOn).ToListAsync(ct);
        var sb = new StringBuilder($"<h1>{H.E(t.Subject)}</h1><p><small dir=\"ltr\">{H.E(t.Code)}</small> · {Sla.CatFa.GetValueOrDefault(t.Category, t.Category)} · {Sla.StFa[t.Status]}</p>");
        if (!string.IsNullOrEmpty(msg)) sb.Append($"<p class=\"ok\">{H.E(msg)}</p>");
        sb.Append(Msgs(ms, false));
        sb.Append($"<form method=\"post\" action=\"/nojs/me/tickets/{t.Id}/reply\" class=\"card\">__AF__<label for=\"b\">{(t.Status == "Closed" ? "پاسخ (تیکت دوباره باز می‌شود)" : "پاسخ شما")}</label><textarea id=\"b\" name=\"body\" rows=\"4\" maxlength=\"4000\" required></textarea><p><button>ارسال</button> <a class=\"btn btn2\" href=\"/nojs/me/tickets\">بازگشت</a></p></form>");
        return Page(t.Subject, sb.ToString(), false);
    }
    [HttpPost("me/tickets/{id:guid}/reply")]
    public async Task<IActionResult> MyReply(Guid id, [FromForm] string body, CancellationToken ct)
    {
        var u = await Me(); if (u == null) return Redirect("/nojs/login"); if (!await Csrf()) return BadRequest();
        var t = await _db.Set<SupportTicket>().FirstOrDefaultAsync(x => x.Id == id && x.TenantId == this.Tid() && x.UserId == u, ct); if (t == null) return NotFound();
        var e = await _s.CustomerReply(t, u.Value, body ?? "", ct); return Redirect($"/nojs/me/tickets/{id}?msg=" + Uri.EscapeDataString(e ?? "پیام ارسال شد"));
    }

    // ---------- کارشناس ----------
    [HttpGet("admin/tickets")]
    public async Task<IActionResult> AdminList(string? status, bool overdue, CancellationToken ct)
    {
        if (!await Staff(ct)) return Redirect("/nojs/admin/login");
        var now = DateTime.UtcNow; var q = _db.Set<SupportTicket>().Where(t => t.TenantId == this.Tid());
        q = status is "Open" or "Answered" or "Waiting" or "Closed" ? q.Where(t => t.Status == status) : q.Where(t => t.Status != "Closed");
        if (overdue) q = q.Where(t => t.FirstResponseOn == null && t.SlaDueOn < now);
        var l = await q.OrderByDescending(t => t.Priority == "High").ThenBy(t => t.SlaDueOn).Take(200).ToListAsync(ct);
        var sb = new StringBuilder("<h1>تیکت‌های پشتیبانی</h1><p><a href=\"/nojs/admin/tickets\">باز و در جریان</a> · <a href=\"/nojs/admin/tickets?overdue=true\">گذشته از مهلت پاسخ</a> · <a href=\"/nojs/admin/tickets?status=Closed\">بسته‌شده</a></p><div class=\"card\" style=\"overflow:auto\"><table><tr><th>کد</th><th>موضوع</th><th>دسته</th><th>وضعیت</th><th>مهلت پاسخ</th><th></th></tr>");
        foreach (var t in l) sb.Append($"<tr><td dir=\"ltr\">{H.E(t.Code)}</td><td>{H.E(t.Subject)}</td><td>{Sla.CatFa.GetValueOrDefault(t.Category, t.Category)}</td><td>{Sla.StFa[t.Status]}</td><td>{(Sla.Overdue(t, now) ? "<b style=\"color:#ff8a8a\">گذشته</b> " : "")}{Dt(t.SlaDueOn)}</td><td><a href=\"/nojs/admin/tickets/{t.Id}\">باز کردن</a></td></tr>");
        sb.Append("</table></div>"); if (l.Count == 0) sb.Append("<p>تیکتی در این فهرست نیست.</p>");
        return Page("تیکت‌ها", sb.ToString(), true);
    }
    [HttpGet("admin/tickets/{id:guid}")]
    public async Task<IActionResult> AdminOne(Guid id, string? msg, CancellationToken ct)
    {
        if (!await Staff(ct)) return Redirect("/nojs/admin/login");
        var t = await _db.Set<SupportTicket>().FirstOrDefaultAsync(x => x.Id == id && x.TenantId == this.Tid(), ct); if (t == null) return NotFound();
        var ms = await _db.Set<TicketMessage>().Where(x => x.TicketId == id).OrderBy(x => x.CreatedOn).ToListAsync(ct);
        var sb = new StringBuilder($"<h1>{H.E(t.Subject)}</h1><p><small dir=\"ltr\">{H.E(t.Code)}</small> · {Sla.CatFa.GetValueOrDefault(t.Category, t.Category)} · {Sla.StFa[t.Status]} · مشتری: <small dir=\"ltr\">{t.UserId}</small></p>");
        if (!string.IsNullOrEmpty(msg)) sb.Append($"<p class=\"ok\">{H.E(msg)}</p>");
        sb.Append(Msgs(ms, true));
        sb.Append($"<form method=\"post\" action=\"/nojs/admin/tickets/{t.Id}/reply\" class=\"card\">__AF__<label for=\"b\">پاسخ</label><textarea id=\"b\" name=\"body\" rows=\"5\" maxlength=\"4000\"></textarea><label style=\"display:flex;gap:8px;align-items:center\"><input type=\"checkbox\" name=\"internal\" value=\"1\" style=\"width:auto\"> یادداشت داخلی (مشتری نمی‌بیند)</label><label style=\"display:flex;gap:8px;align-items:center\"><input type=\"checkbox\" name=\"close\" value=\"1\" style=\"width:auto\"> بستن تیکت بعد از ارسال</label><p><button>ارسال</button> <a class=\"btn btn2\" href=\"/nojs/admin/tickets\">بازگشت</a></p></form>");
        return Page(t.Subject, sb.ToString(), true);
    }
    [HttpPost("admin/tickets/{id:guid}/reply")]
    public async Task<IActionResult> AdminReply(Guid id, [FromForm] string? body, [FromForm] string? close, CancellationToken ct)
    {
        if (!await Staff(ct)) return Redirect("/nojs/admin/login"); if (!await Csrf()) return BadRequest();
        var me = await Me(); var t = await _db.Set<SupportTicket>().FirstOrDefaultAsync(x => x.Id == id && x.TenantId == this.Tid(), ct); if (t == null) return NotFound();
        var isInternal = Request.Form["internal"] == "1";
        var e = await _s.StaffReply(t, me!.Value, body ?? "", isInternal, close == "1", ct);
        return Redirect($"/nojs/admin/tickets/{id}?msg=" + Uri.EscapeDataString(e ?? "ثبت شد"));
    }
}
