using System.Security.Claims;
using System.Text.Json;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Ghestine.API.Security;
using Ghestine.API.Iam;
namespace Ghestine.API.NoJs;

// ورود و ثبت‌نام بدون JS. منطق (کپچا، محدودیت تلاش، OTP، تیکت، ساخت کاربر) از همان SecurityController پروژه
// در همین پردازش صدا زده می‌شود تا قواعد و IP واقعی یکی بماند؛ هیچ منطق امنیتی دوم ساخته نشده است.
[Route("nojs")]
public class NoJsAuthController : Controller
{
    private readonly IAntiforgery _af; private readonly ICaptchaService _cap; private readonly TwoFaService _tf;
    public NoJsAuthController(IAntiforgery af, ICaptchaService cap, TwoFaService tf) { _af = af; _cap = cap; _tf = tf; }

    SecurityController Sec() { var c = ActivatorUtilities.CreateInstance<SecurityController>(HttpContext.RequestServices); c.ControllerContext = new ControllerContext(ControllerContext); return c; }
    static (int code, JsonElement j) R(IActionResult r) { var o = r as ObjectResult; var code = o?.StatusCode ?? (r is StatusCodeResult s ? s.StatusCode : 200); return (code, JsonSerializer.SerializeToElement(o?.Value ?? new { })); }
    static string Msg(JsonElement j, string dflt) => j.ValueKind == JsonValueKind.Object && j.TryGetProperty("message", out var m) && m.ValueKind == JsonValueKind.String ? m.GetString()! : dflt;
    static string? Tok(JsonElement j)
    {
        if (j.ValueKind != JsonValueKind.Object) return null;
        foreach (var n in new[] { "token", "accessToken", "access_token", "jwt" }) if (j.TryGetProperty(n, out var v) && v.ValueKind == JsonValueKind.String) return v.GetString();
        return j.TryGetProperty("data", out var d) ? Tok(d) : null;
    }
    string Af() { var t = _af.GetAndStoreTokens(HttpContext); return $"<input type=\"hidden\" name=\"{t.FormFieldName}\" value=\"{H.E(t.RequestToken)}\">"; }
    async Task<bool> Csrf() { try { await _af.ValidateRequestAsync(HttpContext); return true; } catch (AntiforgeryValidationException) { return false; } }
    ContentResult Page(string title, string body, int code = 200)
    {
        Response.StatusCode = code; Response.Headers["Cache-Control"] = "no-store";
        Response.Headers["Content-Security-Policy"] = "default-src 'none'; style-src 'unsafe-inline'; img-src 'self' data:; form-action 'self'; base-uri 'none'; frame-ancestors 'none'";
        return Content(H.Page(title, body).Replace("__AF__", Af()), "text/html; charset=utf-8");
    }
    string Cap()
    {
        var c = _cap.Create();   // SVG سمت سرور ساخته می‌شود (بدون اسکریپت)
        return $"<input type=\"hidden\" name=\"cid\" value=\"{H.E(c.Id)}\"><label for=\"ca\">کد امنیتی</label><div style=\"background:#fff;display:inline-block;border-radius:10px;padding:4px\">{c.Svg}</div><input id=\"ca\" name=\"ca\" autocomplete=\"off\" inputmode=\"numeric\" required>";
    }
    void SetCookie(string tok) => Response.Cookies.Append("dp_t", tok, new CookieOptions { HttpOnly = true, Secure = Request.IsHttps, SameSite = SameSiteMode.Strict, MaxAge = TimeSpan.FromHours(4), Path = "/nojs" });
    async Task<bool> IsAdminToken(string tok)
    {
        Request.Headers.Authorization = "Bearer " + tok;
        var r = await HttpContext.AuthenticateAsync("Bearer");
        return r.Succeeded && r.Principal != null && (r.Principal.IsInRole("Admin") || r.Principal.IsInRole("SuperAdmin"));
    }

    // ---------- ورود ----------
    string LoginBody(string? err, bool admin) => $"<h1>{(admin ? "ورود مدیر" : "ورود مشتری")}</h1>{(err == null ? "" : $"<p class=\"err\">{H.E(err)}</p>")}<form method=\"post\" action=\"{(admin ? "/nojs/admin/login" : "/nojs/login")}\" class=\"card\">__AF__<label for=\"u\">موبایل یا نام کاربری</label><input id=\"u\" name=\"u\" autocomplete=\"username\" required><label for=\"p\">رمز عبور</label><input id=\"p\" type=\"password\" name=\"p\" autocomplete=\"current-password\" required>{Cap()}<p><button>ورود</button></p></form>{(admin ? "" : "<p><a href=\"/nojs/register\">ثبت‌نام</a></p>")}";
    [HttpGet("login")] public IActionResult CLogin() => Page("ورود", LoginBody(null, false));
    [HttpGet("admin/login")] public IActionResult ALogin() => Page("ورود مدیر", LoginBody(null, true));
    [HttpPost("login")] public Task<IActionResult> CLoginPost([FromForm] string u, [FromForm] string p, [FromForm] string cid, [FromForm] string ca, CancellationToken ct) => DoLogin(u, p, cid, ca, false);
    [HttpPost("admin/login")] public Task<IActionResult> ALoginPost([FromForm] string u, [FromForm] string p, [FromForm] string cid, [FromForm] string ca, CancellationToken ct) => DoLogin(u, p, cid, ca, true);
    async Task<IActionResult> DoLogin(string u, string p, string cid, string ca, bool admin)
    {
        if (!await Csrf()) return Page("خطا", LoginBody("نشست منقضی شد؛ دوباره تلاش کنید.", admin), 400);
        var (code, j) = R(await Sec().Login(new LoginDto(u ?? "", p ?? "", cid ?? "", ca ?? ""), HttpContext.RequestAborted));
        if (code != 200) return Page("ورود", LoginBody(Msg(j, "ورود انجام نشد."), admin), code == 429 ? 429 : 401);
        var ticket = await _tf.Challenge(j.GetRawText(), this.Tid(), HttpContext.RequestAborted);
        if (ticket != null) return Page("تأیید دومرحله‌ای", TwoFaBody(ticket, admin, null));
        var tok = Tok(j); if (tok == null) return Page("ورود", LoginBody("پاسخ ورود توکن نداشت؛ خروجی --auth-doctor را بفرستید.", admin), 502);
        if (admin && !await IsAdminToken(tok)) return Page("ورود", LoginBody("این حساب دسترسی مدیر ندارد.", true), 403);
        SetCookie(tok); return Redirect(admin ? "/nojs/admin" : "/nojs/me");
    }

    // ---------- مرحله‌ی دوم ورود (TOTP یا کد بازیابی) ----------
    string TwoFaBody(string ticket, bool admin, string? err) => $"<h1>تأیید دومرحله‌ای</h1>{(err == null ? "" : $"<p class=\"err\">{H.E(err)}</p>")}<form method=\"post\" action=\"/nojs/login/2fa\" class=\"card\">__AF__<input type=\"hidden\" name=\"ticket\" value=\"{H.E(ticket)}\"><input type=\"hidden\" name=\"adm\" value=\"{(admin ? 1 : 0)}\"><label for=\"tc\">کد ۶ رقمی برنامه‌ی احراز هویت یا یک کد بازیابی</label><input id=\"tc\" name=\"code\" class=\"num\" dir=\"ltr\" inputmode=\"numeric\" autocomplete=\"one-time-code\" required><p><button>تأیید</button></p></form>";
    [HttpPost("login/2fa")]
    public async Task<IActionResult> Login2fa([FromForm] string ticket, [FromForm] string code, [FromForm] string? adm)
    {
        bool admin = adm == "1";
        if (!await Csrf()) return Page("خطا", LoginBody("نشست منقضی شد؛ دوباره وارد شوید.", admin), 400);
        var (body, err) = await _tf.Complete(ticket ?? "", code ?? "", HttpContext.RequestAborted);
        if (body == null) return Page("تأیید دومرحله‌ای", TwoFaBody(ticket ?? "", admin, err ?? "کد نادرست است."), 401);
        var tok = Tok(JsonSerializer.Deserialize<JsonElement>(body)); if (tok == null) return Redirect("/nojs/login");
        if (admin && !await IsAdminToken(tok)) return Page("ورود", LoginBody("این حساب دسترسی مدیر ندارد.", true), 403);
        SetCookie(tok); return Redirect(admin ? "/nojs/admin" : "/nojs/me");
    }

    // ---------- ثبت‌نام: ۳ مرحله (موبایل+کپچا → کد پیامکی → مشخصات) ----------
    string Step1(string? err, string phone = "") => $"<h1>ثبت‌نام</h1><p><small>مرحله ۱ از ۳: شماره موبایل</small></p>{(err == null ? "" : $"<p class=\"err\">{H.E(err)}</p>")}<form method=\"post\" action=\"/nojs/register\" class=\"card\">__AF__<label for=\"ph\">شماره موبایل</label><input id=\"ph\" name=\"phone\" value=\"{H.E(phone)}\" class=\"num\" dir=\"ltr\" inputmode=\"tel\" autocomplete=\"tel\" required>{Cap()}<p><button>ارسال کد</button></p></form>";
    [HttpGet("register")] public IActionResult Reg() => Page("ثبت‌نام", Step1(null));
    [HttpPost("register")]
    public async Task<IActionResult> RegPost([FromForm] string phone, [FromForm] string cid, [FromForm] string ca)
    {
        if (!await Csrf()) return Page("خطا", Step1("نشست منقضی شد."), 400);
        var (code, j) = R(await Sec().RequestOtp(new OtpRequestDto(phone ?? "", cid ?? "", ca ?? "", "register"), HttpContext.RequestAborted));
        if (code != 200) return Page("ثبت‌نام", Step1(Msg(j, "ارسال کد انجام نشد."), phone ?? ""), code);
        return Page("کد تأیید", Step2(phone!, null));
    }
    string Step2(string phone, string? err) => $"<h1>ثبت‌نام</h1><p><small>مرحله ۲ از ۳: کد پیامکی به {H.Fa(H.E(phone))} ارسال شد</small></p>{(err == null ? "" : $"<p class=\"err\">{H.E(err)}</p>")}<form method=\"post\" action=\"/nojs/register/verify\" class=\"card\">__AF__<input type=\"hidden\" name=\"phone\" value=\"{H.E(phone)}\"><label for=\"cd\">کد تأیید</label><input id=\"cd\" name=\"code\" class=\"num\" dir=\"ltr\" inputmode=\"numeric\" autocomplete=\"one-time-code\" required><p><button>تأیید</button></p></form>";
    [HttpPost("register/verify")]
    public async Task<IActionResult> Verify([FromForm] string phone, [FromForm] string code)
    {
        if (!await Csrf()) return Page("خطا", Step1("نشست منقضی شد."), 400);
        var (c, j) = R(await Sec().Verify(new OtpVerifyDto(phone ?? "", code ?? "", "register"), HttpContext.RequestAborted));
        if (c != 200 || !j.TryGetProperty("ticket", out var t)) return Page("کد تأیید", Step2(phone ?? "", Msg(j, "کد نادرست است.")), c == 200 ? 400 : c);
        return Page("مشخصات", Step3(t.GetString()!, null, "", "", ""));
    }
    string Step3(string ticket, string? err, string name, string nid, string mail) => $"<h1>ثبت‌نام</h1><p><small>مرحله ۳ از ۳: مشخصات (تأیید موبایل ۱۰ دقیقه اعتبار دارد)</small></p>{(err == null ? "" : $"<p class=\"err\">{H.E(err)}</p>")}<form method=\"post\" action=\"/nojs/register/finish\" class=\"card\">__AF__<input type=\"hidden\" name=\"ticket\" value=\"{H.E(ticket)}\"><label for=\"fn\">نام و نام خانوادگی</label><input id=\"fn\" name=\"name\" value=\"{H.E(name)}\" autocomplete=\"name\" required><label for=\"nc\">کد ملی</label><input id=\"nc\" name=\"nid\" value=\"{H.E(nid)}\" class=\"num\" dir=\"ltr\" inputmode=\"numeric\" maxlength=\"10\" required><label for=\"em\">ایمیل (اختیاری)</label><input id=\"em\" type=\"email\" name=\"mail\" value=\"{H.E(mail)}\" autocomplete=\"email\"><label for=\"pw\">رمز عبور (حداقل ۸ نویسه)</label><input id=\"pw\" type=\"password\" name=\"pw\" minlength=\"8\" autocomplete=\"new-password\" required>{Cap()}<p><button>ساخت حساب</button></p></form>";
    [HttpPost("register/finish")]
    public async Task<IActionResult> Finish([FromForm] string ticket, [FromForm] string name, [FromForm] string nid, [FromForm] string? mail, [FromForm] string pw, [FromForm] string cid, [FromForm] string ca)
    {
        if (!await Csrf()) return Page("خطا", Step1("نشست منقضی شد."), 400);
        var (c, j) = R(await Sec().Register(new RegisterDto(ticket ?? "", name ?? "", nid ?? "", pw ?? "", string.IsNullOrWhiteSpace(mail) ? null : mail, null, cid ?? "", ca ?? ""), HttpContext.RequestAborted));
        if (c != 200) return Page("مشخصات", Step3(ticket ?? "", Msg(j, "ثبت‌نام انجام نشد."), name ?? "", nid ?? "", mail ?? ""), c);
        var tok = Tok(j); if (tok == null) return Redirect("/nojs/login");
        SetCookie(tok); return Redirect("/nojs/me");
    }
}
