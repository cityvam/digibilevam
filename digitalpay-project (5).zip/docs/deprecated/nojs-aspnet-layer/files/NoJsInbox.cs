using System.Security.Claims;
using System.Text;
using Ghestine.Domain.Entities;
using Ghestine.API.Iam;
using Ghestine.API.Notify;
using Ghestine.API.Tenancy;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using __DBNS__;
namespace Ghestine.API.NoJs;

// اعلان‌های مشتری (/nojs/me/inbox) و داشبورد مدیر (/nojs/admin/dashboard) بدون JS
[Route("nojs")]
public class NoJsInboxController : Controller
{
    private readonly AppDbContext _db; private readonly IAntiforgery _af; private readonly DashboardService _d; private readonly PermissionService _ps;
    public NoJsInboxController(AppDbContext db, IAntiforgery af, DashboardService d, PermissionService ps) { _db = db; _af = af; _d = d; _ps = ps; }
    async Task<Guid?> Me()
    {
        var t = Request.Cookies["dp_t"]; if (string.IsNullOrEmpty(t)) return null; Request.Headers.Authorization = "Bearer " + t;
        var r = await HttpContext.AuthenticateAsync("Bearer"); if (!r.Succeeded || r.Principal == null) return null; HttpContext.User = r.Principal;
        return Guid.TryParse(r.Principal.FindFirstValue(ClaimTypes.NameIdentifier) ?? r.Principal.FindFirstValue("sub"), out var g) ? g : null;
    }
    async Task<bool> Csrf() { try { await _af.ValidateRequestAsync(HttpContext); return true; } catch (AntiforgeryValidationException) { return false; } }
    ContentResult Page(string title, string body, bool admin)
    {
        var t = _af.GetAndStoreTokens(HttpContext); var tok = $"<input type=\"hidden\" name=\"{t.FormFieldName}\" value=\"{H.E(t.RequestToken)}\">";
        Response.Headers["Cache-Control"] = "no-store"; Response.Headers["Content-Security-Policy"] = "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'";
        var html = H.Page(title, body, admin);
        if (!admin) html = html.Replace("<a href=\"/nojs/login\">ورود</a><a href=\"/nojs/register\">ثبت‌نام</a><a href=\"/nojs/admin\">ورود مدیر</a>", "<a href=\"/nojs/me\">قراردادهای من</a><a href=\"/nojs/me/inbox\">اعلان‌ها</a><a href=\"/nojs/me/tickets\">پشتیبانی</a><a href=\"/nojs/me/security\">امنیت حساب</a><form method=\"post\" action=\"/nojs/logout\" style=\"margin:0\">__AF__<button class=\"btn2\">خروج</button></form>");
        return Content(html.Replace("__AF__", tok), "text/html; charset=utf-8");
    }
    static readonly Dictionary<string, string> KindFa = new() { ["contract"] = "قرارداد", ["ticket"] = "پشتیبانی", ["loan"] = "وام", ["payment"] = "پرداخت", ["info"] = "اطلاعیه" };

    [HttpGet("me/inbox")]
    public async Task<IActionResult> Inbox(CancellationToken ct)
    {
        var u = await Me(); if (u == null) return Redirect("/nojs/login");
        var l = await _db.Set<CustomerNotification>().Where(n => n.TenantId == this.Tid() && n.UserId == u).OrderByDescending(n => n.CreatedOn).Take(100).ToListAsync(ct);
        var unread = l.Count(n => !n.IsRead);
        var sb = new StringBuilder($"<h1>اعلان‌ها</h1><p>{(unread > 0 ? $"{H.Fa(unread)} اعلان خوانده‌نشده" : "همه‌ی اعلان‌ها خوانده شده‌اند")}</p>");
        if (unread > 0) sb.Append("<form method=\"post\" action=\"/nojs/me/inbox/read-all\">__AF__<button class=\"btn2\">علامت‌گذاری همه به‌عنوان خوانده‌شده</button></form>");
        foreach (var n in l)
            sb.Append($"<form method=\"post\" action=\"/nojs/me/inbox/{n.Id}/open\" class=\"card\" style=\"{(n.IsRead ? "opacity:.75" : "border-color:#ffb629")}\">__AF__<small>{KindFa.GetValueOrDefault(n.Kind, "اطلاعیه")} · {H.Fa(n.CreatedOn.ToString("yyyy-MM-dd HH:mm"))} UTC</small><h3 style=\"margin:4px 0\">{(n.IsRead ? "" : "● ")}{H.E(n.Title)}</h3><p style=\"margin:0 0 8px\">{H.E(n.Body)}</p><button class=\"btn2\">{(string.IsNullOrEmpty(n.Link) ? "خواندم" : "مشاهده")}</button></form>");
        if (l.Count == 0) sb.Append("<p>اعلانی وجود ندارد.</p>");
        return Page("اعلان‌ها", sb.ToString(), false);
    }
    [HttpPost("me/inbox/{id:guid}/open")]
    public async Task<IActionResult> Open(Guid id, CancellationToken ct)
    {
        var u = await Me(); if (u == null) return Redirect("/nojs/login"); if (!await Csrf()) return BadRequest();
        var n = await _db.Set<CustomerNotification>().FirstOrDefaultAsync(x => x.Id == id && x.TenantId == this.Tid() && x.UserId == u, ct); if (n == null) return NotFound();
        if (!n.IsRead) { n.IsRead = true; await _db.SaveChangesAsync(ct); }
        var link = NotifyU.SafeLink(n.Link); return Redirect(link != "" && link.StartsWith("/nojs") ? link : "/nojs/me/inbox");
    }
    [HttpPost("me/inbox/read-all")]
    public async Task<IActionResult> ReadAll(CancellationToken ct)
    {
        var u = await Me(); if (u == null) return Redirect("/nojs/login"); if (!await Csrf()) return BadRequest();
        await _db.Set<CustomerNotification>().Where(n => n.TenantId == this.Tid() && n.UserId == u && !n.IsRead).ExecuteUpdateAsync(s => s.SetProperty(n => n.IsRead, true), ct); return Redirect("/nojs/me/inbox");
    }

    // ---------- داشبورد مدیر ----------
    [HttpGet("admin/dashboard")]
    public async Task<IActionResult> Dashboard(CancellationToken ct)
    {
        if (await Me() == null || !(User.IsInRole("Admin") || User.IsInRole("SuperAdmin"))) return Redirect("/nojs/admin/login");
        var tid = this.Tid(); var perms = new Dictionary<string, bool>();
        foreach (var k in new[] { "contracts.manage", "contracts.approve", "documents.review", "tickets.manage", "settings.manage" }) perms[k] = await _ps.HasAsync(User, tid, k, ct);
        var data = await _d.BuildAsync(tid, k => perms.GetValueOrDefault(k), ct);
        var sb = new StringBuilder("<h1>داشبورد</h1>");
        foreach (var (grp, items) in data)
        {
            sb.Append($"<h3>{H.E(grp)}</h3><div class=\"g\">");
            foreach (var k in items) sb.Append($"<div class=\"card\" style=\"{(k.Warn && k.Value > 0 ? "border-color:#ff8a8a" : "")}\"><b style=\"font-size:1.8em\">{H.Fa(k.Value.ToString("0.#", System.Globalization.CultureInfo.InvariantCulture))}</b>{(k.Unit == null ? "" : " <small>" + H.E(k.Unit) + "</small>")}<br>{H.E(k.Label)}{(k.Warn && k.Value > 0 ? " <small style=\"color:#ff8a8a\">نیازمند توجه</small>" : "")}</div>");
            sb.Append("</div>");
        }
        if (data.Count == 0) sb.Append("<p>برای نقش شما شاخصی تعریف نشده است.</p>");
        return Page("داشبورد", sb.ToString(), true);
    }
}
