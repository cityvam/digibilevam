using System.Security.Claims;
using System.Text;
using Ghestine.Domain.Entities;
using Ghestine.API.Notify;
using Ghestine.API.Tenancy;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using __DBNS__;
namespace Ghestine.API.NoJs;

// صندوق اعلان‌ها بدون JS: /nojs/me/notifications
[Route("nojs/me/notifications")]
public class NoJsNotifyController : Controller
{
    private readonly AppDbContext _db; private readonly IAntiforgery _af;
    public NoJsNotifyController(AppDbContext db, IAntiforgery af) { _db = db; _af = af; }
    async Task<Guid?> Me()
    {
        var t = Request.Cookies["dp_t"]; if (string.IsNullOrEmpty(t)) return null; Request.Headers.Authorization = "Bearer " + t;
        var r = await HttpContext.AuthenticateAsync("Bearer"); if (!r.Succeeded || r.Principal == null) return null; HttpContext.User = r.Principal;
        return Guid.TryParse(r.Principal.FindFirstValue(ClaimTypes.NameIdentifier) ?? r.Principal.FindFirstValue("sub"), out var g) ? g : null;
    }
    async Task<bool> Csrf() { try { await _af.ValidateRequestAsync(HttpContext); return true; } catch (AntiforgeryValidationException) { return false; } }
    static readonly Dictionary<string, string> K = new() { ["info"] = "اطلاعیه", ["ticket"] = "پشتیبانی", ["contract"] = "قرارداد", ["payment"] = "پرداخت", ["security"] = "امنیت" };

    [HttpGet("")]
    public async Task<IActionResult> Index(CancellationToken ct)
    {
        var u = await Me(); if (u == null) return Redirect("/nojs/login");
        var l = await _db.Set<UserNotification>().Where(n => n.TenantId == this.Tid() && n.UserId == u).OrderByDescending(n => n.CreatedOn).Take(100).ToListAsync(ct);
        var t = _af.GetAndStoreTokens(HttpContext); var tok = $"<input type=\"hidden\" name=\"{t.FormFieldName}\" value=\"{H.E(t.RequestToken)}\">";
        var unread = l.Count(n => !n.IsRead); var sb = new StringBuilder($"<h1>اعلان‌ها</h1><p>{(unread > 0 ? $"{H.Fa(unread)} اعلان خوانده‌نشده" : "همه‌ی اعلان‌ها خوانده شده")}</p>");
        if (unread > 0) sb.Append($"<form method=\"post\" action=\"/nojs/me/notifications/read-all\">{tok}<button class=\"btn2\">علامت‌گذاری همه به‌عنوان خوانده‌شده</button></form>");
        foreach (var n in l)
            sb.Append($"<form method=\"post\" action=\"/nojs/me/notifications/{n.Id}/open\" class=\"card\" style=\"{(n.IsRead ? "opacity:.7" : "border-color:#ffb629")}\">{tok}<small>{K.GetValueOrDefault(n.Kind, n.Kind)} · {H.Fa(n.CreatedOn.ToString("yyyy-MM-dd HH:mm"))} UTC</small><h3 style=\"margin:4px 0\">{(n.IsRead ? "" : "● ")}{H.E(n.Title)}</h3><p style=\"margin:0 0 8px\">{H.E(n.Body)}</p><button class=\"btn2\">{(string.IsNullOrEmpty(n.Link) ? "خواندم" : "باز کردن")}</button></form>");
        if (l.Count == 0) sb.Append("<p>اعلانی ندارید.</p>");
        var nav = "<a href=\"/nojs\">وام‌ها</a><a href=\"/nojs/me\">قراردادهای من</a><a href=\"/nojs/me/tickets\">پشتیبانی</a><a href=\"/nojs/me/notifications\">اعلان‌ها</a><a href=\"/nojs/me/security\">امنیت حساب</a><form method=\"post\" action=\"/nojs/logout\" style=\"margin:0\">" + tok + "<button class=\"btn2\">خروج</button></form>";
        Response.Headers["Cache-Control"] = "no-store"; Response.Headers["Content-Security-Policy"] = "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'";
        return Content(H.Page("اعلان‌ها", sb.ToString()).Replace("<a href=\"/nojs/login\">ورود</a><a href=\"/nojs/register\">ثبت‌نام</a><a href=\"/nojs/admin\">ورود مدیر</a>", nav), "text/html; charset=utf-8");
    }
    [HttpPost("{id:guid}/open")]
    public async Task<IActionResult> Open(Guid id, CancellationToken ct)
    {
        var u = await Me(); if (u == null) return Redirect("/nojs/login"); if (!await Csrf()) return BadRequest();
        var n = await _db.Set<UserNotification>().FirstOrDefaultAsync(x => x.Id == id && x.TenantId == this.Tid() && x.UserId == u, ct); if (n == null) return NotFound();
        if (!n.IsRead) { n.IsRead = true; n.ReadOn = DateTime.UtcNow; await _db.SaveChangesAsync(ct); }
        var link = Notifier.SafeLink(n.Link); return LocalRedirect(link == "" ? "/nojs/me/notifications" : link);
    }
    [HttpPost("read-all")]
    public async Task<IActionResult> ReadAll(CancellationToken ct)
    {
        var u = await Me(); if (u == null) return Redirect("/nojs/login"); if (!await Csrf()) return BadRequest(); var now = DateTime.UtcNow;
        foreach (var n in await _db.Set<UserNotification>().Where(x => x.TenantId == this.Tid() && x.UserId == u && !x.IsRead).Take(500).ToListAsync(ct)) { n.IsRead = true; n.ReadOn = now; }
        await _db.SaveChangesAsync(ct); return Redirect("/nojs/me/notifications");
    }
}
