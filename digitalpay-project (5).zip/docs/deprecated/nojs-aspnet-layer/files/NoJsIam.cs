using System.Security.Claims;
using System.Text;
using System.Text.Json;
using Ghestine.Domain.Entities;
using Ghestine.API.Iam;
using Ghestine.API.Tenancy;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using __DBNS__;
namespace Ghestine.API.NoJs;

// رمز دومرحله‌ای (/nojs/me/security) و مدیریت نقش‌ها (/nojs/admin/roles) بدون JS
[Route("nojs")]
public class NoJsIamController : Controller
{
    private readonly AppDbContext _db; private readonly IAntiforgery _af; private readonly TwoFaService _tf; private readonly PermissionService _ps;
    public NoJsIamController(AppDbContext db, IAntiforgery af, TwoFaService tf, PermissionService ps) { _db = db; _af = af; _tf = tf; _ps = ps; }
    string Af() { var t = _af.GetAndStoreTokens(HttpContext); return $"<input type=\"hidden\" name=\"{t.FormFieldName}\" value=\"{H.E(t.RequestToken)}\">"; }
    ContentResult Page(string title, string body, int code = 200, bool admin = false)
    {
        Response.StatusCode = code; Response.Headers["Cache-Control"] = "no-store";
        Response.Headers["Content-Security-Policy"] = "default-src 'none'; style-src 'unsafe-inline'; img-src 'self' data:; form-action 'self'; base-uri 'none'; frame-ancestors 'none'";
        var nav = "<a href=\"/nojs/me\">قراردادهای من</a><a href=\"/nojs/me/inbox\">اعلان‌ها</a><a href=\"/nojs/me/tickets\">پشتیبانی</a><a href=\"/nojs/me/notifications\">اعلان‌ها</a><a href=\"/nojs/me/security\">امنیت حساب</a>" + (admin ? "<a href=\"/nojs/admin\">مدیریت وام‌ها</a><a href=\"/nojs/admin/roles\">نقش‌ها</a>" : "") + "<form method=\"post\" action=\"/nojs/logout\" style=\"margin:0\">__AF__<button class=\"btn2\">خروج</button></form>";
        return Content(H.Page(title, body).Replace("<a href=\"/nojs/login\">ورود</a><a href=\"/nojs/register\">ثبت‌نام</a><a href=\"/nojs/admin\">ورود مدیر</a>", nav).Replace("__AF__", Af()), "text/html; charset=utf-8");
    }
    async Task<Guid?> Me()
    {
        var t = Request.Cookies["dp_t"]; if (string.IsNullOrEmpty(t)) return null;
        Request.Headers.Authorization = "Bearer " + t;
        var r = await HttpContext.AuthenticateAsync("Bearer"); if (!r.Succeeded || r.Principal == null) return null;
        HttpContext.User = r.Principal;
        return Guid.TryParse(r.Principal.FindFirstValue(ClaimTypes.NameIdentifier) ?? r.Principal.FindFirstValue("sub"), out var g) ? g : null;
    }
    bool IsAdm => User.IsInRole("Admin") || User.IsInRole("SuperAdmin");
    async Task<bool> Csrf() { try { await _af.ValidateRequestAsync(HttpContext); return true; } catch (AntiforgeryValidationException) { return false; } }

    // ---------- رمز دومرحله‌ای ----------
    [HttpGet("me/security")]
    public async Task<IActionResult> Security(string? msg, CancellationToken ct)
    {
        var u = await Me(); if (u == null) return Redirect("/nojs/login");
        var t = await _tf.Get(this.Tid(), u.Value, ct);
        var sb = new StringBuilder("<h1>امنیت حساب</h1>");
        if (!string.IsNullOrEmpty(msg)) sb.Append($"<p class=\"ok\">{H.E(msg)}</p>");
        if (t?.Enabled == true)
            sb.Append("<div class=\"card\"><h3>رمز دومرحله‌ای فعال است</h3><p>برای غیرفعال کردن، کد فعلی برنامه یا یک کد بازیابی را وارد کنید.</p><form method=\"post\" action=\"/nojs/me/security/disable\">__AF__<label for=\"c\">کد</label><input id=\"c\" name=\"code\" class=\"num\" dir=\"ltr\" inputmode=\"numeric\" autocomplete=\"one-time-code\" required><p><button class=\"btn2\">غیرفعال کردن</button></p></form></div>");
        else
            sb.Append("<div class=\"card\"><h3>رمز دومرحله‌ای غیرفعال است</h3><p>با یک برنامه‌ی احراز هویت (Google Authenticator، Microsoft Authenticator یا مشابه) ورود مدیران را امن‌تر کنید. توصیه‌ی جدی برای همه‌ی مدیران.</p><form method=\"post\" action=\"/nojs/me/security/setup\">__AF__<button>شروع راه‌اندازی</button></form></div>");
        return Page("امنیت حساب", sb.ToString(), 200, IsAdm);
    }
    [HttpPost("me/security/setup")]
    public async Task<IActionResult> Setup(CancellationToken ct)
    {
        var u = await Me(); if (u == null) return Redirect("/nojs/login"); if (!await Csrf()) return BadRequest();
        var (s, e) = await _tf.Setup(this.Tid(), u.Value, ct); if (s == null) return Redirect("/nojs/me/security?msg=" + Uri.EscapeDataString(e ?? "انجام نشد"));
        var acct = User.FindFirstValue(ClaimTypes.Name) ?? u.Value.ToString("N")[..8]; var grp = string.Join(" ", Enumerable.Range(0, s.Length / 4).Select(i => s.Substring(i * 4, 4)));
        return Page("راه‌اندازی", $"<h1>راه‌اندازی رمز دومرحله‌ای</h1><div class=\"card\"><p>۱) در برنامه‌ی احراز هویت گزینه‌ی «افزودن با کلید» را بزنید و این کلید را وارد کنید (نوع: بر پایه‌ی زمان):</p><p class=\"num\" dir=\"ltr\" style=\"font-size:1.3em;letter-spacing:2px\">{H.E(grp)}</p><p><small>این کلید فقط همین یک بار نشان داده می‌شود. برای افزودن خودکار، این نشانی را در برنامه باز کنید:</small></p><p class=\"num\" dir=\"ltr\" style=\"word-break:break-all\"><small>{H.E(Totp.Uri("DigitalPay", acct, s))}</small></p></div><form method=\"post\" action=\"/nojs/me/security/enable\" class=\"card\">__AF__<p>۲) کد ۶ رقمی که برنامه نشان می‌دهد را وارد کنید:</p><label for=\"c\">کد</label><input id=\"c\" name=\"code\" class=\"num\" dir=\"ltr\" inputmode=\"numeric\" autocomplete=\"one-time-code\" required><p><button>فعال‌سازی</button></p></form>", 200, IsAdm);
    }
    [HttpPost("me/security/enable")]
    public async Task<IActionResult> Enable([FromForm] string code, CancellationToken ct)
    {
        var u = await Me(); if (u == null) return Redirect("/nojs/login"); if (!await Csrf()) return BadRequest();
        var (r, e) = await _tf.Enable(this.Tid(), u.Value, code ?? "", ct);
        if (r == null) return Redirect("/nojs/me/security?msg=" + Uri.EscapeDataString((e ?? "انجام نشد") + " اگر لازم شد راه‌اندازی را دوباره شروع کنید."));
        return Page("کدهای بازیابی", $"<h1>رمز دومرحله‌ای فعال شد</h1><div class=\"card\"><p>این ۸ کد بازیابی را الان در جای امن ذخیره کنید. هرکدام یک بار مصرف است و دیگر نشان داده نمی‌شود. اگر گوشی را گم کردید با آن‌ها وارد می‌شوید.</p><p class=\"num\" dir=\"ltr\" style=\"font-size:1.15em;line-height:2.2\">{string.Join("<br>", r.Select(H.E))}</p></div><p><a class=\"btn\" href=\"/nojs/me/security\">ادامه</a></p>", 200, IsAdm);
    }
    [HttpPost("me/security/disable")]
    public async Task<IActionResult> Disable([FromForm] string code, CancellationToken ct)
    {
        var u = await Me(); if (u == null) return Redirect("/nojs/login"); if (!await Csrf()) return BadRequest();
        var e = await _tf.Disable(this.Tid(), u.Value, code ?? "", ct);
        return Redirect("/nojs/me/security?msg=" + Uri.EscapeDataString(e ?? "رمز دومرحله‌ای غیرفعال شد"));
    }

    // ---------- نقش‌ها (فقط با مجوز users.manage) ----------
    async Task<bool> CanManage(CancellationToken ct) => await Me() != null && IsAdm && await _ps.HasAsync(User, this.Tid(), "users.manage", ct);
    [HttpGet("admin/roles")]
    public async Task<IActionResult> Roles(string? msg, CancellationToken ct)
    {
        if (await Me() == null) return Redirect("/nojs/admin/login");
        if (!await CanManage(ct)) return Page("دسترسی ندارید", "<p class=\"err\">مدیریت نقش‌ها فقط با مجوز «مدیریت نقش‌ها و دسترسی‌ها» ممکن است.</p>", 403, IsAdm);
        var tid = this.Tid(); var roles = await _db.Set<AdminRole>().Where(r => r.TenantId == tid).OrderBy(r => r.Name).ToListAsync(ct);
        var cnt = await _db.Set<AdminRoleAssignment>().Where(a => a.TenantId == tid).GroupBy(a => a.RoleId).Select(g => new { g.Key, n = g.Count() }).ToListAsync(ct);
        var lab = Perms.All.ToDictionary(x => x.Key, x => x.Label);
        var sb = new StringBuilder("<h1>نقش‌ها و دسترسی‌ها</h1>");
        if (!string.IsNullOrEmpty(msg)) sb.Append($"<p class=\"ok\">{H.E(msg)}</p>");
        sb.Append("<div class=\"card\" style=\"overflow:auto\"><table><tr><th>نقش</th><th>مجوزها</th><th>کاربران</th></tr>");
        foreach (var r in roles)
        {
            string[] ps; try { ps = JsonSerializer.Deserialize<string[]>(r.PermissionsJson) ?? Array.Empty<string>(); } catch { ps = Array.Empty<string>(); }
            sb.Append($"<tr><td>{H.E(r.Name)}{(r.IsSystem ? " <small>(پیش‌فرض)</small>" : "")}</td><td>{string.Join(" ", ps.Select(k => $"<span style=\"display:inline-block;border:1px solid #4b3a69;border-radius:99px;padding:0 10px;margin:2px\">{H.E(lab.GetValueOrDefault(k, k))}</span>"))}</td><td>{H.Fa(cnt.FirstOrDefault(c => c.Key == r.Id)?.n ?? 0)}</td></tr>");
        }
        sb.Append("</table></div>");
        if (roles.Count == 0) sb.Append("<form method=\"post\" action=\"/nojs/admin/roles/seed\" class=\"card\">__AF__<p>نقشی تعریف نشده. نقش‌های پیش‌فرض (مالی، پشتیبانی، مدیر قرارداد، تأییدکننده‌ی قرارداد، حسابرس) ساخته شود؟</p><button>ساخت نقش‌های پیش‌فرض</button></form>");
        sb.Append("<form method=\"post\" action=\"/nojs/admin/roles/create\" class=\"card\">__AF__<h3>نقش جدید</h3><label for=\"rn\">نام نقش</label><input id=\"rn\" name=\"name\" minlength=\"2\" maxlength=\"80\" required><fieldset style=\"border:1px solid #3a2c52;border-radius:10px;margin-top:8px\"><legend>مجوزها</legend>");
        foreach (var (k, l) in Perms.All) sb.Append($"<label style=\"display:flex;gap:8px;align-items:center\"><input type=\"checkbox\" name=\"perm\" value=\"{k}\" style=\"width:auto\"> {H.E(l)}</label>");
        sb.Append("</fieldset><p><button>ساخت نقش</button></p></form>");
        sb.Append("<form method=\"post\" action=\"/nojs/admin/roles/assign\" class=\"card\">__AF__<h3>دادن نقش به کاربر</h3><label for=\"ui\">شناسه‌ی کاربر (GUID)</label><input id=\"ui\" name=\"userId\" class=\"num\" dir=\"ltr\" required pattern=\"[0-9a-fA-F-]{32,36}\"><label for=\"ri\">نقش</label><select id=\"ri\" name=\"roleId\" required>");
        foreach (var r in roles) sb.Append($"<option value=\"{r.Id}\">{H.E(r.Name)}</option>");
        sb.Append("</select><p><button>اختصاص</button></p></form>");
        return Page("نقش‌ها", sb.ToString(), 200, true);
    }
    [HttpPost("admin/roles/seed")]
    public async Task<IActionResult> Seed(CancellationToken ct)
    {
        if (!await CanManage(ct)) return Redirect("/nojs/admin/login"); if (!await Csrf()) return BadRequest();
        var tid = this.Tid(); var have = (await _db.Set<AdminRole>().Where(r => r.TenantId == tid).Select(r => r.Name).ToListAsync(ct)).ToHashSet(); int n = 0;
        foreach (var (name, perms) in Perms.Defaults) if (!have.Contains(name)) { _db.Add(new AdminRole { TenantId = tid, Name = name, IsSystem = true, PermissionsJson = JsonSerializer.Serialize(perms) }); n++; }
        await _db.SaveChangesAsync(ct); return Redirect("/nojs/admin/roles?msg=" + Uri.EscapeDataString($"{n} نقش ساخته شد"));
    }
    [HttpPost("admin/roles/create")]
    public async Task<IActionResult> Create([FromForm] string name, [FromForm] string[]? perm, CancellationToken ct)
    {
        if (!await CanManage(ct)) return Redirect("/nojs/admin/login"); if (!await Csrf()) return BadRequest();
        name = (name ?? "").Trim(); var ps = (perm ?? Array.Empty<string>()).Distinct().ToList(); var tid = this.Tid();
        string? err = name.Length < 2 || name.Length > 80 ? "نام نقش ۲ تا ۸۰ نویسه باشد." : ps.Any(k => !Perms.Keys.Contains(k)) ? "مجوز ناشناخته." : ps.Contains("users.manage") && !User.IsInRole("SuperAdmin") ? "فقط مدیر ارشد می‌تواند مجوز مدیریت دسترسی بدهد." : await _db.Set<AdminRole>().AnyAsync(r => r.TenantId == tid && r.Name == name, ct) ? "این نام قبلاً ثبت شده." : null;
        if (err != null) return Redirect("/nojs/admin/roles?msg=" + Uri.EscapeDataString(err));
        _db.Add(new AdminRole { TenantId = tid, Name = name, PermissionsJson = JsonSerializer.Serialize(ps) }); await _db.SaveChangesAsync(ct);
        return Redirect("/nojs/admin/roles?msg=" + Uri.EscapeDataString("نقش ساخته شد"));
    }
    [HttpPost("admin/roles/assign")]
    public async Task<IActionResult> Assign([FromForm] string userId, [FromForm] Guid roleId, CancellationToken ct)
    {
        if (!await CanManage(ct)) return Redirect("/nojs/admin/login"); if (!await Csrf()) return BadRequest();
        var me = await Me(); var tid = this.Tid(); var super = User.IsInRole("SuperAdmin");
        string? err = !Guid.TryParse(userId?.Trim(), out var uid) ? "شناسه‌ی کاربر معتبر نیست." : uid == me && !super ? "تخصیص نقش به خودتان مجاز نیست." : null;
        var r = err == null ? await _db.Set<AdminRole>().FirstOrDefaultAsync(x => x.Id == roleId && x.TenantId == tid, ct) : null;
        if (err == null && r == null) err = "نقش پیدا نشد.";
        if (err == null && r!.PermissionsJson.Contains("users.manage") && !super) err = "فقط مدیر ارشد.";
        if (err == null && await _db.Set<AdminRoleAssignment>().AnyAsync(a => a.TenantId == tid && a.UserId == uid && a.RoleId == roleId, ct)) err = "این نقش قبلاً داده شده.";
        if (err != null) return Redirect("/nojs/admin/roles?msg=" + Uri.EscapeDataString(err));
        _db.Add(new AdminRoleAssignment { TenantId = tid, UserId = uid, RoleId = roleId, AssignedBy = me }); await _db.SaveChangesAsync(ct);
        return Redirect("/nojs/admin/roles?msg=" + Uri.EscapeDataString("نقش اختصاص یافت"));
    }
}
