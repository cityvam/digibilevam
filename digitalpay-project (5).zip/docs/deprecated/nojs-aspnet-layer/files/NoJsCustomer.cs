using System.Net;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using Ghestine.Domain.Entities;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Ghestine.API.Tenancy;
using __DBNS__;
namespace Ghestine.API.NoJs;

// بخش مشتری بدون JS: ورود، فهرست قراردادهای من، مشاهده‌ی متن، قبول یا رد.
// قبول الکترونیکی ساده است (امضای دیجیتال حقوقی نیست). همان قواعد /api/v1/me/contracts.
[Route("nojs")]
public class NoJsCustomerController : Controller
{
    private readonly AppDbContext _db; private readonly IAntiforgery _af; private readonly IConfiguration _cfg; private readonly IHttpClientFactory _hf;
    public NoJsCustomerController(AppDbContext db, IAntiforgery af, IConfiguration cfg, IHttpClientFactory hf) { _db = db; _af = af; _cfg = cfg; _hf = hf; }
    static readonly string[] Visible = { "Presented", "AwaitingSignature", "Signed", "Rejected", "Expired" };
    static readonly Dictionary<string, string> Fa = new() { ["Presented"] = "ارائه‌شده", ["AwaitingSignature"] = "منتظر قبول شما", ["Signed"] = "قبول‌شده", ["Rejected"] = "ردشده", ["Expired"] = "منقضی" };

    string Af() { var t = _af.GetAndStoreTokens(HttpContext); return $"<input type=\"hidden\" name=\"{t.FormFieldName}\" value=\"{H.E(t.RequestToken)}\">"; }
    ContentResult Html(string title, string body, int code = 200, bool frame = false)
    {
        Response.StatusCode = code; Response.Headers["Cache-Control"] = "no-store";
        Response.Headers["Content-Security-Policy"] = "default-src 'none'; style-src 'unsafe-inline'; img-src 'self' data:; form-action 'self'; base-uri 'none'; frame-ancestors 'none'" + (frame ? "; frame-src 'self'" : "");
        var nav = "<a href=\"/nojs\">وام‌ها</a><a href=\"/nojs/me\">قراردادهای من</a><a href=\"/nojs/me/inbox\">اعلان‌ها</a><a href=\"/nojs/me/tickets\">پشتیبانی</a><a href=\"/nojs/me/notifications\">اعلان‌ها</a><a href=\"/nojs/me/security\">امنیت حساب</a><form method=\"post\" action=\"/nojs/logout\" style=\"margin:0\">__AF__<button class=\"btn2\">خروج</button></form>";
        return Content(H.Page(title, body).Replace("<a href=\"/nojs/login\">ورود</a><a href=\"/nojs/register\">ثبت‌نام</a><a href=\"/nojs/admin\">ورود مدیر</a>", nav).Replace("__AF__", Af()), "text/html; charset=utf-8");
    }
    async Task<Guid?> Me()
    {
        var t = Request.Cookies["dp_t"]; if (string.IsNullOrEmpty(t)) return null;
        Request.Headers.Authorization = "Bearer " + t;
        var r = await HttpContext.AuthenticateAsync("Bearer"); if (!r.Succeeded || r.Principal == null) return null;
        HttpContext.User = r.Principal;
        return Guid.TryParse(r.Principal.FindFirstValue(ClaimTypes.NameIdentifier) ?? r.Principal.FindFirstValue("sub"), out var g) ? g : null;
    }
    async Task<bool> Csrf() { try { await _af.ValidateRequestAsync(HttpContext); return true; } catch (AntiforgeryValidationException) { return false; } }
    [HttpGet("me")]
    public async Task<IActionResult> MyContracts(string? msg, CancellationToken ct)
    {
        var u = await Me(); if (u == null) return Redirect("/nojs/login");
        var now = DateTime.UtcNow; var tid = this.Tid();
        foreach (var x in await _db.Set<GeneratedContract>().Where(x => x.TenantId == tid && x.UserId == u && (x.Status == "Presented" || x.Status == "AwaitingSignature") && x.ExpiresAt < now).ToListAsync(ct)) x.Status = "Expired";
        await _db.SaveChangesAsync(ct);
        var l = await _db.Set<GeneratedContract>().Where(x => x.TenantId == tid && x.UserId == u && Visible.Contains(x.Status)).OrderByDescending(x => x.CreatedOn).Select(x => new { x.Id, x.Number, x.Title, x.Status, x.CreatedOn }).ToListAsync(ct);
        var sb = new StringBuilder("<h1>قراردادهای من</h1>");
        if (!string.IsNullOrEmpty(msg)) sb.Append($"<p class=\"ok\">{H.E(msg)}</p>");
        sb.Append("<div class=\"card\" style=\"overflow:auto\"><table><tr><th>شماره</th><th>عنوان</th><th>وضعیت</th><th></th></tr>");
        foreach (var c in l) sb.Append($"<tr><td>{H.Fa(c.Number)}</td><td>{H.E(c.Title)}</td><td>{H.E(Fa.GetValueOrDefault(c.Status, c.Status))}</td><td><a href=\"/nojs/me/contracts/{c.Id}\">مشاهده</a></td></tr>");
        sb.Append("</table></div>"); if (l.Count == 0) sb.Append("<p>قراردادی برای شما ارائه نشده است.</p>");
        return Html("قراردادهای من", sb.ToString());
    }
    async Task<GeneratedContract?> Own(Guid id, Guid u, CancellationToken ct) => await _db.Set<GeneratedContract>().FirstOrDefaultAsync(x => x.Id == id && x.TenantId == this.Tid() && x.UserId == u && Visible.Contains(x.Status), ct);
    static string Sha(string s) => Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(Encoding.UTF8.GetBytes(s))).ToLowerInvariant();

    [HttpGet("me/contracts/{id:guid}")]
    public async Task<IActionResult> View(Guid id, string? err, CancellationToken ct)
    {
        var u = await Me(); if (u == null) return Redirect("/nojs/login");
        var c = await Own(id, u.Value, ct); if (c == null) return Html("پیدا نشد", "<p class=\"err\">این قرارداد وجود ندارد.</p>", 404);
        var open = c.Status is "Presented" or "AwaitingSignature";
        var sb = new StringBuilder($"<h1>{H.E(c.Title)}</h1><p>شماره: {H.Fa(c.Number)} · وضعیت: {H.E(Fa.GetValueOrDefault(c.Status, c.Status))}</p>");
        if (!string.IsNullOrEmpty(err)) sb.Append($"<p class=\"err\">{H.E(err)}</p>");
        sb.Append($"<iframe src=\"/nojs/me/contracts/{c.Id}/html\" title=\"متن قرارداد\" style=\"width:100%;height:70vh;border:1px solid #3a2c52;border-radius:14px;background:#fff\" sandbox></iframe>");
        if (open)
        {
            sb.Append($"<form method=\"post\" action=\"/nojs/me/contracts/{c.Id}/sign\" class=\"card\">__AF__<label><input type=\"checkbox\" name=\"agree\" value=\"1\" required style=\"width:auto\"> متن قرارداد را خوانده‌ام و با آن موافقم.</label><p><small>این قبول الکترونیکی ساده است؛ زمان، حساب و IP شما ثبت می‌شود.</small></p><button>قبول و ثبت</button></form>");
            sb.Append($"<form method=\"post\" action=\"/nojs/me/contracts/{c.Id}/reject\" class=\"card\">__AF__<label for=\"n\">دلیل رد (اختیاری)</label><input id=\"n\" name=\"note\" maxlength=\"300\"><p><button class=\"btn2\">رد قرارداد</button></p></form>");
        }
        sb.Append("<p><a class=\"btn btn2\" href=\"/nojs/me\">بازگشت</a></p>");
        return Html(c.Title, sb.ToString(), 200, true);
    }
    [HttpGet("me/contracts/{id:guid}/html")]
    public async Task<IActionResult> Body(Guid id, CancellationToken ct)
    {
        var u = await Me(); if (u == null) return Unauthorized();
        var c = await Own(id, u.Value, ct); if (c == null) return NotFound();
        if (Sha(c.Html) != c.BodyHash) return StatusCode(500, "یکپارچگی متن قرارداد تأیید نشد");
        _db.Add(new ContractEvent { TenantId = c.TenantId, ContractId = c.Id, ActorId = u, Action = "ViewedByCustomer", Ip = HttpContext.Connection.RemoteIpAddress?.ToString() ?? "" }); await _db.SaveChangesAsync(ct);
        Response.Headers["Content-Security-Policy"] = "default-src 'none'; style-src 'unsafe-inline'; img-src data:; sandbox; frame-ancestors 'self'"; Response.Headers["Cache-Control"] = "no-store"; Response.Headers["X-Content-Type-Options"] = "nosniff";
        return Content(c.Html, "text/html; charset=utf-8");
    }
    [HttpPost("me/contracts/{id:guid}/sign")]
    public async Task<IActionResult> Sign(Guid id, [FromForm] string? agree, CancellationToken ct)
    {
        var u = await Me(); if (u == null) return Redirect("/nojs/login"); if (!await Csrf()) return BadRequest();
        var c = await Own(id, u.Value, ct); if (c == null) return NotFound();
        if (agree != "1") return Redirect($"/nojs/me/contracts/{id}?err=" + Uri.EscapeDataString("برای ثبت، تیک موافقت را بزنید."));
        if (c.Status is not ("Presented" or "AwaitingSignature")) return Redirect($"/nojs/me/contracts/{id}?err=" + Uri.EscapeDataString("این قرارداد قابل امضا نیست."));
        var ip = HttpContext.Connection.RemoteIpAddress?.ToString() ?? "";
        c.Status = "Signed"; c.SignedAt = DateTime.UtcNow; c.SignedIp = ip; var ua = Request.Headers.UserAgent.ToString(); c.SignedUa = ua.Length <= 200 ? ua : ua[..200]; c.SignatureMethod = "SimpleAccept";
        _db.Add(new ContractEvent { TenantId = c.TenantId, ContractId = c.Id, ActorId = u, Action = "Signed", Ip = ip }); await _db.SaveChangesAsync(ct);
        return Redirect("/nojs/me?msg=" + Uri.EscapeDataString("قرارداد ثبت شد"));
    }
    [HttpPost("me/contracts/{id:guid}/reject")]
    public async Task<IActionResult> Reject(Guid id, [FromForm] string? note, CancellationToken ct)
    {
        var u = await Me(); if (u == null) return Redirect("/nojs/login"); if (!await Csrf()) return BadRequest();
        var c = await Own(id, u.Value, ct); if (c == null) return NotFound();
        if (c.Status is not ("Presented" or "AwaitingSignature")) return Redirect($"/nojs/me/contracts/{id}?err=" + Uri.EscapeDataString("این قرارداد قابل رد نیست."));
        note = (note ?? "").Trim(); if (note.Length > 300) note = note[..300];
        c.Status = "Rejected"; _db.Add(new ContractEvent { TenantId = c.TenantId, ContractId = c.Id, ActorId = u, Action = "Rejected", Note = note, Ip = HttpContext.Connection.RemoteIpAddress?.ToString() ?? "" }); await _db.SaveChangesAsync(ct);
        return Redirect("/nojs/me?msg=" + Uri.EscapeDataString("قرارداد رد شد"));
    }
}
