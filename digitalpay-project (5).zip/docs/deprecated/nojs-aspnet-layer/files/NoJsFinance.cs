using System.Security.Claims;
using System.Text;
using System.Text.Json;
using Ghestine.Domain.Entities;
using Ghestine.API.Enterprise;
using Ghestine.API.Iam;
using Ghestine.API.Tenancy;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using __DBNS__;
namespace Ghestine.API.NoJs;

// دفتر کل (/nojs/admin/ledger) و حسابرسی (/nojs/admin/audit) بدون JS.
// ثبت سند و حساب از همان LedgerController پروژه صدا زده می‌شود (همان اعتبارسنجی دوطرفه، همان شماره‌گذاری).
[Route("nojs/admin")]
public class NoJsFinanceController : Controller
{
    private readonly AppDbContext _db; private readonly IAntiforgery _af; private readonly PermissionService _ps;
    public NoJsFinanceController(AppDbContext db, IAntiforgery af, PermissionService ps) { _db = db; _af = af; _ps = ps; }
    async Task<bool> Can(string perm, CancellationToken ct)
    {
        var t = Request.Cookies["dp_t"]; if (string.IsNullOrEmpty(t)) return false; Request.Headers.Authorization = "Bearer " + t;
        var r = await HttpContext.AuthenticateAsync("Bearer"); if (!r.Succeeded || r.Principal == null) return false; HttpContext.User = r.Principal;
        return await _ps.HasAsync(r.Principal, this.Tid(), perm, ct);
    }
    async Task<bool> Csrf() { try { await _af.ValidateRequestAsync(HttpContext); return true; } catch (AntiforgeryValidationException) { return false; } }
    ContentResult Page(string title, string body, int code = 200)
    {
        var t = _af.GetAndStoreTokens(HttpContext); var tok = $"<input type=\"hidden\" name=\"{t.FormFieldName}\" value=\"{H.E(t.RequestToken)}\">";
        Response.StatusCode = code; Response.Headers["Cache-Control"] = "no-store"; Response.Headers["Content-Security-Policy"] = "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'";
        return Content(H.Page(title, body, true).Replace("__AF__", tok), "text/html; charset=utf-8");
    }
    LedgerController Led() { var c = ActivatorUtilities.CreateInstance<LedgerController>(HttpContext.RequestServices); c.ControllerContext = new ControllerContext(ControllerContext); return c; }
    static string Msg(IActionResult r, string ok)
    {
        if (r is ObjectResult o && (o.StatusCode ?? 200) >= 400) { try { var j = JsonSerializer.SerializeToElement(o.Value); if (j.TryGetProperty("message", out var m)) return m.GetString() ?? "ناموفق"; } catch { } return "ناموفق"; }
        return ok;
    }
    static readonly Dictionary<string, string> TypeFa = new() { ["Asset"] = "دارایی", ["Liability"] = "بدهی", ["Equity"] = "حقوق صاحبان سهام", ["Income"] = "درآمد", ["Expense"] = "هزینه" };

    // ---------- دفتر کل ----------
    [HttpGet("ledger")]
    public async Task<IActionResult> Ledger(string? msg, CancellationToken ct)
    {
        if (!await Can("ledger.view", ct)) return Redirect("/nojs/admin/login");
        var tid = this.Tid(); var canPost = await _ps.HasAsync(User, tid, "ledger.post", ct);
        var accs = await _db.Set<LedgerAccount>().Where(a => a.TenantId == tid).OrderBy(a => a.Code).ToListAsync(ct);
        var sums = await _db.Set<JournalLine>().Where(l => l.TenantId == tid).GroupBy(l => l.AccountId).Select(g => new { g.Key, d = g.Sum(x => x.Debit), c = g.Sum(x => x.Credit) }).ToListAsync(ct);
        var ents = await _db.Set<JournalEntry>().Where(e => e.TenantId == tid).OrderByDescending(e => e.Number).Take(30).ToListAsync(ct);
        var sb = new StringBuilder("<h1>دفتر کل</h1>");
        if (!string.IsNullOrEmpty(msg)) sb.Append($"<p class=\"{(msg.StartsWith("✓") ? "ok" : "err")}\">{H.E(msg)}</p>");
        decimal td = 0, tc = 0;
        sb.Append("<h3>تراز آزمایشی</h3><div class=\"card\" style=\"overflow:auto\"><table><tr><th>کد</th><th>حساب</th><th>نوع</th><th>بدهکار</th><th>بستانکار</th></tr>");
        foreach (var a in accs) { var s = sums.FirstOrDefault(x => x.Key == a.Id); var d = s?.d ?? 0; var c = s?.c ?? 0; td += d; tc += c; sb.Append($"<tr><td dir=\"ltr\">{H.E(a.Code)}</td><td>{H.E(a.Name)}{(a.IsActive ? "" : " <small>(غیرفعال)</small>")}</td><td>{TypeFa.GetValueOrDefault(a.Type, a.Type)}</td><td class=\"num\">{H.Money(d)}</td><td class=\"num\">{H.Money(c)}</td></tr>"); }
        sb.Append($"<tr><th colspan=\"3\">جمع</th><th class=\"num\">{H.Money(td)}</th><th class=\"num\">{H.Money(tc)}</th></tr></table>{(td == tc ? "<p class=\"ok\">تراز متعادل است.</p>" : "<p class=\"err\">تراز متعادل نیست؛ فوراً بررسی شود.</p>")}</div>");
        if (accs.Count == 0) sb.Append("<p>حسابی تعریف نشده است.</p>");
        sb.Append("<h3>آخرین اسناد</h3><div class=\"card\" style=\"overflow:auto\"><table><tr><th>شماره</th><th>شرح</th><th>مرجع</th><th>مبلغ</th><th></th></tr>");
        var lines = await _db.Set<JournalLine>().Where(l => ents.Select(e => e.Id).Contains(l.EntryId)).ToListAsync(ct);
        foreach (var e in ents) sb.Append($"<tr><td>{H.Fa(e.Number)}</td><td>{H.E(e.Memo)}{(e.ReversalOf != null ? " <small>(معکوس)</small>" : "")}</td><td dir=\"ltr\">{H.E(e.Reference)}</td><td class=\"num\">{H.Money(lines.Where(l => l.EntryId == e.Id).Sum(l => l.Debit))}</td><td>{(canPost && e.ReversalOf == null ? $"<form method=\"post\" action=\"/nojs/admin/ledger/{e.Id}/reverse\" style=\"margin:0\">__AF__<button class=\"btn2\">صدور سند معکوس</button></form>" : "")}</td></tr>");
        sb.Append("</table></div>");
        if (canPost)
        {
            sb.Append("<form method=\"post\" action=\"/nojs/admin/ledger/account\" class=\"card\">__AF__<h3>حساب جدید</h3><label for=\"ac\">کد</label><input id=\"ac\" name=\"code\" maxlength=\"20\" dir=\"ltr\" required><label for=\"an\">نام</label><input id=\"an\" name=\"name\" maxlength=\"120\" required><label for=\"at\">نوع</label><select id=\"at\" name=\"type\">");
            foreach (var (k, v) in TypeFa) sb.Append($"<option value=\"{k}\">{v}</option>"); sb.Append("</select><p><button>افزودن حساب</button></p></form>");
            var opts = string.Concat(accs.Where(a => a.IsActive).Select(a => $"<option value=\"{a.Id}\">{H.E(a.Code)} · {H.E(a.Name)}</option>"));
            sb.Append("<form method=\"post\" action=\"/nojs/admin/ledger/entry\" class=\"card\">__AF__<h3>سند جدید</h3><p><small>هر سطر فقط بدهکار یا فقط بستانکار دارد. جمع دو طرف باید برابر باشد. سند ثبت‌شده ویرایش نمی‌شود؛ فقط با سند معکوس اصلاح می‌شود.</small></p><label for=\"m\">شرح</label><input id=\"m\" name=\"memo\" maxlength=\"300\" required><label for=\"rf\">مرجع (اختیاری)</label><input id=\"rf\" name=\"reference\" maxlength=\"60\" dir=\"ltr\"><div class=\"scroll\" style=\"overflow:auto\"><table><tr><th>حساب</th><th>بدهکار</th><th>بستانکار</th></tr>");
            for (int i = 0; i < 6; i++) sb.Append($"<tr><td><select name=\"acc\" aria-label=\"حساب سطر {i + 1}\"><option value=\"\">—</option>{opts}</select></td><td><input name=\"dr\" class=\"num\" dir=\"ltr\" inputmode=\"decimal\" aria-label=\"بدهکار سطر {i + 1}\"></td><td><input name=\"cr\" class=\"num\" dir=\"ltr\" inputmode=\"decimal\" aria-label=\"بستانکار سطر {i + 1}\"></td></tr>");
            sb.Append("</table></div><p><button>ثبت سند</button></p></form>");
        }
        return Page("دفتر کل", sb.ToString());
    }
    [HttpPost("ledger/account")]
    public async Task<IActionResult> AddAccount([FromForm] string code, [FromForm] string name, [FromForm] string type, CancellationToken ct)
    {
        if (!await Can("ledger.post", ct)) return Redirect("/nojs/admin/login"); if (!await Csrf()) return BadRequest();
        var m = Msg(await Led().AddAccount(new AccountIn(code ?? "", name ?? "", type ?? ""), ct), "✓ حساب افزوده شد"); return Redirect("/nojs/admin/ledger?msg=" + Uri.EscapeDataString(m));
    }
    [HttpPost("ledger/entry")]
    public async Task<IActionResult> Post([FromForm] string memo, [FromForm] string? reference, [FromForm] string[] acc, [FromForm] string[] dr, [FromForm] string[] cr, CancellationToken ct)
    {
        if (!await Can("ledger.post", ct)) return Redirect("/nojs/admin/login"); if (!await Csrf()) return BadRequest();
        var ls = new List<LineIn>();
        for (int i = 0; i < acc.Length; i++)
        {
            if (!Guid.TryParse(acc[i], out var aid)) { if (i < dr.Length && H.Num(dr[i]) != 0 || i < cr.Length && H.Num(cr[i]) != 0) return Redirect("/nojs/admin/ledger?msg=" + Uri.EscapeDataString("برای سطر دارای مبلغ، حساب را انتخاب کنید")); continue; }
            ls.Add(new LineIn(aid, i < dr.Length ? H.Num(dr[i]) : 0, i < cr.Length ? H.Num(cr[i]) : 0));
        }
        var r = await Led().Post(new EntryIn(memo ?? "", reference, ls), ct);
        string m = Msg(r, "✓"); if (m == "✓" && r is OkObjectResult ok) { var j = JsonSerializer.SerializeToElement(ok.Value); m = "✓ سند شماره " + H.Fa(j.GetProperty("Number").GetInt64()) + " ثبت شد"; }
        return Redirect("/nojs/admin/ledger?msg=" + Uri.EscapeDataString(m));
    }
    [HttpPost("ledger/{id:guid}/reverse")]
    public async Task<IActionResult> Reverse(Guid id, CancellationToken ct)
    {
        if (!await Can("ledger.post", ct)) return Redirect("/nojs/admin/login"); if (!await Csrf()) return BadRequest();
        return Redirect("/nojs/admin/ledger?msg=" + Uri.EscapeDataString(Msg(await Led().Reverse(id, ct), "✓ سند معکوس صادر شد")));
    }

    // ---------- حسابرسی ----------
    [HttpGet("audit")]
    public async Task<IActionResult> Audit(string? q, string? verify, CancellationToken ct)
    {
        if (!await Can("audit.view", ct)) return Redirect("/nojs/admin/login");
        var tid = this.Tid(); var qq = _db.Set<AuditEntry>().Where(a => a.TenantId == tid); q = (q ?? "").Trim();
        if (q.Length > 0) qq = qq.Where(a => a.Path.Contains(q) || a.UserName.Contains(q) || a.Ip.Contains(q));
        var l = await qq.OrderByDescending(a => a.Seq).Take(200).ToListAsync(ct);
        var sb = new StringBuilder("<h1>گزارش حسابرسی</h1><p><small>هر رکورد هش رکورد قبلی را دارد؛ تغییر یا حذف رکورد قدیمی با «بررسی زنجیره» آشکار می‌شود.</small></p>");
        if (verify == "ok") sb.Append("<p class=\"ok\">زنجیره سالم است.</p>"); else if (verify != null && verify.StartsWith("broken")) sb.Append($"<p class=\"err\">زنجیره در رکورد {H.Fa(verify[6..])} شکسته است. فوراً بررسی شود.</p>");
        sb.Append($"<form method=\"get\" class=\"card\"><label for=\"q\">جست‌وجو (مسیر، کاربر یا IP)</label><input id=\"q\" name=\"q\" value=\"{H.E(q)}\"><p><button>جست‌وجو</button></p></form>");
        if (User.IsInRole("SuperAdmin")) sb.Append("<form method=\"post\" action=\"/nojs/admin/audit/verify\" class=\"card\">__AF__<p>بررسی کامل زنجیره ممکن است برای حجم زیاد چند ثانیه طول بکشد.</p><button class=\"btn2\">بررسی زنجیره</button></form>");
        sb.Append("<div class=\"card\" style=\"overflow:auto\"><table><tr><th>#</th><th>زمان (UTC)</th><th>کاربر</th><th>روش</th><th>مسیر</th><th>کد</th><th>IP</th></tr>");
        foreach (var a in l) sb.Append($"<tr><td>{H.Fa(a.Seq)}</td><td>{H.Fa(a.At.ToString("yyyy-MM-dd HH:mm:ss"))}</td><td>{H.E(a.UserName)}</td><td dir=\"ltr\">{H.E(a.Method)}</td><td dir=\"ltr\"><small>{H.E(a.Path)}</small></td><td>{H.Fa(a.StatusCode)}</td><td dir=\"ltr\">{H.E(a.Ip)}</td></tr>");
        sb.Append("</table></div>"); if (l.Count == 0) sb.Append("<p>رکوردی پیدا نشد.</p>");
        return Page("حسابرسی", sb.ToString());
    }
    [HttpPost("audit/verify")]
    public async Task<IActionResult> VerifyChain(CancellationToken ct)
    {
        if (!await Can("audit.view", ct) || !User.IsInRole("SuperAdmin")) return Redirect("/nojs/admin/login"); if (!await Csrf()) return BadRequest();
        var tid = this.Tid(); string prev = new string('0', 64); long expect = 1;
        await foreach (var a in _db.Set<AuditEntry>().Where(x => x.TenantId == tid).OrderBy(x => x.Seq).AsAsyncEnumerable().WithCancellation(ct))
        {
            if (a.Seq != expect || a.PrevHash != prev || a.Hash != AuditFilter.Compute(prev, a)) return Redirect("/nojs/admin/audit?verify=broken" + a.Seq);
            prev = a.Hash; expect++;
        }
        return Redirect("/nojs/admin/audit?verify=ok");
    }
}
