using System.Net;
using System.Text;
using System.Text.Json;
using Ghestine.Domain.Entities;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Ghestine.API.Tenancy;
using Ghestine.API.Core;
using __DBNS__;
namespace Ghestine.API.NoJs;

// صفحات بدون جاوااسکریپت (Server-rendered). مسیر: /nojs
// احراز هویت: JWT در کوکی HttpOnly (dp_t) و اعتبارسنجی با همان JwtBearer پروژه. CSRF: Antiforgery.
public static class H
{
    public static string E(string? s) => WebUtility.HtmlEncode(s ?? "");
    public static string Fa(object? v) => new string((v?.ToString() ?? "").Select(c => c >= '0' && c <= '9' ? (char)('۰' + (c - '0')) : c).ToArray());
    public static string Money(decimal v) => Fa(v.ToString("#,0.########", System.Globalization.CultureInfo.InvariantCulture));
    public static decimal Num(string? s)
    {
        if (string.IsNullOrWhiteSpace(s)) return 0;
        var b = new StringBuilder();
        foreach (var c in s) { if (c >= '۰' && c <= '۹') b.Append((char)('0' + (c - '۰'))); else if (c >= '٠' && c <= '٩') b.Append((char)('0' + (c - '٠'))); else if (c == '٫') b.Append('.'); else if (c == ',' || c == '٬' || c == ' ') { } else b.Append(c); }
        return decimal.TryParse(b.ToString(), System.Globalization.NumberStyles.Number, System.Globalization.CultureInfo.InvariantCulture, out var d) ? d : 0;
    }
    public const string Css = "*{box-sizing:border-box}body{margin:0;font-family:Vazirmatn,Tahoma,sans-serif;background:#130c1f;color:#f3edfb;line-height:1.9}a{color:#ffb629}main{max-width:960px;margin:0 auto;padding:16px}header{background:#1d1330;border-bottom:1px solid #3a2c52;padding:10px 16px;display:flex;gap:16px;flex-wrap:wrap;align-items:center}.card{background:#1d1330;border:1px solid #3a2c52;border-radius:14px;padding:14px;margin:10px 0}.g{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:12px}input,select,textarea{width:100%;font:inherit;padding:9px;border-radius:10px;border:1px solid #4b3a69;background:#0f0919;color:#fff}label{display:block;margin:8px 0 2px;font-size:.9em;color:#cdbfe6}button,.btn{font:inherit;display:inline-block;padding:9px 18px;border:0;border-radius:10px;background:#ffb629;color:#1b1024;cursor:pointer;text-decoration:none}.btn2{background:#3a2c52;color:#fff}table{width:100%;border-collapse:collapse}th,td{padding:8px;border-bottom:1px solid #3a2c52;text-align:right}.err{background:#4a1522;padding:10px;border-radius:10px}.ok{background:#12391f;padding:10px;border-radius:10px}.tabs>input{position:absolute;opacity:0}.tabs>label{display:inline-block;padding:8px 16px;margin:0 0 -1px;border:1px solid #3a2c52;border-radius:10px 10px 0 0;cursor:pointer}.tabs>.p{display:none;border:1px solid #3a2c52;padding:12px;border-radius:0 10px 10px 10px}#t1:checked~.p1,#t2:checked~.p2,#t3:checked~.p3{display:block}#t1:checked~.l1,#t2:checked~.l2,#t3:checked~.l3{background:#3a2c52}.num{direction:ltr;text-align:left}small{color:#a89cc0}";
    public static string Page(string title, string body, bool admin = false) =>
        $"<!doctype html><html lang=\"fa\" dir=\"rtl\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>{E(title)} | دیجی‌بایل پی</title><style>{Css}</style></head><body><header><b>دیجی‌بایل پی</b><a href=\"/nojs\">وام‌ها</a>{(admin ? "<a href=\"/nojs/admin/dashboard\">داشبورد</a><a href=\"/nojs/admin\">مدیریت وام‌ها</a><a href=\"/nojs/admin/roles\">نقش‌ها</a><a href=\"/nojs/admin/ledger\">دفتر کل</a><a href=\"/nojs/admin/audit\">حسابرسی</a><a href=\"/nojs/admin/tickets\">تیکت‌ها</a><a href=\"/nojs/admin/jobs\">صف کارها</a><a href=\"/nojs/me/security\">امنیت حساب</a><form method=\"post\" action=\"/nojs/logout\" style=\"margin:0\">__AF__<button class=\"btn2\">خروج</button></form>" : "<a href=\"/nojs/login\">ورود</a><a href=\"/nojs/register\">ثبت‌نام</a><a href=\"/nojs/admin\">ورود مدیر</a>")}</header><main>{body}</main></body></html>";
}

[Route("nojs")]
public class NoJsController : Controller
{
    private readonly AppDbContext _db; private readonly IAntiforgery _af; private readonly IConfiguration _cfg; private readonly IHttpClientFactory _hf;
    public NoJsController(AppDbContext db, IAntiforgery af, IConfiguration cfg, IHttpClientFactory hf) { _db = db; _af = af; _cfg = cfg; _hf = hf; }

    string Af() { var t = _af.GetAndStoreTokens(HttpContext); return $"<input type=\"hidden\" name=\"{t.FormFieldName}\" value=\"{H.E(t.RequestToken)}\">"; }
    ContentResult Html(string title, string body, bool admin = false, int code = 200)
    { Response.StatusCode = code; Response.Headers["Content-Security-Policy"] = "default-src 'none'; style-src 'unsafe-inline'; img-src 'self' data:; form-action 'self'; base-uri 'none'; frame-ancestors 'none'"; Response.Headers["Cache-Control"] = "no-store";
      return Content(H.Page(title, body, admin).Replace("__AF__", Af()), "text/html; charset=utf-8"); }
    async Task<bool> IsAdmin()
    {
        var t = Request.Cookies["dp_t"]; if (string.IsNullOrEmpty(t)) return false;
        Request.Headers.Authorization = "Bearer " + t;
        var r = await HttpContext.AuthenticateAsync("Bearer");
        if (!r.Succeeded || r.Principal == null) return false;
        HttpContext.User = r.Principal; return r.Principal.IsInRole("Admin") || r.Principal.IsInRole("SuperAdmin");
    }
    async Task<bool> Csrf() { try { await _af.ValidateRequestAsync(HttpContext); return true; } catch (AntiforgeryValidationException) { return false; } }

    // ---------- عمومی ----------
    [HttpGet("")]
    public async Task<IActionResult> Home(CancellationToken ct)
    {
        var tid = this.Tid(); var l = await _db.Set<LoanProduct>().Where(p => p.TenantId == tid && p.IsActive && p.ShowInList).OrderBy(p => p.SortOrder).ToListAsync(ct);
        var sb = new StringBuilder("<h1>طرح‌های وام</h1><div class=\"g\">");
        foreach (var p in l)
            sb.Append($"<div class=\"card\"><h3>{H.E(string.IsNullOrWhiteSpace(p.Title) ? p.Name : p.Title)}</h3><p>{H.E(p.Description)}</p><p>مبلغ: {H.Money(p.MinAmount)} تا {H.Money(p.MaxAmount)} تومان<br>سود: {H.Fa(p.InterestPercent)}٪</p><a class=\"btn\" href=\"/nojs/loans/{Uri.EscapeDataString(p.Slug)}\">جزئیات</a></div>");
        sb.Append("</div>"); if (l.Count == 0) sb.Append("<p>طرحی ثبت نشده است.</p>");
        return Html("طرح‌های وام", sb.ToString());
    }
    [HttpGet("loans/{slug}")]
    public async Task<IActionResult> Detail(string slug, CancellationToken ct)
    {
        var p = await _db.Set<LoanProduct>().FirstOrDefaultAsync(x => x.TenantId == this.Tid() && x.IsActive && x.Slug == slug, ct);
        if (p == null) return Html("پیدا نشد", "<p class=\"err\">این طرح وجود ندارد.</p>", false, 404);
        var sb = new StringBuilder($"<h1>{H.E(string.IsNullOrWhiteSpace(p.Title) ? p.Name : p.Title)}</h1>");
        if (!string.IsNullOrEmpty(p.ImageUrl) && p.ImageUrl.StartsWith("/")) sb.Append($"<img src=\"{H.E(p.ImageUrl)}\" alt=\"\" style=\"max-width:100%;border-radius:14px\">");
        sb.Append($"<div class=\"card\">مبلغ: {H.Money(p.MinAmount)} تا {H.Money(p.MaxAmount)} تومان · سود: {H.Fa(p.InterestPercent)}٪ · جریمه‌ی روزانه: {H.Fa(p.LateDailyCoef)} · تخفیف زودکرد: {H.Fa(p.EarlyDailyCoef)}</div>");
        try { foreach (var t in JsonSerializer.Deserialize<JsonElement>(p.TiersJson).EnumerateArray()) sb.Append($"<span class=\"card\" style=\"display:inline-block\">{H.Fa(t.GetProperty("months").GetInt32())} ماه</span> "); } catch { }
        if (!string.IsNullOrEmpty(p.FullDescriptionHtml)) sb.Append($"<div class=\"card\">{p.FullDescriptionHtml}</div>"); // قبلاً با HtmlClean پاک‌سازی شده
        return Html(p.Name, sb.ToString());
    }

    [HttpPost("logout")] public async Task<IActionResult> Logout() { if (await Csrf()) Response.Cookies.Delete("dp_t", new CookieOptions { Path = "/nojs" }); return Redirect("/nojs"); }

    // ---------- مدیریت وام‌ها ----------
    [HttpGet("admin")]
    public async Task<IActionResult> Admin(string? msg, CancellationToken ct)
    {
        if (!await IsAdmin()) return Redirect("/nojs/admin/login");
        var l = await _db.Set<LoanProduct>().Where(p => p.TenantId == this.Tid()).OrderBy(p => p.SortOrder).ToListAsync(ct);
        var sb = new StringBuilder("<h1>تعریف وام‌ها</h1>");
        if (!string.IsNullOrEmpty(msg)) sb.Append($"<p class=\"ok\">{H.E(msg)}</p>");
        sb.Append("<p><a class=\"btn\" href=\"/nojs/admin/loans/new\">+ وام جدید</a></p><div class=\"card\" style=\"overflow:auto\"><table><tr><th>ترتیب</th><th>عنوان</th><th>سود / دیرکرد / زودکرد</th><th>بازه‌ی مبلغ</th><th>وضعیت</th><th></th></tr>");
        foreach (var p in l)
            sb.Append($"<tr><td>{H.Fa(p.SortOrder)}</td><td>{H.E(string.IsNullOrWhiteSpace(p.Title) ? p.Name : p.Title)}</td><td class=\"num\">{H.Fa(p.InterestPercent)} / {H.Fa(p.LateDailyCoef)} / {H.Fa(p.EarlyDailyCoef)}</td><td>{H.Money(p.MinAmount)} – {H.Money(p.MaxAmount)}</td><td>{(p.IsActive ? "فعال" : "غیرفعال")}</td><td><a class=\"btn btn2\" href=\"/nojs/admin/loans/{p.Id}\">ویرایش</a> <form method=\"post\" action=\"/nojs/admin/loans/{p.Id}/toggle\" style=\"display:inline\">__AF__<button class=\"btn2\">{(p.IsActive ? "غیرفعال" : "فعال")}</button></form></td></tr>");
        sb.Append("</table></div>"); if (l.Count == 0) sb.Append("<p>هنوز وامی تعریف نشده است.</p>");
        return Html("مدیریت وام‌ها", sb.ToString(), true);
    }
    [HttpPost("admin/loans/{id:guid}/toggle")]
    public async Task<IActionResult> Toggle(Guid id, CancellationToken ct)
    {
        if (!await IsAdmin()) return Redirect("/nojs/admin/login"); if (!await Csrf()) return BadRequest();
        var p = await _db.Set<LoanProduct>().FindAsync(new object[] { id }, ct); if (p == null || p.TenantId != this.Tid()) return NotFound();
        p.IsActive = !p.IsActive; await _db.SaveChangesAsync(ct); return Redirect("/nojs/admin?msg=" + Uri.EscapeDataString("وضعیت تغییر کرد"));
    }
    [HttpGet("admin/loans/new")] public async Task<IActionResult> New() => await IsAdmin() ? Html("وام جدید", Form(new LoanProduct { IsActive = true, ShowInList = true, SendReminders = true, MinAmount = 1_000_000, MaxAmount = 50_000_000, TiersJson = "[{\"months\":3,\"feePercent\":12,\"downPaymentPercent\":0}]" }, null, true), true) : Redirect("/nojs/admin/login");
    [HttpGet("admin/loans/{id:guid}")]
    public async Task<IActionResult> Edit(Guid id, CancellationToken ct)
    {
        if (!await IsAdmin()) return Redirect("/nojs/admin/login");
        var p = await _db.Set<LoanProduct>().FirstOrDefaultAsync(x => x.Id == id && x.TenantId == this.Tid(), ct); if (p == null) return NotFound();
        return Html("ویرایش وام", Form(p, null, false), true);
    }
    static string Lines(string json, params string[] keys)
    {
        var sb = new StringBuilder();
        try { foreach (var e in JsonSerializer.Deserialize<JsonElement>(json).EnumerateArray()) { sb.AppendLine(string.Join(",", keys.Select(k => e.TryGetProperty(k, out var v) ? (v.ValueKind == JsonValueKind.String ? v.GetString() : v.ToString()) : ""))); } } catch { }
        return sb.ToString();
    }
    string Form(LoanProduct p, string? err, bool isNew)
    {
        string In(string n, object? v, string lbl, bool num = false, string extra = "") => $"<label>{lbl}</label><input name=\"{n}\" value=\"{H.E(v?.ToString())}\" {(num ? "inputmode=\"decimal\" class=\"num\" dir=\"ltr\"" : "")} {extra}>";
        string Plain(decimal d) => d.ToString("0.########", System.Globalization.CultureInfo.InvariantCulture);
        var labels = ""; try { labels = string.Join("، ", JsonSerializer.Deserialize<string[]>(p.LabelsJson) ?? Array.Empty<string>()); } catch { }
        var sel = (string m) => p.InterestMethod == m ? "selected" : "";
        return $@"<h1>{(isNew ? "وام جدید" : "ویرایش: " + H.E(p.Name))}</h1>{(err == null ? "" : $"<p class=\"err\">{H.E(err)}</p>")}
<form method=""post"" action=""/nojs/admin/loans/{(isNew ? "new" : p.Id.ToString())}/save"" enctype=""multipart/form-data"">__AF__
<div class=""tabs"">
<input type=""radio"" name=""tab"" id=""t1"" checked><label for=""t1"" class=""l1"">مشخصات وام</label>
<input type=""radio"" name=""tab"" id=""t2""><label for=""t2"" class=""l2"">اطلاعات طرح</label>
<input type=""radio"" name=""tab"" id=""t3""><label for=""t3"" class=""l3"">مدارک</label>
<div class=""p p1"">{In("Name", p.Name, "نام وام *", false, "required maxlength=120")}{In("Slug", p.Slug, "شناسه‌ی لاتین (slug) *", false, "required pattern=\"[a-z0-9-]{1,40}\" dir=\"ltr\"")}
<label>روش محاسبه‌ی سود</label><select name=""InterestMethod""><option value=""Monthly"" {sel("Monthly")}>ماهانه</option><option value=""Annual"" {sel("Annual")}>سالانه</option><option value=""Flat"" {sel("Flat")}>کارمزد ثابت</option></select>
{In("InterestPercent", Plain(p.InterestPercent), "درصد سود", true)}{In("LateDailyCoef", Plain(p.LateDailyCoef), "ضریب جریمه‌ی روزانه‌ی تأخیر (مثل 0.0008)", true)}{In("EarlyDailyCoef", Plain(p.EarlyDailyCoef), "ضریب تخفیف روزانه‌ی تسویه‌ی زودتر", true)}
{In("MinAmount", Plain(p.MinAmount), "حداقل مبلغ (تومان)", true)}{In("MaxAmount", Plain(p.MaxAmount), "حداکثر مبلغ (تومان)", true)}{In("IntervalDays", p.IntervalDays, "فاصله‌ی اقساط (روز)", true)}{In("SortOrder", p.SortOrder, "ترتیب نمایش", true)}
<label>گزینه‌های اقساط (هر خط: ماه,درصد کارمزد,درصد پیش‌پرداخت)</label><textarea name=""Tiers"" rows=""4"" class=""num"" dir=""ltr"">{H.E(Lines(p.TiersJson, "months", "feePercent", "downPaymentPercent"))}</textarea>
<label><input type=""checkbox"" name=""IsActive"" value=""1"" {(p.IsActive ? "checked" : "")} style=""width:auto""> فعال</label>
<label><input type=""checkbox"" name=""ShowInList"" value=""1"" {(p.ShowInList ? "checked" : "")} style=""width:auto""> نمایش در لیست</label>
<label><input type=""checkbox"" name=""SendReminders"" value=""1"" {(p.SendReminders ? "checked" : "")} style=""width:auto""> ارسال یادآور</label></div>
<div class=""p p2"">{In("Title", p.Title, "عنوان نمایشی طرح", false, "maxlength=160")}{In("Badge", p.Badge, "نشان (Badge)", false, "maxlength=40")}{In("Description", p.Description, "توضیح کوتاه", false, "maxlength=500")}{In("Labels", labels, "برچسب‌ها (با ویرگول جدا کنید)")}
<label>توضیحات کامل (HTML ساده مجاز: p, b, i, ul, ol, li, h3, br, a)</label><textarea name=""FullDescriptionHtml"" rows=""8"">{H.E(p.FullDescriptionHtml)}</textarea>
<label>هزینه‌های عملیاتی (هر خط: عنوان,مبلغ)</label><textarea name=""Costs"" rows=""3"" dir=""ltr"">{H.E(Lines(p.OperationalCostsJson, "title", "amount"))}</textarea>
<label>تصویر طرح (حداکثر ۲ مگابایت؛ jpg/png/webp)</label><input type=""file"" name=""Image"" accept=""image/jpeg,image/png,image/webp""></div>
<div class=""p p3""><label>مدارک لازم (هر خط: نام مدرک,1 برای الزامی یا 0)</label><textarea name=""Docs"" rows=""6"">{H.E(Lines(p.DocumentsJson, "name", "required"))}</textarea><p><small>در همین تب‌ها قالب قرارداد هم وصل می‌شود (ماژول قرارداد).</small></p></div>
</div><p><button>ذخیره</button> <a class=""btn btn2"" href=""/nojs/admin"">انصراف</a></p></form>";
    }
    [HttpPost("admin/loans/{idOrNew}/save"), RequestSizeLimit(3_000_000)]
    public async Task<IActionResult> Save(string idOrNew, IFormCollection f, [FromServices] IWebHostEnvironment env, CancellationToken ct)
    {
        if (!await IsAdmin()) return Redirect("/nojs/admin/login"); if (!await Csrf()) return BadRequest();
        bool isNew = idOrNew == "new"; LoanProduct? p;
        if (isNew) p = new LoanProduct { TenantId = this.Tid() };
        else { if (!Guid.TryParse(idOrNew, out var id)) return NotFound(); p = await _db.Set<LoanProduct>().FirstOrDefaultAsync(x => x.Id == id && x.TenantId == this.Tid(), ct); if (p == null) return NotFound(); }
        string S(string k) => (f[k].ToString() ?? "").Trim();
        p.Name = S("Name"); p.Slug = S("Slug").ToLowerInvariant(); p.Description = S("Description"); p.Badge = S("Badge"); p.Title = S("Title");
        p.InterestMethod = new[] { "Monthly", "Annual", "Flat" }.Contains(S("InterestMethod")) ? S("InterestMethod") : "Monthly";
        p.InterestPercent = H.Num(S("InterestPercent")); p.LateDailyCoef = H.Num(S("LateDailyCoef")); p.EarlyDailyCoef = H.Num(S("EarlyDailyCoef"));
        p.MinAmount = H.Num(S("MinAmount")); p.MaxAmount = H.Num(S("MaxAmount")); p.IntervalDays = (int)H.Num(S("IntervalDays")); p.SortOrder = (int)H.Num(S("SortOrder"));
        p.IsActive = f["IsActive"] == "1"; p.ShowInList = f["ShowInList"] == "1"; p.SendReminders = f["SendReminders"] == "1";
        string? err = null;
        if (p.Name.Length == 0 || p.Name.Length > 120) err = "نام وام الزامی است.";
        else if (!System.Text.RegularExpressions.Regex.IsMatch(p.Slug, "^[a-z0-9-]{1,40}$")) err = "شناسه فقط حروف کوچک لاتین، عدد و خط تیره.";
        else if (p.MinAmount <= 0 || p.MaxAmount < p.MinAmount) err = "بازه‌ی مبلغ نامعتبر است.";
        else if (p.IntervalDays < 1 || p.IntervalDays > 365) err = "فاصله‌ی اقساط باید بین ۱ تا ۳۶۵ روز باشد.";
        else if (p.InterestPercent < 0 || p.InterestPercent > 1000 || p.LateDailyCoef < 0 || p.LateDailyCoef > 1 || p.EarlyDailyCoef < 0 || p.EarlyDailyCoef > 1) err = "درصد سود یا ضرایب خارج از محدوده است.";
        var tiers = new List<object>();
        if (err == null) foreach (var ln in S("Tiers").Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        { var c = ln.Split(','); if (c.Length < 3) { err = "هر خط گزینه‌ی اقساط باید «ماه,کارمزد,پیش‌پرداخت» باشد."; break; } var m = (int)H.Num(c[0]); if (m < 1 || m > 120) { err = "تعداد ماه نامعتبر است."; break; } tiers.Add(new { months = m, feePercent = H.Num(c[1]), downPaymentPercent = H.Num(c[2]) }); }
        if (err == null && tiers.Count == 0) err = "حداقل یک گزینه‌ی اقساط لازم است.";
        if (err == null && await _db.Set<LoanProduct>().AnyAsync(x => x.TenantId == p.TenantId && x.Slug == p.Slug && x.Id != p.Id, ct)) err = "این شناسه قبلاً ثبت شده.";
        p.FullDescriptionHtml = HtmlClean.Clean(S("FullDescriptionHtml"));
        if (err != null) { p.TiersJson = "[]"; return Html("خطا", Form(p, err, isNew), true, 400); }
        p.TiersJson = JsonSerializer.Serialize(tiers);
        p.LabelsJson = JsonSerializer.Serialize(S("Labels").Split(new[] { ',', '،' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).Distinct().Take(20).ToArray());
        p.OperationalCostsJson = JsonSerializer.Serialize(S("Costs").Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).Select(l => l.Split(',')).Where(c => c.Length >= 2).Select(c => new { title = c[0].Trim(), amount = H.Num(c[1]) }).Take(30));
        p.DocumentsJson = JsonSerializer.Serialize(S("Docs").Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).Select(l => l.Split(',')).Select(c => new { name = c[0].Trim(), required = c.Length < 2 || c[1].Trim() != "0" }).Take(30));
        var img = f.Files.GetFile("Image");
        if (img != null && img.Length > 0)
        {
            var ext = img.ContentType switch { "image/jpeg" => ".jpg", "image/png" => ".png", "image/webp" => ".webp", _ => null };
            if (ext == null || img.Length > 2_000_000) { return Html("خطا", Form(p, "تصویر باید jpg/png/webp و حداکثر ۲ مگابایت باشد.", isNew), true, 400); }
            var head = new byte[12]; await using (var s0 = img.OpenReadStream()) { await s0.ReadAsync(head, 0, 12, ct); }
            bool magic = (ext == ".jpg" && head[0] == 0xFF && head[1] == 0xD8) || (ext == ".png" && head[0] == 0x89 && head[1] == 0x50) || (ext == ".webp" && head[0] == 0x52 && head[8] == 0x57);
            if (!magic) return Html("خطا", Form(p, "محتوای تصویر معتبر نیست.", isNew), true, 400);
            var dir = Path.Combine(env.WebRootPath ?? "wwwroot", "uploads", "loans"); Directory.CreateDirectory(dir);
            var name = Guid.NewGuid().ToString("N") + ext; await using (var o = System.IO.File.Create(Path.Combine(dir, name))) await img.CopyToAsync(o, ct);
            p.ImageUrl = "/uploads/loans/" + name;
        }
        if (isNew) _db.Add(p); await _db.SaveChangesAsync(ct);
        return Redirect("/nojs/admin?msg=" + Uri.EscapeDataString("ذخیره شد"));
    }
}
