#!/bin/bash
# نصب صفحات بدون جاوااسکریپت (/nojs): لیست و جزئیات وام عمومی + ورود مدیر + تعریف وام سه‌تبه
set -e
ROOT="${1:-/home/ghestine/domains/ghestine.ir/Ghestine}"
HERE="$(cd "$(dirname "$0")" && pwd)"; SRC="$ROOT/src"
[ -d "$SRC" ] || { echo "پوشه src پیدا نشد: $SRC"; exit 1; }
B="$ROOT/.nojs-backup-$(date +%Y%m%d%H%M%S)"; mkdir -p "$B"
DBF=$(grep -rl "class AppDbContext" "$SRC" --include=*.cs | head -1); [ -n "$DBF" ] || { echo "AppDbContext پیدا نشد"; exit 1; }
PG="$SRC/Ghestine.API/Program.cs"; cp "$PG" "$B/Program.cs.bak"; echo "بکاپ: $B"
grep -rq "class LoanProduct" "$SRC" --include=*.cs || { echo "ابتدا ماژول core را نصب کنید."; exit 1; }
grep -rq "static class HtmlClean" "$SRC" --include=*.cs || { echo "HtmlClean پیدا نشد؛ ماژول core را نصب کنید."; exit 1; }
grep -rq "class TwoFaService" "$SRC" --include=*.cs || { echo "ابتدا ماژول iam را نصب کنید."; exit 1; }
grep -rq "class JobWorker" "$SRC" --include=*.cs || { echo "ابتدا ماژول platform را نصب کنید."; exit 1; }
grep -rq "class LedgerController" "$SRC" --include=*.cs || { echo "ابتدا ماژول enterprise را نصب کنید."; exit 1; }
grep -rq "class DashboardService" "$SRC" --include=*.cs || { echo "ابتدا ماژول notify را نصب کنید."; exit 1; }
grep -rq "class SupportService" "$SRC" --include=*.cs || { echo "ابتدا ماژول support را نصب کنید."; exit 1; }
grep -rq "class TenantMiddleware" "$SRC" --include=*.cs || { echo "ابتدا ماژول tenancy را نصب کنید."; exit 1; }
DBNS=$(grep -h "^namespace" "$DBF" | head -1 | sed 's/namespace //; s/;//; s/\r//')
mkdir -p "$SRC/Ghestine.API/NoJs"; for f in NoJsPages NoJsCustomer NoJsAuth NoJsIam NoJsJobs NoJsSupport NoJsNotify; do cp "$HERE/files/$f.cs" "$SRC/Ghestine.API/NoJs/$f.cs"; sed -i "s/__DBNS__/$DBNS/" "$SRC/Ghestine.API/NoJs/$f.cs"; done
grep -q "AddAntiforgery" "$PG" || sed -i '0,/var app = builder.Build();/s//builder.Services.AddAntiforgery();\n\nvar app = builder.Build();/' "$PG"
grep -q "AddHttpClient()" "$PG" || sed -i '0,/var app = builder.Build();/s//builder.Services.AddHttpClient();\n\nvar app = builder.Build();/' "$PG"
grep -q "AddAntiforgery" "$PG" && grep -q "AddHttpClient" "$PG" || { echo "درج سرویس‌ها در Program.cs انجام نشد. بکاپ: $B"; exit 1; }
cd "$ROOT"
if dotnet build 2>&1 | tee /tmp/nojs-build.log | tail -15 | grep -q "Build succeeded"; then echo "ساخت موفق."; else
  echo "خطای build؛ ۱۵ خط آخر را بفرستید. برگرداندن: cp $B/Program.cs.bak $PG ; rm -r $SRC/Ghestine.API/NoJs"; exit 1; fi
cat <<'MSG'

=== بعد از استقرار ===
  عمومی: /nojs        ورود مدیر: /nojs/admin/login        مدیریت وام‌ها: /nojs/admin
نکته: ورود از مسیر NoJs:LoginUrl (پیش‌فرض http://127.0.0.1:5200/api/v1/auth/login) انجام می‌شود.
اگر ورود شما کپچا لازم دارد، این فرم هنوز آن را نشان نمی‌دهد؛ در آن صورت خروجی را برایم بفرستید.
نیازی به مایگریشن ندارد (جدول جدید نمی‌سازد).
MSG
