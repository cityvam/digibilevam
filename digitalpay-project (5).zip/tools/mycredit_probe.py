#!/usr/bin/env python3
"""ابزار خط فرمان برای تست مستقیم اتصال به «اعتبارسنجی ایران (MyCreditAPIs v3.2)» — بدون سایت.
هدف: قبل از وصل کردن به سایت مطمئن شوید نام‌کاربری/رمز/ApiKey و IP سرور درست است.
نمونه:
  export MYCREDIT_BASE=https://<آدرس-رسمی> MYCREDIT_USER=... MYCREDIT_PASS=... [MYCREDIT_APIKEY=...]
  python3 mycredit_probe.py login                       # فقط ورود (بخش ۱)
  python3 mycredit_probe.py request 0012345679 09121234567   # بخش ۳ ← کد ارسال می‌شود، HashCode چاپ می‌شود
  python3 mycredit_probe.py validate <hash> <otp>       # بخش ۵
  python3 mycredit_probe.py status <hash>               # بخش ۶
  python3 mycredit_probe.py report <reportCode>         # بخش ۹ (JSON)   |   pdf <reportCode> out.pdf   # بخش ۱۰
  python3 mycredit_probe.py regen <hash> | renew <hash> | records [--from yyyy-mm-dd --to yyyy-mm-dd --page 1]
رمز و توکن هرگز چاپ نمی‌شود (فقط ۴ نویسه‌ی آخر). فقط کتابخانه‌ی استاندارد."""
import json, os, sys, time, urllib.parse, urllib.request, urllib.error

class MyCredit:
    def __init__(self, base, user, pw, apikey=None, timeout=25):
        self.base, self.user, self.pw, self.key, self.timeout = base.rstrip('/'), user, pw, apikey, timeout
        self.access = self.refresh = self.exp = None
    def _raw(self, method, path, form=None, bearer=None, key=True, version=None, binary=False):
        h = {'Accept': 'application/json'}
        if bearer: h['Authorization'] = 'Bearer ' + bearer
        if key and self.key: h['x-apikey'] = self.key
        if version: h['x-version'] = version
        data = None
        if form is not None: data = urllib.parse.urlencode(form).encode(); h['Content-Type'] = 'application/x-www-form-urlencoded'
        req = urllib.request.Request(self.base + path, data=data, headers=h, method=method)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r: code, body, ct = r.status, r.read(), r.headers.get('content-type', '')
        except urllib.error.HTTPError as e: code, body, ct = e.code, e.read(), e.headers.get('content-type', '')
        except urllib.error.URLError as e: return {'ok': False, 'reason': 'Unavailable', 'message': str(e.reason), 'http': 0}
        if code == 401: return {'ok': False, 'reason': 'Unauthorized', 'http': 401}
        if code >= 500 or code == 429: return {'ok': False, 'reason': 'Unavailable', 'http': code}
        if binary and code < 300 and 'json' not in ct: return {'ok': True, 'bytes': body, 'http': code}
        try: j = json.loads(body)
        except Exception: return {'ok': False, 'reason': 'DataError', 'http': code}
        if j.get('hasError') or code >= 300:
            m = (j.get('messages') or [{}])[0]; return {'ok': False, 'reason': m.get('reason') or 'BadInput', 'message': m.get('message'), 'http': code}
        return {'ok': True, 'data': j.get('data'), 'json': j, 'http': code}
    def login(self):
        r = self._raw('POST', '/Connect/Token', {'username': self.user, 'password': self.pw}, key=False)
        if r['ok']:
            d = r['data']; self.access, self.refresh = d['accessToken'], d.get('refreshToken'); self.key = self.key or d.get('apiKey'); self.exp = time.time() + 11 * 3600
        return r
    def _ensure(self):
        if self.access and time.time() < self.exp: return None
        if self.refresh:
            r = self._raw('PUT', '/Connect/Token', {'accessToken': self.access or '', 'refreshToken': self.refresh}, bearer=self.access, key=False)
            if r['ok']: self.access = r['data']['accessToken']; self.refresh = r['data'].get('refreshToken', self.refresh); self.exp = time.time() + 11 * 3600; return None
        r = self.login(); return None if r['ok'] else r
    def call(self, method, path, form=None, version=None, binary=False):
        for i in range(2):
            e = self._ensure()
            if e: return e
            r = self._raw(method, path, form, self.access, True, version, binary)
            if r.get('reason') == 'Unauthorized' and i == 0: self.exp = 0; continue
            return r
    q = staticmethod(lambda s: urllib.parse.quote(s, safe=''))
    def request(self, nc, mobile, legal=None): f = {'RealPersonNationalCode': nc, 'MobileNumber': mobile}; legal and f.update(LegalPersonNationalCode=legal); return self.call('POST', '/b2b/api/request', f)
    def renew(self, h): return self.call('POST', f'/b2b/api/request/{self.q(h)}/renewToken')
    def validate(self, h, token): return self.call('POST', f'/b2b/api/request/{self.q(h)}/validate', {'Token': token})
    def status(self, h): return self.call('GET', f'/b2b/api/request/{self.q(h)}/status')
    def regen(self, h): return self.call('POST', f'/b2b/api/request/{self.q(h)}/reGenerateReport')
    def report(self, code): return self.call('GET', f'/Report/{self.q(code)}/json', version='2.0')
    def pdf(self, code): return self.call('GET', f'/b2b/api/request/{self.q(code)}/pdfReport', version='2.0', binary=True)
    def records(self, frm=None, to=None, sort=-1, page=1, size=100):
        qs = {k: v for k, v in dict(fromDate=frm, toDate=to, sort=sort, page=page, size=size).items() if v is not None}
        return self.call('GET', '/Record/requests?' + urllib.parse.urlencode(qs))

TERMINAL = {'ReportGenerated', 'Success', 'IdentityCheckFailed', 'OTPLocked', 'ReportGenerationFailed', 'ReportGeneratedButDataLost', 'ShahkarFailed', 'SherkathaFailed'}
def wait_report(c, h, timeout=180, every=2):
    """منتظر ماندن تا وضعیت نهایی؛ برمی‌گرداند (status, reportCode)."""
    t0 = time.time()
    while time.time() - t0 < timeout:
        r = c.status(h)
        if not r['ok']: return r.get('reason'), None
        d = r['data']; st = d.get('status')
        if st in TERMINAL or st.startswith('NotMatching'): return st, (d.get('reportLink') or '').rstrip('/').split('/')[-1] or None
        time.sleep(every)
    return 'Timeout', None

def _mask(v): return '…' + v[-4:] if v else '(none)'
def main(argv):
    a = argv[1:]
    if not a or a[0] in ('-h', '--help'): print(__doc__); return 0
    base, user, pw = os.environ.get('MYCREDIT_BASE'), os.environ.get('MYCREDIT_USER'), os.environ.get('MYCREDIT_PASS')
    if not (base and user and pw): print('متغیرهای MYCREDIT_BASE / MYCREDIT_USER / MYCREDIT_PASS را تنظیم کنید.'); return 2
    c = MyCredit(base, user, pw, os.environ.get('MYCREDIT_APIKEY')); cmd = a[0]
    def out(r):
        if not r['ok']: print('ERROR', r.get('reason'), r.get('message') or '', f"(http {r.get('http')})"); return 1
        if 'bytes' in r: return 0
        print(json.dumps(r.get('json') or r.get('data'), ensure_ascii=False, indent=2)); return 0
    if cmd == 'login':
        r = c.login()
        if r['ok']: print('OK  accessToken=' + _mask(c.access), ' refreshToken=' + _mask(c.refresh), ' apiKey=' + _mask(c.key)); return 0
        return out(r)
    if cmd == 'request': return out(c.request(a[1], a[2], a[3] if len(a) > 3 else None))
    if cmd == 'renew': return out(c.renew(a[1]))
    if cmd == 'validate': return out(c.validate(a[1], a[2]))
    if cmd == 'status': return out(c.status(a[1]))
    if cmd == 'regen': return out(c.regen(a[1]))
    if cmd == 'report': return out(c.report(a[1]))
    if cmd == 'pdf':
        r = c.pdf(a[1])
        if r['ok'] and 'bytes' in r: open(a[2], 'wb').write(r['bytes']); print('saved', a[2], len(r['bytes']), 'bytes'); return 0
        return out(r)
    if cmd == 'records':
        o = dict(zip(a[1::2], a[2::2])); return out(c.records(o.get('--from'), o.get('--to'), int(o.get('--sort', -1)), int(o.get('--page', 1))))
    print('دستور نامعتبر. -h را بزنید.'); return 2
if __name__ == '__main__': sys.exit(main(sys.argv))
