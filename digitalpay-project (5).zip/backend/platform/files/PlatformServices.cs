using System.Diagnostics;
using System.Text.Json;
using System.Text.RegularExpressions;
using Ghestine.Domain.Entities;
using Ghestine.API.Security;
using Microsoft.EntityFrameworkCore;
using Serilog.Core;
using Serilog.Events;
using __DBNS__;
namespace Ghestine.API.Platform;

// ---------- شناسه‌ی پیگیری هر درخواست ----------
public class CorrelationMiddleware
{
    private readonly RequestDelegate _next; public CorrelationMiddleware(RequestDelegate n) => _next = n;
    public async Task Invoke(HttpContext c)
    {
        var id = c.Request.Headers["X-Request-Id"].FirstOrDefault();
        if (string.IsNullOrWhiteSpace(id) || id.Length > 40 || !Regex.IsMatch(id, "^[A-Za-z0-9-]+$")) id = Guid.NewGuid().ToString("N")[..16];
        c.Items["rid"] = id; c.Response.Headers["X-Request-Id"] = id;
        using (Serilog.Context.LogContext.PushProperty("RequestId", id)) await _next(c);
    }
}

// ---------- خطای سراسری: به کاربر پیام کلی + شناسه‌ی پیگیری، جزئیات فقط در لاگ ----------
public class ErrorMiddleware
{
    private readonly RequestDelegate _next; private readonly ILogger<ErrorMiddleware> _log;
    public ErrorMiddleware(RequestDelegate n, ILogger<ErrorMiddleware> l) { _next = n; _log = l; }
    public async Task Invoke(HttpContext c)
    {
        try { await _next(c); }
        catch (OperationCanceledException) when (c.RequestAborted.IsCancellationRequested) { }
        catch (Exception ex)
        {
            var rid = c.Items["rid"]?.ToString() ?? "-"; _log.LogError(ex, "Unhandled exception {Path} rid={Rid}", c.Request.Path.Value, rid);
            if (c.Response.HasStarted) throw;
            c.Response.Clear(); c.Response.StatusCode = 500;
            if (c.Request.Path.StartsWithSegments("/api")) { c.Response.ContentType = "application/json; charset=utf-8"; await c.Response.WriteAsync(JsonSerializer.Serialize(new { message = "خطای داخلی سرور", requestId = rid })); }
            else { c.Response.ContentType = "text/html; charset=utf-8"; await c.Response.WriteAsync($"<!doctype html><meta charset=utf-8><title>خطا</title><body style=\"font-family:Tahoma;background:#130c1f;color:#f3edfb;padding:24px\" dir=rtl><h1>خطای داخلی</h1><p>مشکلی پیش آمد. اگر تکرار شد، این شناسه را به پشتیبانی بدهید:</p><p dir=ltr>{System.Net.WebUtility.HtmlEncode(rid)}</p>"); }
        }
    }
}

// ---------- پنهان‌سازی داده‌ی حساس در لاگ (کد ملی، موبایل، توکن، رمز، شماره کارت) ----------
public class MaskEnricher : ILogEventEnricher
{
    static readonly Regex Card = new(@"\b(\d{6})\d{6,9}(\d{4})\b", RegexOptions.Compiled);
    static readonly Regex Nid = new(@"(?<!\d)(\d{3})\d{4}(\d{3})(?!\d)", RegexOptions.Compiled);
    static readonly Regex Phone = new(@"(?<!\d)(09\d{2})\d{4}(\d{3})(?!\d)", RegexOptions.Compiled);
    static readonly Regex Secret = new(@"(?i)(bearer\s+|token[""'=:\s]+|password[""'=:\s]+|secret[""'=:\s]+|authorization[""'=:\s]+)[A-Za-z0-9._\-+/=]{8,}", RegexOptions.Compiled);
    public static string Mask(string s) => Secret.Replace(Phone.Replace(Card.Replace(Nid.Replace(s, "$1***$2"), "$1******$2"), "$1***$2"), "$1***");
    public void Enrich(LogEvent e, ILogEventPropertyFactory f)
    {
        foreach (var p in e.Properties.ToList()) if (p.Value is ScalarValue { Value: string s }) { var m = Mask(s); if (m != s) e.AddOrUpdateProperty(new LogEventProperty(p.Key, new ScalarValue(m))); }
    }
}

// ---------- صف کار ----------
public interface IJobQueue { Task<Guid> EnqueueAsync(Guid tenant, string type, object payload, DateTime? runAt = null, string? dedupKey = null, int maxAttempts = 6, CancellationToken ct = default); }
public interface IJobHandler { string Type { get; } Task HandleAsync(Guid tenant, JsonElement payload, CancellationToken ct); }

public class JobQueue : IJobQueue
{
    private readonly AppDbContext _db; public JobQueue(AppDbContext db) => _db = db;
    public async Task<Guid> EnqueueAsync(Guid tenant, string type, object payload, DateTime? runAt = null, string? dedupKey = null, int maxAttempts = 6, CancellationToken ct = default)
    {
        if (!string.IsNullOrEmpty(dedupKey))
        { var ex = await _db.Set<BackgroundJob>().Where(j => j.TenantId == tenant && j.DedupKey == dedupKey && (j.Status == "Pending" || j.Status == "Running" || j.Status == "Done")).Select(j => j.Id).FirstOrDefaultAsync(ct); if (ex != Guid.Empty) return ex; }
        var job = new BackgroundJob { TenantId = tenant, Type = type, PayloadJson = JsonSerializer.Serialize(payload), RunAt = runAt ?? DateTime.UtcNow, DedupKey = dedupKey ?? "", MaxAttempts = Math.Clamp(maxAttempts, 1, 20) };
        _db.Add(job); await _db.SaveChangesAsync(ct); return job.Id;
    }
}

/// پیامک: {phone, text}. شماره و متن در لاگ ماسک می‌شود.
public class SmsJobHandler : IJobHandler
{
    private readonly ISmsSender _sms; public SmsJobHandler(ISmsSender s) => _sms = s;
    public string Type => "sms.send";
    public async Task HandleAsync(Guid tenant, JsonElement p, CancellationToken ct)
    {
        var (ok, info) = await _sms.SendAsync(p.GetProperty("phone").GetString() ?? "", p.GetProperty("text").GetString() ?? "", ct);
        if (!ok) throw new InvalidOperationException("SMS failed: " + info);
    }
}

public class JobWorker : BackgroundService
{
    private readonly IServiceScopeFactory _sf; private readonly ILogger<JobWorker> _log; private readonly IConfiguration _cfg;
    public JobWorker(IServiceScopeFactory sf, ILogger<JobWorker> log, IConfiguration cfg) { _sf = sf; _log = log; _cfg = cfg; }
    public static TimeSpan Backoff(int attempt) => TimeSpan.FromSeconds(Math.Min(3600, 15 * Math.Pow(4, Math.Max(0, attempt - 1))));  // ۱۵ث، ۱ د، ۴ د، ۱۶ د، ۱ ساعت
    protected override async Task ExecuteAsync(CancellationToken ct)
    {
        if ((_cfg["Jobs:Enabled"] ?? "true") == "false") { _log.LogInformation("Job worker disabled"); return; }
        await Task.Delay(TimeSpan.FromSeconds(10), ct).ContinueWith(_ => { });
        while (!ct.IsCancellationRequested)
        {
            var did = 0;
            try { did = await Tick(ct); } catch (OperationCanceledException) { return; } catch (Exception ex) { _log.LogError(ex, "Job worker tick failed"); }
            try { await Task.Delay(did > 0 ? TimeSpan.FromMilliseconds(300) : TimeSpan.FromSeconds(5), ct); } catch (OperationCanceledException) { return; }
        }
    }
    async Task<int> Tick(CancellationToken ct)
    {
        using var scope = _sf.CreateScope(); var db = scope.ServiceProvider.GetRequiredService<AppDbContext>(); var now = DateTime.UtcNow;
        // کارهای گیرکرده (سرور وسط کار خاموش شد) بعد از ۱۰ دقیقه دوباره Pending می‌شوند
        foreach (var s in await db.Set<BackgroundJob>().Where(j => j.Status == "Running" && j.StartedOn < now.AddMinutes(-10)).Take(50).ToListAsync(ct)) s.Status = "Pending";
        var jobs = await db.Set<BackgroundJob>().Where(j => j.Status == "Pending" && j.RunAt <= now).OrderBy(j => j.RunAt).Take(10).ToListAsync(ct);
        foreach (var j in jobs) { j.Status = "Running"; j.StartedOn = now; j.Attempts++; }
        if (jobs.Count == 0) { await db.SaveChangesAsync(ct); return 0; }
        await db.SaveChangesAsync(ct);   // اگر نسخه‌ی دیگری همزمان برداشته باشد، همین‌جا تداخل را می‌فهمیم
        var handlers = scope.ServiceProvider.GetServices<IJobHandler>().ToDictionary(h => h.Type);
        foreach (var j in jobs)
        {
            var sw = Stopwatch.StartNew();
            using (Serilog.Context.LogContext.PushProperty("JobId", j.Id))
            try
            {
                if (!handlers.TryGetValue(j.Type, out var h)) throw new InvalidOperationException("no handler for " + j.Type);
                await h.HandleAsync(j.TenantId, JsonSerializer.Deserialize<JsonElement>(j.PayloadJson), ct);
                j.Status = "Done"; j.FinishedOn = DateTime.UtcNow; j.LastError = "";
                _log.LogInformation("Job {Type} done in {Ms}ms attempt {A}", j.Type, sw.ElapsedMilliseconds, j.Attempts);
            }
            catch (Exception ex)
            {
                j.LastError = LastErr(ex);
                if (j.Attempts >= j.MaxAttempts) { j.Status = "Dead"; j.FinishedOn = DateTime.UtcNow; _log.LogError(ex, "Job {Type} dead after {A} attempts", j.Type, j.Attempts); }
                else { j.Status = "Pending"; j.RunAt = DateTime.UtcNow + Backoff(j.Attempts); _log.LogWarning("Job {Type} failed attempt {A}: {E}", j.Type, j.Attempts, j.LastError); }
            }
            await db.SaveChangesAsync(ct);
        }
        return jobs.Count;
    }
    static string LastErr(Exception ex) { var m = MaskEnricher.Mask(ex.GetType().Name + ": " + ex.Message); return m.Length <= 400 ? m : m[..400]; }
}
