using System.ComponentModel.DataAnnotations;
using Ghestine.Domain.Common;
namespace Ghestine.Domain.Entities;

/// کار پایدار در صف. بعد از ری‌استارت سرور هم از دست نمی‌رود.
public class BackgroundJob : BaseEntity
{
    public Guid TenantId { get; set; }
    [MaxLength(60)] public string Type { get; set; } = string.Empty;        // مثل sms.send
    public string PayloadJson { get; set; } = "{}";
    [MaxLength(80)] public string DedupKey { get; set; } = string.Empty;    // اختیاری؛ از ساخت دوباره‌ی همان کار جلوگیری می‌کند
    [MaxLength(12)] public string Status { get; set; } = "Pending";          // Pending | Running | Done | Failed | Dead
    public DateTime RunAt { get; set; } = DateTime.UtcNow;
    public int Attempts { get; set; }
    public int MaxAttempts { get; set; } = 6;
    [MaxLength(400)] public string LastError { get; set; } = string.Empty;
    public DateTime CreatedOn { get; set; } = DateTime.UtcNow;
    public DateTime? StartedOn { get; set; }
    public DateTime? FinishedOn { get; set; }
}
