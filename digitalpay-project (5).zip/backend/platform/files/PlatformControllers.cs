using System.Reflection;
using Ghestine.Domain.Entities;
using Ghestine.API.Tenancy;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using __DBNS__;
namespace Ghestine.API.Platform;

/// پایش صف کار برای مدیر: شمارش وضعیت‌ها، فهرست کارهای مرده/ناموفق، تلاش دوباره.
[ApiController, Route("api/v1/admin/jobs"), Authorize(Roles = "Admin,SuperAdmin")]
public class JobsAdminController : ControllerBase
{
    private readonly AppDbContext _db; public JobsAdminController(AppDbContext db) => _db = db;
    [HttpGet("summary")] public async Task<IActionResult> Summary(CancellationToken ct)
    {
        var tid = this.Tid(); var g = await _db.Set<BackgroundJob>().Where(j => j.TenantId == tid).GroupBy(j => j.Status).Select(x => new { s = x.Key, n = x.Count() }).ToListAsync(ct);
        var oldest = await _db.Set<BackgroundJob>().Where(j => j.TenantId == tid && j.Status == "Pending" && j.RunAt <= DateTime.UtcNow).OrderBy(j => j.RunAt).Select(j => (DateTime?)j.RunAt).FirstOrDefaultAsync(ct);
        return Ok(new { counts = g.ToDictionary(x => x.s, x => x.n), oldestDueSeconds = oldest == null ? 0 : (int)(DateTime.UtcNow - oldest.Value).TotalSeconds });
    }
    [HttpGet] public async Task<IActionResult> List([FromQuery] string? status, CancellationToken ct)
    {
        var q = _db.Set<BackgroundJob>().Where(j => j.TenantId == this.Tid()); if (!string.IsNullOrEmpty(status)) q = q.Where(j => j.Status == status);
        return Ok(await q.OrderByDescending(j => j.CreatedOn).Take(200).Select(j => new { j.Id, j.Type, j.Status, j.Attempts, j.MaxAttempts, j.RunAt, j.LastError, j.CreatedOn, j.FinishedOn }).ToListAsync(ct));
    }
    [HttpPost("{id:guid}/retry")] public async Task<IActionResult> Retry(Guid id, CancellationToken ct)
    {
        var j = await _db.Set<BackgroundJob>().FirstOrDefaultAsync(x => x.Id == id && x.TenantId == this.Tid(), ct); if (j == null) return NotFound();
        if (j.Status is not ("Dead" or "Failed")) return Conflict(new { message = "فقط کار مرده یا ناموفق دوباره اجرا می‌شود" });
        j.Status = "Pending"; j.Attempts = 0; j.RunAt = DateTime.UtcNow; j.LastError = ""; await _db.SaveChangesAsync(ct); return Ok();
    }
}

/// نسخه و زمان کارکرد برای پایش (بدون جزئیات حساس)
[ApiController, Route("api/v1/version"), AllowAnonymous]
public class VersionController : ControllerBase
{
    static readonly DateTime Started = DateTime.UtcNow;
    [HttpGet] public IActionResult Get() => Ok(new { version = Assembly.GetEntryAssembly()?.GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion?.Split('+')[0] ?? "dev", uptimeSeconds = (int)(DateTime.UtcNow - Started).TotalSeconds });
}
