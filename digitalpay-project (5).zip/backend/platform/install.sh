#!/bin/bash
# نصب زیرساخت عملیاتی: لاگ ساختاریافته (Serilog) با ماسک داده‌ی حساس، شناسه‌ی پیگیری، خطای سراسری، صف کار پایدار
set -e
ROOT="${1:-/home/ghestine/domains/ghestine.ir/Ghestine}"
HERE="$(cd "$(dirname "$0")" && pwd)"; SRC="$ROOT/src"
[ -d "$SRC" ] || { echo "پوشه src پیدا نشد: $SRC"; exit 1; }
B="$ROOT/.platform-backup-$(date +%Y%m%d%H%M%S)"; mkdir -p "$B"
DBF=$(grep -rl "class AppDbContext" "$SRC" --include=*.cs | head -1); [ -n "$DBF" ] || { echo "AppDbContext پیدا نشد"; exit 1; }
PG="$SRC/Ghestine.API/Program.cs"; cp "$PG" "$B/Program.cs.bak"; cp "$DBF" "$B/AppDbContext.cs.bak"; echo "بکاپ: $B"
BE=$(grep -rl "class BaseEntity" "$SRC" --include=*.cs | head -1); [ -n "$BE" ] || { echo "کلاس BaseEntity پیدا نشد."; exit 1; }
BENS=$(grep -h "^namespace" "$BE" | head -1 | sed 's/namespace //; s/;//; s/\r//')
DBNS=$(grep -h "^namespace" "$DBF" | head -1 | sed 's/namespace //; s/;//; s/\r//')
grep -rq "class TenantMiddleware" "$SRC" --include=*.cs || { echo "ابتدا ماژول tenancy را نصب کنید."; exit 1; }
grep -rq "interface ISmsSender" "$SRC" --include=*.cs || { echo "ابتدا ماژول security را نصب کنید (ISmsSender)."; exit 1; }
grep -q "var builder = WebApplication.CreateBuilder" "$PG" || { echo "خط var builder = WebApplication.CreateBuilder در Program.cs پیدا نشد؛ ساختار Program.cs متفاوت است."; exit 1; }
grep -q "var app = builder.Build();" "$PG" || { echo "خط var app = builder.Build(); پیدا نشد."; exit 1; }
cp "$HERE/files/PlatformModule.cs" "$SRC/Ghestine.Domain/Entities/PlatformModule.cs"
sed -i "s/^using Ghestine.Domain.Common;/using $BENS;/" "$SRC/Ghestine.Domain/Entities/PlatformModule.cs"
mkdir -p "$SRC/Ghestine.API/Platform"; for f in PlatformServices PlatformControllers; do cp "$HERE/files/$f.cs" "$SRC/Ghestine.API/Platform/$f.cs"; sed -i "s/__DBNS__/$DBNS/" "$SRC/Ghestine.API/Platform/$f.cs"; done
grep -q "DbSet<Ghestine.Domain.Entities.BackgroundJob>" "$DBF" || {
  grep -q "protected override void OnModelCreating" "$DBF" || { echo "OnModelCreating پیدا نشد؛ DbSet را دستی اضافه کنید"; exit 1; }
  sed -i "0,/protected override void OnModelCreating/s//public DbSet<Ghestine.Domain.Entities.BackgroundJob> BackgroundJobs => Set<Ghestine.Domain.Entities.BackgroundJob>();\n\n    protected override void OnModelCreating/" "$DBF"; }
grep -q "DbSet<Ghestine.Domain.Entities.BackgroundJob>" "$DBF" || { echo "درج DbSet انجام نشد. بکاپ: $B"; exit 1; }
API="$SRC/Ghestine.API/Ghestine.API.csproj"; [ -f "$API" ] || API=$(ls "$SRC"/Ghestine.API/*.csproj | head -1)
grep -q "Serilog.AspNetCore" "$API" || (cd "$SRC/Ghestine.API" && dotnet add package Serilog.AspNetCore) || { echo "نصب Serilog.AspNetCore انجام نشد (دسترسی nuget؟)"; exit 1; }
if ! grep -q "UseSerilog" "$PG"; then
  T=$(mktemp); cat > "$T" <<'EOT'
builder.Host.UseSerilog((ctx, lc) => lc.ReadFrom.Configuration(ctx.Configuration).Enrich.FromLogContext().Enrich.With<Ghestine.API.Platform.MaskEnricher>().WriteTo.Console().WriteTo.File(new Serilog.Formatting.Compact.CompactJsonFormatter(), ctx.Configuration["Logging:File"] ?? "/var/log/digitalpay/app-.log", rollingInterval: Serilog.RollingInterval.Day, retainedFileCountLimit: 30));
builder.Services.AddScoped<Ghestine.API.Platform.IJobQueue, Ghestine.API.Platform.JobQueue>();
builder.Services.AddScoped<Ghestine.API.Platform.IJobHandler, Ghestine.API.Platform.SmsJobHandler>();
builder.Services.AddHostedService<Ghestine.API.Platform.JobWorker>();
EOT
  sed -i "/var builder = WebApplication.CreateBuilder/r $T" "$PG"; rm -f "$T"
fi
if ! grep -q "CorrelationMiddleware" "$PG"; then
  T=$(mktemp); cat > "$T" <<'EOT'
app.UseMiddleware<Ghestine.API.Platform.CorrelationMiddleware>();
app.UseMiddleware<Ghestine.API.Platform.ErrorMiddleware>();
app.UseSerilogRequestLogging();
EOT
  sed -i "/var app = builder.Build();/r $T" "$PG"; rm -f "$T"
fi
grep -q "CorrelationMiddleware" "$PG" && grep -q "UseSerilog(" "$PG" || { echo "ثبت در Program.cs انجام نشد. برگرداندن: cp $B/Program.cs.bak $PG"; exit 1; }
cd "$ROOT"
if dotnet build 2>&1 | tee /tmp/platform-build.log | tail -15 | grep -q "Build succeeded"; then echo "ساخت موفق."; else
  echo "خطای build؛ ۱۵ خط آخر را بفرستید. برگرداندن: cp $B/AppDbContext.cs.bak $DBF ; cp $B/Program.cs.bak $PG"; exit 1; fi
cat <<'MSG'

=== مراحل بعد ===
۱) پوشه‌ی لاگ (یک بار، با کاربر root):
     mkdir -p /var/log/digitalpay && chown ghestine:ghestine /var/log/digitalpay
   مسیر دیگر: appsettings → "Logging": { "File": "/مسیر/app-.log" }. لاگ‌ها JSON فشرده و روزانه‌اند، ۳۰ روز نگه داشته می‌شوند.
۲) مایگریشن (بعد از بکاپ دیتابیس). ایندکس پیشنهادی: BackgroundJobs(Status,RunAt) و BackgroundJobs(TenantId,DedupKey).
۳) استفاده: IJobQueue.EnqueueAsync(tenantId, "sms.send", new { phone, text }, runAt, dedupKey). برای کار جدید یک IJobHandler بنویسید و AddScoped کنید.
۴) پایش: GET api/v1/admin/jobs/summary و فهرست کارهای مرده + retry ؛ api/v1/version ؛ api/v1/health (ماژول enterprise).
۵) ماسک لاگ فقط روی پارامترهای قالب لاگ اعمال می‌شود؛ مقدار حساس را داخل رشته‌ی الحاقی ($"...") لاگ نکنید.
۶) Sentry (اختیاری): dotnet add package Sentry.AspNetCore و DSN را فقط در secrets.env بگذارید.
MSG
