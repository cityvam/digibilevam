using Xunit;
using Ghestine.API.Platform;
public class PlatformTests
{
    [Theory]
    [InlineData(1, 15)] [InlineData(2, 60)] [InlineData(3, 240)] [InlineData(4, 960)] [InlineData(5, 3600)] [InlineData(9, 3600)]
    public void BackoffGrowsAndCaps(int attempt, int seconds) => Assert.Equal(TimeSpan.FromSeconds(seconds), JobWorker.Backoff(attempt));
    [Fact] public void MasksNationalCodePhoneAndSecrets()
    {
        Assert.Equal("012***789", MaskEnricher.Mask("0123456789"));
        Assert.Equal("0912***789", MaskEnricher.Mask("09123456789"));
        Assert.DoesNotContain("abcdefghijk", MaskEnricher.Mask("Authorization: Bearer abcdefghijk.lmnop"));
        Assert.DoesNotContain("S3cretPass!", MaskEnricher.Mask("password=S3cretPass!"));
        Assert.Equal("603799******7890", MaskEnricher.Mask("6037991234567890"));
        Assert.Equal("سلام ۱۲۳", MaskEnricher.Mask("سلام ۱۲۳"));
    }
}
