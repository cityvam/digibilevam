using Ghestine.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using __DBNS__;
namespace Ghestine.API.Notify;

public static class NotifyU
{
    /// فقط مسیر داخلی («/…» و نه «//…» یا نشانی کامل) مجاز است تا اعلان به سایت دیگر هدایت نکند.
    public static string SafeLink(string? l) { l = (l ?? "").Trim(); return l.Length is > 0 and <= 200 && l[0] == '/' && !l.StartsWith("//") && !l.Contains('\\') && !l.Any(char.IsControl) && !l.Contains(':') ? l : ""; }
    public static string Cut(string? s, int n) { s = (s ?? "").Trim(); return s.Length <= n ? s : s[..n]; }
}

/// رابط ساخت اعلان؛ ماژول‌های دیگر (پشتیبانی، اعتبارسنجی، درخواست وام) فقط به این وابسته‌اند.
public interface INotifier { Task AddAsync(Guid tenant, Guid user, string kind, string title, string body, string? link, string? dedupeKey = null, DateTime? expiresOn = null, CancellationToken ct = default); }

public class NotificationService : INotifier
{
    private readonly AppDbContext _db; public NotificationService(AppDbContext db) => _db = db;
    public async Task AddAsync(Guid tenant, Guid user, string kind, string title, string body, string? link, string? dedupeKey = null, DateTime? expiresOn = null, CancellationToken ct = default)
    {
        dedupeKey = string.IsNullOrWhiteSpace(dedupeKey) ? null : NotifyU.Cut(dedupeKey, 120);
        if (dedupeKey != null && await _db.Set<CustomerNotification>().AnyAsync(x => x.TenantId == tenant && x.UserId == user && x.DedupeKey == dedupeKey, ct)) return;
        _db.Add(new CustomerNotification { TenantId = tenant, UserId = user, Kind = NotifyU.Cut(kind, 20), Title = NotifyU.Cut(title, 120), Body = NotifyU.Cut(body, 400), Link = NotifyU.SafeLink(link), DedupeKey = dedupeKey, ExpiresOn = expiresOn });
        await _db.SaveChangesAsync(ct);
    }
}

public record Kpi(string Key, string Label, double Value, string? Unit = null, bool Warn = false);

/// شاخص‌های عملیاتی برای داشبورد مدیر. هر گروه فقط با مجوز مربوط نشان داده می‌شود.
public class DashboardService
{
    private readonly AppDbContext _db; public DashboardService(AppDbContext db) => _db = db;
    public async Task<Dictionary<string, List<Kpi>>> BuildAsync(Guid tid, Func<string, bool> can, CancellationToken ct)
    {
        var now = DateTime.UtcNow; var o = new Dictionary<string, List<Kpi>>();
        if (can("contracts.manage") || can("contracts.approve"))
        {
            var c = _db.Set<GeneratedContract>().Where(x => x.TenantId == tid);
            o["قراردادها"] = new()
            {
                new("c_appr", "در انتظار تأیید", await c.CountAsync(x => x.Status == "ReadyForReview", ct)),
                new("c_sign", "منتظر قبول مشتری", await c.CountAsync(x => x.Status == "Presented" || x.Status == "AwaitingSignature", ct)),
                new("c_old", "منتظر قبول بیش از ۳ روز", await c.CountAsync(x => (x.Status == "Presented" || x.Status == "AwaitingSignature") && x.PresentedAt < now.AddDays(-3), ct), null, true),
                new("c_done", "قبول‌شده در ۳۰ روز اخیر", await c.CountAsync(x => x.Status == "Signed" && x.SignedAt > now.AddDays(-30), ct)),
            };
        }
        if (can("documents.review"))
        {
            var d = _db.Set<CustomerDocument>().Where(x => x.TenantId == tid && x.Status == "Pending"); var oldest = await d.OrderBy(x => x.CreatedOn).Select(x => (DateTime?)x.CreatedOn).FirstOrDefaultAsync(ct);
            o["مدارک"] = new() { new("d_pend", "مدرک در انتظار بررسی", await d.CountAsync(ct)), new("d_age", "قدیمی‌ترین در انتظار", oldest == null ? 0 : Math.Round((now - oldest.Value).TotalHours, 1), "ساعت", oldest != null && now - oldest.Value > TimeSpan.FromHours(48)) };
        }
        if (can("tickets.manage"))
        {
            var t = _db.Set<SupportTicket>().Where(x => x.TenantId == tid);
            var avg = await t.Where(x => x.FirstResponseOn != null && x.CreatedOn > now.AddDays(-30)).Select(x => (double?)EF.Functions.DateDiffMinute(x.CreatedOn, x.FirstResponseOn!.Value)).AverageAsync(ct);
            o["پشتیبانی"] = new()
            {
                new("t_open", "تیکت باز", await t.CountAsync(x => x.Status == "Open", ct)),
                new("t_over", "گذشته از مهلت پاسخ", await t.CountAsync(x => x.FirstResponseOn == null && x.Status != "Closed" && x.SlaDueOn < now, ct), null, true),
                new("t_avg", "میانگین زمان پاسخ اول (۳۰ روز)", avg == null ? 0 : Math.Round(avg.Value / 60, 1), "ساعت"),
                new("t_closed", "بسته‌شده در ۳۰ روز اخیر", await t.CountAsync(x => x.Status == "Closed" && x.ClosedOn > now.AddDays(-30), ct)),
            };
        }
        if (can("settings.manage"))
        {
            var j = _db.Set<BackgroundJob>().Where(x => x.TenantId == tid);
            o["سامانه"] = new() { new("j_pend", "کار در صف", await j.CountAsync(x => x.Status == "Pending" || x.Status == "Running", ct)), new("j_dead", "کار مرده (نیازمند بررسی)", await j.CountAsync(x => x.Status == "Dead", ct), null, true) };
        }
        return o;
    }
}
