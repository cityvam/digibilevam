using System.ComponentModel.DataAnnotations;
using Ghestine.Domain.Common;
namespace Ghestine.Domain.Entities;

/// اعلان درون‌برنامه‌ای برای مشتری. لینک فقط مسیر داخلی سایت است.
public class CustomerNotification : BaseEntity
{
    public Guid TenantId { get; set; }
    public Guid UserId { get; set; }
    [MaxLength(20)] public string Kind { get; set; } = "info";       // contract | ticket | loan | payment | info
    [MaxLength(120)] public string Title { get; set; } = string.Empty;
    [MaxLength(400)] public string Body { get; set; } = string.Empty;
    [MaxLength(200)] public string Link { get; set; } = string.Empty;
    [MaxLength(120)] public string? DedupeKey { get; set; }          // برای جلوگیری از اعلان تکراری یک رویداد
    public DateTime? ExpiresOn { get; set; }
    public bool IsRead { get; set; }
    public DateTime CreatedOn { get; set; } = DateTime.UtcNow;
}
