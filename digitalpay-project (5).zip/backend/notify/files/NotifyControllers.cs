using System.Security.Claims;
using Ghestine.Domain.Entities;
using Ghestine.API.Iam;
using Ghestine.API.Tenancy;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using __DBNS__;
namespace Ghestine.API.Notify;

[ApiController, Route("api/v1/me/notifications"), Authorize]
public class MyNotificationsController : ControllerBase
{
    private readonly AppDbContext _db; public MyNotificationsController(AppDbContext db) => _db = db;
    Guid? Me => Guid.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub"), out var g) ? g : null;
    [HttpGet] public async Task<IActionResult> List([FromQuery] bool unread, CancellationToken ct)
    {
        var u = Me; if (u == null) return Unauthorized(); var q = _db.Set<CustomerNotification>().Where(n => n.TenantId == this.Tid() && n.UserId == u); if (unread) q = q.Where(n => !n.IsRead);
        return Ok(await q.OrderByDescending(n => n.CreatedOn).Take(100).Select(n => new { n.Id, n.Kind, n.Title, n.Body, n.Link, n.IsRead, n.CreatedOn }).ToListAsync(ct));
    }
    [HttpGet("count")] public async Task<IActionResult> Count(CancellationToken ct) { var u = Me; if (u == null) return Unauthorized(); return Ok(new { unread = await _db.Set<CustomerNotification>().CountAsync(n => n.TenantId == this.Tid() && n.UserId == u && !n.IsRead, ct) }); }
    [HttpPost("{id:guid}/read")] public async Task<IActionResult> Read(Guid id, CancellationToken ct)
    { var u = Me; if (u == null) return Unauthorized(); var n = await _db.Set<CustomerNotification>().FirstOrDefaultAsync(x => x.Id == id && x.TenantId == this.Tid() && x.UserId == u, ct); if (n == null) return NotFound(); n.IsRead = true; await _db.SaveChangesAsync(ct); return Ok(); }
    [HttpPost("read-all")] public async Task<IActionResult> ReadAll(CancellationToken ct)
    { var u = Me; if (u == null) return Unauthorized(); await _db.Set<CustomerNotification>().Where(n => n.TenantId == this.Tid() && n.UserId == u && !n.IsRead).ExecuteUpdateAsync(s => s.SetProperty(n => n.IsRead, true), ct); return Ok(); }
}

[ApiController, Route("api/v1/admin/dashboard"), Authorize(Roles = "Admin,SuperAdmin")]
public class DashboardController : ControllerBase
{
    private readonly DashboardService _d; private readonly PermissionService _p; public DashboardController(DashboardService d, PermissionService p) { _d = d; _p = p; }
    [HttpGet] public async Task<IActionResult> Get(CancellationToken ct)
    {
        var tid = this.Tid(); var perms = new Dictionary<string, bool>();
        foreach (var k in new[] { "contracts.manage", "contracts.approve", "documents.review", "tickets.manage", "settings.manage" }) perms[k] = await _p.HasAsync(User, tid, k, ct);
        return Ok(await _d.BuildAsync(tid, k => perms.GetValueOrDefault(k), ct));
    }
}
