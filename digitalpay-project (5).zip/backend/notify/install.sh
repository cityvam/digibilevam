#!/bin/bash
# نصب اعلان‌های مشتری و داشبورد مدیر
set -e
ROOT="${1:-/home/ghestine/domains/ghestine.ir/Ghestine}"
HERE="$(cd "$(dirname "$0")" && pwd)"; SRC="$ROOT/src"
[ -d "$SRC" ] || { echo "پوشه src پیدا نشد: $SRC"; exit 1; }
B="$ROOT/.notify-backup-$(date +%Y%m%d%H%M%S)"; mkdir -p "$B"
DBF=$(grep -rl "class AppDbContext" "$SRC" --include=*.cs | head -1); [ -n "$DBF" ] || { echo "AppDbContext پیدا نشد"; exit 1; }
PG="$SRC/Ghestine.API/Program.cs"; CC="$SRC/Ghestine.API/Contracts/ContractControllers.cs"
cp "$PG" "$B/Program.cs.bak"; cp "$DBF" "$B/AppDbContext.cs.bak"; [ -f "$CC" ] && cp "$CC" "$B/ContractControllers.cs.bak"; echo "بکاپ: $B"
BE=$(grep -rl "class BaseEntity" "$SRC" --include=*.cs | head -1); [ -n "$BE" ] || { echo "کلاس BaseEntity پیدا نشد."; exit 1; }
BENS=$(grep -h "^namespace" "$BE" | head -1 | sed 's/namespace //; s/;//; s/\r//')
DBNS=$(grep -h "^namespace" "$DBF" | head -1 | sed 's/namespace //; s/;//; s/\r//')
for c in PermissionService BackgroundJob CustomerDocument GeneratedContract; do grep -rq "class $c" "$SRC" --include=*.cs || { echo "ماژول لازم نصب نیست ($c). ترتیب install-all.sh را رعایت کنید."; exit 1; }; done
cp "$HERE/files/NotifyModule.cs" "$SRC/Ghestine.Domain/Entities/NotifyModule.cs"
sed -i "s/^using Ghestine.Domain.Common;/using $BENS;/" "$SRC/Ghestine.Domain/Entities/NotifyModule.cs"
mkdir -p "$SRC/Ghestine.API/Notify"; for f in NotifyServices NotifyControllers; do cp "$HERE/files/$f.cs" "$SRC/Ghestine.API/Notify/$f.cs"; sed -i "s/__DBNS__/$DBNS/" "$SRC/Ghestine.API/Notify/$f.cs"; done
grep -q "DbSet<Ghestine.Domain.Entities.CustomerNotification>" "$DBF" || {
  grep -q "protected override void OnModelCreating" "$DBF" || { echo "OnModelCreating پیدا نشد؛ DbSet را دستی اضافه کنید"; exit 1; }
  sed -i "0,/protected override void OnModelCreating/s//public DbSet<Ghestine.Domain.Entities.CustomerNotification> CustomerNotifications => Set<Ghestine.Domain.Entities.CustomerNotification>();\n\n    protected override void OnModelCreating/" "$DBF"; }
grep -q "DbSet<Ghestine.Domain.Entities.CustomerNotification>" "$DBF" || { echo "درج DbSet انجام نشد. بکاپ: $B"; exit 1; }
grep -q "NotificationService" "$PG" || sed -i '0,/var app = builder.Build();/s//builder.Services.AddScoped<Ghestine.API.Notify.NotificationService>();\nbuilder.Services.AddScoped<Ghestine.API.Notify.DashboardService>();\n\nvar app = builder.Build();/' "$PG"
# INotifier (رابط اعلان برای پشتیبانی/اعتبارسنجی/درخواست وام) — جدا از بالا تا روی نصب قدیمی هم اضافه شود
grep -q "INotifier" "$PG" || sed -i '0,/var app = builder.Build();/s//builder.Services.AddScoped<Ghestine.API.Notify.INotifier, Ghestine.API.Notify.NotificationService>();\n\nvar app = builder.Build();/' "$PG"
grep -q "INotifier" "$PG" || { echo "ثبت INotifier در Program.cs انجام نشد. برگرداندن: cp $B/Program.cs.bak $PG"; exit 1; }
grep -q "DashboardService" "$PG" || { echo "ثبت سرویس در Program.cs انجام نشد. برگرداندن: cp $B/Program.cs.bak $PG"; exit 1; }
# اتصال: وقتی قرارداد به مشتری ارائه می‌شود، اعلان ساخته شود (یک خط، همان تراکنش)
if [ -f "$CC" ] && ! grep -q "CustomerNotification" "$CC"; then
  sed -i 's|c.Status = t.to; await _db.SaveChangesAsync(ct);|c.Status = t.to; if (op == "present") _db.Add(new CustomerNotification { TenantId = c.TenantId, UserId = c.UserId, Kind = "contract", Title = "قرارداد جدید برای مشاهده و قبول شما", Body = c.Title, Link = "/app/contracts/" + c.Id }); await _db.SaveChangesAsync(ct);|' "$CC"
  grep -q "CustomerNotification" "$CC" || { echo "اتصال اعلان به قرارداد انجام نشد (متن فایل تغییر کرده)؛ بقیه‌ی نصب ادامه دارد."; }
fi
cd "$ROOT"
if dotnet build 2>&1 | tee /tmp/notify-build.log | tail -15 | grep -q "Build succeeded"; then echo "ساخت موفق."; else
  echo "خطای build؛ ۱۵ خط آخر را بفرستید. برگرداندن: cp $B/AppDbContext.cs.bak $DBF ; cp $B/Program.cs.bak $PG ; [ -f $B/ContractControllers.cs.bak ] && cp $B/ContractControllers.cs.bak $CC"; exit 1; fi
cat <<'MSG'

=== مراحل بعد ===
۱) مایگریشن (بعد از بکاپ). ایندکس پیشنهادی: CustomerNotifications(TenantId,UserId,IsRead,CreatedOn).
۲) مشتری: /app/inbox ؛ API: api/v1/me/notifications (+count, read, read-all). مدیر: /admin و api/v1/admin/dashboard.
۳) اعلان‌ها فعلاً از دو رویداد ساخته می‌شوند: ارائه‌ی قرارداد و پاسخ پشتیبان. برای رویداد دیگر: NotificationService.AddAsync(tenant, user, kind, title, body, "/nojs/…").
MSG
