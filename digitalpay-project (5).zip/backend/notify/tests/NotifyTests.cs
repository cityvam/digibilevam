using Xunit;
using Ghestine.API.Notify;
public class NotifyTests
{
    [Theory]
    [InlineData("/app/tickets/abc", "/app/tickets/abc")] [InlineData("//evil.com", "")] [InlineData("https://evil.com", "")]
    [InlineData("javascript:alert(1)", "")] [InlineData("/ok\\..\\evil", "")] [InlineData("", "")] [InlineData("/a:b", "")]
    public void SafeLinkOnlyAllowsInternalPaths(string input, string expected) => Assert.Equal(expected, NotifyU.SafeLink(input));
    [Fact] public void CutLimitsLength() => Assert.Equal(3, NotifyU.Cut("abcdef", 3).Length);
}
