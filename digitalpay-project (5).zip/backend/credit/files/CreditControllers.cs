using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Ghestine.Domain.Entities;
using Ghestine.API.Iam;
using Ghestine.API.Security;
using Ghestine.API.Tenancy;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using __DBNS__;
namespace Ghestine.API.Credit;

public record CrStartIn(string NationalCode, string MobileNumber, string? LegalNationalCode, bool Consent);
public record CrAdminStartIn(Guid UserId, string NationalCode, string MobileNumber, string? LegalNationalCode, bool Consent);
public record CrOtpIn(string Token);
public record CrSettingsIn(bool Enabled, bool AutoFetchReport, int RetentionDays, decimal? MinScore);

static class CrU
{
    public static Guid? Me(this ControllerBase c) => Guid.TryParse(c.User.FindFirstValue(ClaimTypes.NameIdentifier) ?? c.User.FindFirstValue("sub"), out var g) ? g : null;
    public static string Ip(this ControllerBase c) => c.HttpContext.Connection.RemoteIpAddress?.ToString() ?? "";
    /// نمای ایمن برای مشتری و مدیر؛ هیچ‌وقت کد ملی کامل، موبایل کامل، HashCode یا ReportCode برنمی‌گردد.
    public static object View(CreditRequest r) => new
    {
        r.Id, r.Code, r.NcMask, r.MobileMask, r.Status, r.StatusTitle, r.Submitted, r.OtpSends, maxOtpSends = Cr.MaxOtpSends, r.ResendLocked,
        resendIn = r.ResendUntil == null ? 0 : Math.Max(0, (int)Math.Ceiling((r.ResendUntil.Value - DateTime.UtcNow).TotalSeconds)),
        r.HashExpiresOn, r.ReportExpiresOn, r.ReportAt, hasReport = r.ReportEnc != null, reportReady = Cr.Ready(r.Status), canRegenerate = Cr.CanRegenerate(r.Status) && r.HashExpiresOn > DateTime.UtcNow,
        r.Score, r.Settled, r.Source, r.CreatedOn, r.UpdatedOn, r.OtpMessageStatus, r.ReportMessageStatus, r.LastError, legal = r.LegalNcEnc != null,
    };
}

/// مشتری: استعلام اعتبار خودش
[ApiController, Route("api/v1/me/credit"), Authorize]
public class MyCreditController : ControllerBase
{
    private readonly AppDbContext _db; private readonly CreditService _s;
    public MyCreditController(AppDbContext db, CreditService s) { _db = db; _s = s; }
    async Task<CreditRequest?> Mine(Guid id, CancellationToken ct) { var u = this.Me(); return u == null ? null : await _db.Set<CreditRequest>().FirstOrDefaultAsync(x => x.Id == id && x.TenantId == this.Tid() && x.UserId == u, ct); }
    IActionResult Res(CrResult r) => r.Ok ? Ok(new { request = CrU.View(r.R!), wait = r.WaitSeconds }) : BadRequest(new { message = r.Error, request = r.R == null ? null : CrU.View(r.R), wait = r.WaitSeconds });

    [HttpGet] public async Task<IActionResult> List(CancellationToken ct)
    { var u = this.Me(); if (u == null) return Unauthorized(); var xs = await _db.Set<CreditRequest>().Where(x => x.TenantId == this.Tid() && x.UserId == u).OrderByDescending(x => x.CreatedOn).Take(50).ToListAsync(ct); return Ok(xs.Select(CrU.View)); }
    [HttpGet("{id:guid}")] public async Task<IActionResult> One(Guid id, CancellationToken ct) { var r = await Mine(id, ct); return r == null ? NotFound() : Ok(CrU.View(r)); }
    [HttpPost] public async Task<IActionResult> Start(CrStartIn i, CancellationToken ct)
    { var u = this.Me(); if (u == null) return Unauthorized(); return Res(await _s.StartAsync(this.Tid(), u.Value, i.NationalCode, i.MobileNumber, i.LegalNationalCode, i.Consent, this.Ip(), "Customer", null, ct)); }
    [HttpPost("{id:guid}/resend")] public async Task<IActionResult> Resend(Guid id, CancellationToken ct) { var r = await Mine(id, ct); return r == null ? NotFound() : Res(await _s.ResendOtpAsync(r, null, ct)); }
    [HttpPost("{id:guid}/otp")] public async Task<IActionResult> Otp(Guid id, CrOtpIn i, CancellationToken ct) { var r = await Mine(id, ct); return r == null ? NotFound() : Res(await _s.SubmitOtpAsync(r, i.Token, null, ct)); }
    /// پرسش وضعیت؛ برای جلوگیری از فشار روی سرویس‌دهنده حداکثر هر ۵ ثانیه یک‌بار واقعاً به سرویس‌دهنده می‌رود.
    [HttpPost("{id:guid}/refresh")] public async Task<IActionResult> Refresh(Guid id, CancellationToken ct)
    {
        var r = await Mine(id, ct); if (r == null) return NotFound(); if (r.Settled || (r.LastPolledOn != null && r.LastPolledOn > DateTime.UtcNow.AddSeconds(-5))) return Ok(new { request = CrU.View(r) });
        return Res(await _s.RefreshAsync(r, "Api", null, ct));
    }
    [HttpPost("{id:guid}/regenerate")] public async Task<IActionResult> Regen(Guid id, CancellationToken ct) { var r = await Mine(id, ct); return r == null ? NotFound() : Res(await _s.ReGenerateAsync(r, null, ct)); }
    [HttpGet("{id:guid}/report")] public async Task<IActionResult> Report(Guid id, CancellationToken ct)
    {
        var r = await Mine(id, ct); if (r == null) return NotFound(); if (!Cr.Ready(r.Status)) return Conflict(new { message = "گزارش هنوز آماده نیست." });
        if (r.ReportEnc == null) { var f = await _s.FetchReportAsync(r, null, ct); if (!f.Ok) return BadRequest(new { message = f.Error }); }
        return Ok(new { request = CrU.View(r), report = JsonSerializer.Deserialize<JsonElement>(_s.ReportJson(r)!) });
    }
    [HttpGet("{id:guid}/pdf")] public async Task<IActionResult> Pdf(Guid id, CancellationToken ct)
    {
        var r = await Mine(id, ct); if (r == null) return NotFound(); var (b, e) = await _s.PdfAsync(r, null, ct); if (b == null) return BadRequest(new { message = e });
        Response.Headers["Cache-Control"] = "no-store"; Response.Headers["X-Content-Type-Options"] = "nosniff"; return File(b, "application/pdf", "credit-" + r.Code + ".pdf");
    }
}

/// مدیر: مدیریت درخواست‌ها، بازتولید، ریزلاگ سرویس‌دهنده، تنظیمات
[ApiController, Route("api/v1/admin/credit"), Authorize(Roles = "Admin,SuperAdmin")]
public class CreditAdminController : ControllerBase
{
    private readonly AppDbContext _db; private readonly CreditService _s; private readonly MyCreditClient _c;
    public CreditAdminController(AppDbContext db, CreditService s, MyCreditClient c) { _db = db; _s = s; _c = c; }
    async Task<CreditRequest?> One(Guid id, CancellationToken ct) => await _db.Set<CreditRequest>().FirstOrDefaultAsync(x => x.Id == id && x.TenantId == this.Tid(), ct);
    IActionResult Res(CrResult r) => r.Ok ? Ok(new { request = CrU.View(r.R!), wait = r.WaitSeconds }) : BadRequest(new { message = r.Error, request = r.R == null ? null : CrU.View(r.R) });

    [HttpGet, RequirePermission("credit.view")]
    public async Task<IActionResult> List([FromQuery] string? status, [FromQuery] string? q, [FromQuery] int page = 1, CancellationToken ct = default)
    {
        var xs = _db.Set<CreditRequest>().Where(x => x.TenantId == this.Tid());
        if (!string.IsNullOrEmpty(status)) xs = xs.Where(x => x.Status == status);
        if (!string.IsNullOrWhiteSpace(q)) { q = q.Trim(); xs = xs.Where(x => x.Code.Contains(q) || x.NcMask.StartsWith(q) || x.MobileMask.StartsWith(q)); }
        var total = await xs.CountAsync(ct); page = Math.Max(1, page);
        var items = await xs.OrderByDescending(x => x.CreatedOn).Skip((page - 1) * 50).Take(50).ToListAsync(ct);
        return Ok(new { total, page, items = items.Select(x => new { v = CrU.View(x), x.UserId }) });
    }
    [HttpGet("{id:guid}"), RequirePermission("credit.view")]
    public async Task<IActionResult> Detail(Guid id, CancellationToken ct)
    {
        var r = await One(id, ct); if (r == null) return NotFound();
        var ev = await _db.Set<CreditEvent>().Where(e => e.RequestId == id).OrderByDescending(e => e.CreatedOn).Take(200).Select(e => new { e.Kind, e.Op, e.Ok, e.Reason, e.Message, e.Ms, e.ActorId, e.CreatedOn }).ToListAsync(ct);
        return Ok(new { request = CrU.View(r), r.UserId, events = ev });
    }
    /// محتوای گزارش فقط با مجوز جدا (credit.report). هر بار دیدن در حسابرسی ثبت می‌شود (GET ثبت نمی‌شود؛ پس خود را در رویدادها می‌نویسیم).
    [HttpGet("{id:guid}/report"), RequirePermission("credit.report")]
    public async Task<IActionResult> Report(Guid id, CancellationToken ct)
    {
        var r = await One(id, ct); if (r == null) return NotFound(); if (!Cr.Ready(r.Status)) return Conflict(new { message = "گزارش هنوز آماده نیست." });
        if (r.ReportEnc == null) { var f = await _s.FetchReportAsync(r, this.Me(), ct); if (!f.Ok) return BadRequest(new { message = f.Error }); }
        _db.Add(new CreditEvent { TenantId = r.TenantId, RequestId = r.Id, Kind = "Admin", Op = "view-report", Ok = true, ActorId = this.Me() }); await _db.SaveChangesAsync(ct);
        return Ok(new { request = CrU.View(r), report = JsonSerializer.Deserialize<JsonElement>(_s.ReportJson(r)!) });
    }
    [HttpGet("{id:guid}/pdf"), RequirePermission("credit.report")]
    public async Task<IActionResult> Pdf(Guid id, CancellationToken ct)
    {
        var r = await One(id, ct); if (r == null) return NotFound(); var (b, e) = await _s.PdfAsync(r, this.Me(), ct); if (b == null) return BadRequest(new { message = e });
        Response.Headers["Cache-Control"] = "no-store"; Response.Headers["X-Content-Type-Options"] = "nosniff"; return File(b, "application/pdf", "credit-" + r.Code + ".pdf");
    }
    [HttpPost, RequirePermission("credit.manage")]
    public async Task<IActionResult> Start(CrAdminStartIn i, CancellationToken ct)
    {
        if (i.UserId == Guid.Empty) return BadRequest(new { message = "شناسه‌ی مشتری الزامی است." });
        return Res(await _s.StartAsync(this.Tid(), i.UserId, i.NationalCode, i.MobileNumber, i.LegalNationalCode, i.Consent, this.Ip(), "Admin", this.Me(), ct));
    }
    [HttpPost("{id:guid}/otp"), RequirePermission("credit.manage")] public async Task<IActionResult> Otp(Guid id, CrOtpIn i, CancellationToken ct) { var r = await One(id, ct); return r == null ? NotFound() : Res(await _s.SubmitOtpAsync(r, i.Token, this.Me(), ct)); }
    [HttpPost("{id:guid}/resend"), RequirePermission("credit.manage")] public async Task<IActionResult> Resend(Guid id, CancellationToken ct) { var r = await One(id, ct); return r == null ? NotFound() : Res(await _s.ResendOtpAsync(r, this.Me(), ct)); }
    [HttpPost("{id:guid}/refresh"), RequirePermission("credit.manage")] public async Task<IActionResult> Refresh(Guid id, CancellationToken ct) { var r = await One(id, ct); return r == null ? NotFound() : Res(await _s.RefreshAsync(r, "Admin", this.Me(), ct)); }
    [HttpPost("{id:guid}/regenerate"), RequirePermission("credit.manage")] public async Task<IActionResult> Regen(Guid id, CancellationToken ct) { var r = await One(id, ct); return r == null ? NotFound() : Res(await _s.ReGenerateAsync(r, this.Me(), ct)); }

    /// وضعیت اتصال: تنظیم‌شدن، فعال‌بودن، و (اختیاری) تست ورود به سرویس‌دهنده. هیچ مقدار محرمانه‌ای برنمی‌گردد.
    [HttpGet("health"), RequirePermission("credit.view")]
    public async Task<IActionResult> Health([FromQuery] bool test, CancellationToken ct)
    {
        var st = await CrSettings.LoadAsync(_db, this.Tid(), ct); object? t = null;
        if (test && _c.Configured) { var sw = System.Diagnostics.Stopwatch.StartNew(); var r = await _c.LoginAsync(ct); t = new { ok = r.Ok, reason = r.Reason, message = r.Ok ? "ورود موفق بود." : r.Message, ms = sw.ElapsedMilliseconds }; }
        var since = DateTime.UtcNow.AddDays(-30); var q = _db.Set<CreditRequest>().Where(x => x.TenantId == this.Tid() && x.CreatedOn > since);
        return Ok(new
        {
            configured = _c.Configured, callbackConfigured = !string.IsNullOrEmpty(_c.CallbackSecret) && _c.CallbackSecret!.Length >= 24, settings = st, test = t,
            stats = new { total = await q.CountAsync(ct), ready = await q.CountAsync(x => x.Status == "ReportGenerated" || x.Status == "Success", ct), failed = await q.CountAsync(x => x.Status == "ReportGenerationFailed" || x.Status == "ReportGeneratedButDataLost" || x.Status == "IdentityCheckFailed" || x.Status.StartsWith("NotMatching"), ct), open = await q.CountAsync(x => !x.Settled, ct) },
        });
    }
    [HttpPut("settings"), RequirePermission("settings.manage")]
    public async Task<IActionResult> Save(CrSettingsIn i, CancellationToken ct)
    {
        if (i.RetentionDays is < 1 or > 365) return BadRequest(new { message = "مدت نگهداری گزارش باید بین ۱ تا ۳۶۵ روز باشد." }); if (i.MinScore is < 0 or > 100000) return BadRequest(new { message = "حداقل امتیاز نامعتبر است." });
        await CrSettings.SaveAsync(_db, this.Tid(), new(i.Enabled, i.AutoFetchReport, i.RetentionDays, i.MinScore), ct); return Ok();
    }
    /// ریزلاگ سمت سرویس‌دهنده (بخش ۱۱ مستند): فرمت تاریخ میلادی yyyy-MM-dd
    [HttpGet("records"), RequirePermission("credit.view")]
    public async Task<IActionResult> Records([FromQuery] string? from, [FromQuery] string? to, [FromQuery] int sort = -1, [FromQuery] int page = 1, [FromQuery] int size = 50, CancellationToken ct = default)
    {
        DateTime? f = null, t = null;
        if (!string.IsNullOrEmpty(from)) { if (!DateTime.TryParseExact(from, "yyyy-MM-dd", null, System.Globalization.DateTimeStyles.None, out var a)) return BadRequest(new { message = "تاریخ شروع نامعتبر است." }); f = a; }
        if (!string.IsNullOrEmpty(to)) { if (!DateTime.TryParseExact(to, "yyyy-MM-dd", null, System.Globalization.DateTimeStyles.None, out var b)) return BadRequest(new { message = "تاریخ پایان نامعتبر است." }); t = b; }
        if (f != null && f < DateTime.UtcNow.AddMonths(-3).Date) return BadRequest(new { message = "تاریخ شروع حداکثر ۳ ماه قبل می‌تواند باشد." }); if (f != null && t != null && (t < f || t > f.Value.AddMonths(1))) return BadRequest(new { message = "بازه‌ی تاریخ حداکثر ۱ ماه است." });
        var r = await _c.RecordsAsync(f, t, sort, page, Math.Min(size, 200), ct); if (!r.Ok) return BadRequest(new { message = r.Message });
        return Ok(JsonSerializer.Deserialize<JsonElement>(r.Root.GetRawText()));
    }
}

/// کال‌بک سرویس‌دهنده (بخش ۷ مستند): GET .../callback/{secret}?message=...
/// امنیت: ۱) راز در مسیر (مقایسه‌ی زمان‌ثابت) ۲) پیام فقط محرک است و وضعیت با پرسش مستقیم از سرویس‌دهنده تأیید می‌شود ۳) همیشه ۲۰۰ ساده؛ هیچ اطلاعاتی بازتاب نمی‌شود.
/// آدرس نهایی را (مثلاً https://ghestine.ir/api/v1/credit/callback/<راز>) به شرکت اعتبارسنجی ایران بدهید تا در پروفایل شما ثبت کنند.
[ApiController, Route("api/v1/credit/callback"), AllowAnonymous]
public class CreditCallbackController : ControllerBase
{
    private readonly CreditService _s; private readonly MyCreditClient _c; private readonly IRateLimiter _rl;
    public CreditCallbackController(CreditService s, MyCreditClient c, IRateLimiter rl) { _s = s; _c = c; _rl = rl; }
    [HttpGet("{secret}")]
    public async Task<IActionResult> Hit(string secret, [FromQuery] string? message, CancellationToken ct)
    {
        var want = _c.CallbackSecret ?? ""; if (want.Length < 24) return NotFound();
        var ok = CryptographicOperations.FixedTimeEquals(SHA256.HashData(Encoding.UTF8.GetBytes(secret)), SHA256.HashData(Encoding.UTF8.GetBytes(want))); if (!ok) return NotFound();
        if (!_rl.Hit("crcb:" + (HttpContext.Connection.RemoteIpAddress?.ToString() ?? "?"), 120, TimeSpan.FromMinutes(1))) return StatusCode(429);
        try { await _s.OnCallbackAsync(message ?? "", ct); } catch (Exception) { /* خطای داخلی نباید به سرویس‌دهنده برگردد؛ پرسش دوره‌ای وضعیت جبران می‌کند */ }
        return Ok("ok");
    }
}
