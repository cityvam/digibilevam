using System.ComponentModel.DataAnnotations;
using Ghestine.Domain.Common;
namespace Ghestine.Domain.Entities;

/// یک درخواست اعتبارسنجی نزد «اعتبارسنجی ایران» (MyCreditAPIs).
/// کد ملی، موبایل، HashCode و محتوای گزارش فقط رمزنگاری‌شده (DataProtection) ذخیره می‌شوند؛ در فهرست‌ها فقط نسخه‌ی ماسک‌شده دیده می‌شود.
public class CreditRequest : BaseEntity
{
    public Guid TenantId { get; set; }
    public Guid UserId { get; set; }                                   // مشتری صاحب گزارش
    [MaxLength(20)] public string Code { get; set; } = string.Empty;    // کد قابل ارائه به مشتری مثل C-7K3Q9X
    public string RealNcEnc { get; set; } = string.Empty;
    public string MobileEnc { get; set; } = string.Empty;
    public string? LegalNcEnc { get; set; }                             // شناسه‌ی ملی شرکت (شخص حقوقی)، اختیاری
    [MaxLength(16)] public string NcMask { get; set; } = string.Empty;   // 0015******
    [MaxLength(16)] public string MobileMask { get; set; } = string.Empty; // 0912*****32
    public string HashCodeEnc { get; set; } = string.Empty;             // کد یکتای درخواست نزد سرویس‌دهنده (۲۴ ساعت معتبر)
    [MaxLength(64)] public string HashKey { get; set; } = string.Empty;  // HMAC کد، فقط برای پیدا کردن درخواست در کال‌بک
    [MaxLength(48)] public string Status { get; set; } = "Entry";        // مقدارهای سرویس‌دهنده یا Expired
    [MaxLength(160)] public string StatusTitle { get; set; } = string.Empty;
    public bool Submitted { get; set; }                                  // مشتری رمز یکبارمصرف را فرستاده است
    public int OtpSends { get; set; } = 1;                               // حداکثر ۵ بار ارسال مجدد
    public int OtpTries { get; set; }
    public DateTime? ResendUntil { get; set; }
    public bool ResendLocked { get; set; }
    public int? OtpMessageStatus { get; set; }                           // وضعیت پیامک رمز (۲..۶)
    public int? ReportMessageStatus { get; set; }
    [MaxLength(300)] public string? ReportCode { get; set; }             // انتهای لینک گزارش نزد سرویس‌دهنده
    public string? ReportEnc { get; set; }                               // JSON گزارش (رمزنگاری‌شده)
    public decimal? Score { get; set; }                                  // خلاصه‌ی استخراج‌شده از گزارش (در صورت وجود)
    public DateTime? ReportAt { get; set; }
    public DateTime? ReportExpiresOn { get; set; }                       // اعتبار دریافت از سرویس‌دهنده: ۴۸ ساعت
    public DateTime HashExpiresOn { get; set; }                          // ۲۴ ساعت از ساخت
    public DateTime? ConsentAt { get; set; }                             // رضایت‌نامه‌ی استعلام (الزامی)
    [MaxLength(45)] public string ConsentIp { get; set; } = string.Empty;
    [MaxLength(10)] public string Source { get; set; } = "Customer";     // Customer | Admin
    public Guid? CreatedBy { get; set; }
    public int PollCount { get; set; }
    public DateTime? LastPolledOn { get; set; }
    [MaxLength(300)] public string LastError { get; set; } = string.Empty;
    public bool Settled { get; set; }                                     // دیگر نیازی به پرسش مجدد وضعیت نیست
    public DateTime CreatedOn { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedOn { get; set; } = DateTime.UtcNow;
}

/// ردپای هر تماس با سرویس‌دهنده و هر کال‌بک (بدون توکن، رمز یکبارمصرف یا محتوای گزارش).
public class CreditEvent : BaseEntity
{
    public Guid TenantId { get; set; }
    public Guid RequestId { get; set; }
    [MaxLength(12)] public string Kind { get; set; } = "Api";            // Api | Callback | Admin | Job
    [MaxLength(40)] public string Op { get; set; } = string.Empty;       // request | renew | validate | status | regenerate | report | pdf
    [MaxLength(60)] public string Reason { get; set; } = string.Empty;
    [MaxLength(300)] public string Message { get; set; } = string.Empty;
    public bool Ok { get; set; }
    public int Ms { get; set; }
    public Guid? ActorId { get; set; }
    public DateTime CreatedOn { get; set; } = DateTime.UtcNow;
}
