using System.Diagnostics;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Ghestine.Domain.Entities;
using Ghestine.API.Core;
using Ghestine.API.Notify;
using Ghestine.API.Platform;
using Ghestine.API.Security;
using Microsoft.EntityFrameworkCore;
using __DBNS__;
namespace Ghestine.API.Credit;

/// ثابت‌ها و توابع خالص (بدون وابستگی) مطابق مستند ICS.IT.MyCredit MNL V3.2
public static class Cr
{
    /// وضعیت‌های سرویس «بررسی وضعیت درخواست» (بخش ۶ مستند)
    public static readonly Dictionary<string, string> Fa = new()
    {
        ["Success"] = "دریافت موفقیت‌آمیز گزارش", ["Entry"] = "ثبت درخواست", ["OTPSent"] = "رمز یکبارمصرف ارسال شد", ["OTPLocked"] = "دریافت مجدد رمز قفل شد",
        ["OTPAccepted"] = "رمز پذیرفته شد", ["OTPCheckFailed"] = "رمز اشتباه است", ["OTPResend"] = "رمز مجدد ارسال شد",
        ["NotMatchingRealPersonNationalCodeAndMobileNumber"] = "کد ملی و شماره‌ی همراه با هم تطابق ندارند", ["NotMatchingRealPersonAndLegalPerson"] = "کد ملی و شناسه‌ی ملی شرکت تطابق ندارند",
        ["IdentityCheckAccepted"] = "احراز هویت انجام شد", ["ReportGenerated"] = "گزارش آماده است", ["ReportGeneratedButDataLost"] = "گزارش ساخته شد اما داده‌ها از دست رفت",
        ["ReportGenerationFailed"] = "ساخت گزارش ناموفق بود", ["IdentityCheckFailed"] = "احراز هویت ناموفق بود", ["InQueue"] = "در صف پردازش", ["Expired"] = "مهلت درخواست تمام شد",
    };
    public static string Title(string s) => Fa.TryGetValue(s, out var t) ? t : "وضعیت نامشخص";
    /// پیام‌های خطای سرویس‌دهنده (Reason ← متن فارسی). متن خام سرویس‌دهنده هرگز مستقیم به مشتری نشان داده نمی‌شود.
    public static readonly Dictionary<string, string> Err = new()
    {
        ["IncorrectAPIKey"] = "کلید اتصال (ApiKey) نادرست است.", ["APIKeyNotExists"] = "کلید اتصال (ApiKey) وجود ندارد.", ["InvalidIP"] = "نشانی IP این سرور در سرویس‌دهنده ثبت نشده است.",
        ["UserLocked"] = "سرویس اعتبارسنجی غیرفعال شده است.", ["Forbidden"] = "دسترسی محدود است.", ["Forbiden"] = "دسترسی محدود است.", ["OTPFailed"] = "ارسال پیامک ناموفق بود؛ کمی بعد دوباره تلاش کنید.",
        ["DataError"] = "خطای سیستمی سرویس‌دهنده.", ["Error"] = "خطای سیستمی سرویس‌دهنده.", ["ResendLocked"] = "سقف ارسال مجدد رمز پر شده است؛ تا ۲۴ ساعت با پشتیبانی تماس بگیرید.",
        ["ResendWait"] = "چند لحظه‌ی دیگر دوباره تلاش کنید.", ["DoubleClickError"] = "درخواست قبلی هنوز کامل نشده است.", ["InProccessing"] = "درخواست در حال پردازش است.", ["InProccessingOrSucceed"] = "بازتولید گزارش برای این درخواست ممکن نیست.",
        ["RequestProccessedBefore"] = "این درخواست قبلاً پردازش شده است.", ["RequestExpired"] = "مهلت این درخواست تمام شده است.", ["IncorrectToken"] = "رمز واردشده صحیح نیست.", ["TokenExpired"] = "اعتبار رمز تمام شده است؛ رمز جدید بگیرید.",
        ["OtpLocked"] = "درخواست قفل شده است.", ["ShahkarError"] = "خطا در استعلام شاهکار.", ["SherkathaError"] = "خطا در استعلام شرکت‌ها.", ["ShahkarFailed"] = "کد ملی و شماره‌ی موبایل با هم تطابق ندارند.",
        ["SherkathaFailed"] = "شناسه‌ی ملی شرکت و کد ملی تطابق ندارند.", ["GenerateReportFailed"] = "دریافت گزارش با خطا مواجه شد.", ["ReportExpired"] = "زمان دریافت گزارش تمام شده است.", ["OutputTypeNotSupported"] = "نوع خروجی نامعتبر است.",
        ["BadInput"] = "ورودی نامعتبر است.", ["Unavailable"] = "سرویس اعتبارسنجی در دسترس نیست؛ کمی بعد دوباره تلاش کنید.", ["NotConfigured"] = "اتصال به سرویس اعتبارسنجی هنوز تنظیم نشده است.",
    };
    public static string ErrFa(string? reason) => reason != null && Err.TryGetValue(reason, out var m) ? m : "خطای ناشناخته از سرویس اعتبارسنجی.";
    /// خطاهایی که با تلاش دوباره درست می‌شوند (نه خطای ورودی)
    public static bool Transient(string? reason) => reason is "Unavailable" or "DataError" or "Error" or "InProccessing" or "DoubleClickError" or "ResendWait";

    public static readonly HashSet<string> CallbackEvents = new() { "OTPAccepted", "OTPLocked", "ShahkarFailed", "SherkathaFailed", "ShahkarError", "SherkathaError", "IdentityCheckAccepted", "ReportGenerated", "GenerateReportFailed", "ReportDataLost" };
    static readonly Regex HashRx = new(@"^[A-Za-z0-9_\-=+/.]{6,300}$", RegexOptions.Compiled), CodeRx = new(@"^[A-Za-z0-9_\-=+/.]{3,300}$", RegexOptions.Compiled);
    /// پیام کال‌بک: «رویداد-hashCode» یا «ReportGenerated-hashCode@{Baseurl}/report/{reportCode}&hashCode=..&reportLink=..»
    public static bool CodeOk(string c) => CodeRx.IsMatch(c);
    public static (string Event, string Hash, string? ReportCode)? ParseCallback(string? msg)
    {
        if (string.IsNullOrWhiteSpace(msg) || msg.Length > 2000) return null;
        msg = msg.Trim().Trim('"'); var dash = msg.IndexOf('-'); if (dash <= 0) return null;
        var ev = msg[..dash]; if (!CallbackEvents.Contains(ev)) return null;
        var rest = msg[(dash + 1)..]; var at = rest.IndexOf('@'); var hash = at < 0 ? rest : rest[..at]; if (!HashRx.IsMatch(hash)) return null;
        string? code = null;
        if (at >= 0)
        {
            var tail = rest[(at + 1)..]; var i = tail.IndexOf("/report/", StringComparison.OrdinalIgnoreCase);
            if (i >= 0) { var c = tail[(i + 8)..]; var amp = c.IndexOf('&'); if (amp >= 0) c = c[..amp]; if (CodeRx.IsMatch(c)) code = c; }
        }
        return (ev, hash, code);
    }
    /// زمان‌بندی پرسش وضعیت: ۵،۱۰،۲۰،۳۰ ثانیه، سپس هر ۶۰ ثانیه تا ۱۰ دقیقه، بعد هر ۵ دقیقه (کال‌بک اگر بیاید سریع‌تر است)
    public static TimeSpan PollDelay(int pollCount) => pollCount switch { 0 => TimeSpan.FromSeconds(5), 1 => TimeSpan.FromSeconds(10), 2 => TimeSpan.FromSeconds(20), 3 => TimeSpan.FromSeconds(30), < 14 => TimeSpan.FromSeconds(60), _ => TimeSpan.FromMinutes(5) };
    /// مهلت انتظار بین ارسال‌های رمز طبق مستند (۱۲۰، ۱۸۰، ۲۷۰ ثانیه ...) فقط برای نمایش پیش‌فرض اگر سرویس‌دهنده مقدار نداد
    public static int DefaultResendWait(int sends) => sends <= 1 ? 120 : sends == 2 ? 180 : 270;
    public const int MaxOtpSends = 5;
    public static string Mask(string? v, int head, int tail) { v ??= ""; if (v.Length <= head + tail) return new string('*', v.Length); return v[..head] + new string('*', v.Length - head - tail) + v[^tail..]; }
    public static bool MobileOk(string? m) => m != null && Regex.IsMatch(m, @"^09\d{9}$");
    public static bool OtpOk(string? t) => t != null && Regex.IsMatch(t, @"^\d{4,8}$");
    /// وضعیت‌هایی که کار تمام‌شده‌اند (پرسش مجدد لازم نیست). «ساخت ناموفق» با بازتولید دستی ادامه می‌یابد.
    public static bool IsSettled(string status) => status is "ReportGenerated" or "Success" or "IdentityCheckFailed" or "OTPLocked" or "ReportGenerationFailed" or "ReportGeneratedButDataLost" or "Expired" || status.StartsWith("NotMatching");
    public static bool CanRegenerate(string status) => status is "ReportGenerationFailed" or "ReportGeneratedButDataLost";
    public static bool Ready(string status) => status is "ReportGenerated" or "Success";
    /// خلاصه‌ی گزارش: نام کلیدی که شامل score/امتیاز است را (به‌صورت بازگشتی) پیدا می‌کند. ساختار گزارش در مستند نیامده؛ تا دیدن نمونه‌ی واقعی، بهترین تلاش است.
    public static decimal? FindScore(JsonElement e, int depth = 0)
    {
        if (depth > 8) return null;
        if (e.ValueKind == JsonValueKind.Object)
        {
            foreach (var p in e.EnumerateObject())
                if (Regex.IsMatch(p.Name, "score|امتیاز", RegexOptions.IgnoreCase) && p.Value.ValueKind == JsonValueKind.Number && p.Value.TryGetDecimal(out var d)) return d;
            foreach (var p in e.EnumerateObject()) { var r = FindScore(p.Value, depth + 1); if (r != null) return r; }
        }
        else if (e.ValueKind == JsonValueKind.Array) foreach (var x in e.EnumerateArray().Take(50)) { var r = FindScore(x, depth + 1); if (r != null) return r; }
        return null;
    }
}

public class CrResp
{
    public bool Ok { get; init; } public int Http { get; init; } public JsonElement Data { get; init; } public string? Reason { get; init; } public string? Message { get; init; } public byte[]? Bytes { get; init; } public JsonElement Root { get; init; }
    public static CrResp Fail(string reason, string? msg = null, int http = 0) => new() { Ok = false, Reason = reason, Message = msg ?? Cr.ErrFa(reason), Http = http };
}

/// کلاینت MyCreditAPIs. توکن‌ها فقط در حافظه‌ی همین فرایند نگهداری می‌شوند. نام کاربری/رمز/ApiKey از پیکربندی محرمانه‌ی سرور خوانده می‌شود:
/// MyCredit:BaseUrl ، MyCredit:Username ، MyCredit:Password ، MyCredit:ApiKey (اختیاری؛ در نبود آن مقدار apiKey پاسخ لاگین استفاده می‌شود)
public class MyCreditClient
{
    private readonly IHttpClientFactory _hf; private readonly IConfiguration _cfg; private readonly ILogger<MyCreditClient> _log;
    private readonly SemaphoreSlim _gate = new(1, 1);
    private string? _access, _refresh, _apiKey; private DateTime _accessExp, _refreshExp;
    public MyCreditClient(IHttpClientFactory hf, IConfiguration cfg, ILogger<MyCreditClient> log) { _hf = hf; _cfg = cfg; _log = log; }
    string Base => (_cfg["MyCredit:BaseUrl"] ?? "").TrimEnd('/');
    public bool Configured => Base.Length > 0 && !string.IsNullOrEmpty(_cfg["MyCredit:Username"]) && !string.IsNullOrEmpty(_cfg["MyCredit:Password"]) && (Base.StartsWith("https://") || _cfg["MyCredit:AllowHttp"] == "true");
    public string? CallbackSecret => _cfg["MyCredit:CallbackSecret"];
    public void Invalidate() { _access = _refresh = null; }

    static CrResp Parse(HttpResponseMessage r, string body, byte[]? raw)
    {
        if ((int)r.StatusCode == 401) return CrResp.Fail("Unauthorized", "نشست سرویس‌دهنده منقضی شد.", 401);
        if ((int)r.StatusCode >= 500 || (int)r.StatusCode == 429) return CrResp.Fail("Unavailable", null, (int)r.StatusCode);
        try
        {
            using var d = JsonDocument.Parse(body); var root = d.RootElement.Clone(); var he = root.ValueKind == JsonValueKind.Object && root.TryGetProperty("hasError", out var h) && h.ValueKind == JsonValueKind.True;
            if (he || !r.IsSuccessStatusCode)
            {
                string? reason = null, msg = null;
                if (root.ValueKind == JsonValueKind.Object && root.TryGetProperty("messages", out var ms) && ms.ValueKind == JsonValueKind.Array && ms.GetArrayLength() > 0) { var m0 = ms[0]; if (m0.TryGetProperty("reason", out var rr)) reason = rr.GetString(); }
                reason ??= r.StatusCode == System.Net.HttpStatusCode.Forbidden ? "Forbidden" : "BadInput"; msg = Cr.ErrFa(reason);
                return CrResp.Fail(reason, msg, (int)r.StatusCode);
            }
            return new CrResp { Ok = true, Http = (int)r.StatusCode, Root = root, Data = root.ValueKind == JsonValueKind.Object && root.TryGetProperty("data", out var dd) ? dd : default };
        }
        catch (JsonException) { return raw != null && r.IsSuccessStatusCode ? new CrResp { Ok = true, Http = (int)r.StatusCode, Bytes = raw } : CrResp.Fail("DataError", null, (int)r.StatusCode); }
    }

    async Task<CrResp> Raw(HttpMethod m, string path, Dictionary<string, string>? form, string? bearer, bool apiKey, string? version, CancellationToken ct, bool binary = false)
    {
        var http = _hf.CreateClient("mycredit"); http.Timeout = TimeSpan.FromSeconds(25);
        using var req = new HttpRequestMessage(m, Base + path);
        if (form != null) req.Content = new FormUrlEncodedContent(form);
        if (bearer != null) req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", bearer);
        if (apiKey) req.Headers.TryAddWithoutValidation("x-apikey", _cfg["MyCredit:ApiKey"] ?? _apiKey ?? "");
        if (version != null) req.Headers.TryAddWithoutValidation("x-version", version);
        req.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        try
        {
            using var r = await http.SendAsync(req, ct); var raw = await r.Content.ReadAsByteArrayAsync(ct);
            if (binary && r.IsSuccessStatusCode && !(r.Content.Headers.ContentType?.MediaType ?? "").Contains("json")) return new CrResp { Ok = true, Http = (int)r.StatusCode, Bytes = raw };
            return Parse(r, Encoding.UTF8.GetString(raw), binary ? raw : null);
        }
        catch (TaskCanceledException) when (!ct.IsCancellationRequested) { return CrResp.Fail("Unavailable", "پاسخی از سرویس‌دهنده نرسید."); }
        catch (HttpRequestException) { return CrResp.Fail("Unavailable"); }
    }

    /// بخش ۱: دریافت AccessToken (POST /Connect/Token) — x-www-form-urlencoded
    public Task<CrResp> LoginAsync(CancellationToken ct) => Raw(HttpMethod.Post, "/Connect/Token", new() { ["username"] = _cfg["MyCredit:Username"] ?? "", ["password"] = _cfg["MyCredit:Password"] ?? "" }, null, false, null, ct);
    /// بخش ۲: RefreshToken (PUT /Connect/Token)
    Task<CrResp> RefreshAsync(CancellationToken ct) => Raw(HttpMethod.Put, "/Connect/Token", new() { ["accessToken"] = _access ?? "", ["refreshToken"] = _refresh ?? "" }, _access, false, null, ct);

    static string? Str(JsonElement e, string n) => e.ValueKind == JsonValueKind.Object && e.TryGetProperty(n, out var p) && p.ValueKind == JsonValueKind.String ? p.GetString() : null;
    async Task<CrResp?> EnsureToken(CancellationToken ct)
    {
        if (!Configured) return CrResp.Fail("NotConfigured");
        if (_access != null && DateTime.UtcNow < _accessExp) return null;
        await _gate.WaitAsync(ct);
        try
        {
            if (_access != null && DateTime.UtcNow < _accessExp) return null;
            if (_refresh != null && DateTime.UtcNow < _refreshExp)
            {
                var rr = await RefreshAsync(ct);
                if (rr.Ok && Str(rr.Data, "accessToken") is { Length: > 0 } na) { _access = na; if (Str(rr.Data, "refreshToken") is { Length: > 0 } nr) _refresh = nr; _accessExp = DateTime.UtcNow.AddHours(11); return null; }
            }
            var l = await LoginAsync(ct); if (!l.Ok) return l;
            _access = Str(l.Data, "accessToken"); if (string.IsNullOrEmpty(_access)) return CrResp.Fail("DataError", "پاسخ ورود شامل توکن نبود.");
            _refresh = Str(l.Data, "refreshToken"); _apiKey = Str(l.Data, "apiKey");
            _accessExp = DateTime.UtcNow.AddHours(11); _refreshExp = DateTime.UtcNow.AddHours(23); return null;     // اعتبار: توکن ۱۲ ساعت، رفرش ۲۴ ساعت (با حاشیه‌ی ایمنی)
        }
        finally { _gate.Release(); }
    }
    /// درخواست احرازشده؛ با ۴۰۱ یک‌بار توکن را تازه می‌کند و دوباره می‌فرستد.
    async Task<CrResp> Auth(HttpMethod m, string path, Dictionary<string, string>? form, string? version, CancellationToken ct, bool binary = false)
    {
        for (var i = 0; i < 2; i++)
        {
            var e = await EnsureToken(ct); if (e != null) return e;
            var r = await Raw(m, path, form, _access, true, version, ct, binary);
            if (r.Reason == "Unauthorized" && i == 0) { Invalidate(); _accessExp = DateTime.MinValue; continue; }
            return r;
        }
        return CrResp.Fail("Unavailable");
    }
    static string Seg(string s) => Uri.EscapeDataString(s);
    /// بخش ۳: ارسال درخواست (POST /b2b/api/request) ← data = HashCode
    public Task<CrResp> RequestAsync(string realNc, string mobile, string? legalNc, CancellationToken ct) { var f = new Dictionary<string, string> { ["RealPersonNationalCode"] = realNc, ["MobileNumber"] = mobile }; if (!string.IsNullOrEmpty(legalNc)) f["LegalPersonNationalCode"] = legalNc; return Auth(HttpMethod.Post, "/b2b/api/request", f, null, ct); }
    /// بخش ۴: ارسال مجدد رمز یکبارمصرف ← data { resendWait, resendLocked }
    public Task<CrResp> RenewOtpAsync(string hash, CancellationToken ct) => Auth(HttpMethod.Post, $"/b2b/api/request/{Seg(hash)}/renewToken", null, null, ct);
    /// بخش ۵: بررسی صحت اطلاعات و ایجاد گزارش (Token در بدنه)
    public Task<CrResp> ValidateAsync(string hash, string token, CancellationToken ct) => Auth(HttpMethod.Post, $"/b2b/api/request/{Seg(hash)}/validate", new() { ["Token"] = token }, null, ct);
    /// بخش ۶: بررسی وضعیت درخواست
    public Task<CrResp> StatusAsync(string hash, CancellationToken ct) => Auth(HttpMethod.Get, $"/b2b/api/request/{Seg(hash)}/status", null, null, ct);
    /// بخش ۸: ارسال مجدد درخواست گزارش‌گیری (فقط ReportGenerationFailed / ReportGeneratedButDataLost؛ تا ۲۴ ساعت)
    public Task<CrResp> ReGenerateAsync(string hash, CancellationToken ct) => Auth(HttpMethod.Post, $"/b2b/api/request/{Seg(hash)}/reGenerateReport", null, null, ct);
    /// بخش ۹: اطلاعات گزارش (JSON نسخه‌ی ۲٫۰؛ اعتبار ۴۸ ساعت). reportCode فقط انتهای لینک گزارش است.
    public Task<CrResp> ReportJsonAsync(string reportCode, CancellationToken ct) => Auth(HttpMethod.Get, $"/Report/{Seg(reportCode)}/json", null, "2.0", ct);
    /// بخش ۱۰: فایل PDF (ByteArray؛ در خطا JSON)
    public Task<CrResp> ReportPdfAsync(string reportCode, CancellationToken ct) => Auth(HttpMethod.Get, $"/b2b/api/request/{Seg(reportCode)}/pdfReport", null, "2.0", ct, binary: true);
    /// بخش ۱۱: ریزلاگ درخواست‌ها (fromDate/toDate میلادی yyyy-MM-dd؛ حداکثر ۳ ماه قبل، بازه‌ی حداکثر ۱ ماه)
    public Task<CrResp> RecordsAsync(DateTime? from, DateTime? to, int sort, int page, int size, CancellationToken ct)
    {
        var q = new List<string>(); if (from != null) q.Add("fromDate=" + from.Value.ToString("yyyy-MM-dd")); if (to != null) q.Add("toDate=" + to.Value.ToString("yyyy-MM-dd"));
        q.Add("sort=" + (sort == -1 ? -1 : 1)); q.Add("page=" + Math.Max(1, page)); q.Add("size=" + Math.Clamp(size, 1, 1000));
        return Auth(HttpMethod.Get, "/Record/requests?" + string.Join("&", q), null, null, ct);
    }
}

public record CrSettings(bool Enabled, bool AutoFetchReport, int RetentionDays, decimal? MinScore)
{
    public static async Task<CrSettings> LoadAsync(AppDbContext db, Guid tid, CancellationToken ct)
    {
        var m = await db.Set<AppSetting>().Where(x => x.TenantId == tid && x.Key.StartsWith("credit.")).ToDictionaryAsync(x => x.Key, x => x.Value, ct);
        bool B(string k, bool d) => m.TryGetValue(k, out var v) ? v == "true" : d;
        int.TryParse(m.GetValueOrDefault("credit.retentionDays"), out var rd); decimal.TryParse(m.GetValueOrDefault("credit.minScore"), System.Globalization.NumberStyles.Number, System.Globalization.CultureInfo.InvariantCulture, out var ms);
        return new(B("credit.enabled", true), B("credit.autoFetchReport", true), rd is >= 1 and <= 365 ? rd : 30, m.ContainsKey("credit.minScore") && ms > 0 ? ms : null);
    }
    public static async Task SaveAsync(AppDbContext db, Guid tid, CrSettings s, CancellationToken ct)
    {
        async Task Set(string k, string v) { var x = await db.Set<AppSetting>().FirstOrDefaultAsync(a => a.TenantId == tid && a.Key == k, ct); if (x == null) db.Add(new AppSetting { TenantId = tid, Key = k, Value = v }); else x.Value = v; }
        await Set("credit.enabled", s.Enabled ? "true" : "false"); await Set("credit.autoFetchReport", s.AutoFetchReport ? "true" : "false"); await Set("credit.retentionDays", s.RetentionDays.ToString());
        await Set("credit.minScore", s.MinScore?.ToString(System.Globalization.CultureInfo.InvariantCulture) ?? ""); await db.SaveChangesAsync(ct);
    }
}

public record CrResult(bool Ok, string? Error = null, CreditRequest? R = null, int? WaitSeconds = null);

/// منطق جریان: شروع ← رمز ← اعتبارسنجی ← پرسش وضعیت/کال‌بک ← گزارش. همه‌ی مسیرها (مشتری، مدیر، کال‌بک، صف کار) از همین‌جا می‌گذرند.
public class CreditService
{
    private readonly AppDbContext _db; private readonly MyCreditClient _c; private readonly ICardCrypto _crypto; private readonly IRateLimiter _rl; private readonly IJobQueue _jobs; private readonly INotifier _n;
    public CreditService(AppDbContext db, MyCreditClient c, ICardCrypto crypto, IRateLimiter rl, IJobQueue jobs, INotifier n) { _db = db; _c = c; _crypto = crypto; _rl = rl; _jobs = jobs; _n = n; }
    static string NewCode() { const string a = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"; var b = RandomNumberGenerator.GetBytes(6); return "C-" + new string(b.Select(x => a[x % a.Length]).ToArray()); }
    void Ev(CreditRequest r, string kind, string op, CrResp? resp, Guid? actor, int ms, string? note = null) =>
        _db.Add(new CreditEvent { TenantId = r.TenantId, RequestId = r.Id, Kind = kind, Op = op, Ok = resp?.Ok ?? true, Reason = resp?.Reason ?? "", Message = Notify.NotifyU.Cut(note ?? resp?.Message ?? "", 300), Ms = ms, ActorId = actor });
    async Task<(CrResp R, int Ms)> Timed(Func<Task<CrResp>> f) { var sw = Stopwatch.StartNew(); var r = await f(); return (r, (int)sw.ElapsedMilliseconds); }
    public string Hash(CreditRequest r) => _crypto.Unprotect(r.HashCodeEnc);
    public string Nc(CreditRequest r) => _crypto.Unprotect(r.RealNcEnc);

    public async Task<CrResult> StartAsync(Guid tid, Guid userId, string nc, string mobile, string? legalNc, bool consent, string ip, string source, Guid? actor, CancellationToken ct)
    {
        nc = (nc ?? "").Trim(); mobile = (mobile ?? "").Trim(); legalNc = string.IsNullOrWhiteSpace(legalNc) ? null : legalNc.Trim();
        var st = await CrSettings.LoadAsync(_db, tid, ct);
        if (!_c.Configured || !st.Enabled) return new(false, Cr.ErrFa(_c.Configured ? "Forbidden" : "NotConfigured"));
        if (!consent) return new(false, "برای استعلام، تأیید رضایت‌نامه الزامی است.");
        if (!Iran.NationalCodeOk(nc)) return new(false, "کد ملی نامعتبر است."); if (!Cr.MobileOk(mobile)) return new(false, "شماره‌ی موبایل نامعتبر است.");
        if (legalNc != null && !Regex.IsMatch(legalNc, @"^\d{11}$")) return new(false, "شناسه‌ی ملی شرکت باید ۱۱ رقم باشد.");
        if (!_rl.Hit("cr:" + userId, 3, TimeSpan.FromHours(1))) return new(false, "تعداد درخواست‌های این ساعت به حد مجاز رسیده است.");
        var now = DateTime.UtcNow; var mask = Cr.Mask(nc, 4, 0);
        // درخواست باز همان کد ملی (۲۴ ساعت) دوباره ساخته نمی‌شود؛ هزینه و پیامک تکراری ندارد
        var open = await _db.Set<CreditRequest>().Where(x => x.TenantId == tid && x.UserId == userId && x.NcMask == mask && !x.Settled && x.HashExpiresOn > now).OrderByDescending(x => x.CreatedOn).FirstOrDefaultAsync(ct);
        if (open != null && _crypto.Unprotect(open.RealNcEnc) == nc) return new(true, null, open);
        var (resp, ms) = await Timed(() => _c.RequestAsync(nc, mobile, legalNc, ct));
        var r = new CreditRequest { TenantId = tid, UserId = userId, Code = NewCode(), RealNcEnc = _crypto.Protect(nc), MobileEnc = _crypto.Protect(mobile), LegalNcEnc = legalNc == null ? null : _crypto.Protect(legalNc), NcMask = Cr.Mask(nc, 4, 0), MobileMask = Cr.Mask(mobile, 4, 2),
            ConsentAt = now, ConsentIp = Notify.NotifyU.Cut(ip, 45), Source = source, CreatedBy = actor, HashExpiresOn = now.AddHours(24), Status = "Entry", StatusTitle = Cr.Title("Entry") };
        if (!resp.Ok) { Ev(r, "Api", "request", resp, actor, ms); await _db.SaveChangesAsync(ct); return new(false, resp.Message); }
        var h = resp.Data.ValueKind == JsonValueKind.String ? resp.Data.GetString() : null; if (string.IsNullOrEmpty(h)) { Ev(r, "Api", "request", CrResp.Fail("DataError"), actor, ms); await _db.SaveChangesAsync(ct); return new(false, Cr.ErrFa("DataError")); }
        r.HashCodeEnc = _crypto.Protect(h); r.HashKey = _crypto.Hash("cr-h:" + h); r.Status = "OTPSent"; r.StatusTitle = Cr.Title("OTPSent"); r.ResendUntil = now.AddSeconds(Cr.DefaultResendWait(1));
        _db.Add(r); Ev(r, "Api", "request", resp, actor, ms); await _db.SaveChangesAsync(ct); return new(true, null, r, Cr.DefaultResendWait(1));
    }

    public async Task<CrResult> ResendOtpAsync(CreditRequest r, Guid? actor, CancellationToken ct)
    {
        if (r.Settled || r.HashExpiresOn < DateTime.UtcNow) return new(false, Cr.ErrFa("RequestExpired"), r);
        if (r.Submitted) return new(false, "رمز قبلاً ثبت شده است.", r);
        if (r.OtpSends >= Cr.MaxOtpSends || r.ResendLocked) return new(false, Cr.ErrFa("ResendLocked"), r);
        if (r.ResendUntil != null && r.ResendUntil > DateTime.UtcNow) return new(false, "برای ارسال مجدد باید " + (int)Math.Ceiling((r.ResendUntil.Value - DateTime.UtcNow).TotalSeconds) + " ثانیه صبر کنید.", r, (int)Math.Ceiling((r.ResendUntil.Value - DateTime.UtcNow).TotalSeconds));
        var (resp, ms) = await Timed(() => _c.RenewOtpAsync(Hash(r), ct)); Ev(r, actor == null ? "Api" : "Admin", "renew", resp, actor, ms);
        if (!resp.Ok) { await _db.SaveChangesAsync(ct); return new(false, resp.Message, r); }
        var wait = resp.Data.ValueKind == JsonValueKind.Object && resp.Data.TryGetProperty("resendWait", out var w) && w.TryGetInt32(out var wi) ? wi : Cr.DefaultResendWait(r.OtpSends + 1);
        r.ResendLocked = resp.Data.ValueKind == JsonValueKind.Object && resp.Data.TryGetProperty("resendLocked", out var l) && l.ValueKind == JsonValueKind.True;
        r.OtpSends++; r.ResendUntil = DateTime.UtcNow.AddSeconds(wait); r.Status = "OTPResend"; r.StatusTitle = Cr.Title("OTPResend"); r.UpdatedOn = DateTime.UtcNow; await _db.SaveChangesAsync(ct); return new(true, null, r, wait);
    }

    /// رمز یکبارمصرف هرگز ذخیره یا لاگ نمی‌شود؛ فقط به سرویس‌دهنده فرستاده می‌شود.
    public async Task<CrResult> SubmitOtpAsync(CreditRequest r, string token, Guid? actor, CancellationToken ct)
    {
        if (r.Settled || r.HashExpiresOn < DateTime.UtcNow) return new(false, Cr.ErrFa("RequestExpired"), r);
        if (r.Submitted) return new(false, "رمز قبلاً ثبت شده و درخواست در حال پردازش است.", r);
        if (!Cr.OtpOk(token)) return new(false, "رمز یکبارمصرف را درست وارد کنید.", r);
        if (r.OtpTries >= 5) return new(false, "تعداد تلاش‌های رمز به حد مجاز رسیده است.", r);
        r.OtpTries++;
        var (resp, ms) = await Timed(() => _c.ValidateAsync(Hash(r), token, ct)); Ev(r, actor == null ? "Api" : "Admin", "validate", resp, actor, ms);
        if (!resp.Ok)
        {
            if (resp.Reason is "OtpLocked") { r.Status = "OTPLocked"; r.StatusTitle = Cr.Title("OTPLocked"); r.Settled = true; }
            else if (resp.Reason is "RequestExpired" or "ReportExpired") { r.Status = "Expired"; r.StatusTitle = Cr.Title("Expired"); r.Settled = true; }
            else if (resp.Reason is "ShahkarFailed") { r.Status = "NotMatchingRealPersonNationalCodeAndMobileNumber"; r.StatusTitle = Cr.Title(r.Status); r.Settled = true; }
            else if (resp.Reason is "SherkathaFailed") { r.Status = "NotMatchingRealPersonAndLegalPerson"; r.StatusTitle = Cr.Title(r.Status); r.Settled = true; }
            r.LastError = Notify.NotifyU.Cut(resp.Message, 300); r.UpdatedOn = DateTime.UtcNow; await _db.SaveChangesAsync(ct); return new(false, resp.Message, r);
        }
        r.Submitted = true; r.Status = "OTPAccepted"; r.StatusTitle = Cr.Title("OTPAccepted"); r.LastError = ""; r.UpdatedOn = DateTime.UtcNow; await _db.SaveChangesAsync(ct);
        await ScheduleAsync(r, ct); return new(true, null, r);
    }

    public Task ScheduleAsync(CreditRequest r, CancellationToken ct, bool now = false) =>
        _jobs.EnqueueAsync(r.TenantId, "credit.poll", new { id = r.Id }, DateTime.UtcNow + (now ? TimeSpan.Zero : Cr.PollDelay(r.PollCount)), "crp-" + r.Id.ToString("N") + "-" + r.PollCount + (now ? "n" : ""), 3, ct);

    /// پرسش وضعیت از سرویس‌دهنده و به‌روزرسانی رکورد؛ در صورت آماده بودن گزارش، (اگر تنظیم باشد) محتوا هم گرفته می‌شود.
    public async Task<CrResult> RefreshAsync(CreditRequest r, string kind, Guid? actor, CancellationToken ct)
    {
        if (r.HashExpiresOn < DateTime.UtcNow && !r.Settled) { r.Status = "Expired"; r.StatusTitle = Cr.Title("Expired"); r.Settled = true; r.UpdatedOn = DateTime.UtcNow; await _db.SaveChangesAsync(ct); return new(true, null, r); }
        var (resp, ms) = await Timed(() => _c.StatusAsync(Hash(r), ct)); Ev(r, kind, "status", resp, actor, ms); r.PollCount++; r.LastPolledOn = DateTime.UtcNow;
        if (!resp.Ok)
        {
            r.LastError = Notify.NotifyU.Cut(resp.Message, 300);
            if (resp.Reason is "RequestExpired" or "ReportExpired") { r.Status = "Expired"; r.StatusTitle = Cr.Title("Expired"); r.Settled = true; }
            await _db.SaveChangesAsync(ct); return new(false, resp.Message, r);
        }
        var d = resp.Data; string S(string n) => d.ValueKind == JsonValueKind.Object && d.TryGetProperty(n, out var p) && p.ValueKind == JsonValueKind.String ? p.GetString() ?? "" : "";
        int? I(string n) => d.ValueKind == JsonValueKind.Object && d.TryGetProperty(n, out var p) && p.ValueKind == JsonValueKind.Number && p.TryGetInt32(out var v) ? v : null;
        var was = r.Status; var s = S("status"); if (s.Length > 0 && s.Length <= 48) r.Status = s; r.StatusTitle = Cr.Title(r.Status);
        r.OtpMessageStatus = I("otpMessageStatus") ?? r.OtpMessageStatus; r.ReportMessageStatus = I("reportUrlMessageStatus") ?? r.ReportMessageStatus;
        var rc = S("reportCode"); if (rc.Length is > 0 and <= 300 && Cr.CodeOk(rc)) r.ReportCode = rc;      // مستند بخش ۶: reportCode در خروجی وضعیت هم می‌آید
        var link = S("reportLink"); if (link.Length > 0 && string.IsNullOrEmpty(rc)) { var code = link.TrimEnd('/'); code = code[(code.LastIndexOf('/') + 1)..]; if (code.Length is > 0 and <= 300) r.ReportCode = code; }
        r.LastError = ""; r.UpdatedOn = DateTime.UtcNow; if (Cr.IsSettled(r.Status)) r.Settled = true;
        if (Cr.Ready(r.Status) && r.ReportExpiresOn == null) r.ReportExpiresOn = DateTime.UtcNow.AddHours(48);   // فقط بار اول؛ پرسش‌های بعدی مهلت را تمدید نکنند
        await _db.SaveChangesAsync(ct);
        if (Cr.Ready(r.Status) && r.ReportEnc == null && r.ReportCode != null && (await CrSettings.LoadAsync(_db, r.TenantId, ct)).AutoFetchReport) await FetchReportAsync(r, actor, ct);
        if (was != r.Status && Cr.IsSettled(r.Status)) await NotifyAsync(r, ct);
        if (!r.Settled && r.Submitted) await ScheduleAsync(r, ct);
        return new(true, null, r);
    }

    public async Task<CrResult> FetchReportAsync(CreditRequest r, Guid? actor, CancellationToken ct)
    {
        if (r.ReportCode == null) return new(false, "کد گزارش هنوز دریافت نشده است.", r);
        if (r.ReportExpiresOn != null && r.ReportExpiresOn < DateTime.UtcNow && r.ReportEnc == null) return new(false, Cr.ErrFa("ReportExpired"), r);
        var (resp, ms) = await Timed(() => _c.ReportJsonAsync(r.ReportCode, ct)); Ev(r, actor == null ? "Api" : "Admin", "report", resp, actor, ms);
        if (!resp.Ok) { r.LastError = Notify.NotifyU.Cut(resp.Message, 300); await _db.SaveChangesAsync(ct); return new(false, resp.Message, r); }
        var json = resp.Data.ValueKind == JsonValueKind.Undefined ? resp.Root.GetRawText() : resp.Data.GetRawText();
        r.ReportEnc = _crypto.Protect(json); r.ReportAt = DateTime.UtcNow; r.Score = resp.Data.ValueKind == JsonValueKind.Undefined ? null : Cr.FindScore(resp.Data); r.UpdatedOn = DateTime.UtcNow;
        await _db.SaveChangesAsync(ct); return new(true, null, r);
    }
    public string? ReportJson(CreditRequest r) => r.ReportEnc == null ? null : _crypto.Unprotect(r.ReportEnc);

    public async Task<CrResult> ReGenerateAsync(CreditRequest r, Guid? actor, CancellationToken ct)
    {
        if (!Cr.CanRegenerate(r.Status)) return new(false, Cr.ErrFa("InProccessingOrSucceed"), r);
        if (r.HashExpiresOn < DateTime.UtcNow) return new(false, Cr.ErrFa("RequestExpired"), r);
        var (resp, ms) = await Timed(() => _c.ReGenerateAsync(Hash(r), ct)); Ev(r, actor == null ? "Api" : "Admin", "regenerate", resp, actor, ms);
        if (!resp.Ok) { await _db.SaveChangesAsync(ct); return new(false, resp.Message, r); }
        r.Status = "InQueue"; r.StatusTitle = Cr.Title("InQueue"); r.Settled = false; r.Submitted = true; r.UpdatedOn = DateTime.UtcNow; await _db.SaveChangesAsync(ct); await ScheduleAsync(r, ct, true); return new(true, null, r);
    }

    public async Task<(byte[]? Pdf, string? Err)> PdfAsync(CreditRequest r, Guid? actor, CancellationToken ct)
    {
        if (!Cr.Ready(r.Status) || r.ReportCode == null) return (null, "گزارش هنوز آماده نیست.");
        if (r.ReportExpiresOn != null && r.ReportExpiresOn < DateTime.UtcNow) return (null, Cr.ErrFa("ReportExpired"));
        var (resp, ms) = await Timed(() => _c.ReportPdfAsync(r.ReportCode, ct)); Ev(r, actor == null ? "Api" : "Admin", "pdf", resp, actor, ms); await _db.SaveChangesAsync(ct);
        if (!resp.Ok) return (null, resp.Message); if (resp.Bytes == null || resp.Bytes.Length < 5 || !(resp.Bytes[0] == 0x25 && resp.Bytes[1] == 0x50)) return (null, "فایل PDF معتبر دریافت نشد."); return (resp.Bytes, null);   // «%P» امضای PDF
    }

    async Task NotifyAsync(CreditRequest r, CancellationToken ct)
    {
        var ok = Cr.Ready(r.Status);
        await _n.AddAsync(r.TenantId, r.UserId, "credit", ok ? "گزارش اعتبارسنجی شما آماده است" : "نتیجه‌ی درخواست اعتبارسنجی", ok ? "می‌توانید گزارش را ببینید." : r.StatusTitle, "/app/credit/" + r.Id, "cr-" + r.Id + "-" + r.Status, null, ct);
    }

    /// از کال‌بک: پیام سرویس‌دهنده «محرک» است، نه منبع حقیقت؛ وضعیت همیشه با پرسش مستقیم از سرویس‌دهنده تأیید می‌شود.
    public async Task<bool> OnCallbackAsync(string message, CancellationToken ct)
    {
        var p = Cr.ParseCallback(message); if (p == null) return false;
        var key = _crypto.Hash("cr-h:" + p.Value.Hash); var r = await _db.Set<CreditRequest>().FirstOrDefaultAsync(x => x.HashKey == key, ct); if (r == null) return false;
        _db.Add(new CreditEvent { TenantId = r.TenantId, RequestId = r.Id, Kind = "Callback", Op = p.Value.Event, Ok = true }); await _db.SaveChangesAsync(ct);
        await ScheduleAsync(r, ct, true); return true;
    }

    public async Task<CreditRequest?> LatestReadyAsync(Guid tid, Guid userId, CancellationToken ct) =>
        await _db.Set<CreditRequest>().Where(x => x.TenantId == tid && x.UserId == userId && (x.Status == "ReportGenerated" || x.Status == "Success")).OrderByDescending(x => x.ReportAt ?? x.CreatedOn).FirstOrDefaultAsync(ct);
}

/// کار صف: credit.poll {id}
public class CreditPollHandler : IJobHandler
{
    private readonly AppDbContext _db; private readonly CreditService _s; public CreditPollHandler(AppDbContext db, CreditService s) { _db = db; _s = s; }
    public string Type => "credit.poll";
    public async Task HandleAsync(Guid tenant, JsonElement p, CancellationToken ct)
    {
        var id = p.GetProperty("id").GetGuid(); var r = await _db.Set<CreditRequest>().FirstOrDefaultAsync(x => x.Id == id && x.TenantId == tenant, ct); if (r == null || r.Settled) return;
        var res = await _s.RefreshAsync(r, "Job", null, ct);
        if (!res.Ok && !r.Settled && r.Submitted) await _s.ScheduleAsync(r, ct);       // خطای گذرا: دوباره با فاصله (در موفقیت، RefreshAsync خودش زمان‌بندی می‌کند)
    }
}

/// نگهداری: منقضی‌کردن درخواست‌های بی‌پایان و پاک‌سازی محتوای گزارش بعد از مدت نگهداری (پیش‌فرض ۳۰ روز).
public class CreditMaintenance : BackgroundService
{
    private readonly IServiceScopeFactory _sf; private readonly ILogger<CreditMaintenance> _log; public CreditMaintenance(IServiceScopeFactory sf, ILogger<CreditMaintenance> log) { _sf = sf; _log = log; }
    protected override async Task ExecuteAsync(CancellationToken ct)
    {
        await Task.Delay(TimeSpan.FromMinutes(1), ct).ContinueWith(_ => { });
        while (!ct.IsCancellationRequested)
        {
            try
            {
                using var sc = _sf.CreateScope(); var db = sc.ServiceProvider.GetRequiredService<AppDbContext>(); var now = DateTime.UtcNow;
                foreach (var r in await db.Set<CreditRequest>().Where(x => !x.Settled && x.HashExpiresOn < now).Take(200).ToListAsync(ct)) { r.Status = "Expired"; r.StatusTitle = Cr.Title("Expired"); r.Settled = true; r.UpdatedOn = now; }
                foreach (var tid in await db.Set<CreditRequest>().Where(x => x.ReportEnc != null).Select(x => x.TenantId).Distinct().ToListAsync(ct))
                {
                    var st = await CrSettings.LoadAsync(db, tid, ct); var cut = now.AddDays(-st.RetentionDays);
                    foreach (var r in await db.Set<CreditRequest>().Where(x => x.TenantId == tid && x.ReportEnc != null && x.ReportAt < cut).Take(200).ToListAsync(ct)) { r.ReportEnc = null; r.UpdatedOn = now; }
                }
                await db.SaveChangesAsync(ct);
            }
            catch (OperationCanceledException) { return; }
            catch (Exception ex) { _log.LogError(ex, "Credit maintenance failed"); }
            try { await Task.Delay(TimeSpan.FromMinutes(30), ct); } catch (OperationCanceledException) { return; }
        }
    }
}
