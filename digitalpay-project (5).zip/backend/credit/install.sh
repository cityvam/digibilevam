#!/bin/bash
# نصب ماژول اعتبارسنجی (اعتبارسنجی ایران — MyCreditAPIs v3.2): جریان کامل مشتری، مدیریت، کال‌بک، صف کار و نگهداری
set -e
ROOT="${1:-/home/ghestine/domains/ghestine.ir/Ghestine}"
HERE="$(cd "$(dirname "$0")" && pwd)"; SRC="$ROOT/src"
[ -d "$SRC" ] || { echo "پوشه src پیدا نشد: $SRC"; exit 1; }
B="$ROOT/.credit-backup-$(date +%Y%m%d%H%M%S)"; mkdir -p "$B"
DBF=$(grep -rl "class AppDbContext" "$SRC" --include=*.cs | head -1); [ -n "$DBF" ] || { echo "AppDbContext پیدا نشد"; exit 1; }
PG="$SRC/Ghestine.API/Program.cs"; IAM=$(grep -rl "class Perms" "$SRC" --include=*.cs | head -1)
cp "$PG" "$B/Program.cs.bak"; cp "$DBF" "$B/AppDbContext.cs.bak"; [ -n "$IAM" ] && cp "$IAM" "$B/Iam.cs.bak"; echo "بکاپ: $B"
BE=$(grep -rl "class BaseEntity" "$SRC" --include=*.cs | head -1); [ -n "$BE" ] || { echo "کلاس BaseEntity پیدا نشد."; exit 1; }
BENS=$(grep -h "^namespace" "$BE" | head -1 | sed 's/namespace //; s/;//; s/\r//')
DBNS=$(grep -h "^namespace" "$DBF" | head -1 | sed 's/namespace //; s/;//; s/\r//')
for need in "class PermissionService:iam" "interface INotifier:notify" "interface IRateLimiter:security" "interface IJobQueue:platform" "interface ICardCrypto:core" "class AppSetting:ops"; do
  grep -rq "${need%%:*}" "$SRC" --include=*.cs || { echo "ابتدا ماژول ${need##*:} را نصب کنید."; exit 1; }; done
cp "$HERE/files/CreditModule.cs" "$SRC/Ghestine.Domain/Entities/CreditModule.cs"
sed -i "s/^using Ghestine.Domain.Common;/using $BENS;/" "$SRC/Ghestine.Domain/Entities/CreditModule.cs"
mkdir -p "$SRC/Ghestine.API/Credit"; for f in CreditServices CreditControllers; do cp "$HERE/files/$f.cs" "$SRC/Ghestine.API/Credit/$f.cs"; sed -i "s/__DBNS__/$DBNS/" "$SRC/Ghestine.API/Credit/$f.cs"; done
addset(){ grep -q "DbSet<Ghestine.Domain.Entities.$1>" "$DBF" && return 0
  grep -q "protected override void OnModelCreating" "$DBF" || { echo "OnModelCreating پیدا نشد؛ DbSet ها را دستی اضافه کنید"; exit 1; }
  sed -i "0,/protected override void OnModelCreating/s//public DbSet<Ghestine.Domain.Entities.$1> $2 => Set<Ghestine.Domain.Entities.$1>();\n\n    protected override void OnModelCreating/" "$DBF"; }
addset CreditRequest CreditRequests; addset CreditEvent CreditEvents
for n in CreditRequest CreditEvent; do grep -q "DbSet<Ghestine.Domain.Entities.$n>" "$DBF" || { echo "درج DbSet $n انجام نشد. بکاپ: $B"; exit 1; }; done
# مجوزها: credit.view / credit.manage / credit.report
if [ -n "$IAM" ] && ! grep -q '"credit.view"' "$IAM"; then
  sed -i 's/("backups.manage", "پشتیبان‌گیری"),/("credit.view", "مشاهده‌ی استعلام‌های اعتباری"), ("credit.manage", "ثبت و پیگیری استعلام اعتباری"), ("credit.report", "دیدن محتوای گزارش اعتباری"), ("backups.manage", "پشتیبان‌گیری"),/' "$IAM"
  grep -q '"credit.view"' "$IAM" || echo "هشدار: مجوزهای credit.* به Perms.All اضافه نشد؛ دستی اضافه کنید (view، manage، report)."
fi
if ! grep -q "MyCreditClient" "$PG"; then
  sed -i '0,/var app = builder.Build();/s//builder.Services.AddHttpClient("mycredit");\nbuilder.Services.AddSingleton<Ghestine.API.Credit.MyCreditClient>();\nbuilder.Services.AddScoped<Ghestine.API.Credit.CreditService>();\nbuilder.Services.AddScoped<Ghestine.API.Platform.IJobHandler, Ghestine.API.Credit.CreditPollHandler>();\nbuilder.Services.AddHostedService<Ghestine.API.Credit.CreditMaintenance>();\n\nvar app = builder.Build();/' "$PG"; fi
grep -q "MyCreditClient" "$PG" || { echo "ثبت سرویس‌ها در Program.cs انجام نشد. برگرداندن: cp $B/Program.cs.bak $PG"; exit 1; }
cd "$ROOT"
if dotnet build 2>&1 | tee /tmp/credit-build.log | tail -15 | grep -q "Build succeeded"; then echo "ساخت موفق."; else
  echo "خطای build؛ ۱۵ خط آخر را بفرستید. برگرداندن: cp $B/AppDbContext.cs.bak $DBF ; cp $B/Program.cs.bak $PG ; [ -f $B/Iam.cs.bak ] && cp $B/Iam.cs.bak $IAM"; exit 1; fi
cat <<'MSG'

=== مراحل بعد ===
۱) مایگریشن (بعد از بکاپ): dotnet ef migrations add AddCredit -p src/Ghestine.Infrastructure -s src/Ghestine.API ; dotnet ef database update ...
   ایندکس‌های پیشنهادی: CreditRequests(TenantId,UserId,CreatedOn) ، CreditRequests(HashKey) ، CreditRequests(TenantId,Status) ، CreditEvents(RequestId,CreatedOn)
۲) پیکربندی محرمانه‌ی سرور (فایل خارج از گیت؛ نه appsettings داخل مخزن):
   "MyCredit": { "BaseUrl": "https://<آدرس-رسمی-که-اعتبارسنجی-ایران-داده>", "Username": "...", "Password": "...", "ApiKey": "(اختیاری؛ اگر خالی باشد از پاسخ لاگین گرفته می‌شود)", "CallbackSecret": "<حداقل ۲۴ نویسه‌ی تصادفی>" }
   تولید راز: openssl rand -hex 24
۳) به شرکت اعتبارسنجی ایران بدهید: (الف) IP خروجی سرور شما برای لیست مجاز  (ب) آدرس کال‌بک: https://ghestine.ir/api/v1/credit/callback/<CallbackSecret>
۴) نقش‌ها: credit.view / credit.manage / credit.report را از «نقش‌ها» به نقش‌های مناسب بدهید (credit.report دیدن محتوای گزارش است؛ فقط به افراد مجاز).
۵) پنل: /admin/credit (مدیر) ، /app/credit (مشتری). ابتدا «تست اتصال» در /admin/credit/settings را بزنید.
MSG
