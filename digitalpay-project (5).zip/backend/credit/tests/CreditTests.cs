using System.Text.Json;
using Xunit;
using Ghestine.API.Credit;
public class CreditTests
{
    [Fact] public void ParsesPlainCallback()
    {
        var p = Cr.ParseCallback("OTPAccepted-AbC123xyz_9"); Assert.NotNull(p); Assert.Equal("OTPAccepted", p!.Value.Event); Assert.Equal("AbC123xyz_9", p.Value.Hash); Assert.Null(p.Value.ReportCode);
    }
    [Fact] public void ParsesReportGeneratedCallbackWithLink()
    {
        var p = Cr.ParseCallback("ReportGenerated-HASH123456@https://api.x/report/RC9z&hashCode=HASH123456&reportLink=https://api.x/report/RC9z");
        Assert.NotNull(p); Assert.Equal("ReportGenerated", p!.Value.Event); Assert.Equal("HASH123456", p.Value.Hash); Assert.Equal("RC9z", p.Value.ReportCode);
    }
    [Theory] [InlineData("")] [InlineData(null)] [InlineData("Unknown-ABCDEFGH")] [InlineData("OTPAccepted-")] [InlineData("OTPAccepted-<script>")] [InlineData("nodash")]
    public void RejectsBadCallbacks(string? m) => Assert.Null(Cr.ParseCallback(m));
    [Fact] public void RejectsHugeCallback() => Assert.Null(Cr.ParseCallback("OTPAccepted-" + new string('a', 5000)));
    [Fact] public void EveryProviderStatusHasPersianTitle()
    {
        foreach (var s in new[] { "Success", "Entry", "OTPSent", "OTPLocked", "OTPAccepted", "OTPCheckFailed", "OTPResend", "NotMatchingRealPersonNationalCodeAndMobileNumber", "NotMatchingRealPersonAndLegalPerson", "IdentityCheckAccepted", "ReportGenerated", "ReportGeneratedButDataLost", "ReportGenerationFailed", "IdentityCheckFailed", "InQueue" })
            Assert.NotEqual("وضعیت نامشخص", Cr.Title(s));
        Assert.Equal("وضعیت نامشخص", Cr.Title("Foo"));
    }
    [Fact] public void SettledAndRegenerateRules()
    {
        Assert.True(Cr.IsSettled("ReportGenerated")); Assert.True(Cr.IsSettled("NotMatchingRealPersonAndLegalPerson")); Assert.False(Cr.IsSettled("InQueue")); Assert.False(Cr.IsSettled("OTPSent"));
        Assert.True(Cr.CanRegenerate("ReportGenerationFailed")); Assert.True(Cr.CanRegenerate("ReportGeneratedButDataLost")); Assert.False(Cr.CanRegenerate("ReportGenerated")); Assert.False(Cr.CanRegenerate("InQueue"));
    }
    [Fact] public void ResendWaitsFollowDocument() { Assert.Equal(120, Cr.DefaultResendWait(1)); Assert.Equal(180, Cr.DefaultResendWait(2)); Assert.Equal(270, Cr.DefaultResendWait(3)); Assert.Equal(270, Cr.DefaultResendWait(5)); Assert.Equal(5, Cr.MaxOtpSends); }
    [Fact] public void PollDelayGrowsThenCaps() { Assert.Equal(TimeSpan.FromSeconds(5), Cr.PollDelay(0)); Assert.Equal(TimeSpan.FromSeconds(30), Cr.PollDelay(3)); Assert.Equal(TimeSpan.FromSeconds(60), Cr.PollDelay(10)); Assert.Equal(TimeSpan.FromMinutes(5), Cr.PollDelay(40)); }
    [Fact] public void MasksSensitiveValues() { Assert.Equal("0015******", Cr.Mask("0015123456", 4, 0)); Assert.Equal("0912*****32", Cr.Mask("09123456732", 4, 2)); }
    [Fact] public void ValidatesInputs() { Assert.True(Cr.MobileOk("09121234567")); Assert.False(Cr.MobileOk("9121234567")); Assert.False(Cr.MobileOk("0912123456a")); Assert.True(Cr.OtpOk("12345")); Assert.False(Cr.OtpOk("12")); Assert.False(Cr.OtpOk("12a45")); }
    [Fact] public void FindsScoreRecursively()
    {
        using var d = JsonDocument.Parse("{\"a\":{\"b\":[{\"x\":1},{\"creditScore\":742.5}]}}"); Assert.Equal(742.5m, Cr.FindScore(d.RootElement));
        using var e = JsonDocument.Parse("{\"a\":1,\"score\":\"x\"}"); Assert.Null(Cr.FindScore(e.RootElement));
    }
    [Fact] public void MapsProviderErrorsToPersianAndKnowsTransient()
    {
        Assert.Contains("IP", Cr.ErrFa("InvalidIP")); Assert.Contains("ناشناخته", Cr.ErrFa("Whatever")); Assert.True(Cr.Transient("Unavailable")); Assert.False(Cr.Transient("IncorrectToken"));
    }
}
