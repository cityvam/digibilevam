using System.ComponentModel.DataAnnotations;
using Ghestine.Domain.Common;
namespace Ghestine.Domain.Entities;

/// درخواست وام/خرید اقساطی مشتری، پیش از ساخت قرارداد. مبلغ‌ها همیشه سمت سرور و با ContractEngine.Calc محاسبه و در همان لحظه ثبت می‌شوند.
public class LoanApplication : BaseEntity
{
    public Guid TenantId { get; set; }
    public Guid UserId { get; set; }
    [MaxLength(20)] public string Code { get; set; } = string.Empty;           // مثل L-7K3Q9X
    [MaxLength(64)] public string ProductKey { get; set; } = string.Empty;      // شناسه/اسلاگ طرح (اسنپ‌شات)
    [MaxLength(120)] public string ProductName { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public decimal DownPercent { get; set; }
    public int Months { get; set; }
    public decimal FeePercent { get; set; }                                     // درصد کارمزد کل دوره در لحظه‌ی ثبت
    public decimal Down { get; set; }
    public decimal Financed { get; set; }
    public decimal Fee { get; set; }
    public decimal Total { get; set; }
    public decimal Each { get; set; }
    public decimal Last { get; set; }
    [MaxLength(16)] public string Status { get; set; } = "Submitted";           // Submitted | InReview | NeedInfo | Approved | Rejected | Cancelled
    [MaxLength(500)] public string CustomerNote { get; set; } = string.Empty;
    [MaxLength(500)] public string ReviewNote { get; set; } = string.Empty;      // پیام کارشناس به مشتری
    public Guid? ReviewedBy { get; set; }
    public DateTime? ReviewedOn { get; set; }
    public Guid? CreditRequestId { get; set; }                                   // استعلام اعتباری آماده‌ی مشتری در لحظه‌ی ثبت (اختیاری)
    public decimal? CreditScore { get; set; }
    public DateTime CreatedOn { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedOn { get; set; } = DateTime.UtcNow;
}

public class LoanAppEvent : BaseEntity
{
    public Guid TenantId { get; set; }
    public Guid ApplicationId { get; set; }
    [MaxLength(16)] public string FromStatus { get; set; } = string.Empty;
    [MaxLength(16)] public string ToStatus { get; set; } = string.Empty;
    [MaxLength(500)] public string Note { get; set; } = string.Empty;
    public Guid? ActorId { get; set; }
    public DateTime CreatedOn { get; set; } = DateTime.UtcNow;
}
