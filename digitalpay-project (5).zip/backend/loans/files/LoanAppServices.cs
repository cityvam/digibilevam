using System.Security.Cryptography;
using Ghestine.Domain.Entities;
using Ghestine.API.Contracts;
using Ghestine.API.Notify;
using Ghestine.API.Security;
using Microsoft.EntityFrameworkCore;
using __DBNS__;
namespace Ghestine.API.Loans;

/// قواعد خالص درخواست وام (بدون وابستگی؛ قابل تست)
public static class La
{
    public static readonly Dictionary<string, string> Fa = new()
    { ["Submitted"] = "ثبت‌شده", ["InReview"] = "در حال بررسی", ["NeedInfo"] = "نیازمند اطلاعات بیشتر", ["Approved"] = "تأیید شد", ["Rejected"] = "رد شد", ["Cancelled"] = "لغو شد" };
    public static bool IsOpen(string s) => s is "Submitted" or "InReview" or "NeedInfo";
    /// گذارهای مجاز وضعیت توسط کارشناس. تأیید/رد نهایی است؛ لغو فقط توسط مشتری.
    public static readonly Dictionary<string, string[]> Next = new()
    { ["Submitted"] = new[] { "InReview", "NeedInfo", "Approved", "Rejected" }, ["InReview"] = new[] { "NeedInfo", "Approved", "Rejected" }, ["NeedInfo"] = new[] { "InReview", "Approved", "Rejected" } };
    public static bool CanMove(string from, string to) => Next.TryGetValue(from, out var xs) && xs.Contains(to);
    public record Limits(decimal MinAmount, decimal MaxAmount, int MinMonths, int MaxMonths, decimal MaxDownPercent, decimal FeePerMonthPercent, int MaxOpen);
    public static string? Validate(Limits l, decimal amount, decimal downPct, int months)
    {
        if (amount < l.MinAmount || amount > l.MaxAmount) return $"مبلغ باید بین {l.MinAmount:N0} و {l.MaxAmount:N0} تومان باشد.";
        if (months < l.MinMonths || months > l.MaxMonths) return $"مدت باید بین {l.MinMonths} و {l.MaxMonths} ماه باشد.";
        if (downPct < 0 || downPct > l.MaxDownPercent) return $"پیش‌پرداخت باید بین ۰ و {l.MaxDownPercent:0.#} درصد باشد.";
        return null;
    }
    /// کارمزد کل دوره = نرخ ماهانه × مدت (هم‌شکل با ماشین‌حساب صفحه‌ی اصلی)
    public static decimal FeePercent(Limits l, int months) => Math.Round(l.FeePerMonthPercent * months, 2);
}

public record LaResult(bool Ok, string? Error = null, LoanApplication? A = null);

public class LoanAppService
{
    private readonly AppDbContext _db; private readonly IConfiguration _cfg; private readonly IRateLimiter _rl; private readonly INotifier _n;
    public LoanAppService(AppDbContext db, IConfiguration cfg, IRateLimiter rl, INotifier n) { _db = db; _cfg = cfg; _rl = rl; _n = n; }
    public La.Limits Limits() => new(
        _cfg.GetValue("LoanApp:MinAmount", 1_000_000m), _cfg.GetValue("LoanApp:MaxAmount", 500_000_000m), _cfg.GetValue("LoanApp:MinMonths", 3), _cfg.GetValue("LoanApp:MaxMonths", 60),
        _cfg.GetValue("LoanApp:MaxDownPercent", 70m), _cfg.GetValue("LoanApp:FeePerMonthPercent", 0.6m), _cfg.GetValue("LoanApp:MaxOpen", 3));
    static string NewCode() { const string a = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"; var b = RandomNumberGenerator.GetBytes(6); return "L-" + new string(b.Select(x => a[x % a.Length]).ToArray()); }
    void Ev(LoanApplication a, string from, string to, string note, Guid? actor) => _db.Add(new LoanAppEvent { TenantId = a.TenantId, ApplicationId = a.Id, FromStatus = from, ToStatus = to, Note = Notify.NotifyU.Cut(note, 500), ActorId = actor });

    public async Task<LaResult> CreateAsync(Guid tid, Guid userId, string productKey, string productName, decimal amount, decimal downPct, int months, string? note, bool attachCredit, CancellationToken ct)
    {
        var l = Limits(); var err = La.Validate(l, amount, downPct, months); if (err != null) return new(false, err);
        productKey = (productKey ?? "").Trim(); if (productKey.Length is 0 or > 64 || productKey.Any(char.IsControl)) return new(false, "طرح انتخاب‌شده نامعتبر است.");
        if (!_rl.Hit("la:" + userId, 6, TimeSpan.FromHours(1))) return new(false, "تعداد درخواست‌های این ساعت به حد مجاز رسیده است.");
        var open = await _db.Set<LoanApplication>().CountAsync(x => x.TenantId == tid && x.UserId == userId && (x.Status == "Submitted" || x.Status == "InReview" || x.Status == "NeedInfo"), ct);
        if (open >= l.MaxOpen) return new(false, $"شما همزمان حداکثر {l.MaxOpen} درخواست باز می‌توانید داشته باشید.");
        var fp = La.FeePercent(l, months); var (down, fee, total, rows) = ContractEngine.Calc(amount, downPct, fp, months, 30, DateTime.UtcNow);
        var a = new LoanApplication { TenantId = tid, UserId = userId, Code = NewCode(), ProductKey = productKey, ProductName = Notify.NotifyU.Cut(productName, 120), Amount = amount, DownPercent = downPct, Months = months, FeePercent = fp,
            Down = down, Financed = amount - down, Fee = fee, Total = total, Each = rows[0].Amount, Last = rows[^1].Amount, CustomerNote = Notify.NotifyU.Cut(note, 500) };
        if (attachCredit) { var c = await _db.Set<CreditRequest>().Where(x => x.TenantId == tid && x.UserId == userId && (x.Status == "ReportGenerated" || x.Status == "Success")).OrderByDescending(x => x.ReportAt ?? x.CreatedOn).FirstOrDefaultAsync(ct); if (c != null) { a.CreditRequestId = c.Id; a.CreditScore = c.Score; } }
        _db.Add(a); Ev(a, "", "Submitted", "ثبت درخواست", userId); await _db.SaveChangesAsync(ct); return new(true, null, a);
    }

    public async Task<LaResult> CancelAsync(LoanApplication a, Guid actor, CancellationToken ct)
    {
        if (!La.IsOpen(a.Status)) return new(false, "این درخواست دیگر قابل لغو نیست.", a);
        var from = a.Status; a.Status = "Cancelled"; a.UpdatedOn = DateTime.UtcNow; Ev(a, from, "Cancelled", "لغو توسط مشتری", actor); await _db.SaveChangesAsync(ct); return new(true, null, a);
    }

    public async Task<LaResult> ReviewAsync(LoanApplication a, string to, string? note, Guid actor, CancellationToken ct)
    {
        if (!La.CanMove(a.Status, to)) return new(false, "این تغییر وضعیت برای درخواست مجاز نیست.", a);
        note = (note ?? "").Trim(); if ((to is "Rejected" or "NeedInfo") && note.Length < 3) return new(false, "برای رد یا درخواست اطلاعات، توضیح برای مشتری لازم است.", a);
        var from = a.Status; a.Status = to; a.ReviewNote = Notify.NotifyU.Cut(note, 500); a.ReviewedBy = actor; a.ReviewedOn = DateTime.UtcNow; a.UpdatedOn = DateTime.UtcNow; Ev(a, from, to, note, actor); await _db.SaveChangesAsync(ct);
        if (to != "InReview") await _n.AddAsync(a.TenantId, a.UserId, "loan", "درخواست وام " + a.Code + ": " + La.Fa[to], note.Length > 0 ? note : "برای جزئیات وارد درخواست شوید.", "/app/loans/" + a.Id, "la-" + a.Id + "-" + to, null, ct);
        return new(true, null, a);
    }
}
