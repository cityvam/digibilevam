using System.Security.Claims;
using Ghestine.Domain.Entities;
using Ghestine.API.Iam;
using Ghestine.API.Tenancy;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using __DBNS__;
namespace Ghestine.API.Loans;

public record LaCreateIn(string ProductKey, string? ProductName, decimal Amount, decimal DownPercent, int Months, string? Note, bool AttachCredit);
public record LaReviewIn(string Status, string? Note);

static class LaU
{
    public static Guid? Me(this ControllerBase c) => Guid.TryParse(c.User.FindFirstValue(ClaimTypes.NameIdentifier) ?? c.User.FindFirstValue("sub"), out var g) ? g : null;
    public static object View(LoanApplication a) => new
    {
        a.Id, a.Code, a.ProductKey, a.ProductName, a.Amount, a.DownPercent, a.Months, a.FeePercent, a.Down, a.Financed, a.Fee, a.Total, a.Each, a.Last, a.Status, statusTitle = La.Fa.GetValueOrDefault(a.Status, a.Status),
        open = La.IsOpen(a.Status), canCancel = La.IsOpen(a.Status), a.CustomerNote, a.ReviewNote, a.ReviewedOn, a.CreditRequestId, a.CreditScore, a.CreatedOn, a.UpdatedOn,
    };
}

[ApiController, Route("api/v1/me/loan-applications"), Authorize]
public class MyLoanAppsController : ControllerBase
{
    private readonly AppDbContext _db; private readonly LoanAppService _s;
    public MyLoanAppsController(AppDbContext db, LoanAppService s) { _db = db; _s = s; }
    async Task<LoanApplication?> Mine(Guid id, CancellationToken ct) { var u = this.Me(); return u == null ? null : await _db.Set<LoanApplication>().FirstOrDefaultAsync(x => x.Id == id && x.TenantId == this.Tid() && x.UserId == u, ct); }
    [HttpGet] public async Task<IActionResult> List(CancellationToken ct) { var u = this.Me(); if (u == null) return Unauthorized(); var xs = await _db.Set<LoanApplication>().Where(x => x.TenantId == this.Tid() && x.UserId == u).OrderByDescending(x => x.CreatedOn).Take(50).ToListAsync(ct); return Ok(xs.Select(LaU.View)); }
    [HttpGet("limits")] public IActionResult Limits() => Ok(_s.Limits());
    [HttpGet("{id:guid}")]
    public async Task<IActionResult> One(Guid id, CancellationToken ct)
    {
        var a = await Mine(id, ct); if (a == null) return NotFound();
        var ev = await _db.Set<LoanAppEvent>().Where(e => e.ApplicationId == id).OrderBy(e => e.CreatedOn).Select(e => new { e.FromStatus, e.ToStatus, e.Note, e.CreatedOn, byStaff = e.ActorId != a.UserId }).ToListAsync(ct);
        return Ok(new { application = LaU.View(a), events = ev });
    }
    [HttpPost]
    public async Task<IActionResult> Create(LaCreateIn i, CancellationToken ct)
    {
        var u = this.Me(); if (u == null) return Unauthorized(); var r = await _s.CreateAsync(this.Tid(), u.Value, i.ProductKey, i.ProductName ?? "", i.Amount, i.DownPercent, i.Months, i.Note, i.AttachCredit, ct);
        return r.Ok ? Ok(new { application = LaU.View(r.A!) }) : BadRequest(new { message = r.Error });
    }
    [HttpPost("{id:guid}/cancel")] public async Task<IActionResult> Cancel(Guid id, CancellationToken ct) { var a = await Mine(id, ct); if (a == null) return NotFound(); var r = await _s.CancelAsync(a, this.Me()!.Value, ct); return r.Ok ? Ok(new { application = LaU.View(a) }) : BadRequest(new { message = r.Error }); }
}

[ApiController, Route("api/v1/admin/loan-applications"), Authorize(Roles = "Admin,SuperAdmin")]
public class LoanAppAdminController : ControllerBase
{
    private readonly AppDbContext _db; private readonly LoanAppService _s;
    public LoanAppAdminController(AppDbContext db, LoanAppService s) { _db = db; _s = s; }
    [HttpGet, RequirePermission("loans.view")]
    public async Task<IActionResult> List([FromQuery] string? status, [FromQuery] string? q, [FromQuery] int page = 1, CancellationToken ct = default)
    {
        var xs = _db.Set<LoanApplication>().Where(x => x.TenantId == this.Tid());
        if (!string.IsNullOrEmpty(status) && La.Fa.ContainsKey(status)) xs = xs.Where(x => x.Status == status);
        if (!string.IsNullOrWhiteSpace(q)) { q = q.Trim(); xs = xs.Where(x => x.Code.Contains(q) || x.ProductName.Contains(q)); }
        var total = await xs.CountAsync(ct); page = Math.Max(1, page);
        var items = await xs.OrderByDescending(x => x.CreatedOn).Skip((page - 1) * 50).Take(50).ToListAsync(ct);
        return Ok(new { total, page, items = items.Select(x => new { v = LaU.View(x), x.UserId }) });
    }
    [HttpGet("{id:guid}"), RequirePermission("loans.view")]
    public async Task<IActionResult> Detail(Guid id, CancellationToken ct)
    {
        var a = await _db.Set<LoanApplication>().FirstOrDefaultAsync(x => x.Id == id && x.TenantId == this.Tid(), ct); if (a == null) return NotFound();
        var ev = await _db.Set<LoanAppEvent>().Where(e => e.ApplicationId == id).OrderBy(e => e.CreatedOn).Select(e => new { e.FromStatus, e.ToStatus, e.Note, e.CreatedOn, e.ActorId }).ToListAsync(ct);
        var credit = a.CreditRequestId == null ? null : await _db.Set<CreditRequest>().Where(c => c.Id == a.CreditRequestId).Select(c => new { c.Id, c.Code, c.Status, c.StatusTitle, c.Score, c.ReportAt }).FirstOrDefaultAsync(ct);
        var prior = await _db.Set<LoanApplication>().CountAsync(x => x.TenantId == a.TenantId && x.UserId == a.UserId && x.Id != a.Id, ct);
        return Ok(new { application = LaU.View(a), a.UserId, events = ev, credit, priorApplications = prior, next = La.Next.GetValueOrDefault(a.Status, Array.Empty<string>()) });
    }
    [HttpPost("{id:guid}/review"), RequirePermission("loans.review")]
    public async Task<IActionResult> Review(Guid id, LaReviewIn i, CancellationToken ct)
    {
        var a = await _db.Set<LoanApplication>().FirstOrDefaultAsync(x => x.Id == id && x.TenantId == this.Tid(), ct); if (a == null) return NotFound();
        var r = await _s.ReviewAsync(a, i.Status, i.Note, this.Me() ?? Guid.Empty, ct); return r.Ok ? Ok(new { application = LaU.View(a) }) : BadRequest(new { message = r.Error });
    }
}
