#!/bin/bash
# نصب ماژول درخواست وام (مشتری ثبت می‌کند، کارشناس بررسی می‌کند). پیش‌نیاز: contracts, notify, security, iam, credit
set -e
ROOT="${1:-/home/ghestine/domains/ghestine.ir/Ghestine}"
HERE="$(cd "$(dirname "$0")" && pwd)"; SRC="$ROOT/src"
[ -d "$SRC" ] || { echo "پوشه src پیدا نشد: $SRC"; exit 1; }
B="$ROOT/.loans-backup-$(date +%Y%m%d%H%M%S)"; mkdir -p "$B"
DBF=$(grep -rl "class AppDbContext" "$SRC" --include=*.cs | head -1); [ -n "$DBF" ] || { echo "AppDbContext پیدا نشد"; exit 1; }
PG="$SRC/Ghestine.API/Program.cs"; IAM=$(grep -rl "class Perms" "$SRC" --include=*.cs | head -1)
cp "$PG" "$B/Program.cs.bak"; cp "$DBF" "$B/AppDbContext.cs.bak"; [ -n "$IAM" ] && cp "$IAM" "$B/Iam.cs.bak"; echo "بکاپ: $B"
BE=$(grep -rl "class BaseEntity" "$SRC" --include=*.cs | head -1); [ -n "$BE" ] || { echo "کلاس BaseEntity پیدا نشد."; exit 1; }
BENS=$(grep -h "^namespace" "$BE" | head -1 | sed 's/namespace //; s/;//; s/\r//')
DBNS=$(grep -h "^namespace" "$DBF" | head -1 | sed 's/namespace //; s/;//; s/\r//')
for need in "class ContractEngine:contracts" "interface INotifier:notify" "interface IRateLimiter:security" "class PermissionService:iam" "class CreditRequest:credit"; do
  grep -rq "${need%%:*}" "$SRC" --include=*.cs || { echo "ابتدا ماژول ${need##*:} را نصب کنید."; exit 1; }; done
cp "$HERE/files/LoanAppModule.cs" "$SRC/Ghestine.Domain/Entities/LoanAppModule.cs"
sed -i "s/^using Ghestine.Domain.Common;/using $BENS;/" "$SRC/Ghestine.Domain/Entities/LoanAppModule.cs"
mkdir -p "$SRC/Ghestine.API/Loans"; for f in LoanAppServices LoanAppControllers; do cp "$HERE/files/$f.cs" "$SRC/Ghestine.API/Loans/$f.cs"; sed -i "s/__DBNS__/$DBNS/" "$SRC/Ghestine.API/Loans/$f.cs"; done
addset(){ grep -q "DbSet<Ghestine.Domain.Entities.$1>" "$DBF" && return 0
  grep -q "protected override void OnModelCreating" "$DBF" || { echo "OnModelCreating پیدا نشد؛ DbSet ها را دستی اضافه کنید"; exit 1; }
  sed -i "0,/protected override void OnModelCreating/s//public DbSet<Ghestine.Domain.Entities.$1> $2 => Set<Ghestine.Domain.Entities.$1>();\n\n    protected override void OnModelCreating/" "$DBF"; }
addset LoanApplication LoanApplications; addset LoanAppEvent LoanAppEvents
for n in LoanApplication LoanAppEvent; do grep -q "DbSet<Ghestine.Domain.Entities.$n>" "$DBF" || { echo "درج DbSet $n انجام نشد. بکاپ: $B"; exit 1; }; done
if [ -n "$IAM" ] && ! grep -q '"loans.view"' "$IAM"; then
  sed -i 's/("credit.view", /("loans.view", "مشاهده‌ی درخواست‌های وام"), ("loans.review", "بررسی و تصمیم درباره‌ی درخواست وام"), ("credit.view", /' "$IAM"
  grep -q '"loans.view"' "$IAM" || echo "هشدار: مجوزهای loans.* به Perms.All اضافه نشد؛ دستی اضافه کنید (view، review)."
fi
grep -q "LoanAppService" "$PG" || sed -i '0,/var app = builder.Build();/s//builder.Services.AddScoped<Ghestine.API.Loans.LoanAppService>();\n\nvar app = builder.Build();/' "$PG"
grep -q "LoanAppService" "$PG" || { echo "ثبت سرویس در Program.cs انجام نشد. برگرداندن: cp $B/Program.cs.bak $PG"; exit 1; }
cd "$ROOT"
if dotnet build 2>&1 | tee /tmp/loans-build.log | tail -15 | grep -q "Build succeeded"; then echo "ساخت موفق."; else
  echo "خطای build؛ ۱۵ خط آخر را بفرستید. برگرداندن: cp $B/AppDbContext.cs.bak $DBF ; cp $B/Program.cs.bak $PG ; [ -f $B/Iam.cs.bak ] && cp $B/Iam.cs.bak $IAM"; exit 1; fi
cat <<'MSG'

=== مراحل بعد ===
۱) مایگریشن (بعد از بکاپ): dotnet ef migrations add AddLoanApplications ...
   ایندکس‌های پیشنهادی: LoanApplications(TenantId,UserId,CreatedOn) ، LoanApplications(TenantId,Status) ، LoanAppEvents(ApplicationId,CreatedOn)
۲) محدودیت‌ها (اختیاری، در پیکربندی): LoanApp:MinAmount, MaxAmount, MinMonths, MaxMonths, MaxDownPercent, FeePerMonthPercent (پیش‌فرض ۰٫۶ درصد در ماه), MaxOpen
۳) مجوزها: loans.view (دیدن)، loans.review (تأیید/رد/درخواست اطلاعات) — به نقش‌ها بدهید.
۴) تأیید درخواست هنوز خودکار قرارداد نمی‌سازد؛ کارشناس از بخش قراردادها ادامه می‌دهد.
MSG
