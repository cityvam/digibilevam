using Xunit;
using Ghestine.API.Loans;
public class LoanAppTests
{
    static readonly La.Limits L = new(1_000_000m, 500_000_000m, 3, 60, 70m, 0.6m, 3);
    [Fact] public void ValidatesRanges()
    {
        Assert.Null(La.Validate(L, 30_000_000m, 0, 12)); Assert.NotNull(La.Validate(L, 999_999m, 0, 12)); Assert.NotNull(La.Validate(L, 600_000_000m, 0, 12));
        Assert.NotNull(La.Validate(L, 30_000_000m, 0, 2)); Assert.NotNull(La.Validate(L, 30_000_000m, 0, 61)); Assert.NotNull(La.Validate(L, 30_000_000m, -1, 12)); Assert.NotNull(La.Validate(L, 30_000_000m, 71, 12));
    }
    [Fact] public void FeeIsMonthlyRateTimesMonths() { Assert.Equal(7.2m, La.FeePercent(L, 12)); Assert.Equal(3.6m, La.FeePercent(L, 6)); }
    [Fact] public void StatusTransitions()
    {
        Assert.True(La.CanMove("Submitted", "InReview")); Assert.True(La.CanMove("NeedInfo", "Approved")); Assert.False(La.CanMove("Approved", "Rejected")); Assert.False(La.CanMove("Rejected", "InReview")); Assert.False(La.CanMove("Cancelled", "Approved")); Assert.False(La.CanMove("Submitted", "Cancelled"));
    }
    [Fact] public void OpenStates() { Assert.True(La.IsOpen("Submitted")); Assert.True(La.IsOpen("NeedInfo")); Assert.False(La.IsOpen("Approved")); Assert.False(La.IsOpen("Cancelled")); }
    [Fact] public void EveryStatusHasPersianTitle() { foreach (var s in new[] { "Submitted", "InReview", "NeedInfo", "Approved", "Rejected", "Cancelled" }) Assert.True(La.Fa.ContainsKey(s)); }
}
