using System.Security.Claims;
using Ghestine.Domain.Entities;
using Ghestine.API.Iam;
using Ghestine.API.Tenancy;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using __DBNS__;
namespace Ghestine.API.Support;

public record TicketIn(string Subject, string? Category, string? Priority, string Body);
public record ReplyIn(string Body);
public record StaffReplyIn(string? Body, bool Internal, bool Close);

[ApiController, Route("api/v1/me/tickets"), Authorize]
public class MyTicketsController : ControllerBase
{
    private readonly AppDbContext _db; private readonly SupportService _s; public MyTicketsController(AppDbContext db, SupportService s) { _db = db; _s = s; }
    Guid? Me => Guid.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub"), out var g) ? g : null;
    [HttpGet] public async Task<IActionResult> List(CancellationToken ct)
    { var u = Me; if (u == null) return Unauthorized(); return Ok(await _db.Set<SupportTicket>().Where(t => t.TenantId == this.Tid() && t.UserId == u).OrderByDescending(t => t.UpdatedOn).Take(100).Select(t => new { t.Id, t.Code, t.Subject, t.Category, t.Status, t.UpdatedOn }).ToListAsync(ct)); }
    [HttpPost] public async Task<IActionResult> Create(TicketIn i, CancellationToken ct)
    { var u = Me; if (u == null) return Unauthorized(); var (t, e) = await _s.Create(this.Tid(), u.Value, i.Subject, i.Category ?? "Other", "Normal", i.Body, ct); return t == null ? BadRequest(new { message = e }) : Ok(new { t.Id, t.Code }); }
    [HttpGet("{id:guid}")] public async Task<IActionResult> One(Guid id, CancellationToken ct)
    {
        var u = Me; if (u == null) return Unauthorized(); var t = await _db.Set<SupportTicket>().FirstOrDefaultAsync(x => x.Id == id && x.TenantId == this.Tid() && x.UserId == u, ct); if (t == null) return NotFound();
        var m = await _db.Set<TicketMessage>().Where(x => x.TicketId == id && !x.IsInternal).OrderBy(x => x.CreatedOn).Select(x => new { x.IsStaff, x.Body, x.CreatedOn }).ToListAsync(ct);
        return Ok(new { t.Id, t.Code, t.Subject, t.Category, t.Status, messages = m });
    }
    [HttpPost("{id:guid}/reply")] public async Task<IActionResult> Reply(Guid id, ReplyIn i, CancellationToken ct)
    {
        var u = Me; if (u == null) return Unauthorized(); var t = await _db.Set<SupportTicket>().FirstOrDefaultAsync(x => x.Id == id && x.TenantId == this.Tid() && x.UserId == u, ct); if (t == null) return NotFound();
        var e = await _s.CustomerReply(t, u.Value, i.Body, ct); return e == null ? Ok() : BadRequest(new { message = e });
    }
}

[ApiController, Route("api/v1/admin/tickets"), Authorize(Roles = "Admin,SuperAdmin"), RequirePermission("tickets.manage")]
public class TicketsAdminController : ControllerBase
{
    private readonly AppDbContext _db; private readonly SupportService _s; public TicketsAdminController(AppDbContext db, SupportService s) { _db = db; _s = s; }
    Guid? Me => Guid.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub"), out var g) ? g : null;
    [HttpGet] public async Task<IActionResult> List([FromQuery] string? status, [FromQuery] bool overdue, CancellationToken ct)
    {
        var now = DateTime.UtcNow; var q = _db.Set<SupportTicket>().Where(t => t.TenantId == this.Tid());
        if (!string.IsNullOrEmpty(status)) q = q.Where(t => t.Status == status); else q = q.Where(t => t.Status != "Closed");
        if (overdue) q = q.Where(t => t.FirstResponseOn == null && t.SlaDueOn < now);
        return Ok(await q.OrderByDescending(t => t.Priority == "High").ThenBy(t => t.SlaDueOn).Take(200).Select(t => new { t.Id, t.Code, t.Subject, t.Category, t.Priority, t.Status, t.UserId, t.AssignedTo, t.SlaDueOn, t.UpdatedOn, overdue = t.FirstResponseOn == null && t.Status != "Closed" && t.SlaDueOn < now }).ToListAsync(ct));
    }
    [HttpGet("{id:guid}")] public async Task<IActionResult> One(Guid id, CancellationToken ct)
    {
        var t = await _db.Set<SupportTicket>().FirstOrDefaultAsync(x => x.Id == id && x.TenantId == this.Tid(), ct); if (t == null) return NotFound();
        return Ok(new { t, messages = await _db.Set<TicketMessage>().Where(x => x.TicketId == id).OrderBy(x => x.CreatedOn).Select(x => new { x.IsStaff, x.IsInternal, x.AuthorId, x.Body, x.CreatedOn }).ToListAsync(ct) });
    }
    [HttpPost("{id:guid}/reply")] public async Task<IActionResult> Reply(Guid id, StaffReplyIn i, CancellationToken ct)
    {
        var u = Me; if (u == null) return Unauthorized(); var t = await _db.Set<SupportTicket>().FirstOrDefaultAsync(x => x.Id == id && x.TenantId == this.Tid(), ct); if (t == null) return NotFound();
        var e = await _s.StaffReply(t, u.Value, i.Body ?? "", i.Internal, i.Close, ct); return e == null ? Ok() : BadRequest(new { message = e });
    }
}
