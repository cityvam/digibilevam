using System.ComponentModel.DataAnnotations;
using Ghestine.Domain.Common;
namespace Ghestine.Domain.Entities;

public class SupportTicket : BaseEntity
{
    public Guid TenantId { get; set; }
    public Guid UserId { get; set; }
    [MaxLength(20)] public string Code { get; set; } = string.Empty;       // کد قابل ارائه به مشتری، مثل T-7K3Q9X
    [MaxLength(160)] public string Subject { get; set; } = string.Empty;
    [MaxLength(20)] public string Category { get; set; } = "Other";        // Loan | Payment | Account | Contract | Other
    [MaxLength(10)] public string Priority { get; set; } = "Normal";       // Normal | High
    [MaxLength(12)] public string Status { get; set; } = "Open";           // Open | Answered | Waiting | Closed
    public Guid? AssignedTo { get; set; }
    public DateTime CreatedOn { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedOn { get; set; } = DateTime.UtcNow;
    public DateTime SlaDueOn { get; set; }                                  // مهلت اولین پاسخ پشتیبان
    public DateTime? FirstResponseOn { get; set; }
    public DateTime? ClosedOn { get; set; }
}

public class TicketMessage : BaseEntity
{
    public Guid TenantId { get; set; }
    public Guid TicketId { get; set; }
    public Guid AuthorId { get; set; }
    public bool IsStaff { get; set; }
    public bool IsInternal { get; set; }                                    // یادداشت داخلی؛ هرگز به مشتری نشان داده نمی‌شود
    [MaxLength(4000)] public string Body { get; set; } = string.Empty;      // متن ساده (در خروجی HtmlEncode می‌شود)
    public DateTime CreatedOn { get; set; } = DateTime.UtcNow;
}
