using System.Security.Cryptography;
using Ghestine.Domain.Entities;
using Ghestine.API.Security;
using Ghestine.API.Notify;
using Microsoft.EntityFrameworkCore;
using __DBNS__;
namespace Ghestine.API.Support;

public static class Sla
{
    /// مهلت پاسخ اول: عادی ۲۴ ساعت، فوری ۴ ساعت.
    public static DateTime Due(DateTime createdUtc, string priority) => createdUtc.AddHours(priority == "High" ? 4 : 24);
    public static bool Overdue(SupportTicket t, DateTime now) => t.FirstResponseOn == null && t.Status != "Closed" && t.SlaDueOn < now;
    public static readonly string[] Categories = { "Loan", "Payment", "Account", "Contract", "Other" };
    public static readonly Dictionary<string, string> CatFa = new() { ["Loan"] = "وام", ["Payment"] = "پرداخت و اقساط", ["Account"] = "حساب کاربری", ["Contract"] = "قرارداد", ["Other"] = "سایر" };
    public static readonly Dictionary<string, string> StFa = new() { ["Open"] = "باز", ["Answered"] = "پاسخ داده شد", ["Waiting"] = "منتظر مشتری", ["Closed"] = "بسته" };
}

public class SupportService
{
    private readonly AppDbContext _db; private readonly IRateLimiter _rl; private readonly INotifier _n;
    public SupportService(AppDbContext db, IRateLimiter rl, INotifier n) { _db = db; _rl = rl; _n = n; }
    static string NewCode() { const string a = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"; var b = RandomNumberGenerator.GetBytes(6); return "T-" + new string(b.Select(x => a[x % a.Length]).ToArray()); }
    public static string CleanText(string? s, int max) { s = (s ?? "").Replace("\r\n", "\n").Trim(); var sb = new System.Text.StringBuilder(); foreach (var c in s) if (c == '\n' || c == '\t' || !char.IsControl(c)) sb.Append(c); s = sb.ToString(); return s.Length <= max ? s : s[..max]; }

    public async Task<(SupportTicket? T, string? Err)> Create(Guid tid, Guid uid, string subject, string category, string priority, string body, CancellationToken ct)
    {
        if (!_rl.Hit("tk:" + uid, 5, TimeSpan.FromHours(1))) return (null, "تعداد تیکت‌های جدید در این ساعت به حد مجاز رسیده است.");
        subject = CleanText(subject, 160); body = CleanText(body, 4000);
        if (subject.Length < 4) return (null, "موضوع حداقل ۴ نویسه باشد."); if (body.Length < 10) return (null, "متن پیام حداقل ۱۰ نویسه باشد.");
        if (!Sla.Categories.Contains(category)) category = "Other"; priority = priority == "High" ? "High" : "Normal";
        var now = DateTime.UtcNow; var t = new SupportTicket { TenantId = tid, UserId = uid, Code = NewCode(), Subject = subject, Category = category, Priority = priority, SlaDueOn = Sla.Due(now, priority) };
        _db.Add(t); _db.Add(new TicketMessage { TenantId = tid, TicketId = t.Id, AuthorId = uid, Body = body }); await _db.SaveChangesAsync(ct); return (t, null);
    }
    public async Task<string?> CustomerReply(SupportTicket t, Guid uid, string body, CancellationToken ct)
    {
        if (!_rl.Hit("tm:" + uid, 20, TimeSpan.FromHours(1))) return "پیام‌های این ساعت به حد مجاز رسیده است.";
        body = CleanText(body, 4000); if (body.Length < 2) return "متن پیام خالی است.";
        if (t.Status == "Closed" && t.ClosedOn < DateTime.UtcNow.AddDays(-7)) return "این تیکت بیش از ۷ روز پیش بسته شده؛ تیکت جدید بسازید.";
        _db.Add(new TicketMessage { TenantId = t.TenantId, TicketId = t.Id, AuthorId = uid, Body = body });
        t.Status = "Open"; t.ClosedOn = null; t.UpdatedOn = DateTime.UtcNow; await _db.SaveChangesAsync(ct); return null;
    }
    public async Task<string?> StaffReply(SupportTicket t, Guid staff, string body, bool internalNote, bool close, CancellationToken ct)
    {
        body = CleanText(body, 4000); if (body.Length < 2 && !close) return "متن پیام خالی است.";
        if (body.Length >= 2) _db.Add(new TicketMessage { TenantId = t.TenantId, TicketId = t.Id, AuthorId = staff, IsStaff = true, IsInternal = internalNote, Body = body });
        var now = DateTime.UtcNow; t.UpdatedOn = now; t.AssignedTo ??= staff;
        if (!internalNote && body.Length >= 2) { t.FirstResponseOn ??= now; t.Status = "Answered"; }
        if (close) { t.Status = "Closed"; t.ClosedOn = now; }
        await _db.SaveChangesAsync(ct);
        if (!internalNote && (body.Length >= 2 || close)) await _n.AddAsync(t.TenantId, t.UserId, "ticket", close && body.Length < 2 ? "تیکت " + t.Code + " بسته شد" : "پاسخ جدید به تیکت " + t.Code, close && body.Length < 2 ? "پشتیبانی تیکت شما را بسته کرد." : "پشتیبانی به تیکت شما پاسخ داد.", "/app/tickets/" + t.Id, "tk-" + t.Id + "-" + t.UpdatedOn.Ticks, null, ct);
        return null;
    }
}
