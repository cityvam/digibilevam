#!/bin/bash
# نصب سامانه‌ی پشتیبانی: تیکت، SLA، پاسخ کارشناس، یادداشت داخلی
set -e
ROOT="${1:-/home/ghestine/domains/ghestine.ir/Ghestine}"
HERE="$(cd "$(dirname "$0")" && pwd)"; SRC="$ROOT/src"
[ -d "$SRC" ] || { echo "پوشه src پیدا نشد: $SRC"; exit 1; }
B="$ROOT/.support-backup-$(date +%Y%m%d%H%M%S)"; mkdir -p "$B"
DBF=$(grep -rl "class AppDbContext" "$SRC" --include=*.cs | head -1); [ -n "$DBF" ] || { echo "AppDbContext پیدا نشد"; exit 1; }
PG="$SRC/Ghestine.API/Program.cs"; cp "$PG" "$B/Program.cs.bak"; cp "$DBF" "$B/AppDbContext.cs.bak"; echo "بکاپ: $B"
BE=$(grep -rl "class BaseEntity" "$SRC" --include=*.cs | head -1); [ -n "$BE" ] || { echo "کلاس BaseEntity پیدا نشد."; exit 1; }
BENS=$(grep -h "^namespace" "$BE" | head -1 | sed 's/namespace //; s/;//; s/\r//')
DBNS=$(grep -h "^namespace" "$DBF" | head -1 | sed 's/namespace //; s/;//; s/\r//')
grep -rq "class PermissionService" "$SRC" --include=*.cs || { echo "ابتدا ماژول iam را نصب کنید."; exit 1; }
grep -rq "interface INotifier" "$SRC" --include=*.cs || { echo "ابتدا ماژول notify را نصب کنید."; exit 1; }
grep -rq "interface IRateLimiter" "$SRC" --include=*.cs || { echo "ابتدا ماژول security را نصب کنید."; exit 1; }
grep -rq "class NotificationService" "$SRC" --include=*.cs || { echo "ابتدا ماژول notify را نصب کنید."; exit 1; }
grep -rq "tickets.manage" "$SRC" --include=*.cs || { echo "نسخه‌ی ماژول iam قدیمی است (مجوز tickets.manage ندارد)؛ دوباره iam را نصب کنید."; exit 1; }
cp "$HERE/files/SupportModule.cs" "$SRC/Ghestine.Domain/Entities/SupportModule.cs"
sed -i "s/^using Ghestine.Domain.Common;/using $BENS;/" "$SRC/Ghestine.Domain/Entities/SupportModule.cs"
mkdir -p "$SRC/Ghestine.API/Support"; for f in SupportServices SupportControllers; do cp "$HERE/files/$f.cs" "$SRC/Ghestine.API/Support/$f.cs"; sed -i "s/__DBNS__/$DBNS/" "$SRC/Ghestine.API/Support/$f.cs"; done
addset(){ grep -q "DbSet<Ghestine.Domain.Entities.$1>" "$DBF" && return 0
  grep -q "protected override void OnModelCreating" "$DBF" || { echo "OnModelCreating پیدا نشد؛ DbSet ها را دستی اضافه کنید"; exit 1; }
  sed -i "0,/protected override void OnModelCreating/s//public DbSet<Ghestine.Domain.Entities.$1> $2 => Set<Ghestine.Domain.Entities.$1>();\n\n    protected override void OnModelCreating/" "$DBF"; }
addset SupportTicket SupportTickets; addset TicketMessage TicketMessages
for n in SupportTicket TicketMessage; do grep -q "DbSet<Ghestine.Domain.Entities.$n>" "$DBF" || { echo "درج DbSet $n انجام نشد. بکاپ: $B"; exit 1; }; done
grep -q "SupportService" "$PG" || sed -i '0,/var app = builder.Build();/s//builder.Services.AddScoped<Ghestine.API.Support.SupportService>();\n\nvar app = builder.Build();/' "$PG"
grep -q "SupportService" "$PG" || { echo "ثبت سرویس در Program.cs انجام نشد. برگرداندن: cp $B/Program.cs.bak $PG"; exit 1; }
cd "$ROOT"
if dotnet build 2>&1 | tee /tmp/support-build.log | tail -15 | grep -q "Build succeeded"; then echo "ساخت موفق."; else
  echo "خطای build؛ ۱۵ خط آخر را بفرستید. برگرداندن: cp $B/AppDbContext.cs.bak $DBF ; cp $B/Program.cs.bak $PG"; exit 1; fi
cat <<'MSG'

=== مراحل بعد ===
۱) مایگریشن (بعد از بکاپ دیتابیس). ایندکس پیشنهادی: SupportTickets(TenantId,UserId,UpdatedOn) ، SupportTickets(TenantId,Status,SlaDueOn) ، TicketMessages(TicketId,CreatedOn) ، SupportTickets(TenantId,Code) یکتا.
۲) مجوز tickets.manage را به نقش «پشتیبانی» بدهید (نقش‌های پیش‌فرض دوباره seed شوند یا دستی اضافه کنید).
۳) مشتری: /app/tickets ؛ کارشناس: /admin/tickets ؛ API: api/v1/me/tickets و api/v1/admin/tickets.
۴) مهلت پاسخ اول: عادی ۲۴ ساعت، فوری ۴ ساعت (فقط کارشناس می‌تواند فوری کند؛ مشتری همیشه عادی). اعلان پیامکی پاسخ با صف کار (sms.send) قابل اتصال است، به شرط شناختن شماره‌ی کاربر از جدول کاربران.
MSG
