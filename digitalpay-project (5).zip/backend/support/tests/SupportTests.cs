using Xunit;
using Ghestine.Domain.Entities;
using Ghestine.API.Support;
public class SupportTests
{
    [Fact] public void SlaHours() { var t0 = new DateTime(2026, 1, 1, 8, 0, 0, DateTimeKind.Utc); Assert.Equal(t0.AddHours(24), Sla.Due(t0, "Normal")); Assert.Equal(t0.AddHours(4), Sla.Due(t0, "High")); }
    [Fact] public void OverdueOnlyUntilFirstStaffResponse()
    {
        var now = DateTime.UtcNow; var t = new SupportTicket { Status = "Open", SlaDueOn = now.AddMinutes(-1) };
        Assert.True(Sla.Overdue(t, now)); t.FirstResponseOn = now; Assert.False(Sla.Overdue(t, now));
        Assert.False(Sla.Overdue(new SupportTicket { Status = "Closed", SlaDueOn = now.AddDays(-1) }, now));
    }
    [Fact] public void CleanTextStripsControlsAndCaps() { Assert.Equal("a\nb", SupportService.CleanText("a\r\nb\u0007", 100)); Assert.Equal(5, SupportService.CleanText(new string('x', 50), 5).Length); }
}
