using System.Text;
using Xunit;
using Ghestine.API.Iam;
// بردارهای رسمی RFC 6238 (SHA-1، راز ASCII «12345678901234567890»، ۶ رقم)
public class TotpTests
{
    static readonly byte[] Key = Encoding.ASCII.GetBytes("12345678901234567890");
    [Theory]
    [InlineData(59L, "287082")] [InlineData(1111111109L, "081804")] [InlineData(1111111111L, "050471")]
    [InlineData(1234567890L, "005924")] [InlineData(2000000000L, "279037")] [InlineData(20000000000L, "353130")]
    public void MatchesRfc6238(long t, string expected) => Assert.Equal(expected, Totp.Code(Key, t / 30));
    [Fact] public void Base32RoundTrip() { var s = Totp.NewSecret(); Assert.Equal(32, s.Length); Assert.Equal(s, Totp.Base32(Totp.FromBase32(s))); }
    [Fact] public void VerifyAcceptsWindowAndRejectsReplay()
    {
        var sec = Totp.Base32(Key); var now = DateTimeOffset.FromUnixTimeSeconds(1111111109); var step = Totp.StepAt(now);
        var code = Totp.Code(Key, step - 1);                       // یک گام قبل هنوز قابل قبول است
        Assert.Equal(step - 1, Totp.Verify(sec, code, 0, now));
        Assert.Equal(-1, Totp.Verify(sec, code, step - 1, now));    // بازپخش رد می‌شود
        Assert.Equal(-1, Totp.Verify(sec, "000000", 0, now));
        Assert.Equal(-1, Totp.Verify(sec, "12", 0, now));
    }
}
