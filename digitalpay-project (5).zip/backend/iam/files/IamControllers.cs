using System.Security.Claims;
using System.Text.Json;
using Ghestine.Domain.Entities;
using Ghestine.API.Security;
using Ghestine.API.Tenancy;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using __DBNS__;
namespace Ghestine.API.Iam;

static class IamU
{
    public static Guid? Uid(this ControllerBase c) => Guid.TryParse(c.User.FindFirstValue(ClaimTypes.NameIdentifier) ?? c.User.FindFirstValue("sub"), out var g) ? g : null;
    public static string Ip(this ControllerBase c)
    {
        var ra = c.HttpContext.Connection.RemoteIpAddress;
        if (ra != null && System.Net.IPAddress.IsLoopback(ra)) { var xf = c.Request.Headers["X-Real-IP"].FirstOrDefault() ?? c.Request.Headers["X-Forwarded-For"].FirstOrDefault()?.Split(',')[0].Trim(); if (!string.IsNullOrWhiteSpace(xf) && System.Net.IPAddress.TryParse(xf, out var ip)) return ip.ToString(); }
        return ra?.ToString() ?? "unknown";
    }
}

public record CodeIn(string Code);
public record CompleteIn(string Ticket, string Code);
public record RoleIn(string Name, string? Description, List<string>? Permissions);
public record AssignIn(Guid UserId, Guid RoleId);

/// رمز دومرحله‌ای خود کاربر (مدیر یا هر کاربر وارد شده).
[ApiController, Route("api/v1/me/2fa"), Authorize]
public class MyTwoFaController : ControllerBase
{
    private readonly TwoFaService _t; public MyTwoFaController(TwoFaService t) => _t = t;
    [HttpGet] public async Task<IActionResult> Status(CancellationToken ct) { var u = this.Uid(); if (u == null) return Unauthorized(); var x = await _t.Get(this.Tid(), u.Value, ct); return Ok(new TwoFaStatus(x != null, x?.Enabled == true)); }
    [HttpPost("setup")] public async Task<IActionResult> Setup(CancellationToken ct)
    {
        var u = this.Uid(); if (u == null) return Unauthorized(); var (s, e) = await _t.Setup(this.Tid(), u.Value, ct); if (s == null) return Conflict(new { message = e });
        var acct = User.FindFirstValue(ClaimTypes.Name) ?? u.Value.ToString("N")[..8];
        return Ok(new { secret = s, uri = Totp.Uri("DigitalPay", acct, s) });   // فقط یک بار نمایش داده می‌شود
    }
    [HttpPost("enable")] public async Task<IActionResult> Enable(CodeIn i, CancellationToken ct)
    { var u = this.Uid(); if (u == null) return Unauthorized(); var (r, e) = await _t.Enable(this.Tid(), u.Value, i.Code, ct); return r == null ? BadRequest(new { message = e }) : Ok(new { recoveryCodes = r }); }
    [HttpPost("disable")] public async Task<IActionResult> Disable(CodeIn i, CancellationToken ct)
    { var u = this.Uid(); if (u == null) return Unauthorized(); var e = await _t.Disable(this.Tid(), u.Value, i.Code, ct); return e == null ? Ok() : BadRequest(new { message = e }); }
}

/// مرحله‌ی دوم ورود JSON: بلیت + کد → همان بدنه‌ی پاسخ ورود (با توکن).
[ApiController, Route("api/v1/security/2fa"), AllowAnonymous]
public class TwoFaCompleteController : ControllerBase
{
    private readonly TwoFaService _t; private readonly IRateLimiter _rl; public TwoFaCompleteController(TwoFaService t, IRateLimiter rl) { _t = t; _rl = rl; }
    [HttpPost("complete")] public async Task<IActionResult> Complete(CompleteIn i, CancellationToken ct)
    {
        if (!_rl.Hit("2fa:" + this.Ip(), 20, TimeSpan.FromMinutes(15))) return StatusCode(429, new { message = "تلاش زیاد بود؛ کمی بعد دوباره امتحان کنید" });
        var (b, e) = await _t.Complete(i.Ticket ?? "", i.Code ?? "", ct); if (b == null) return Unauthorized(new { message = e });
        return Content(b, "application/json");
    }
}

[ApiController, Route("api/v1/admin/iam"), Authorize(Roles = "Admin,SuperAdmin")]
public class IamAdminController : ControllerBase
{
    private readonly AppDbContext _db; private readonly PermissionService _p;
    public IamAdminController(AppDbContext db, PermissionService p) { _db = db; _p = p; }
    bool Super => User.IsInRole("SuperAdmin");

    [HttpGet("permissions")] public IActionResult Catalog() => Ok(Perms.All.Select(x => new { key = x.Key, label = x.Label }));
    [HttpGet("me")] public async Task<IActionResult> Me(CancellationToken ct)
    {
        var u = this.Uid(); if (u == null) return Unauthorized(); var set = await _p.ForAsync(this.Tid(), u.Value, ct);
        return Ok(new { super = Super, fromRoles = set.OrderBy(x => x).ToArray(), legacyFull = set.Count == 0 && !Super });
    }

    [HttpGet("roles"), RequirePermission("users.manage")]
    public async Task<IActionResult> Roles(CancellationToken ct)
    {
        var tid = this.Tid(); var cnt = await _db.Set<AdminRoleAssignment>().Where(a => a.TenantId == tid).GroupBy(a => a.RoleId).Select(g => new { g.Key, n = g.Count() }).ToListAsync(ct);
        return Ok((await _db.Set<AdminRole>().Where(r => r.TenantId == tid).OrderBy(r => r.Name).ToListAsync(ct)).Select(r => new { r.Id, r.Name, r.Description, r.IsSystem, permissions = JsonSerializer.Deserialize<string[]>(r.PermissionsJson), users = cnt.FirstOrDefault(c => c.Key == r.Id)?.n ?? 0 }));
    }
    string? Fill(AdminRole r, RoleIn i)
    {
        var name = (i.Name ?? "").Trim(); if (name.Length < 2 || name.Length > 80) return "نام نقش ۲ تا ۸۰ نویسه باشد";
        var perms = (i.Permissions ?? new()).Distinct().ToList(); if (perms.Any(k => !Perms.Keys.Contains(k))) return "مجوز ناشناخته";
        if (perms.Contains("users.manage") && !Super) return "فقط مدیر ارشد می‌تواند مجوز مدیریت دسترسی بدهد";
        r.Name = name; r.Description = (i.Description ?? "").Trim(); if (r.Description.Length > 300) r.Description = r.Description[..300]; r.PermissionsJson = JsonSerializer.Serialize(perms); return null;
    }
    [HttpPost("roles"), RequirePermission("users.manage")]
    public async Task<IActionResult> Create(RoleIn i, CancellationToken ct)
    {
        var r = new AdminRole { TenantId = this.Tid() }; var e = Fill(r, i); if (e != null) return BadRequest(new { message = e });
        if (await _db.Set<AdminRole>().AnyAsync(x => x.TenantId == r.TenantId && x.Name == r.Name, ct)) return Conflict(new { message = "این نام قبلاً ثبت شده" });
        _db.Add(r); await _db.SaveChangesAsync(ct); return Ok(new { r.Id });
    }
    [HttpPut("roles/{id:guid}"), RequirePermission("users.manage")]
    public async Task<IActionResult> Update(Guid id, RoleIn i, CancellationToken ct)
    {
        var r = await _db.Set<AdminRole>().FirstOrDefaultAsync(x => x.Id == id && x.TenantId == this.Tid(), ct); if (r == null) return NotFound();
        if (r.PermissionsJson.Contains("users.manage") && !Super) return StatusCode(403, new { message = "فقط مدیر ارشد" });
        var e = Fill(r, i); if (e != null) return BadRequest(new { message = e }); await _db.SaveChangesAsync(ct); return Ok();
    }
    [HttpDelete("roles/{id:guid}"), RequirePermission("users.manage")]
    public async Task<IActionResult> Delete(Guid id, CancellationToken ct)
    {
        var tid = this.Tid(); var r = await _db.Set<AdminRole>().FirstOrDefaultAsync(x => x.Id == id && x.TenantId == tid, ct); if (r == null) return NotFound();
        if (r.IsSystem) return Conflict(new { message = "نقش سیستمی حذف نمی‌شود" });
        if (await _db.Set<AdminRoleAssignment>().AnyAsync(a => a.RoleId == id && a.TenantId == tid, ct)) return Conflict(new { message = "این نقش به کاربرانی داده شده؛ ابتدا برداشته شود" });
        _db.Remove(r); await _db.SaveChangesAsync(ct); return Ok();
    }
    [HttpPost("seed-defaults"), RequirePermission("users.manage")]
    public async Task<IActionResult> Seed(CancellationToken ct)
    {
        var tid = this.Tid(); var have = (await _db.Set<AdminRole>().Where(r => r.TenantId == tid).Select(r => r.Name).ToListAsync(ct)).ToHashSet(); int n = 0;
        foreach (var (name, perms) in Perms.Defaults) if (!have.Contains(name)) { _db.Add(new AdminRole { TenantId = tid, Name = name, IsSystem = true, PermissionsJson = JsonSerializer.Serialize(perms) }); n++; }
        await _db.SaveChangesAsync(ct); return Ok(new { added = n });
    }
    [HttpGet("assignments"), RequirePermission("users.manage")]
    public async Task<IActionResult> Assignments([FromQuery] Guid? userId, CancellationToken ct)
    {
        var tid = this.Tid(); var q = _db.Set<AdminRoleAssignment>().Where(a => a.TenantId == tid); if (userId != null) q = q.Where(a => a.UserId == userId);
        return Ok(await q.OrderByDescending(a => a.AssignedOn).Take(500).Select(a => new { a.Id, a.UserId, a.RoleId, a.AssignedOn, a.AssignedBy }).ToListAsync(ct));
    }
    [HttpPost("assign"), RequirePermission("users.manage")]
    public async Task<IActionResult> Assign(AssignIn i, CancellationToken ct)
    {
        var tid = this.Tid(); var me = this.Uid();
        if (i.UserId == me && !Super) return StatusCode(403, new { message = "تخصیص نقش به خودتان مجاز نیست" });
        var r = await _db.Set<AdminRole>().FirstOrDefaultAsync(x => x.Id == i.RoleId && x.TenantId == tid, ct); if (r == null) return NotFound(new { message = "نقش پیدا نشد" });
        if (r.PermissionsJson.Contains("users.manage") && !Super) return StatusCode(403, new { message = "فقط مدیر ارشد" });
        if (await _db.Set<AdminRoleAssignment>().AnyAsync(a => a.TenantId == tid && a.UserId == i.UserId && a.RoleId == i.RoleId, ct)) return Conflict(new { message = "قبلاً داده شده" });
        _db.Add(new AdminRoleAssignment { TenantId = tid, UserId = i.UserId, RoleId = i.RoleId, AssignedBy = me }); await _db.SaveChangesAsync(ct); return Ok();
    }
    [HttpDelete("assignments/{id:guid}"), RequirePermission("users.manage")]
    public async Task<IActionResult> Unassign(Guid id, CancellationToken ct)
    {
        var a = await _db.Set<AdminRoleAssignment>().FirstOrDefaultAsync(x => x.Id == id && x.TenantId == this.Tid(), ct); if (a == null) return NotFound();
        if (a.UserId == this.Uid() && !Super) return StatusCode(403, new { message = "برداشتن نقش از خودتان مجاز نیست" });
        _db.Remove(a); await _db.SaveChangesAsync(ct); return Ok();
    }
}
