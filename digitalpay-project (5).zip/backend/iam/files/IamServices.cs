using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Ghestine.Domain.Entities;
using Ghestine.API.Core;
using Ghestine.API.Security;
using Ghestine.API.Tenancy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;
using __DBNS__;
namespace Ghestine.API.Iam;

/// فهرست ثابت مجوزها. کلیدها نباید بعد از انتشار تغییر نام بدهند.
public static class Perms
{
    public static readonly (string Key, string Label)[] All =
    {
        ("customers.view", "مشاهده‌ی مشتریان"), ("customers.manage", "ویرایش مشتریان"),
        ("loans.view", "مشاهده‌ی وام‌ها"), ("loans.manage", "تعریف و ویرایش وام"),
        ("installments.manage", "مدیریت اقساط و پرداخت‌ها"), ("deposits.review", "بررسی اعلام واریز"),
        ("documents.review", "بررسی مدارک"), ("tickets.manage", "پاسخ به تیکت‌های پشتیبانی"), ("contracts.manage", "ساخت و ویرایش قالب قرارداد"), ("contracts.approve", "تأیید قالب و قرارداد"),
        ("ledger.view", "مشاهده‌ی دفتر کل"), ("ledger.post", "ثبت سند"), ("audit.view", "مشاهده‌ی حسابرسی"),
        ("backups.manage", "پشتیبان‌گیری"), ("settings.manage", "تنظیمات سامانه"), ("users.manage", "مدیریت نقش‌ها و دسترسی‌ها"),
    };
    public static readonly HashSet<string> Keys = All.Select(x => x.Key).ToHashSet();
    public static readonly Dictionary<string, string[]> Defaults = new()
    {
        ["مالی"] = new[] { "installments.manage", "deposits.review", "ledger.view", "ledger.post", "customers.view", "loans.view" },
        ["پشتیبانی"] = new[] { "customers.view", "loans.view", "documents.review", "tickets.manage" },
        ["مدیر قرارداد"] = new[] { "contracts.manage", "loans.view", "documents.review" },
        ["تأییدکننده‌ی قرارداد"] = new[] { "contracts.approve", "loans.view" },
        ["حسابرس"] = new[] { "audit.view", "ledger.view", "loans.view", "customers.view" },
    };
}

public class PermissionService
{
    private readonly AppDbContext _db; private readonly IConfiguration _cfg;
    public PermissionService(AppDbContext db, IConfiguration cfg) { _db = db; _cfg = cfg; }
    public async Task<HashSet<string>> ForAsync(Guid tenant, Guid user, CancellationToken ct)
    {
        var ids = await _db.Set<AdminRoleAssignment>().Where(a => a.TenantId == tenant && a.UserId == user).Select(a => a.RoleId).ToListAsync(ct);
        var set = new HashSet<string>();
        foreach (var js in await _db.Set<AdminRole>().Where(r => r.TenantId == tenant && ids.Contains(r.Id)).Select(r => r.PermissionsJson).ToListAsync(ct))
            try { foreach (var k in JsonSerializer.Deserialize<string[]>(js) ?? Array.Empty<string>()) if (Perms.Keys.Contains(k)) set.Add(k); } catch { }
        return set;
    }
    /// SuperAdmin همیشه مجاز است. ادمین قدیمی بدون هیچ نقش، تا وقتی Iam:LegacyAdminFullAccess=true باشد (پیش‌فرض) دسترسی کامل دارد
    /// به‌جز users.manage؛ بعد از تخصیص نقش‌ها این گزینه را false کنید.
    public async Task<bool> HasAsync(ClaimsPrincipal u, Guid tenant, string perm, CancellationToken ct)
    {
        if (u.IsInRole("SuperAdmin")) return true;
        if (!u.IsInRole("Admin")) return false;
        if (!Guid.TryParse(u.FindFirstValue(ClaimTypes.NameIdentifier) ?? u.FindFirstValue("sub"), out var uid)) return false;
        var mine = await ForAsync(tenant, uid, ct);
        if (mine.Count > 0) return mine.Contains(perm);
        return perm != "users.manage" && (_cfg["Iam:LegacyAdminFullAccess"] ?? "true") != "false";
    }
}

[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
public class RequirePermissionAttribute : TypeFilterAttribute
{
    public RequirePermissionAttribute(string perm) : base(typeof(PermFilter)) { Arguments = new object[] { perm }; }
}
public class PermFilter : IAsyncActionFilter
{
    private readonly PermissionService _p; private readonly string _perm;
    public PermFilter(PermissionService p, string perm) { _p = p; _perm = perm; }
    public async Task OnActionExecutionAsync(ActionExecutingContext ctx, ActionExecutionDelegate next)
    {
        var tid = (ctx.HttpContext.Items["tenant"] as TenantInfo)?.Id ?? Guid.Empty;
        if (!await _p.HasAsync(ctx.HttpContext.User, tid, _perm, ctx.HttpContext.RequestAborted)) { ctx.Result = new ObjectResult(new { message = "دسترسی این کار برای شما فعال نیست" }) { StatusCode = 403 }; return; }
        await next();
    }
}

/// TOTP طبق RFC 6238 (SHA-1، ۶ رقم، ۳۰ ثانیه) سازگار با Google Authenticator و مشابه.
public static class Totp
{
    const string B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
    public static string NewSecret() { var b = RandomNumberGenerator.GetBytes(20); return Base32(b); }
    public static string Base32(byte[] d) { var sb = new StringBuilder(); int buf = 0, bits = 0; foreach (var x in d) { buf = (buf << 8) | x; bits += 8; while (bits >= 5) { sb.Append(B32[(buf >> (bits - 5)) & 31]); bits -= 5; } } if (bits > 0) sb.Append(B32[(buf << (5 - bits)) & 31]); return sb.ToString(); }
    public static byte[] FromBase32(string s) { var o = new List<byte>(); int buf = 0, bits = 0; foreach (var ch in s.Trim().Replace(" ", "").ToUpperInvariant()) { var i = B32.IndexOf(ch); if (i < 0) continue; buf = (buf << 5) | i; bits += 5; if (bits >= 8) { o.Add((byte)((buf >> (bits - 8)) & 255)); bits -= 8; } } return o.ToArray(); }
    public static string Code(byte[] key, long step, int digits = 6)
    {
        var c = BitConverter.GetBytes(step); if (BitConverter.IsLittleEndian) Array.Reverse(c);
        var h = HMACSHA1.HashData(key, c); var o = h[^1] & 15;
        var n = ((h[o] & 0x7f) << 24) | (h[o + 1] << 16) | (h[o + 2] << 8) | h[o + 3];
        return (n % (int)Math.Pow(10, digits)).ToString().PadLeft(digits, '0');
    }
    public static long StepAt(DateTimeOffset t) => t.ToUnixTimeSeconds() / 30;
    /// پنجره‌ی ±۱ گام؛ گام تطبیق‌یافته را برمی‌گرداند یا -1. گام باید از lastStep بزرگ‌تر باشد (ضد بازپخش).
    public static long Verify(string secretB32, string? code, long lastStep, DateTimeOffset now)
    {
        var c = new string((code ?? "").Where(char.IsDigit).ToArray()); if (c.Length != 6) return -1;
        var key = FromBase32(secretB32); long hit = -1; var cur = StepAt(now);
        for (long s = cur - 1; s <= cur + 1; s++)
            if (s > lastStep && CryptographicOperations.FixedTimeEquals(Encoding.ASCII.GetBytes(Code(key, s)), Encoding.ASCII.GetBytes(c))) hit = s;
        return hit;
    }
    public static string Uri(string issuer, string account, string secret) => $"otpauth://totp/{System.Uri.EscapeDataString(issuer)}:{System.Uri.EscapeDataString(account)}?secret={secret}&issuer={System.Uri.EscapeDataString(issuer)}&algorithm=SHA1&digits=6&period=30";
}

public record TwoFaStatus(bool Enrolled, bool Enabled);

public class TwoFaService
{
    private readonly AppDbContext _db; private readonly ICardCrypto _cr; private readonly IConfiguration _cfg;
    public TwoFaService(AppDbContext db, ICardCrypto cr, IConfiguration cfg) { _db = db; _cr = cr; _cfg = cfg; }
    string Pepper => Pep.Get(_cfg);
    string RH(string code) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(Pepper + "|rc|" + code.Trim().ToUpperInvariant().Replace("-", "")))).ToLowerInvariant();
    public Task<AdminTotp?> Get(Guid tid, Guid uid, CancellationToken ct) => _db.Set<AdminTotp>().FirstOrDefaultAsync(x => x.TenantId == tid && x.UserId == uid, ct);
    public async Task<bool> IsEnabled(Guid tid, Guid uid, CancellationToken ct) => (await Get(tid, uid, ct))?.Enabled == true;

    /// راز جدید می‌سازد (فعال نیست تا کد اول تأیید شود). فقط اگر 2FA هنوز فعال نشده.
    public async Task<(string? Secret, string? Err)> Setup(Guid tid, Guid uid, CancellationToken ct)
    {
        var t = await Get(tid, uid, ct); if (t?.Enabled == true) return (null, "رمز دومرحله‌ای قبلاً فعال شده است. برای تنظیم دوباره ابتدا غیرفعال کنید.");
        var s = Totp.NewSecret(); if (t == null) { t = new AdminTotp { TenantId = tid, UserId = uid }; _db.Add(t); }
        t.SecretEnc = _cr.Protect(s); t.Enabled = false; t.LastStep = 0; t.RecoveryHashesJson = "[]"; t.FailedCount = 0; t.LockedUntil = null;
        await _db.SaveChangesAsync(ct); return (s, null);
    }
    public async Task<(List<string>? Recovery, string? Err)> Enable(Guid tid, Guid uid, string code, CancellationToken ct)
    {
        var t = await Get(tid, uid, ct); if (t == null || t.Enabled) return (null, "ابتدا راه‌اندازی را شروع کنید.");
        var step = Totp.Verify(_cr.Unprotect(t.SecretEnc), code, t.LastStep, DateTimeOffset.UtcNow); if (step < 0) return (null, "کد نادرست است.");
        var rec = Enumerable.Range(0, 8).Select(_ => { var b = RandomNumberGenerator.GetBytes(5); var h = Convert.ToHexString(b); return h[..5] + "-" + h[5..]; }).ToList();
        t.RecoveryHashesJson = JsonSerializer.Serialize(rec.Select(RH)); t.Enabled = true; t.EnabledOn = DateTime.UtcNow; t.LastStep = step; await _db.SaveChangesAsync(ct); return (rec, null);
    }
    /// کد TOTP یا یکی از کدهای بازیابی. بعد از ۵ خطا ۱۵ دقیقه قفل می‌شود.
    public async Task<(bool Ok, string? Err)> Check(Guid tid, Guid uid, string code, CancellationToken ct)
    {
        var t = await Get(tid, uid, ct); if (t == null || !t.Enabled) return (true, null);
        if (t.LockedUntil > DateTime.UtcNow) return (false, "به‌دلیل تلاش‌های ناموفق، چند دقیقه بعد دوباره امتحان کنید.");
        var step = Totp.Verify(_cr.Unprotect(t.SecretEnc), code, t.LastStep, DateTimeOffset.UtcNow);
        if (step >= 0) { t.LastStep = step; t.FailedCount = 0; await _db.SaveChangesAsync(ct); return (true, null); }
        var list = JsonSerializer.Deserialize<List<string>>(t.RecoveryHashesJson) ?? new(); var h = RH(code ?? "");
        if ((code ?? "").Length >= 10 && list.Remove(h)) { t.RecoveryHashesJson = JsonSerializer.Serialize(list); t.FailedCount = 0; await _db.SaveChangesAsync(ct); return (true, null); }
        t.FailedCount++; if (t.FailedCount >= 5) { t.LockedUntil = DateTime.UtcNow.AddMinutes(15); t.FailedCount = 0; }
        await _db.SaveChangesAsync(ct); return (false, "کد نادرست است.");
    }
    public async Task<string?> Disable(Guid tid, Guid uid, string code, CancellationToken ct)
    {
        var (ok, err) = await Check(tid, uid, code, ct); if (!ok) return err;
        var t = await Get(tid, uid, ct); if (t != null) { _db.Remove(t); await _db.SaveChangesAsync(ct); } return null;
    }

    // ---- بلیت مرحله‌ی دوم ورود: بدنه‌ی پاسخ ورود، رمزنگاری‌شده و دارای انقضا (۵ دقیقه) ----
    public static (Guid Uid, Guid Tid, string? Role)? ReadToken(string tokenJson)
    {
        try
        {
            string? tok = Find(JsonSerializer.Deserialize<JsonElement>(tokenJson)); if (tok == null) return null;
            var jwt = new System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler().ReadJwtToken(tok);
            var sub = jwt.Claims.FirstOrDefault(c => c.Type is "sub" or ClaimTypes.NameIdentifier)?.Value; if (!Guid.TryParse(sub, out var uid)) return null;
            var rl = jwt.Claims.Where(c => c.Type is "role" or ClaimTypes.Role).Select(c => c.Value).ToList(); var role = rl.Contains("SuperAdmin") ? "SuperAdmin" : rl.Contains("Admin") ? "Admin" : rl.FirstOrDefault();
            var t = jwt.Claims.FirstOrDefault(c => c.Type is "tenant" or "tid" or "tenantId")?.Value; Guid.TryParse(t, out var tid);
            return (uid, tid, role);
        }
        catch { return null; }
    }
    public static string? Find(JsonElement j)
    {
        if (j.ValueKind != JsonValueKind.Object) return null;
        foreach (var n in new[] { "token", "accessToken", "access_token", "jwt" }) if (j.TryGetProperty(n, out var v) && v.ValueKind == JsonValueKind.String) return v.GetString();
        return j.TryGetProperty("data", out var d) ? Find(d) : null;
    }
    /// اگر کاربر مدیر باشد و 2FA فعال داشته باشد بلیت می‌دهد، وگرنه null (یعنی ورود عادی ادامه یابد).
    public async Task<string?> Challenge(string tokenJson, Guid requestTenant, CancellationToken ct)
    {
        var r = ReadToken(tokenJson); if (r == null) return null;
        if (r.Value.Role is not ("Admin" or "SuperAdmin")) return null;
        var tid = r.Value.Tid != Guid.Empty ? r.Value.Tid : requestTenant;
        if (!await IsEnabled(tid, r.Value.Uid, ct) && !await IsEnabled(requestTenant, r.Value.Uid, ct)) return null;
        return _cr.Protect(JsonSerializer.Serialize(new { b = tokenJson, u = r.Value.Uid, t = tid == Guid.Empty ? requestTenant : tid, e = DateTimeOffset.UtcNow.AddMinutes(5).ToUnixTimeSeconds() }));
    }
    public async Task<(string? Body, string? Err)> Complete(string ticket, string code, CancellationToken ct)
    {
        try
        {
            var j = JsonSerializer.Deserialize<JsonElement>(_cr.Unprotect(ticket));
            if (j.GetProperty("e").GetInt64() < DateTimeOffset.UtcNow.ToUnixTimeSeconds()) return (null, "زمان تأیید تمام شد؛ دوباره وارد شوید.");
            var (ok, err) = await Check(j.GetProperty("t").GetGuid(), j.GetProperty("u").GetGuid(), code, ct);
            return ok ? (j.GetProperty("b").GetString(), null) : (null, err);
        }
        catch { return (null, "بلیت نامعتبر است؛ دوباره وارد شوید."); }
    }
}

/// ورود JSON پروژه (/api/v1/security/login): اگر مدیر 2FA فعال دارد، به‌جای توکن بلیت می‌دهد (HTTP 202).
public class TwoFaLoginFilter : IAsyncResultFilter
{
    private readonly TwoFaService _t; public TwoFaLoginFilter(TwoFaService t) => _t = t;
    public async Task OnResultExecutionAsync(ResultExecutingContext ctx, ResultExecutionDelegate next)
    {
        if (ctx.ActionDescriptor is Microsoft.AspNetCore.Mvc.Controllers.ControllerActionDescriptor d && d.ControllerName == "Security" && d.ActionName == "Login" && ctx.Result is OkObjectResult ok && ok.Value != null)
        {
            var body = JsonSerializer.Serialize(ok.Value);
            var tid = (ctx.HttpContext.Items["tenant"] as TenantInfo)?.Id ?? Guid.Empty;
            var ticket = await _t.Challenge(body, tid, ctx.HttpContext.RequestAborted);
            if (ticket != null) ctx.Result = new ObjectResult(new { needs2fa = true, ticket, message = "کد برنامه‌ی احراز هویت را وارد کنید" }) { StatusCode = 202 };
        }
        await next();
    }
}
