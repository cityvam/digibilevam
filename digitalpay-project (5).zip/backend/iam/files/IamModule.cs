using System.ComponentModel.DataAnnotations;
using Ghestine.Domain.Common;
namespace Ghestine.Domain.Entities;

/// نقش مدیریتی ریز (مجوزهای قابل ترکیب). نقش‌های سیستمی قابل حذف نیستند.
public class AdminRole : BaseEntity
{
    public Guid TenantId { get; set; }
    [MaxLength(80)] public string Name { get; set; } = string.Empty;
    [MaxLength(300)] public string Description { get; set; } = string.Empty;
    public string PermissionsJson { get; set; } = "[]";   // ["loans.manage", ...]
    public bool IsSystem { get; set; }
    public DateTime CreatedOn { get; set; } = DateTime.UtcNow;
}

public class AdminRoleAssignment : BaseEntity
{
    public Guid TenantId { get; set; }
    public Guid UserId { get; set; }
    public Guid RoleId { get; set; }
    public Guid? AssignedBy { get; set; }
    public DateTime AssignedOn { get; set; } = DateTime.UtcNow;
}

/// کلید TOTP هر کاربر. راز رمزنگاری‌شده ذخیره می‌شود؛ کدهای بازیابی فقط به‌صورت هش.
public class AdminTotp : BaseEntity
{
    public Guid TenantId { get; set; }
    public Guid UserId { get; set; }
    public string SecretEnc { get; set; } = string.Empty;
    public bool Enabled { get; set; }
    public DateTime? EnabledOn { get; set; }
    public long LastStep { get; set; }                     // جلوگیری از استفاده‌ی دوباره‌ی همان کد
    public string RecoveryHashesJson { get; set; } = "[]";
    public int FailedCount { get; set; }
    public DateTime? LockedUntil { get; set; }
}
