#!/bin/bash
# نصب دسترسی ریز (RBAC) و رمز دومرحله‌ای (TOTP) برای مدیران
set -e
ROOT="${1:-/home/ghestine/domains/ghestine.ir/Ghestine}"
HERE="$(cd "$(dirname "$0")" && pwd)"; SRC="$ROOT/src"
[ -d "$SRC" ] || { echo "پوشه src پیدا نشد: $SRC"; exit 1; }
B="$ROOT/.iam-backup-$(date +%Y%m%d%H%M%S)"; mkdir -p "$B"
DBF=$(grep -rl "class AppDbContext" "$SRC" --include=*.cs | head -1); [ -n "$DBF" ] || { echo "AppDbContext پیدا نشد"; exit 1; }
PG="$SRC/Ghestine.API/Program.cs"; cp "$PG" "$B/Program.cs.bak"; cp "$DBF" "$B/AppDbContext.cs.bak"; echo "بکاپ: $B"
BE=$(grep -rl "class BaseEntity" "$SRC" --include=*.cs | head -1); [ -n "$BE" ] || { echo "کلاس BaseEntity پیدا نشد."; exit 1; }
grep -q "Guid Id" "$BE" || { echo "BaseEntity کلید Guid ندارد ($BE)."; exit 1; }
BENS=$(grep -h "^namespace" "$BE" | head -1 | sed 's/namespace //; s/;//; s/\r//')
DBNS=$(grep -h "^namespace" "$DBF" | head -1 | sed 's/namespace //; s/;//; s/\r//')
grep -rq "class TenantMiddleware" "$SRC" --include=*.cs || { echo "ابتدا ماژول tenancy را نصب کنید."; exit 1; }
grep -rq "interface ICardCrypto" "$SRC" --include=*.cs || { echo "ابتدا ماژول core را نصب کنید (ICardCrypto)."; exit 1; }
grep -rq "class SecurityController" "$SRC" --include=*.cs || { echo "ابتدا ماژول security را نصب کنید."; exit 1; }
cp "$HERE/files/IamModule.cs" "$SRC/Ghestine.Domain/Entities/IamModule.cs"
sed -i "s/^using Ghestine.Domain.Common;/using $BENS;/" "$SRC/Ghestine.Domain/Entities/IamModule.cs"
mkdir -p "$SRC/Ghestine.API/Iam"; for f in IamServices IamControllers; do cp "$HERE/files/$f.cs" "$SRC/Ghestine.API/Iam/$f.cs"; sed -i "s/__DBNS__/$DBNS/" "$SRC/Ghestine.API/Iam/$f.cs"; done
addset(){ grep -q "DbSet<Ghestine.Domain.Entities.$1>" "$DBF" && return 0
  grep -q "protected override void OnModelCreating" "$DBF" || { echo "OnModelCreating پیدا نشد؛ DbSet ها را دستی اضافه کنید"; exit 1; }
  sed -i "0,/protected override void OnModelCreating/s//public DbSet<Ghestine.Domain.Entities.$1> $2 => Set<Ghestine.Domain.Entities.$1>();\n\n    protected override void OnModelCreating/" "$DBF"; }
addset AdminRole AdminRoles; addset AdminRoleAssignment AdminRoleAssignments; addset AdminTotp AdminTotps
for n in AdminRole AdminRoleAssignment AdminTotp; do grep -q "DbSet<Ghestine.Domain.Entities.$n>" "$DBF" || { echo "درج DbSet $n انجام نشد. بکاپ: $B"; exit 1; }; done
if ! grep -q "TwoFaLoginFilter" "$PG"; then
  sed -i '0,/var app = builder.Build();/s//builder.Services.AddScoped<Ghestine.API.Iam.PermissionService>();\nbuilder.Services.AddScoped<Ghestine.API.Iam.TwoFaService>();\nbuilder.Services.AddScoped<Ghestine.API.Iam.TwoFaLoginFilter>();\nbuilder.Services.Configure<Microsoft.AspNetCore.Mvc.MvcOptions>(o => o.Filters.AddService<Ghestine.API.Iam.TwoFaLoginFilter>());\n\nvar app = builder.Build();/' "$PG"
fi
grep -q "TwoFaLoginFilter" "$PG" || { echo "ثبت سرویس‌ها در Program.cs انجام نشد. برگرداندن: cp $B/Program.cs.bak $PG"; exit 1; }
cd "$ROOT"
if dotnet build 2>&1 | tee /tmp/iam-build.log | tail -15 | grep -q "Build succeeded"; then echo "ساخت موفق."; else
  echo "خطای build؛ ۱۵ خط آخر را بفرستید. برگرداندن: cp $B/AppDbContext.cs.bak $DBF ; cp $B/Program.cs.bak $PG"; exit 1; fi
cat <<'MSG'

=== مراحل بعد ===
۱) مایگریشن (بعد از بکاپ دیتابیس). ایندکس یکتای پیشنهادی: AdminTotps(TenantId,UserId) ، AdminRoleAssignments(TenantId,UserId,RoleId) ، AdminRoles(TenantId,Name).
۲) نقش‌های پیش‌فرض: POST /api/v1/admin/iam/seed-defaults (مالی، پشتیبانی، مدیر قرارداد، تأییدکننده، حسابرس) یا از /admin/roles.
۳) تا وقتی به مدیری نقش نداده‌اید، دسترسی کامل (به‌جز مدیریت نقش‌ها) دارد. بعد از تخصیص نقش‌ها در appsettings بگذارید:  "Iam": { "LegacyAdminFullAccess": false }
۴) رمز دومرحله‌ای: هر مدیر از /app/security فعال می‌کند. بعد از فعال‌سازی، ورود JSON هم به‌جای توکن HTTP 202 با «ticket» می‌دهد؛ صفحه‌ی login-v2.html (و frontend/login.html) از قبل کد را می‌گیرد و به /api/v1/security/2fa/complete می‌فرستد.
۵) مجوزها به‌صورت [RequirePermission("loans.manage")] روی کنترلرها گذاشته می‌شوند؛ روی کنترلرهای قدیمی خودکار گذاشته نشده تا چیزی خراب نشود (فهرست پیشنهادی در README).
۶) تست: backend/iam/tests/TotpTests.cs (بردارهای RFC 6238) را در پروژه‌ی تست xunit بگذارید.
MSG
