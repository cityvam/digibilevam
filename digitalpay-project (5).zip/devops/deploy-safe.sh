#!/bin/bash
# استقرار امن با بکاپ، health check و برگشت خودکار.   استفاده: bash deploy-safe.sh [staging|prod]
# پیش‌نیاز: همان deploy.sh فعلی شما (publish + restart). این اسکریپت دورش را می‌پیچد.
set -u
ENVN="${1:-prod}"; APP="${APP_DIR:-/home/ghestine/domains/ghestine.ir/Ghestine}"; PUB="${PUB_DIR:-/home/ghestine/publish}"
SVC="${SERVICE:-ghestine.service}"; PORT="${PORT:-5200}"; KEEP=5; STAMP=$(date +%Y%m%d-%H%M%S)
[ "$ENVN" = staging ] && { SVC="${SERVICE:-ghestine-staging.service}"; PORT="${PORT:-5201}"; PUB="${PUB_DIR:-/home/ghestine/publish-staging}"; }
BK="$(dirname "$PUB")/releases/$ENVN-$STAMP"; mkdir -p "$(dirname "$BK")"
echo "۱) بکاپ نسخه‌ی فعلی → $BK"; [ -d "$PUB" ] && cp -a "$PUB" "$BK" || echo "(نسخه‌ی قبلی نبود)"
echo "۲) ساخت و انتشار"; cd "$APP" && dotnet publish src/Ghestine.API -c Release -o "$PUB.new" || { echo "خطای publish؛ چیزی تغییر نکرد."; rm -rf "$PUB.new"; exit 1; }
echo "۳) جایگزینی و راه‌اندازی"; systemctl stop "$SVC"; rm -rf "$PUB.old"; [ -d "$PUB" ] && mv "$PUB" "$PUB.old"; mv "$PUB.new" "$PUB"; systemctl start "$SVC"
echo "۴) بررسی سلامت (حداکثر ۶۰ ثانیه)"
for i in $(seq 1 30); do sleep 2; c=$(curl -s -o /dev/null -w "%{http_code}" "http://127.0.0.1:$PORT/api/v1/health"); [ "$c" = 200 ] && { echo "سالم (۲۰۰). استقرار موفق."; ls -1dt "$(dirname "$BK")"/$ENVN-* 2>/dev/null | tail -n +$((KEEP+1)) | xargs -r rm -rf; rm -rf "$PUB.old"; exit 0; }; done
echo "ناموفق؛ برگشت به نسخه‌ی قبلی…"; systemctl stop "$SVC"; rm -rf "$PUB"; [ -d "$PUB.old" ] && mv "$PUB.old" "$PUB"; systemctl start "$SVC"; sleep 4
c=$(curl -s -o /dev/null -w "%{http_code}" "http://127.0.0.1:$PORT/api/v1/health"); echo "پس از برگشت: HTTP $c"; echo "لاگ: journalctl -u $SVC -n 80 --no-pager"; exit 2
