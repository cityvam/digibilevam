#!/bin/bash
# بکاپ رمزنگاری‌شده‌ی خارج از سرور با rclone (S3 سازگار، SFTP، Backblaze، …).   اجرا با cron روزانه، با کاربر سرویس.
# یک بار: apt install rclone ; rclone config  (ریموت مثلاً به نام offsite) ؛ سپس ریموت رمزنگاری‌شده بسازید (rclone config → type: crypt → remote: offsite:digitalpay)
# متغیرها در /etc/ghestine/backup.env (chmod 600):  RCLONE_REMOTE=offsite-crypt:  LOCAL_BACKUPS=/home/ghestine/backups  KEEP_DAYS=30
set -euo pipefail
[ -f /etc/ghestine/backup.env ] && . /etc/ghestine/backup.env
: "${RCLONE_REMOTE:?RCLONE_REMOTE تنظیم نشده}"; : "${LOCAL_BACKUPS:=/home/ghestine/backups}"; : "${KEEP_DAYS:=30}"
LOG=/var/log/digitalpay/offsite-backup.log; mkdir -p "$(dirname "$LOG")" 2>/dev/null || LOG=/tmp/offsite-backup.log
exec >>"$LOG" 2>&1; echo "== $(date -Is) شروع"
[ -d "$LOCAL_BACKUPS" ] || { echo "پوشه‌ی بکاپ محلی نیست: $LOCAL_BACKUPS"; exit 1; }
N=$(find "$LOCAL_BACKUPS" -type f -mtime -2 | wc -l); [ "$N" -gt 0 ] || { echo "هشدار: در ۲ روز اخیر بکاپ محلی تازه نیست؛ ارسال انجام نشد."; exit 1; }
rclone copy "$LOCAL_BACKUPS" "$RCLONE_REMOTE$(hostname)" --min-age 1m --transfers 2 --checksum --max-age "${KEEP_DAYS}d"
rclone delete "$RCLONE_REMOTE$(hostname)" --min-age "${KEEP_DAYS}d"
# اعتبارسنجی: چند فایل تصادفی دوباره دانلود و مقایسه می‌شود
rclone check "$LOCAL_BACKUPS" "$RCLONE_REMOTE$(hostname)" --one-way --max-age 3d --download && echo "بررسی تطابق موفق" || { echo "خطا: تطابق بکاپ تأیید نشد"; exit 2; }
echo "== پایان موفق"
# cron:  17 3 * * *  /home/ghestine/devops/offsite-backup.sh
